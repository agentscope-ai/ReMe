---
description: Records the user's newly acquired passion for musical theater sparked
  by the 2019 Cats film, ongoing consumption of the In the Heights soundtrack, and
  concrete volunteer activities including a pending usher application and outreach
  for the summer 2023 Kinky Boots production. Details comprehensive strategies and
  ticketing data (pricing, locations, apps) for securing Hadestown Broadway tickets,
  while preserving a categorized catalog of specific musical theater recommendations
  provided as part of the advisory session.
name: musical-theater-interest-and-volunteering
session_id: 4445fe6c
source_conversation: '[[session/dialog/4445fe6c.jsonl]]'
---

## Origins of Musical Theater Interest [[session/dialog/4445fe6c.jsonl#L5]]
- As of 2023-05-17, the user identifies a passion for musical theater originating from watching the 2019 film adaptation of Cats hosted on Amazon Prime.

## Active Musical Listening Habits [[session/dialog/4445fe6c.jsonl#L3]]
- On 2023-05-17, the user states continuous listening habits centered on the original cast recording of In the Heights.

## Broadway Acquisition Strategy: Hadestown [[session/dialog/4445fe6c.jsonl#L3-L6]]
### Official Channels & Pricing Mechanisms
- Authorized purchasing platforms identified for Broadway access include Telecharge, Ticketmaster, and the dedicated website hadestown.com/tickets [[session/dialog/4445fe6c.jsonl#L4]].
- Supplementary reservation ecosystems involve third-party lottery applications such as TodayTix and Lucky Seat, alongside secondary reseller platforms like StubHub and Vivid Seats [[session/dialog/4445fe6c.jsonl#L4]].
- The physical venue hosting Hadestown is established as the Walter Kerr Theatre, geographically located at 219 W 48th St within New York City [[session/dialog/4445fe6c.jsonl#L4]].
- Specific ticket pricing structures include a Digital Lottery yielding $30 admission passes and Day-Of Rush Tickets also priced at $30, accessible starting at 10:00 AM at the venue box office [[session/dialog/4445fe6c.jsonl#L4]].

### Temporal Availability Optimization
- Strategic approaches to improve admission probability emphasize selecting weekday performances over weekend slots to exploit availability gaps [[session/dialog/4445fe6c.jsonl#L5-L6]].
- Further optimizing factors include targeting matinee showings and adjusting schedules to accommodate winter seasonal fluctuations between December and February [[session/dialog/4445fe6c.jsonl#L6]].

## Local Theater Volunteer Operations Plan [[session/dialog/4445fe6c.jsonl#L7-L11]]
- As of 2023-05-17, the user submitted a formal application to serve as an usher at an unidentified local theater and awaits confirmation [[session/dialog/4445fe6c.jsonl#L9]].
- Operational aspirations encompass expanding beyond front-of-house duties into backstage sectors such as set construction, scenic painting, and costume wardrobe management [[session/dialog/4445fe6c.jsonl#L10]].
- Direct engagement protocols are underway to facilitate behind-the-scenes support for the summer 2023 staging of Kinky Boots [[session/dialog/4445fe6c.jsonl#L11]].
- Admission commitments verified include purchased tickets for the specific Kinky Boots performance dated July 15, 2023 [[session/dialog/4445fe6c.jsonl#L11]].

## Reference Catalog of Musical Theater Recommendations [[session/dialog/4445fe6c.jsonl#L2]]
- Classic Musicals include West Side Story (1957), The Sound of Music (1959), and Chicago (1975) [[session/dialog/4445fe6c.jsonl#L2]].
- Modern Musicals include Hamilton (2015), Dear Evan Hansen (2015), and The Book of Mormon (2011) [[session/dialog/4445fe6c.jsonl#L2]].
- Jukebox Musicals include Mamma Mia! (1999), Jersey Boys (2005), and On Your Feet! (2015) [[session/dialog/4445fe6c.jsonl#L2]].
- Dark and Edgy Productions include Sweeney Todd: The Demon Barber of Fleet Street (1979), Les Misérables (1980), and Spring Awakening (2006) [[session/dialog/4445fe6c.jsonl#L2]].
- Additional Featured Titles include Hadestown (2019), The Band's Visit (2017), and In the Heights (2008) [[session/dialog/4445fe6c.jsonl#L2]].
