---
description: Comprehensive recommendations for dance workout playlists on Spotify,
  divided into general, hip hop, and R&B-focused categories along with featured artists.
  Covers highly-rated YouTube channels for hip hop and jazz dance tutorials, including
  associated dance studios and programs. Details the user's current home dance practice
  environment and frequency, identifies skill targets (pirouettes and jazz turns),
  and outlines technical strategies for improvement. Also documents the plan to record
  practice sessions via smartphone tripod for technique review and establishes a strategy
  for using a physical dance journal to track progress and set goals.
name: dance-workout-playlists-tutorials-journaling
session_id: a126eeab_3
source_conversation: '[[session/dialog/a126eeab_3.jsonl]]'
---

## Personal Dance Practice Context
- On 2023-01-13, the user expressed interest in hip hop dance after experiencing it for the first time at a workshop approximately one month prior [[session/dialog/a126eeab_3.jsonl#L1-L1]].
- The user maintains a mini dance studio in the living room equipped with a mirror and a Bluetooth speaker [[session/dialog/a126eeab_3.jsonl#L7-L7]].
- The user practices dance routines at home to music playlists for roughly 30 minutes, two to three times per week [[session/dialog/a126eeab_3.jsonl#L7-L7]].
- Skill focus centers on perfecting pirouettes and jazz turns, which remain challenging [[session/dialog/a126eeab_3.jsonl#L7-L7]].
- The user plans to acquire a camera or smartphone tripod to capture dance videos for technique analysis from an external viewpoint [[session/dialog/a126eeab_3.jsonl#L9-L9]].
- The user intends to begin a physical dance journal to log progress, steps requiring refinement, and learning reflections, pending acquisition of a dance-themed notebook [[session/dialog/a126eeab_3.jsonl#L11-L11]].

## Spotify Playlist Recommendations
- General dance and workout playlists recommended on Spotify include: *Beast Mode* (high-intensity mix of hip hop, electronic, and pop), *Cardio Kickstart* by Fitness Blender, *Hip Hop Workout* (old-school and new-school hip hop), *Dance Workout* by PopSugar Fitness, *Fitness Frenzy* by DJ Khaled, *Sweat Session* by Zumba, *Dance Party*, *Get Moving* by Nike Training Club, *Hip Hop Cardio* by Fitness Marshall, and *Dance Fitness* by Jazzercise [[session/dialog/a126eeab_3.jsonl#L2-L2]]. Search suggestions highlighted established programs such as Zumba, Hip Hop Abs, and Jazzercise [[session/dialog/a126eeab_3.jsonl#L2-L2]].
- For hip hop and R&B focused tracks, recommended playlists feature: *Hip Hop Workout* highlighting Kendrick Lamar, Cardi B, and Travis Scott; *R&B Workout* blending tracks by The Weeknd, Drake, and Beyoncé; *Trap Cardio* by Fitness Marshall showcasing Lil Uzi Vert, Migos, and Gunna; *Hip Hop Hits* emphasizing Post Malone, Nicki Minaj, and Chris Brown; *RapCaviar Workout* combining tracks by J. Cole, Anderson .Paak, and Kehlani; *Hip Hop Dance* by DanceWithJanet; *Street Heat* focusing on underground talent; *Hip Hop Fitness* by FitMix; *Turnt Up* delivering high-energy tracks; and *Hip Hop Bootcamp* by Bootcamp Fitness [[session/dialog/a126eeab_3.jsonl#L4-L4]]. Suggestions included curating custom playlists from artists like Drake, Kendrick Lamar, and The Weeknd [[session/dialog/a126eeab_3.jsonl#L4-L4]].

## YouTube Dance Tutorial Channels
- Recommended hip hop tutorial channels include: *MattSteffanina* (professional hip hop dancer and choreographer), *D-Trix* (Dominic Sandoval, a *So You Think You Can Dance* contestant), *WilldaBeast Adams*, *Janelle Ginestra*, and *Monster of Dance* [[session/dialog/a126eeab_3.jsonl#L6-L6]].
- Recommended jazz tutorial channels include: *Jazzercise* (jazz-based fitness program), *DanceWithJanet* (covering jazz, hip hop, contemporary), *The Dance Room* (jazz, tap, contemporary), *Jazz Funk Dance*, and *Broadway Dance Center* (a renowned studio in New York City providing jazz, tap, ballet, and contemporary classes) [[session/dialog/a126eeab_3.jsonl#L6-L6]].
- Additional channels offering multi-style training include: *DanceTutorialsLive* (live classes), *SteppinOut Studios* (hip hop, jazz, contemporary, ballet), and *Codarts* (a dance academy in the Netherlands) [[session/dialog/a126eeab_3.jsonl#L6-L6]].

## Dance Technique Improvement and Review Methods
- Corrective strategies for pirouettes and jazz turns involve maintaining proper posture and alignment with even weight distribution, engaging the core, keeping arms relaxed, utilizing "spotting" (fixing eyes on a stationary point), alternating turning directions, initiating rotations slowly and progressively increasing speed and amplitude, and maintaining controlled breathing throughout turns [[session/dialog/a126eeab_3.jsonl#L8-L8]]. Employing a partner, chair, or wall for balance assistance is recommended during jazz turn exercises [[session/dialog/a126eeab_3.jsonl#L8-L8]].
- Video recording captures actionable visual data regarding posture, skeletal alignment, footwork execution, musical timing, limb placement, and expressive energy levels [[session/dialog/a126eeab_3.jsonl#L10-L10]]. Replaying identical routines with incremental mechanical adjustments builds durable muscle memory [[session/dialog/a126eeab_3.jsonl#L10-L10]]. Distributing recorded footage to qualified instructors or experienced peers secures objective technical evaluations [[session/dialog/a126eeab_3.jsonl#L10-L10]].
- An active dance journal serves as a centralized tracking system for new choreography, session performance metrics, targeted objectives, motivational material, geometric movement schematics, and archival photographs [[session/dialog/a126eeab_3.jsonl#L12-L12]]. Applying decorative accessories such as stickers, decorative tapes, or hand-drawn illustrations personalizes the notebook experience [[session/dialog/a126eeab_3.jsonl#L12-L12]].
