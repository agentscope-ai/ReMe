---
description: Comprehensive guide to museums, art galleries, cultural landmarks, and
  wineries in the Côte-d'Or region of France, featuring notable artworks, historical
  contexts (e.g., Hospices de Beaune), and specific winery details (Domaine Pavelot,
  Romanee-Conti, etc.). Includes user travel plans for art and wine tourism in the
  region.
name: cote-d-or-museums-and-wineries-guide
session_id: ultrachat_305422
source_conversation: '[[session/dialog/ultrachat_305422.jsonl]]'
---

# Côte-d'Or Tourism Guide: Museums, Sites, and Wineries

## Museums and Galleries in Côte-d'Or

- **Musée des Beaux-Arts de Dijon**: Housed in the historic Palace of the Dukes of Burgundy. Notable artworks include "the raising of lazarus" by Sebastiano del Piombo, "the madonna and child with st. john the baptist and st. john the evangelist" by Raphael, and "the three graces" by Peter Paul Rubens. Collections span the Renaissance to the 20th century. [[session/dialog/ultrachat_305422.jsonl#L1-L2,L4]]
- **Musée Magnin**: Features paintings from the 16th to the 19th century, including works by lesser-known artists. Notable pieces include "the virgin mary with infant christ in a flower garland" by Jan Breughel the elder, "the descent from the cross" by Simon Vouet, and "portrait of an architect in his office" by Jan Jansz van de velde. [[session/dialog/ultrachat_305422.jsonl#L1-L2,L4]]
- **Muséoparc Alésia**: Displays replicas of Vercingetorix's helmet and statues of Julius Caesar alongside other Roman leaders. [[session/dialog/ultrachat_305422.jsonl#L2]]
- **Musée d'Histoire de la Médecine et de la Pharmacie de Dijon**: Exhibits old medical equipment, instruments, books, and historical documents. [[session/dialog/ultrachat_305422.jsonl#L2]]
- **Maison Vougeot**: Focuses on the history of Burgundy wine, displaying artifacts from local vineyards and cellars. [[session/dialog/ultrachat_305422.jsonl#L2]]
- **Gallery Mazarine**: Showcases a collection of contemporary art by various artists across France. [[session/dialog/ultrachat_305422.jsonl#L2]]
- **Centre d'Art Contemporain La Vapeur**: Exhibits artworks by contemporary artists experimenting with digital forms. [[session/dialog/ultrachat_305422.jsonl#L2]]
- **Musée de la Vie Bourguignonne Perrin de Puycousin**: Preserves exhibits from traditional regional life, including clothing, furniture, and tools. [[session/dialog/ultrachat_305422.jsonl#L2]]
- **Cité des Arts et des Sciences**: Specializes in the scientific and technical history of the region, featuring interactive installations. [[session/dialog/ultrachat_305422.jsonl#L2]]

## Must-See Cultural Sites and Traditions

- **Hospices de Beaune**: A historic hospital in Beaune founded in the 15th century by Nicolas Rolin (Chancellor of Burgundy) and his wife to care for the less privileged. Today, it operates as a museum highlighting the institution's architectural heritage and philanthropic history. [[session/dialog/ultrachat_305422.jsonl#L8]]
- **Château de la Rochepot**: A castle situated outside Beaune dating back to the 13th century, distinguished by its unique multicolored tiled roof. [[session/dialog/ultrachat_305422.jsonl#L8]]
- **Les Bons Crus d'Avize**: A wine cellar located in Dijon providing an immersive experience into the wine-making traditions, including tastings. [[session/dialog/ultrachat_305422.jsonl#L8]]
- **Dijon Market**: A market operating every Tuesday, Thursday, and Saturday, offering local produce, meats, cheeses, and pastries. [[session/dialog/ultrachat_305422.jsonl#L8]]
- **Route des Grands Crus**: A scenic wine trail running through the Burgundy vineyards, allowing visitors to tour local wineries and sample regional wines. [[session/dialog/ultrachat_305422.jsonl#L8]]

## Wineries Along Route des Grands Crus

- **Domaine Pavelot**: Family-owned estate in Savigny-lès-Beaune; renowned for red wines, specifically Pinot Noir. [[session/dialog/ultrachat_305422.jsonl#L10]]
- **Domaine de la Vougeraie**: Located in Premeaux-Prissey, producing biodynamic wines using natural techniques to maintain grape integrity. [[session/dialog/ultrachat_305422.jsonl#L10]]
- **Domaine de la Romanee-Conti**: Legendary estate in Vosne-Romanée known for producing some of the world's most exclusive and expensive wines. Visits are restricted to appointments only. [[session/dialog/ultrachat_305422.jsonl#L10]]
- **Louis Jadot**: Established in the mid-19th century; offers tours and tastings at its facilities in Beaune. [[session/dialog/ultrachat_305422.jsonl#L10]]
- **Domaine des Hospices de Beaune**: Owned by the Hospices de Beaune; profits directly fund the hospital's charitable missions. Tours available for red and white wines. [[session/dialog/ultrachat_305422.jsonl#L10]]

## User Interests and Travel Plans

- The user is interested in art and intends to visit the **Musée des Beaux-Arts de Dijon**. [[session/dialog/ultrachat_305422.jsonl#L5]]
- The user plans to visit the **Museum of the History of Medicine** (historically identified as Musée d'Histoire de la Médecine et de la Pharmacie de Dijon). [[session/dialog/ultrachat_305422.jsonl#L5-L6]]
- The user is interested in experiencing Côte-d'Or's cultural traditions, specifically the region's culinary and winemaking history. [[session/dialog/ultrachat_305422.jsonl#L7]]
- The user aims to explore the **Route des Grands Crus** and taste famous regional wines at specific wineries. [[session/dialog/ultrachat_305422.jsonl#L9]]
