---
description: 'Overview of top-selling candle brands (Yankee Candle, Bath and Body
  Works, Jo Malone, Diptyque, Nest Fragrances, Voluspa, Capri Blue, Lumira). Detailed
  profiles of five natural and eco-friendly brands: P.F. Candle Co., Brooklyn Candle
  Studio, Lite+Cycle, Boy Smells, and Keap, including materials used (soy wax, essential
  oils, organic coconut wax, recycled glass), cruelty-free status, and specific lavender-scented
  products and sampler set sizes. Records user preference for natural candles and
  lavender scent, confirming a purchase decision for the P.F. Candle Co. Best Seller
  Mini Candle Set. Outlines four procedural tips for candle longevity: trimming wicks
  to 1/4 inch, burning for 1 hour per inch of diameter to prevent tunneling, avoiding
  drafts, and using a snuffer.'
name: candle-brands-and-care-tips
session_id: ultrachat_27975
source_conversation: '[[session/dialog/ultrachat_27975.jsonl]]'
---

## Popular Candle Brands
Some popular candle brands based on past trends include Yankee Candle, Bath and Body Works, Jo Malone, Diitype, Nest Fragrances, Voluspa, Capri Blue, and Lumira. [[session/dialog/ultrachat_27975.jsonl#L1-L2]]

## Natural and Eco-Friendly Candle Brands
The following brands focus on sustainable and eco-friendly approaches using natural, non-toxic ingredients:
- P.F. Candle Co.: Offers candles made with soy wax and phthalate-free fragrance oils. Includes a candle named "Lavender" made with essential oils, and a "Best Seller Mini Candle Set" featuring five 3.5oz candles that includes the lavender scent.
- Brooklyn Candle Studio: Utilizes soy wax, cotton wicks, and essential oils. Offers a candle named "Lavender Noir" and a "Discovery Set" containing four 2oz candles including one with a lavender scent.
- Lite+Cycle: Uses organic ingredients, recycled glass, and biodegradable packaging. Features a candle named "Grounding" made with certified organic lavender essential oil and organic coconut wax, alongside a "Discovery Set" with three 2.5oz candles including a lavender-scented option.
- Boy Smells: Produces candles using coconut wax, beeswax, and vegetable waxes; also known as cruelty-free. Sells a candle named "Lanai" and a "Discovery Set" with six 3oz candles including one with a lavender scent.
- Keap: Crafts candles using organic coconut wax, natural fragrance oils, and reusable or recyclable glass containers. Offers a candle named "Amalfi Coast" blended with lavender essential oil and bergamot, plus a "Sample Set" with four 2oz candles including the lavender-scented variety. [[session/dialog/ultrachat_27975.jsonl#L5-L6,L7-L8,L9-L10]]

## User Preferences and Actions
On 2023-05-30, the user expressed interest in natural and eco-friendly candles and stated their favorite scent is lavender. The user decided to purchase the P.F. Candle Co. Best Seller Mini Candle Set which contains the lavender-scented candle. [[session/dialog/ultrachat_27975.jsonl#L11-L12]]

## Candle Care and Longevity Tips
To extend the lifespan of candles, the following procedures are recommended:
- Trim the wick to approximately 1/4 inch prior to lighting to prevent an overly high flame and rapid melting.
- Burn the candle for 1 hour per inch of its diameter each time it is lit to ensure the wax melts evenly across the entire surface and prevents tunneling.
- Place candles in still locations away from open windows or drafty rooms to avoid faster burning caused by drafts.
- Extinguish flames using a candle snuffer rather than blowing them out to prevent smoke buildup on the wick, which can negatively affect the scent. [[session/dialog/ultrachat_27975.jsonl#L13-L14]]
