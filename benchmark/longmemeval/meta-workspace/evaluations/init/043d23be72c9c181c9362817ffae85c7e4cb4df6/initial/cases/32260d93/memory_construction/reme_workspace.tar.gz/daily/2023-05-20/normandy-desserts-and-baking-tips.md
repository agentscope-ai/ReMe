---
description: 'Discussion identifying three traditional Normandy desserts: Tarte aux
  Pommes (apple tart), Teurgoule (rice pudding), and Calvados Soufflé (soufflé with
  apple brandy). The user selected Tarte aux Pommes and requested drink pairings (non-alcoholic
  teas/milk and alcoholic cider/Calvados/mimosa) along with baking instructions. Specific
  baking tips included using tart/firm apples (Granny Smith, Honeycrisp, Braeburn),
  keeping ingredients cold for a flaky crust, gentle dough handling, spiral apple
  layering, and applying an egg wash (one egg, tablespoon water) before baking.'
name: normandy-desserts-and-baking-tips
session_id: ultrachat_528391
source_conversation: '[[session/dialog/ultrachat_528391.jsonl]]'
---

### Traditional Desserts of Normandy
*   Three traditional desserts from the Normandy region were identified:
    *   **Tarte aux Pommes**: An apple tart composed of crisp apples encased in a buttery, flaky pastry crust [[session/dialog/ultrachat_528391.jsonl#L2]].
    *   **Teurgoule**: A sweet rice pudding formulated with milk, cinnamon, and sugar, traditionally baked within a ceramic dish [[session/dialog/ultrachat_528391.jsonl#L2]].
    *   **Calvados Soufflé**: A light, airy soufflé utilizing Calvados, the renowned apple brandy produced in the Normandy region [[session/dialog/ultrachat_528391.jsonl#L2]].

### Preference for Tarte aux Pommes
*   When comparing options, apple-focused desserts (the Tarte aux Pommes and the Calvados Soufflé) were determined to be better suited for individuals who prefer apple desserts compared to the creamy profile of the Teurgoule [[session/dialog/ultrachat_528391.jsonl#L4]].
*   A decision was finalized to attempt the Tarte aux Pommes first, driven by a preference for apple-based confections [[session/dialog/ultrachat_528391.jsonl#L5]].
*   The Tarte aux Pommes is characterized as a dessert particularly suitable for the autumn season when apples are abundant [[session/dialog/ultrachat_528391.jsonl#L6]].

### Beverage Pairings for the Apple Tart
*   Compatible beverage pairings were categorized into non-alcoholic and alcoholic options:
    *   Non-alcoholic selections include Earl Grey tea, English Breakfast tea, cold milk, and iced tea [[session/dialog/ultrachat_528391.jsonl#L8]].
    *   Alcoholic selections include Calvados (Normandy apple brandy), hard cider, and an apple cider mimosa; the tartness and sweetness of these drinks are noted to complement the dessert's flavor profile effectively [[session/dialog/ultrachat_528391.jsonl#L8]].
*   The apple cider mimosa was specifically selected by the user to accompany the Tarte aux Pommes [[session/dialog/ultrachat_528391.jsonl#L9]].
*   The apple cider mimosa is described as festive and refreshing, matching well with fall-themed desserts [[session/dialog/ultrachat_528391.jsonl#L10]].

### Baking Guidelines for Tarte aux Pommes
*   Instructions and techniques for preparing the apple tart were provided:
    *   **Select Appropriate Apples**: Prioritize tart and firm apple varieties such as Granny Smith, Honeycrisp, or Braeburn [[session/dialog/ultrachat_528391.jsonl#L12]].
    *   **Manage Ingredient Temperatures**: Retain cold temperatures for butter and all ingredients to promote a flaky pastry texture; refrigerating the mixing bowl briefly prior to preparation assists in this goal [[session/dialog/ultrachat_528391.jsonl#L12]].
    *   **Handle Dough Carefully**: Utilize a lightly floured surface and rolling pin to roll out the pastry, minimizing handling to prevent gluten activation and maintain tenderness [[session/dialog/ultrachat_528391.jsonl#L12]].
    *   **Arrange Slices Uniformly**: Distribute apple slices evenly and tightly across the tart, favoring a spiral fanning pattern for visual appeal [[session/dialog/ultrachat_528391.jsonl#L12]].
    *   **Apply Egg Wash**: Brush the exterior of the pie with an egg wash consisting of one egg mixed with one tablespoon of water immediately prior to baking to secure a golden finish and gloss [[session/dialog/ultrachat_528391.jsonl#L12]].
