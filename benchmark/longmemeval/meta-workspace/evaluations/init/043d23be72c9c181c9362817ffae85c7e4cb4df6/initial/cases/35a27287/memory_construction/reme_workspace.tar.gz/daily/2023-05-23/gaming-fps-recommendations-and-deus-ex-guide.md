---
description: 'A record of a gaming consultation session where the user, having completed
  Call of Duty on November 15th, sought fast-paced FPS games with strong narratives.
  The assistant recommended various titles including Battlefield, Titanfall 2, Doom,
  and Wolfenstein. The user ultimately chose Deus Ex: Mankind Divided to explore deeper
  story-driven gameplay. The note details game categories, campaign lengths (6-30
  hours), specific augmentation mechanics (Combat, Stealth, Exploration, Social) for
  Deus Ex, and post-game content like New Game Plus and Breaching Mode.'
name: gaming-fps-recommendations-and-deus-ex-guide
session_id: d20be4f3_1
source_conversation: '[[session/dialog/d20be4f3_1.jsonl]]'
---

## User Gaming Profile & Context
- User completed the *Call of Duty* campaign mode on November 15th [[session/dialog/d20be4f3_1.jsonl#L1-L1]].
- User prefers video games with fast-paced action, intense combat, and a strong focus on storytelling/single-player campaigns [[session/dialog/d20be4f3_1.jsonl#L3-L3]].
- User worries they may have finished the *Call of Duty* campaign too quickly, indicating a desire for longer or more engaging experiences [[session/dialog/d20be4f3_1.jsonl#L5-L5]].

## First-Person Shooter Recommendations
### Core Genre Suggestions
Assistant suggests multiple FPS franchises based on the genre interest:
- **Battlefield Series**: Includes *Battlefield 1*, *Battlefield 4*, and *Battlefield V*; known for large-scale multiplayer battles [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Titanfall Series**: Specifically *Titanfall 2*, noted for mech combat and a well-regarded single-player campaign [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Halo Series**: Sci-Fi shooter recommendation; suggestions include *Halo 5: Guardians* and *Halo Infinite* [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **CS:GO (Counter-Strike: Global Offensive)**: Suggested for a competitive, tactical FPS experience [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Overwatch**: A team-based shooter focusing on heroes with unique abilities rather than traditional FPS mechanics [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Wolfenstein Series**: Titles include *Wolfenstein: The New Colossus* and *Wolfenstein: Youngblood*; described as fast-paced and action-oriented [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Far Cry Series**: Features open-world exploration and strong narratives; includes *Far Cry 5* [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Rainbow Six Siege**: Tactical FPS focused on strategic team play and competitive firefights [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Doom (2016)**: Fast-paced title with a strong emphasis on intense single-player combat [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Metro Series**: Atmospheric and story-driven options like *Metro 2033* and *Metro: Last Light* [[session/dialog/d20be4f3_1.jsonl#L2-L2]].

### Targeted Recommendations for Narrative Depth
User requests games offering a similar feel to *Call of Duty* but with stronger storytelling and potentially longer campaigns [[session/dialog/d20be4f3_1.jsonl#L5-L5]]. Assistant highlights:
- **Deus Ex: Mankind Divided**: Single-player campaign estimated at 20–30 hours; highly story-driven with complex exploration and player choice [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Dishonored 2**: Estimated duration of 15–20 hours; acclaimed for stealth mechanics, rich world design, and engaging narrative [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Wolfenstein: The New Colossus**: Estimated campaign length of 10–12 hours; praised for atmosphere, setting, and storytelling [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Far Cry 5**: Estimated duration of 20–30 hours; offers an open-ended story focused on exploring a villainous leader’s territory [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Battlefield 1**: Estimated campaign length of 6–8 hours; features cinematic "War Stories" combining action, stealth, and vehicles [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Titanfall 2**: Estimated campaign length of 6–8 hours; tightly designed level layout integrating narrative closely with gameplay [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Warframe**: Free-to-play cooperative sci-fi title where story is delivered via quests playable solo or co-op [[session/dialog/d20be4f3_1.jsonl#L4-L4]].
- **Overkill's The Walking Dead**: Cooperative FPS set in *The Walking Dead* universe featuring a single-player campaign [[session/dialog/d20be4f3_1.jsonl#L4-L4]].

## User Selection: Deus Ex: Mankind Divided
- User decides to play *Deus Ex: Mankind Divided* to investigate the game's highly regarded story and setting [[session/dialog/d20be4f3_1.jsonl#L7-L9]].
- User is willing to adapt to a different gameplay style compared to *Call of Duty* [[session/dialog/d20be4f3_1.jsonl#L7-L9]].
- Assistant cautions that *Deus Ex: Mankind Divided* prioritizes methodical, stealth-oriented, and tactical approaches over the rapid-fire action found in *Call of Duty* [[session/dialog/d20be4f3_1.jsonl#L8-L8]].
- Gameplay requires using augmentations, hacking, social engineering, and strategy alongside combat [[session/dialog/d20be4f3_1.jsonl#L8-L8]].

## Deus Ex: Mankind Divided: Augmentation Mechanics
- **Cybernetic Augmentations**: Enhancements installed in the body granting new abilities; purchased or crafted using Praxis Points earned from missions and activities [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
- **Usage Strategy**: Requires adapting augmentation selection to situations (e.g., stealth for ambushes, combat for clearing groups) while managing limited equipment slots and currency [[session/dialog/d20be4f3_1.jsonl#L10-L10]].

### Augmentation Categories and Tools
- **Combat Augmentations**: Focus on damage output and accuracy [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - **Typhoon**: Unleashes explosive energy bursts to eliminate multiple enemies simultaneously [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
- **Stealth Augmentations**: Facilitate undetected movement, hacking security systems, and creating distractions [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
- **Exploration Augmentations**: Enable climbing walls, higher jumping, and seeing hidden paths [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - **Smart Vision**: Highlights enemies, security systems, and hidden objects for navigation planning [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - **Icarus Landing**: Allows falling from great heights without sustaining damage [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
- **Social Augmentations**: Improve effectiveness in persuading or intimidating NPCs [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - **Social Enhancer**: Improves skills related to social interaction and negotiation [[session/dialog/d20be4f3_1.jsonl#L10-L10]].

## Replayability & Post-Game Content
- **New Game Plus Mode**: Allows replaying the game with retained upgrades, facing tougher enemies and discovering new story elements [[session/dialog/d20be4f3_1.jsonl#L12-L12]].
- **Breaching Mode**: A separate simulation mode involving corporate facility breaches, wave defense, and high-score leaderboards [[session/dialog/d20be4f3_1.jsonl#L12-L12]].
- **Jensen's Stories DLC**: Downloadable content containing additional missions, characters, and augmentations intended for post-story play [[session/dialog/d20be4f3_1.jsonl#L12-L12]].
- **Side Content**: Extensive side quests and optional objectives provide additional context and rewards during or after the main campaign [[session/dialog/d20be4f3_1.jsonl#L12-L12]].
