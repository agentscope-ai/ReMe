---
description: Detailed playlist recommendations for fitness routines. Includes high-energy
  hip-hop tracks for Saturday Morning Hip Hop Abs with Mike (Morning Motivation, Old
  School Flava, New Wave, High-Energy Anthems) and chill hip-hop/R&B tracks for Sunday
  Yoga (Mellow Vibes, Chillhop Essentials, R&B Revival, Lo-Fi Hip-Hop). Lists artists,
  song titles, and instrumentation notes.
name: workout-music-playlists
session_id: answer_8f6b938d_2
source_conversation: '[[session/dialog/answer_8f6b938d_2.jsonl]]'
---

## Fitness Music Playlists [[session/dialog/answer_8f6b938d_2.jsonl#L1-L4]]

### High-Energy Hip-Hop Playlists (Saturday Morning Abs Class with Mike)
Target: Pump up for Saturday Morning Hip Hop Abs class at 10:00 AM.

**Morning Motivation**
1. Eminem - "Lose Yourself"
2. Kendrick Lamar - "Humble"
3. Cardi B - "Bodak Yellow"
4. Travis Scott - "Sicko Mode"
5. Nicki Minaj - "Chun-Li"
6. J. Cole - "Middle Child"
7. Post Malone - "White Iverson"
8. Drake - "God's Plan"
9. Lil Uzi Vert - "XO Tour Llama"
10. Missy Elliott - "Get Ur Freak On"

**Old School Flava**
1. 2Pac - "California Love"
2. The Notorious B.I.G. - "Hypnotize"
3. Jay-Z - "99 Problems"
4. Nas - "Hate Me Now"
5. DMX - "Ruff Ryders' Anthem"
6. Busta Rhymes - "Woo Hah!! Got You All in Check"
7. LL Cool J - "Mama Said Knock You Out"
8. Snoop Dogg - "Drop It Like It's Hot"
9. Ludacris - "Money Maker"
10. OutKast - "Hey Ya!"

**New Wave**
1. Megan Thee Stallion - "Hot Girl Summer"
2. Lil Baby - "Woah"
3. Gunna - "Sold Out Dates"
4. Nav - "Champion"
5. A$AP Ferg - "Plain Jane"
6. Joey Bada$$ - "Devastated"
7. Logic - "1-800-273-8255"
8. G-Eazy - "No Limit"
9. Tyga - "Taste"
10. City Girls - "Act Up"

**High-Energy Anthems**
1. Macklemore & Ryan Lewis - "Can't Hold Us"
2. Kanye West - "Stronger"
3. Drake - "Started From the Bottom"
4. Lil Wayne - "6 Foot 7 Foot"
5. T.I. - "Whatever You Like"
6. Young Jeezy - "I Luv It"
7. Rick Ross - "Hustlin'"
8. Wale - "Ambition"
9. Meek Mill - "Dreams and Nightmares"
10. DJ Khaled - "All I Do is Win"

### Relaxing Hip-Hop & R&B Playlists (Sunday Yoga Classes)
Target: Unwind and relax during Sunday yoga sessions.

**Mellow Vibes**
1. The Weeknd - "Earned It" (Instrumental)
2. Bryson Tiller - "Exchange"
3. Anderson .Paak - "The Season / Carry Me"
4. Kendrick Lamar - "These Walls"
5. Jhené Aiko - "The Worst"
6. Drake - "Jungle" (Remix)
7. Kehlani - "Gangsta"
8. Frank Ocean - "Thinkin Bout You"
9. PARTYNEXTDOOR - "Break from Toronto"
10. Childish Gambino - "Redbone" (Instrumental)

**Chillhop Essentials**
1. J. Cole - "Apparently"
2. Chance the Rapper - "Coloring Book" (Instrumental)
3. Khalid - "Location"
4. 6LACK - "PRBLMS"
5. Anderson East - "Satisfy Me"
6. Tory Lanez - "Say It"
7. BJ the Chicago Kid - "Love Inside"
8. Aminé - "Spice Girl"
9. GoldLink - "Crew" (Remix)
10. Noname - "Diddy Bop"

**R&B Revival**
1. Usher - "Climax"
2. Chris Brown - "Lost in Ya Eyes"
3. Miguel - "Adorn"
4. The-Dream - "Love vs. Money"
5. Trey Songz - "Heart Attack"
6. Jeremih - "Birthday Sex"
7. Omarion - "Entourage"
8. Keri Hilson - "Pretty Girl Rock"
9. Ne-Yo - "Because of You"
10. Teyana Taylor - "Gonna Love Me"

**Lo-Fi Hip-Hop**
1. Jinsang - "Pillow Talk"
2. Yung Gud - "Snowflake"
3. Mndsgn - "Eggs"
4. Nujabes - "Aruarian Dance"
5. J Dilla - "So Far to Go"
6. Slum Village - "Fall in Love"
7. A Tribe Called Quest - "Find a Way"
8. The Pharcyde - "Passin' Me By"
9. De La Soul - "Feel Good Inc."
10. DJ Shadow - "Midnight in a Perfect World"
