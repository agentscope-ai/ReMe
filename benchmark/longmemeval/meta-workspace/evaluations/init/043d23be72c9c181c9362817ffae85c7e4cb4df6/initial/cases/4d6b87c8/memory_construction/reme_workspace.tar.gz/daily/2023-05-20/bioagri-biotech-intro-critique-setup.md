---
description: Request to assume the role of a doctor of bioagriculture and biotechnology
  to critique an upcoming introduction without rewriting it, using English output.
  The actual introduction text has not yet been provided; the session is currently
  awaiting input from the user to proceed with the critique.
name: bioagri-biotech-intro-critique-setup
session_id: sharegpt_undG8q1_0
source_conversation: '[[session/dialog/sharegpt_undG8q1_0.jsonl]]'
---

## Interaction Setup [[session/dialog/sharegpt_undG8q1_0.jsonl#L1-L2]]
- **Role Assignment**: Act as a doctor of bioagriculture and biotechnology.
- **Task**: Read an introduction provided by the user, critique it, but do not rewrite it.
- **Language Preference**: Write the critique in English language.
- **Current State**: Awaiting the introduction text to begin the critique task.
- **Interaction Timestamp**: 2023-05-20T10:25:00.
