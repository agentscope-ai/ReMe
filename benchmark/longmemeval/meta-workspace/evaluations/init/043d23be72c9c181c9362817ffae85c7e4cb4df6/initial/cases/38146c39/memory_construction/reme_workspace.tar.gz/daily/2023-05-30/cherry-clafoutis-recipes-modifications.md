---
description: 'Two complete dessert recipes: Cherry Clafoutis (serves 6–8; ingredients
  include 2 cups pitted cherries, 1 ½ cups granulated sugar, ½ cup all-purpose flour,
  ½ tsp baking powder, ½ tsp salt, ½ cup whole milk, 2 eggs, 2 tbsp melted butter,
  1 tsp vanilla extract; bake at 375°F for 35–40 min in a 9×13-inch dish; dust with
  powdered sugar) and Cherry Crisp (serves 6–8; cherries mixed with ½ cup sugar, 2
  tbsp cornstarch, ¼ cup flour, ½ tsp cinnamon, ¼ tsp nutmeg, ¼ tsp salt, topped with
  crumb mixture of ½ cup oats, ½ cup brown sugar, ½ cup cold unsalted butter; bake
  at 375°F for 40–45 min in a 9×9-inch dish; serve with vanilla ice cream or whipped
  cream). Four documented substitutions for the clafoutis: (1) granulated sugar →
  light brown sugar adds caramel/molasses flavor, increases moisture/density, reduce
  quantity to 1¼ cups, monitor browning and cover with foil during final 10–15 minutes;
  (2) all-purpose flour → almond flour produces gluten-free low-carb option with dense
  moist pound-cake-like crumb and nutty flavor, reduce baking powder to ¼ tsp, sift
  flour, add extra liquid if needed, avoid overmixing; (3) sliced almond topping uses
  ¼–½ cup thinly sliced almonds sprinkled evenly over fruit surface, optional brown
  sugar sprinkle for caramelization; (4) frozen cherries require thawing at room temperature
  or microwave, thorough patting dry to prevent sogginess, gentle mixing to avoid
  mashing, possible sugar reduction if excess water present. On 2023-05-30, the speaker
  decided to prepare the clafoutis implementing all four modifications simultaneously.'
name: cherry-clafoutis-recipes-modifications
session_id: 87aaee77
source_conversation: '[[session/dialog/87aaee77.jsonl]]'
---

## Cherry Clafoutis and Cherry Crisp Recipes [[session/dialog/87aaee77.jsonl#L1-L2]]

### Cherry Clafoutis Recipe
Serves 6–8 people. A classic French dessert resembling a cobbler but with a lighter, fluffier texture.

**Ingredients:**
- 2 cups fresh or frozen cherries, pitted
- 1 ½ cups granulated sugar
- ½ cup all-purpose flour
- ½ teaspoon baking powder
- ½ teaspoon salt
- ½ cup whole milk
- 2 large eggs
- 2 tablespoons unsalted butter, melted
- 1 teaspoon vanilla extract

**Instructions:**
1. Preheat oven to 375°F (190°C).
2. In a large bowl, whisk together the sugar, flour, and baking powder.
3. In a separate bowl, whisk together the milk, eggs, and melted butter.
4. Add wet ingredients to dry ingredients and whisk until smooth.
5. Pour batter into a 9x13-inch baking dish and arrange the cherries on top.
6. Bake for 35–40 minutes until the clafoutis is puffed and golden brown.
7. Dust with powdered sugar and serve warm.

### Cherry Crisp Recipe
Serves 6–8 people. A classic American dessert suitable for warm weather.

**Ingredients:**
- 2 cups fresh or frozen cherries, pitted
- ½ cup granulated sugar
- 2 tablespoons cornstarch
- ¼ cup all-purpose flour
- ½ teaspoon cinnamon
- ¼ teaspoon nutmeg
- ¼ teaspoon salt
- ½ cup rolled oats
- ½ cup brown sugar
- ½ cup cold unsalted butter, cut into small pieces

**Instructions:**
1. Preheat oven to 375°F (190°C).
2. Mix together the cherries, granulated sugar, cornstarch, and flour in a large bowl.
3. Transfer the mixture to a 9x9-inch baking dish.
4. In a separate bowl, mix together the rolled oats, brown sugar, cinnamon, nutmeg, and salt.
5. Add the cold butter to the oat mixture and use fingers or a pastry blender to work it into a crumbly mixture.
6. Spread the crumb topping evenly over the cherry mixture.
7. Bake for 40–45 minutes until the topping is golden brown and the fruit is bubbly.
8. Serve warm with vanilla ice cream or whipped cream.

## Brown Sugar Substitution for Clafoutis [[session/dialog/87aaee77.jsonl#L3-L4]]

Granulated sugar may be replaced with brown sugar in the cherry clafoutis recipe, with expected alterations to flavor and texture.

**Flavor impact:** Brown sugar produces a richer, deeper taste with caramel and molasses notes that complement the sweetness of the cherries. The flavor becomes more complex and nuanced compared to granulated sugar.

**Texture impact:** Brown sugar contains higher moisture than granulated sugar, resulting in a slightly denser, moister batter. The clafoutis will develop a heavier, more cake-like texture with reduced puffing during baking, though the result remains tender and delicious.

**Application guidelines:** Use light brown sugar rather than dark brown sugar to avoid overpowering the cherries. Reduce the quantity from 1 ½ cups to 1 ¼ cups, as brown sugar is sweeter. Monitor the clafoutis closely during baking and cover the top with foil during the last 10–15 minutes to prevent excessive browning. For traditional French clafoutis flavor, retain granulated sugar. Brown sugar provides an effective variation for those seeking a modified recipe.

## Almond Flour Substitution for Clafoutis [[session/dialog/87aaee77.jsonl#L5-L6]]

All-purpose flour may be replaced with almond flour in the cherry clafoutis recipe, producing significant changes to texture and flavor.

**Flavor impact:** Almond flour introduces a distinct nutty flavor that complements the cherries well. The almond character becomes more pronounced when using high-quality blanched almond flour.

**Texture impact:** Almond flour is a low-carb, high-fat alternative that yields a denser, moister, more delicate crumb resembling pound cake. The structure will be slightly fragile with a crumbly consistency.

**Application guidelines:** Apply a 1:1 substitution ratio, accounting for increased liquid absorption by adding additional milk or eggs as needed. Reduce baking powder to ¼ teaspoon, as almond flour responds differently to leavening agents. Use high-quality finely ground blanched almond flour and sift beforehand to remove lumps and incorporate air. Avoid overmixing the batter to prevent toughness. The clafoutis progresses rapidly between perfectly cooked and burnt states during baking, requiring close observation. This substitution accommodates gluten intolerance or sensitivity requirements while providing a low-carb dessert option. Retain all-purpose flour for a traditional clafoutis texture profile.

## Sliced Almonds Topping [[session/dialog/87aaee77.jsonl#L7-L8]]

A layer of sliced almonds placed atop the cherries before baking enhances both visual appeal and textural contrast. The crunchy quality and nutty flavor align with the sweet cherries and dense cake-like clafoutis base.

**Application guidelines:** Select thinly sliced almonds (slivers) to promote even toasting and prevent excessive crunch or bitterness. Sprinkle the almonds evenly across the entire surface, using approximately ¼–½ cup based on personal preference. When employing brown sugar, optionally sprinkle a pinch of brown sugar over the almond layer before baking to encourage caramelization and produce a crunchy sweet crust. Monitor the clafoutis carefully during baking, as the almonds transition quickly from toasted to burnt. Apply the standard foil-covering procedure during the final 10–15 minutes if necessary. The combination of brown sugar, almond flour, and sliced almonds creates a distinctive cherry clafoutis variant.

## Frozen Cherries Preparation [[session/dialog/87aaee77.jsonl#L9-L10]]

Frozen cherries serve as a viable substitute for fresh cherries in the clafoutis recipe. Frozen cherries often achieve peak ripeness before flash-freezing, which preserves flavor and structural quality.

**Preparation procedures:** Thaw the frozen cherries either by leaving them at room temperature for several hours or following package microwave instructions. Completely pat the thawed cherries dry with paper towels to eliminate excess moisture, preventing a soggy clafoutis base. Handle the cherries gently when combining with sugar and flour to avoid crushing or mashing, as frozen cherries are structurally fragile.

**Baking adjustments:** Frozen cherries release additional juice during the baking process and hold their shape less effectively than fresh fruit. If the thawed cherries exhibit particular wetness or ice content, reduce the sugar quantity in the recipe to balance the flavor. The altered fruit behavior does not negatively impact the overall flavor or texture outcome.

## Execution Decision [[session/dialog/87aaee77.jsonl#L11-L12]]

On 2023-05-30, the speaker confirmed possession of all required materials and determined to prepare the cherry clafoutis incorporating all four simultaneous modifications: brown sugar replacing granulated sugar, almond flour replacing all-purpose flour, a sliced almond topping layer, and thawed frozen cherries in place of fresh fruit. The speaker intends to communicate results upon completion of the preparation.
