---
description: 'A detailed legal reference outlining construction contract termination
  principles and remedies based on two key cases: Brewarrina Shire Council v Beckhaus
  Civil Pty Ltd & 1 Or [2005] NSWCA 248 and Blessed Sydney Constructions PL v Vasudevan.
  Documents the significance of contract termination for claiming defective work damages,
  defines repudiatory conduct with specific examples, outlines valid termination procedures,
  and explains the Blessed Sydney Constructions ruling that permits Tribunal renewal
  applications to bypass Brewarrina constraints, thereby enabling money orders and
  alternative remedies.'
name: brewarrina-vasudevan-construction-contract-termination
session_id: sharegpt_b76JUGd_65
source_conversation: '[[session/dialog/sharegpt_b76JUGd_65.jsonl]]'
---

### **Case Overview: Brewarrina Shire Council v Beckhaus Civil Pty Ltd & 1 Or [2005] NSWCA 248** [[session/dialog/sharegpt_b76JUGd_65.jsonl#L1]]
- The case involves a dispute between Brewarrina Shire Council and Beckhaus Civil Pty Ltd regarding a contract for the construction of flood levees and associated works.
- The dispute originated from defective work, project delays, and the subsequent termination of the contract.
- The matter proceeded through multiple hearings and appeals, concluding with a final decision delivered by the New South Wales Court of Appeal.
- Main Issues Addressed:
  - Validity of the contract termination executed by the council and the contractor's entitlement to claim compensation for work performed prior to termination.
  - Application of the *Building and Construction Industry Security of Payment Act 1999 (NSW)* concerning progress payments and statutory work suspension rights.
  - Availability and enforceability of liquidated damages for project delays and defective work under the contractual terms.
  - Determination of appropriate litigation costs orders.
- The case clarifies the legal rights and obligations of parties operating within construction contracts.
- The case establishes significant precedent regarding the application of the *Building and Construction Industry Security of Payment Act 1999 (NSW)* in construction-related disputes.

### **Significance of Termination of Contract** [[session/dialog/sharegpt_b76JUGd_65.jsonl#L2-L3]]
- A homeowner encounters potential difficulties claiming damages for defective or incomplete work if the building contract has not formally ended.
- Delayed completion damages are only awardable while the building contract remains active ("on foot").
- The contract must conclude, either through a valid termination procedure or via the acceptance of repudiatory conduct.
- Contract termination holds strategic importance because it unlocks the homeowner's ability to pursue claims for damages associated with defective or incomplete work.
| Issue | Key Points |
| --- | --- |
| Difficulties in claiming damages | A homeowner may face difficulties in claiming damages for defective or incomplete work if the building contract has not ended. |
| Delayed completion damages | Only delayed completion damages can be awarded so long as the building contract remains on foot. |
| Contract termination | The contract must end, either by a valid termination or by acceptance of repudiatory conduct. |
| Importance of termination of contract | The termination of the contract is significant because it allows the homeowner to claim damages for defective or incomplete work. |
- Understanding these legal principles derived from *Brewarrina Shire Council v Beckhaus Civil Pty Ltd & 1 Or [2005] NSWCA 248* assists homeowners navigating the New South Wales Civil and Administrative Tribunal (NCAT) claims process to secure entitled financial compensation.

### **Repudiatory Conduct and Termination** [[session/dialog/sharegpt_b76JUGd_65.jsonl#L4-L5]]
- Within the framework of *Brewarrina Shire Council v Beckhaus Civil Pty Ltd & 1 Or [2005] NSWCA 248*, homeowners must establish that the building contract ended via valid termination or acceptance of repudiatory conduct to legally claim damages for defective or incomplete work.
- Definition of Repudiatory Conduct: Occurs when one party breaches a fundamental term of the contract, or signals a clear intention not to perform obligations outlined in the contract.
- Examples of Repudiatory Conduct in Building Contracts:
  - Refusing to complete necessary project work.
  - Failing to meet agreed deadlines or milestones without valid justification.
  - Refusing to rectify defective work or complying with building codes and regulations.
  - Abandoning the project without a valid reason.
- Methods of Termination:
  - Mutual agreement between the parties.
  - Unilateral action initiated by one of the parties.
- Valid Termination Requirements: Homeowners must adhere to established termination procedures, which typically include providing written notice, strictly following contractual notice periods, and ensuring the termination stems from a substantiated valid reason.
- Effect of Termination: Once terminated, homeowners gain the legal capacity to claim damages for defective or incomplete work completed prior to the termination event. Termination permanently concludes the builder's right to execute further project work and immediately creates grounds for a formal breach of contract claim.
| Repudiatory conduct | Termination | Effect of termination |
| --- | --- | --- |
| Occurs when one party breaches a fundamental term or indicates an intention not to perform their obligations under the contract | May be carried out by mutual agreement or unilateral action by one of the parties | Ends the builder's right to carry out any further work on the project and may give rise to a claim for breach of contract |
| Examples include refusing to complete work, failing to meet deadlines, refusing to rectify defective work, and abandoning the project | Must follow proper process for termination, including giving notice in writing and complying with any notice periods required by the contract | Homeowners may be able to claim damages for any defective or incomplete work carried out prior to termination |

### **Blessed Sydney Constructions PL v Vasudevan Case** [[session/dialog/sharegpt_b76JUGd_65.jsonl#L6-L7]]
- The Appeal Panel evaluated how the *Brewarrina* principle influences renewal powers under CATA Schedule 4 paragraph 8 and determines the types of remedial orders permissible on renewal applications.
- Case Background:
  - A building dispute occurred between an owner and a builder.
  - The owner aimed to terminate the contract and claim breach damages.
  - The parties achieved a consent work order that reserved renewal power, simultaneously instructing the builder to rectify defective work.
  - Non-compliance by the builder prompted the owner to initiate a renewal application requesting a money order.
- Impact of the Brewarrina Principle on Renewal Applications:
  - The Appeal Panel ruled that orders available on a renewal application are NOT restricted by the *Brewarrina* principle.
  - Rationale: The contract concluded upon the Tribunal accepting the owner's termination request. The owner's election to terminate for breach (evidenced by the renewal application seeking a money order) became effective upon the vacation or variation of the original work order.
- Available Orders on Renewal Application:
  - A money order falls within HBA Schedule 4 paragraph 8, representing "any other … order… as it could have made when the matter was originally determined."
  - These permitted orders align with the broader range authorized under HBA section 48O, grounded in general law principles referenced in *Brewarrina*.
  - Permitted orders specifically include:
    - Rectification orders
    - Money orders
    - Any other order the Tribunal possessed the jurisdictional authority to issue during the original determination
- Electing to Terminate Strategy:
  - The owner successfully elected to terminate the contract and pursued a money order on renewal, securing Tribunal orders completely free from *Brewarrina* constraints.
  - Homeowners must thoroughly grasp the procedural consequences of electing termination alongside damage claims, as this strategic choice directly dictates the spectrum of available remedial orders.
| Topic | Details |
| --- | --- |
| Case Name | Blessed Sydney Constructions PL v Vasudevan |
| Issues | Impact of Brewarrina principle on renewal power and types of orders available on renewal applications |
| Background | Building dispute between owner and builder with consent work order |
| Tribunal's decision | Order to rectify defective work not complied with, renewal of order sought for money order |
| Impact of Brewarrina principle | Not constrained by the Brewarrina principle because the contract had ended and owner elected to terminate for breach |
| Types of orders available | Rectification orders, money orders, any other order that the Tribunal could have made when the matter was originally determined |
| Electing to terminate | Homeowners need to understand the implications of electing to terminate and seeking damages |
