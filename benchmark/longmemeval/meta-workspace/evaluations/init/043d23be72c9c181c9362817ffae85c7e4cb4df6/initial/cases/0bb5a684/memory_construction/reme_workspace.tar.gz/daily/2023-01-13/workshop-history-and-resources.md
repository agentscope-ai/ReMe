---
description: A consolidated record of the participant's recent seminar engagements—spanning
  photography, digital marketing, entrepreneurship, and mindfulness—with specific
  dates, venues, costs, and outcomes (e.g., pitching ideas, receiving workbooks).
  This entry also aggregates a complete directory of recommended external resources,
  including online courses, technical photography techniques, gear specifications,
  and organizations for finding future educational events in professional and personal
  development fields.
name: workshop-history-and-resources
session_id: 826d51da_3
source_conversation: '[[session/dialog/826d51da_3.jsonl]]'
---

## Personal Workshop History & Outcomes [[session/dialog/826d51da_3.jsonl#L1-L1,L3-L3,L5-L5,L7-L7,L9-L11]]
- **Portrait Photography Workshop**: Attended a one-day event on February 22 at a local studio; the event was free but required advance online registration.
- **Digital Marketing Workshop**: Attended a two-day intensive held at the city convention center from March 15 to March 16; key learnings included social media advertising and Search Engine Optimization (SEO); the participant has actively implemented these strategies into their own business with positive results.
- **Entrepreneurship Workshop**: Completed a three-day program in January at a downtown coworking space, organized by a startup accelerator program; the participant was selected from a pool to be one of 20 participants.
    - Key activities: Learned from experienced entrepreneurs and investors; pitched a business idea to a panel of judges.
    - Outcomes: Received valuable feedback and established connections for potential collaborations or investments.
    - Future Intent: Actively considering applying to other startup accelerator programs and incubators to scale the business.
- **Mindfulness & Wellness Workshop**: Attended a half-day session on December 12 at a yoga studio near home; cost $20 USD; received a takeaway workbook containing exercises and tips.
- **Learning Philosophy**: Believes attending diverse workshops makes one well-rounded; identifies communication and problem-solving as transferable skills across industries; values networking with people from different backgrounds.

## Recommended Educational Platforms & Communities [[session/dialog/826d51da_3.jsonl#L2-L2,L4-L4,L8-L8]]
- **Online Learning Sites**: Udemy (beginner to advanced portrait photography), Skillshare (lighting, posing, editing), CreativeLive (live workshops).
- **Video Tutorials**: YouTube channels run by Peter McKinnon, Tony Northrup, and Jessica Kobeissi.
- **Photography Blogs & Networks**: Digital Camera World, 500px, Portrait Photography Tips, Fstoppers.
- **Event Discovery Tools**: Meetup.com, Eventbrite.com, Facebook Events, Google Search (keywords: "photography workshops near me").
- **Professional Associations**: Professional Photographers of America (PPA), Wedding and Portrait Photographers International (WPPI).
- **Business & Entrepreneurship Resources**: General Assembly, Entrepreneurs' Organization (EO), Startup Grind, Inc.com, Forbes, TED Conferences, Local Business Journals, Industry-specific conferences.

## Technical Photography Guidelines & Gear [[session/dialog/826d51da_3.jsonl#L2-L2]]
- **Fundamentals**: Master the exposure triangle (ISO, aperture, shutter speed).
- **Techniques**: Improve communication/direction with subjects; master lighting (natural/artificial/shadows); apply composition rules (rule of thirds, leading lines, framing).
- **Workflow**: Practice regular shooting; edit photos using Lightroom and Photoshop.
- **Equipment Recommendations**:
    - Cameras/Lenses: Invest in full-frame cameras and prime lenses (specifically 50mm or 85mm).
    - Accessories: Use reflectors and diffusers to control light; experiment with backdrops and props.
