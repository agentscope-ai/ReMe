---
description: Planning a fall-themed dinner for the user's parents in May 2023. Covers
  recipe selection, detailed preparation steps for Apple Cider Braised Short Ribs
  and Apple Crisp, wine pairing strategy resulting in the selection of King Estate
  Pinot Noir, and dessert options.
name: fall-dinner-planning-with-parents
session_id: e57f4635
source_conversation: '[[session/dialog/e57f4635.jsonl]]'
---

## Fall Dinner Planning with Parents
- The user planned a fall-themed dinner for their parents during the week of May 2023.
- The assistant suggested seven dishes: Apple Cider Braised Short Ribs with Mashed Sweet Potatoes, Roasted Butternut Squash and Sage Risotto, Maple-Glazed Pork Chops with Roasted Carrots and Parsnips, Spiced Pumpkin and Lentil Stew, Cranberry-Orange Glazed Chicken with Roasted Brussels Sprouts and Sweet Potatoes, Beef and Mushroom Stroganoff with Egg Noodles, and Fall Harvest Salad with Apple Cider Vinaigrette.
- The user chose Apple Cider Braised Short Ribs with Mashed Sweet Potatoes.
[[session/dialog/e57f4635.jsonl#L1-L3]]

## Main Course Recipe Details
**Apple Cider Braised Short Ribs with Mashed Sweet Potatoes** serves 4–6 people.
- **Short Ribs Ingredients**: 4 pounds beef short ribs, 2 tablespoons olive oil, 1 diced onion, 3 minced garlic cloves, 1 cup apple cider, 1 cup beef broth, 1 tablespoon tomato paste, 1 teaspoon dried thyme, 1/2 teaspoon salt, 1/4 teaspoon black pepper, 2 bay leaves (optional).
- **Mashed Sweet Potatoes Ingredients**: 3–4 large peeled and cubed sweet potatoes, 2 tablespoons butter, 1/2 cup heavy cream or half-and-half, salt and pepper to taste.
- **Instructions**: Preheat oven to 300°F (150°C). Season ribs with salt, pepper, and thyme. Sear ribs in olive oil over medium-high heat for 5 minutes per side. Remove ribs. Soften onions, add garlic. Add apple cider, beef broth, tomato paste, and bay leaves. Return ribs to liquid, cover, and braise in oven for 2.5 to 3 hours until tender. Boil sweet potatoes until tender (15–20 minutes), drain, and mash with butter and cream.
- **Tips & Variations**: A slow cooker alternative exists (8–10 hours on low, 4–6 hours on high). Additional spices like cinnamon stick, cloves, or nutmeg can enhance flavor. Unbraised components can be refrigerated or frozen for make-ahead preparation.
[[session/dialog/e57f4635.jsonl#L4-L4]]

## Wine Pairing Strategy
- The user requested wine pairing recommendations for the selected main course.
- The assistant proposed several options: Pinot Noir, Grenache-based Red Blend, Syrah/Shiraz, Cabernet Franc, Riesling, and Brut Rosé sparkling wine.
- The user chose Pinot Noir and asked for specific brand recommendations.
- The assistant recommended five specific Pinot Noirs: King Estate Pinot Noir (Oregon, USA), Domaine Serene Yamhill Pinot Noir (Oregon, USA), Meiomi Pinot Noir (California, USA), Bourgogne Pinot Noir (Burgundy, France), and Greywacke Pinot Noir (Marlborough, New Zealand). Budget-friendly alternatives in Germany or Italy were also suggested.
- The user finalized the selection with King Estate Pinot Noir.
[[session/dialog/e57f4635.jsonl#L5-L9]]

## Dessert Selection & Recipe
- The user requested dessert recommendations to accompany the short ribs and King Estate Pinot Noir.
- The assistant suggested: Apple Crisp, Pumpkin Spice Crème Brûlée, Maple Pecan Pie Bars, Cranberry Oatmeal Cookies, and Vanilla Ice Cream with Caramel Sauce and Pecans. For dessert wine pairings, Tawny Port and Moscato d'Asti were recommended.
- The user selected Apple Crisp.

### Apple Crisp Recipe
- Serves 6–8 people. Oven temperature: 375°F (190°C). Baking time: 35–40 minutes.
- **Filling Ingredients**: 6–8 medium peeled and sliced apples, 1/2 cup granulated sugar, 2 tablespoons all-purpose flour, 1 teaspoon cinnamon, 1/4 teaspoon nutmeg, 1/4 teaspoon salt.
- **Topping Ingredients**: 1/2 cup rolled oats, 1/2 cup brown sugar, 1/2 cup cold unsalted butter (cut into small pieces).
- **Procedure**: Mix apples with filling ingredients. Transfer mixture to a 9x9-inch baking dish. Combine oat topping ingredients until crumbly, spread evenly over apples. Bake until topping is golden and apples are tender. Serve warm with vanilla ice cream or whipped cream.
- **Tips**: Use mixed apple varieties like Granny Smith and Honeycrisp for balance. Avoid overmixing the oat topping. Extend baking by 5–10 minutes for a crispier topping.
[[session/dialog/e57f4635.jsonl#L10-L12]]
