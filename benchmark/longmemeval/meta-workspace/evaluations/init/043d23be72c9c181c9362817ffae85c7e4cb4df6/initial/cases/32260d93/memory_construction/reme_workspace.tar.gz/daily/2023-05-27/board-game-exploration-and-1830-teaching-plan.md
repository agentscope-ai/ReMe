---
description: A consultation regarding train-themed board game recommendations where
  the user—currently playing 'Ticket to Ride' weekly with their siblings on Sunday
  evenings—explored various titles including 'Train Station', 'Railways of the World',
  'Locomotive Werks', and 'Railroad Revolution'. The discussion detailed mechanics
  for the complex '18xx' series, recommending '1830' as an accessible entry point
  based on its manageable length (2-6 hours) and core economic mechanics (stock rounds,
  dividends). The user committed to purchasing '1830' and received a comprehensive
  instructional framework designed to onboard inexperienced siblings, covering pre-session
  preparation, simplified rule introductions, specific novice gameplay advice (financial
  management, network focus), and post-game review techniques.
name: board-game-exploration-and-1830-teaching-plan
session_id: d6bbe94d_3
source_conversation: '[[session/dialog/d6bbe94d_3.jsonl]]'
---

## Gaming Context and Preferences [[session/dialog/d6bbe94d_3.jsonl#L1]]
- The user engages in weekly *Ticket to Ride* sessions with their siblings every Sunday evening and is seeking new train-themed board game recommendations that offer a similar social competitive experience.

## Board Game Recommendations [[session/dialog/d6bbe94d_3.jsonl#L2]]
- The assistant proposed six distinct train-themed titles: *Train Station*, *Railways of the World*, *TransAmerica*, *Locomotive Werks*, *Railroad Revolution*, and the *18xx* series.
- *Train Station* and *Railways of the World* were highlighted as the closest stylistic matches to *Ticket to Ride*.

## Detailed Mechanics and Comparisons
### 18xx Series Overview [[session/dialog/d6bbe94d_3.jsonl#L4]]
- The *18xx* franchise is characterized by deep economic simulations, extensive rulesets, and a steep learning curve intended for experienced gamers.
- Standard gameplay spans four phases: the **Stock Round** (buying/selling shares), the **Operating Round** (building tracks/managing trains), **Dividend Payment** (income distribution), and the **Game End** (highest net worth wins upon nationalization or set rounds).
- Playtime typically ranges from two to six hours depending on the title and player count.
- *1830* and *1856* were identified as the most accessible entry points for beginners entering the genre.

### Railroad Revolution Mechanics [[session/dialog/d6bbe94d_3.jsonl#L6]]
- *Railroad Revolution* utilizes a modular map composed of interlocking tiles, ensuring unique layouts and high replayability.
- Core mechanics include strategic route-building, area control to limit opponents, and resource management involving coal, iron, and currency.
- Relative to *Ticket to Ride*, it offers a more tactical, abstract experience with a stronger emphasis on engine-building and blocking rival expansion.

### Locomotive Werks Logistics [[session/dialog/d6bbe94d_3.jsonl#L8]]
- *Locomotive Werks* centers on mechanical customization and delivery logistics using resources such as coal, water, and crew members.
- Players utilize **Contract Cards** to identify required cargo, destination cities, and payout values; success depends on matching locomotive capacity to these requirements.
- Delivering goods stimulates target city growth, which unlocks further contracts and resource hubs.
- The board features dynamic, randomized tile arrangements that alter geographic configurations every session, forcing adaptive route planning.

## Decision and Instructional Framework [[session/dialog/d6bbe94d_3.jsonl#L9-L12]]
- **Acquisition**: The user resolved to begin their gaming library expansion with the acquisition of *1830*.
- **Pre-Session Preparation**: Before playing, explain the overarching financial/empire-building objective and physically demonstrate component functionality (maps, rolling stock, currency, stock certificates).
- **Instructional Methodology**:
    - Deploy stripped-down rule sets initially, focusing strictly on core mechanics before introducing edge cases.
    - Actively reference the official *1830* tutorial scenario chapter to guide novices.
    - Introduce individual railroad corporations sequentially to prevent cognitive overload.
    - Perform live demonstrations of standard action cycles to model proper turn flow.
- **Novice Operator Guidance**:
    - Advise players to secure advantageous initial corporation charters—specifically citing the *Pennsylvania Railroad* as an exemplar model.
    - Prioritize foundational track expansion and network connectivity over aggressive profit extraction during early turns.
    - Maintain strict cash reserves to mitigate the risk of bankruptcy.
    - Continuously monitor macro-state indicators, including equity valuations and competitor maneuvers.
- **Post-Game Review**: Conduct structured reviews contrasting planned versus executed strategies, solicit direct pedagogical feedback from novice participants, and iteratively refine facilitation techniques accordingly.
