---
description: 'On 2023-05-29T20:46:00, a request was submitted to compose an email
  declining approval for an ArcGIS Online (AGOL) Story Map submission due to violation
  of the 2020 ERH policy. The drafted rejection email uses the subject line "ArcGIS
  Online Story Map Submission - Rejection" and contains five components: (1) formal
  notification that the AGOL Story Map will not receive approval citing the 2020 ERH
  policy restriction, (2) acknowledgment of substantial effort invested in creating
  the Story Map with an apology for inconvenience, (3) justification based on maintaining
  system security and data stability, (4) invitation for questions or concerns, and
  (5) offer to discuss the rejection decision further.'
name: agol-story-map-rejection-erh-policy
session_id: sharegpt_6ZpPBwe_0
source_conversation: '[[session/dialog/sharegpt_6ZpPBwe_0.jsonl]]'
---

## Email Drafting Request [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L1-L1]]

* At 2023-05-29T20:46:00, a request was submitted to compose an email declining approval for an ArcGIS Online (AGOL) Story Map submission that was sent for review.

## Regulatory Basis for Non-Approval [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L1-L1]]

* The AGOL Story Map submission violates the ERH policy established in 2020, which explicitly mandates that there will be no "live/dynamic" AGOL pages made public in the ER environment.

## Drafted Rejection Email Structure [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L7]]

* The composition utilizes the exact subject line: "ArcGIS Online Story Map Submission - Rejection".
* The opening paragraph formally notifies the recipient that the submitted AGOL Story Map will not receive approval due to the aforementioned 2020 ERH policy restriction against live/dynamic AGOL pages being published in ER.
* The second paragraph recognizes significant effort invested by the creator in developing the Story Map and includes an apology for any inconvenience caused by the non-approval determination.
* The third paragraph provides justification for policy enforcement, citing the necessity of preserving overall system security and data integrity as the rationale for maintaining these restrictions.
* The closing paragraph invites the recipient to contact with questions or concerns and expresses willingness to discuss the rejection decision further.
