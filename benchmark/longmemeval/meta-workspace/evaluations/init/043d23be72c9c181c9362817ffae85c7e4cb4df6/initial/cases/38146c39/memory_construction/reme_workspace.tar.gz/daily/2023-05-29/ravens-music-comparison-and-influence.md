---
description: Stylistic comparison of the 1940s R&B group The Ravens against peers
  like The Ink Spots, The Mills Brothers, and successors like The Temptations and
  The Four Tops, highlighting their raw, blues-heavy sound, stripped-down instrumentation,
  and pioneering role in doo-wop. Details modern R&B artists influenced by The Ravens
  (Boyz II Men, Brian McKnight, Bruno Mars, John Legend) and specific ways they incorporate
  harmonies, rhythms, or gospel influences. Concludes with five recommended starting
  tracks by The Ravens.
name: ravens-music-comparison-and-influence
session_id: ultrachat_321216
source_conversation: '[[session/dialog/ultrachat_321216.jsonl]]'
---

## The Ravens' Musical Style and Historical Impact
- The Ravens were a pioneering R&B group formed in the 1940s whose musical style blended swing, gospel, and blues [[session/dialog/ultrachat_321216.jsonl#L2-L2]]
- The Ravens' harmonizing vocals and upbeat tempo distinguished The Ravens from contemporaries such as The Ink Spots and The Mills Brothers, which groups primarily focused on ballads and crooning styles
- When compared to later R&B groups like The Temptations and The Four Tops, The Ravens possessed a rawer and unpolished sound with a stronger bluesy edge
- The Ravens utilized stripped-down instrumentation characterized by fewer horns and a heavier reliance on vocals and the rhythm section
- The Ravens established foundational standards for subsequent doo-wop and R&B acts, specifically through pioneering work in vocal harmonization and upbeat, danceable rhythms

## Modern Artists Influenced by The Ravens
- Boyz II Men cites The Ravens as a direct influence, integrating similar harmonizing vocals into their own intricate harmonies and romantic ballads, evident in tracks like "motownphilly" [[session/dialog/ultrachat_321216.jsonl#L4-L4,L6-L6]]
- Brian McKnight heavily adopts The Ravens' influence, specifically within his application of smooth and soulful vocal harmonies
- Bruno Mars draws inspiration from The Ravens' emphasis on danceable rhythms and catchy hooks, blending funk, soul, and pop elements into upbeat, uptempo arrangements designed to engage listeners, as seen in the track "uptown funk"
- John Legend incorporates The Ravens' gospel and blues influences directly into his music, utilizing soulful and emotive vocal performances reminiscent of The Ravens' early recordings

## Recommended Starting Songs by The Ravens
- "count every star": Recognized as The Ravens' most widely known song and a definitive showcase of their signature harmonizing vocal technique [[session/dialog/ultrachat_321216.jsonl#L10-L10]]
- "ol' man river": A cover of a classic show tune that The Ravens reinterpreted with powerful vocals and a blues-oriented arrangement
- "deep purple": A classic recording that highlights both the group's harmonizing capabilities and their ability to deliver romantic lyrical themes
- "write me a letter": An energetic, upbeat track driven by a swing-influenced rhythm and featuring robust vocal performances alongside catchy hooks
- "a simple prayer": A comparatively lesser-known track that distinctly demonstrates The Ravens' gospel foundations alongside complex vocal harmonies
