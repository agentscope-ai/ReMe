---
description: Comprehensive documentation of System Development Life Cycle (SDLC) phases
  and their application to web application development. Detailed breakdown of Information
  System (IS) models covering input, processing, output, and feedback components.
  Explanation of Management Information System (MIS) characteristics and pyramid structure.
  Five-step procedure for Business and System Justification. Catalog of 15-mark academic
  examination topics including CRM, SCM, DSS, database structures, security layers,
  and FMCG marketing strategies.
name: sdlc-phases-and-information-system-models
session_id: sharegpt_9sravsc_61
source_conversation: '[[session/dialog/sharegpt_9sravsc_61.jsonl]]'
---

## System Development Life Cycle (SDLC) Phases
The System Development Life Cycle (SDLC) consists of seven structured phases used to develop high-quality information systems:
- **Planning Phase**: Project goals and objectives are identified, feasibility studies determine project worthiness, and preliminary budgets/schedules are created.
- **Analysis Phase**: Stakeholder requirements are gathered, analyzed for specifications, and existing business processes are mapped to the new system.
- **Design Phase**: A detailed blueprint is created based on requirements, encompassing system architecture, hardware/software specifications, and database design.
- **Development Phase**: The system is constructed according to design specifications via software coding, hardware installation, and database schema creation.
- **Testing Phase**: Functional, performance, and security tests ensure the system operates correctly, is bug-free, and meets stakeholder expectations.
- **Implementation Phase**: The system is deployed into the production environment, users receive training, and integration into organizational workflows occurs.
- **Maintenance Phase**: Ongoing modifications are applied to ensure the system remains relevant and continues meeting stakeholder needs.

[[session/dialog/sharegpt_9sravsc_61.jsonl#L1-L1]]

## SDLC Example: Web Application Development
Applying SDLC principles to web application development follows specific deliverables per phase: Planning identifies purpose, scope, budget, timeline, and resources; Analysis determines user needs, business processes, and project feasibility while identifying potential roadblocks; Design establishes system architecture, software design, database schema, UI designs, and technical specifications; Development entails writing code, creating databases, building interfaces, and executing unit/integration/acceptance tests to resolve bugs; Implementation prepares infrastructure, installs the application on servers, and deploys it to production; Maintenance provides ongoing support, regular updates, enhancements, and bug fixes over time.

[[session/dialog/sharegpt_9sravsc_61.jsonl#L3-L3]]

## Foundational Information System (IS) and Management Information System (MIS) Models
An Information System functions as interconnected components collecting, processing, storing, and disseminating information to support decision-making, coordination, and control. Its core structural components are:
- **Input**: Data collection in text, images, audio, or video formats requiring high accuracy and quality for system effectiveness.
- **Processing**: Manual, automated, or hybrid manipulation of input data involving calculations, sorting, and filtering.
- **Output**: Results delivered as reports, charts, graphs, or tables, prioritizing relevance and usefulness to stakeholders.
- **Feedback**: Generated information routed back to the input stage for performance monitoring and system improvements.

Business and system justification within an IS framework requires aligning the information system with organizational goals, identifying supported business processes, defining precise data requirements, and rigorously evaluating costs versus benefits.

Management Information Systems exhibit essential characteristics of timeliness, accuracy, relevance, completeness, consistency, and user-friendly formatting. MIS utilizes a hierarchical pyramid structure organizing information across three distinct management levels:
- **Operational Level**: Manages day-to-day activities and routine transactions.
- **Management Level**: Focuses on monitoring and controlling ongoing operations.
- **Strategic Level**: Handles long-term planning and high-level decision-making.

[[session/dialog/sharegpt_9sravsc_61.jsonl#L5-L5]]

## Business and System Justification Process
Business and system justification is a structured methodology to ensure an organization adopts the correct information system for its operational and strategic needs. The justification process comprises five sequential steps:
1. **Identifying Business Needs**: Understanding organizational objectives, current problems, and operational challenges.
2. **Conducting a Feasibility Study**: Assessing technical, economic, and operational viability of implementing proposed solutions.
3. **Selecting the Information System**: Choosing the optimal system based on functionality, cost efficiency, and future scalability.
4. **Implementing the Information System**: Configuring the system to specific requirements, conducting pre-live testing, and providing comprehensive user training.
5. **Monitoring and Evaluating the Information System**: Performing continuous audits and periodic assessments to verify ongoing alignment with business goals and identify improvement areas.

[[session/dialog/sharegpt_9sravsc_61.jsonl#L9-L9]]

## User-Requested Examination Topics
A user submitted a comprehensive list of academic examination questions spanning Management Information Systems and IT strategy. Requested topics requiring detailed 15-mark coverage include: constructing a Marketing Information System (MKIS) for FMCG distribution organizations; summarizing various facets of the SDLC; analyzing functional modules of financial information systems; illustrating Decision Support System (DSS) program structures; evaluating Internet business applications; analyzing Customer Relationship Management (CRM) systems in customer-focused strategies; appraising intranet and extranet functionalities; examining Supply Chain Management (SCM) features and major models; evaluating Information Technology's strategic role in achieving competitive advantage; contrasting database structures regarding advantages and disadvantages; analyzing various database keys; designing Entity-Relationship (ER) diagrams for online shopping processes; and assessing trends opposing computerized Information Systems alongside required information security layers.

[[session/dialog/sharegpt_9sravsc_61.jsonl#L4-L4]]
