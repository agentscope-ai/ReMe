---
description: Comprehensive record of music discovery preferences initiated by the
  band Glass Animals, resulting in extensive artist recommendations (Tame Impala,
  Alt-J, Foals, etc.) and song suggestions. Includes user listening habits (Spotify
  commuting playlists) and established podcast subscriptions (All Songs Considered,
  Pitchfork) alongside new podcast recommendations. Documents confirmed plans to attend
  The Black Keys and The 1975 concerts in July 2023, and requests for similar artists
  (Pale Waves, The Neighbourhood) mirroring The 1975. Finally, compiles categorized
  lists of music documentaries and clarifies streaming availability issues for Beyoncé's
  "Homecoming."
name: music-discovery-recommendations
session_id: bf2ca4d8
source_conversation: '[[session/dialog/bf2ca4d8.jsonl]]'
---

### Music Taste & Discovery Preferences [[session/dialog/bf2ca4d8.jsonl#L1-L2]]
- On 2023-05-27, the user expressed an interest in indie-rock and mentioned discovering the band Glass Animals.
- Recommendations for artists similar to Glass Animals include:
    - Tame Impala (Kevin Parker’s project)
    - Unknown Mortal Orchestra (New Zealand-based blend of rock and psychedelia)
    - Foals (math rock-infused indie sound)
    - alt-J (British trio blending rock with electronics)
    - MGMT
    - Temples
    - Pond
    - King Gizzard & the Lizard Wizard
    - The Black Angels
    - Mild High Club (Los Angeles-based)

### Listening Habits & Podcast Sources [[session/dialog/bf2ca4d8.jsonl#L3-L6]]
- The user utilizes Spotify to discover new tracks and creates playlists for their daily commute.
- The user confirms subscribing to the music podcasts "All Songs Considered" (NPR) and "Pitchfork".
- Recommendations for additional podcasts to explore include:
    - KCRW's Morning Becomes Eclectic
    - The Needle Drop (focuses on underground rock and electronic)
    - NME's New Music Show
    - Indiecast
    - The Fader's The Mix
    - Song Exploder
    - KEXP's Song of the Day
    - The Adam Buxton Podcast
- Methods provided for locating local concerts include using tracking platforms like Songkick and Bandsintown, checking local venue websites, searching music blogs, and utilizing Google searches.

### Live Events & Concert Plans [[session/dialog/bf2ca4d8.jsonl#L7]]
- The user announced purchasing tickets to see The Black Keys and The 1975 perform live in July 2023.

### Artists & Tracks Similar to The 1975 [[session/dialog/bf2ca4d8.jsonl#L8]]
- To align with the user's interest in The 1975, the following similar artists were recommended:
    - Pale Waves (Manchester-based indie-pop with 80s synths)
    - The Neighbourhood
    - Two Door Cinema Club
    - Walk the Moon
    - COIN
- Recommended songs sharing stylistic similarities to The 1975 include:
    - Arctic Monkeys - "Do I Wanna Know?"
    - The XX - "Intro"
    - Foals - "My Number"
    - Panic! At The Disco - "High Hopes"
    - Bleachers - "Don't Take the Money"

### Music Documentaries & Streaming Clarifications [[session/dialog/bf2ca4d8.jsonl#L9-L12]]
- The user requested recommendations for music documentaries available on YouTube. Categorized lists provided included:
    - **Classic/Iconic**: *The Last Waltz* (1978), *Gimme Shelter* (1970), *The Song Remains the Same* (1976).
    - **Indie/Alternative**: *The Punk Rock Movie* (1978), *Hype!* (1996), *The Decline of Western Civilization* (1981).
    - **Hip-Hop/R&B**: *Style Wars* (1983), *The Art of Rap* (2012), *The Soul of a Man* (2003).
    - **Festivals/Concert Films**: *Woodstock* (1970), *Coachella: 20 Years in the Desert* (2020), *Stop Making Sense* (1984).
- The user initially sought out Beyoncé's documentary "Homecoming" on YouTube; however, it was clarified that "Homecoming: A Film by Beyoncé" is a Netflix exclusive featuring footage and rehearsals of her historic 2018 Coachella performance celebrating historically black colleges and universities (HBCUs).
