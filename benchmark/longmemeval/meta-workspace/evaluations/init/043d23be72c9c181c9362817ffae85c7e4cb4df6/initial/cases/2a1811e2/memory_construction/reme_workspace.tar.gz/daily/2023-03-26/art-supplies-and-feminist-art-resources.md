---
description: Detailed recommendations for art supplies including acrylic, watercolor,
  and oil paint brands (Winsor & Newton, Daler-Rowney, Daniel Smith, Gamblin); natural
  and synthetic brush options; and online retailers. Documents artistic interests
  in mixed media and feminist art inspired by Rachel Lee, along with curated lists
  of feminist art artists (Judy Chicago, Faith Ringgold, Wangechi Mutu), mixed media/assemblage
  artists (Louise Nevelson, Joseph Cornell), contemporary identity-focused artists,
  and relevant historical books (Cornelia Butler, Gabriele Schor). Includes links
  to educational platforms (Coursera, MoMA, Khan Academy, edX, Udemy) and digital
  archives like The Feminist Art Base and The Schlesinger Library at Harvard. User
  is actively taking an online art history course.
name: art-supplies-and-feminist-art-resources
session_id: 901a6763_2
source_conversation: '[[session/dialog/901a6763_2.jsonl]]'
---

### Art Supply Recommendations
- Project requires high-quality paints and brushes [[session/dialog/901a6763_2.jsonl#L1-L1,L2-L2]].
- Acrylic paints: Winsor & Newton's Galeria or Daler-Rowney's System 3 (known for vibrant colors, lightfastness, and durability) [[session/dialog/901a6763_2.jsonl#L2-L2]].
- Watercolor paints: Daniel Smith, Holbein, or Schmincke (offering rich, transparent washes and excellent pigment load) [[session/dialog/901a6763_2.jsonl#L2-L2]].
- Oil paints: Grumbacher or Gamblin (providing high-quality, lightfast pigments with smooth consistency) [[session/dialog/901a6763_2.jsonl#L2-L2]].
- Natural hair brushes: Sable, mongoose, or squirrel hair brushes from Winsor & Newton, Daler-Rowney, or Robert Simmons (best for water-holding capacity and maintaining a fine point) [[session/dialog/901a6763_2.jsonl#L2-L2]].
- Synthetic brushes: Alternatives from brands like Golden, Liquitex, or Princeton (offering excellent performance at lower price points) [[session/dialog/901a6763_2.jsonl#L2-L2]].
- Recommended online art supply retailers include Dick Blick Art Materials, Jerry's Artarama, Cheap Joe's Art Stuff, and Amazon (advised to check reviews and ratings) [[session/dialog/901a6763_2.jsonl#L2-L2]].

### Art Inspiration and Artist Interests
- Seeking local artists or exhibitions specializing in mixed media or feminist art [[session/dialog/901a6763_2.jsonl#L3-L3]].
- Drawing recent inspiration from Rachel Lee's work and wanting to explore similar artistic veins [[session/dialog/901a6763_2.jsonl#L3-L3]].
- Discovery methods include following local artists and galleries on social media platforms (Instagram, Facebook, Twitter) and searching online platforms such as Artsy, Behance, and DeviantArt [[session/dialog/901a6763_2.jsonl#L4-L4]].
- Investigating local art festivals, fairs, markets, artist collectives, cooperatives, and university student exhibitions to discover emerging talent and contact artists regarding upcoming events [[session/dialog/901a6763_2.jsonl#L4-L4]].
- Key figures in the feminist art movement to explore: Judy Chicago, Miriam Schapiro, and Faith Ringgold [[session/dialog/901a6763_2.jsonl#L4-L4]].
- Pioneers in mixed media and assemblage techniques to study: Louise Nevelson, Robert Rauschenberg, and Joseph Cornell [[session/dialog/901a6763_2.jsonl#L4-L4]].
- Contemporary artists addressing identity, feminism, and social justice using mixed media: Wangechi Mutu, Mickalene Thomas, and Lorna Simpson [[session/dialog/901a6763_2.jsonl#L4-L4]].

### Book Recommendations
- "The Dinner Party" by Judy Chicago [[session/dialog/901a6763_2.jsonl#L6-L6]].
- "Feminist Art and the Maternal" by Andrea Liss (explores the relationship between feminist art and motherhood, featuring Mary Kelly and Mierle Laderman Ukeles) [[session/dialog/901a6763_2.jsonl#L6-L6]].
- "Gender and Art" by Gill Perry (an introduction to the relationships between gender, art, and culture) [[session/dialog/901a6763_2.jsonl#L6-L6]].
- "WACK! Art and the Feminist Revolution" by Cornelia Butler (the official catalog for the 2007 Museum of Contemporary Art Los Angeles exhibition, showcasing over 100 feminist artists) [[session/dialog/901a6763_2.jsonl#L6-L6]].
- "The Feminist Avant-Garde of the 1970s" by Gabriele Schor (a comprehensive survey featuring Cindy Sherman and Martha Rosler) [[session/dialog/901a6763_2.jsonl#L6-L6]].

### Online Courses and Educational Platforms
- Actively engaged in a helpful online course focused on art history [[session/dialog/901a6763_2.jsonl#L7-L7]].
- Coursera offers "Feminism and Social Justice" developed by University of California, Irvine, exploring feminist thought and its societal impact [[session/dialog/901a6763_2.jsonl#L6-L6]].
- Institutional educational resources available through MoMA Learning, Tate Modern, and Khan Academy (the latter covering the Guerrilla Girls and Riot Grrrl movement) [[session/dialog/901a6763_2.jsonl#L6-L6]].
- Additional online learning platforms for specialized courses include edX, FutureLearn, and Udemy [[session/dialog/901a6763_2.jsonl#L8-L8]].
- The Feminist Art Project functions as a digital archive and community hub featuring artist profiles, exhibitions, and learning resources [[session/dialog/901a6763_2.jsonl#L6-L6]].

### Digital Archives and Research Libraries
- The Feminist Art Base (a digital archive documenting over 2,000 works created by feminist artists from the 1960s to the present day) [[session/dialog/901a6763_2.jsonl#L6-L6]].
- The Women's Art Library (containing publications and artist profiles dedicated to women's art and feminist art) [[session/dialog/901a6763_2.jsonl#L6-L6]].
- The Schlesinger Library at Harvard University (housing extensive research collections on women's history and feminist art activism) [[session/dialog/901a6763_2.jsonl#L6-L6]].
