---
description: Detailed summary of a legal analysis regarding Ground 1 of a tribunal/appeal
  decision concerning waterproofing obligations for windows. Covers disputes between
  original contract terms and a subsequent Deed (Clauses 7 and 14), comparative expert
  testimony from Mr Brennan and Mr Sim on the necessity of window flashing, reference
  to the Schlegel Test Report (2010) by Schlegel Pty Ltd, and the Tribunal's factual
  finding that missing joint sealant rendered the windows defective, leading to the
  rejection of Ground 1.
name: legal-analysis-ground-1-waterproofing
session_id: sharegpt_conu8MS_14
source_conversation: '[[session/dialog/sharegpt_conu8MS_14.jsonl]]'
---

# Legal Analysis of Ground 1: Waterproofing Obligations and Flashing Dispute [[session/dialog/sharegpt_conu8MS_14.jsonl#L1-L1]]

**Note**: This transcript constitutes Part 5 of a multi-part message sequence sent by the user.

## Contractual Terms vs. The Deed
- **Appellant's Argument**: Original contract stipulated "waterproofing membrane to sill to be provided by builder" and the appellant was "responsible for waterproofing of our windows only. If structure is not waterproofed correctly, warranties are voided". These terms meant the appellant was not responsible for installing window flashings.
- **Respondents' Argument**: Contract terms were superseded by a Deed, relying on Clause 14.1 (entire agreement) and Clause 14.2 (supersedes any prior understanding, agreement, condition, warranty, indemnity, or representation).
- **Appellant's Rebuttal**: Clause 7 of the Deed preserved the original contract terms. Clause 14 was intended to prevent pre-Deed negotiations, oral representations, and correspondence from forming part of the Deed or affecting its construction.

## Expert Evidence Comparison
- **Builder Responsibility**: Builder Mr Bannister allegedly failed to install window flashings according to good building practice, which respondents claimed caused leaks in three windows and the applicant's loss.
- **Tribunal's Preference**: The Tribunal accepted and preferred the expert evidence of Mr Brennan over Mr Sim, disregarding Mr Sim's report because the Schlegel Test he referenced was "irrelevant to the windows fitted on site into a timber frame with light weight external cladding".
- **Mr Brennan's Opinion** (Report dated 17 May 2020 & Reply Report): 
  - Leaks resulted from both the absence of small joint sealer and the absence of flashing around the windows.
  - Paragraph 4.5 states sub-heads, sub jambs, and sills are typical for commercial shop fronts and residential concrete construction but do not substitute for flashing, especially in cavity wall or timber frame/lightweight cladding setups. Flashing is still needed to avoid moisture egress between the window frame and house frame.
  - In oral evidence, Mr Brennan stated window flashing is part of the window installation process, not preparation of the opening. He clarified his reports necessitated flashing but did not explicitly assign responsibility to the window supplier/installer.
  - Replied that testing via a "Schlegel portable test rig" cannot account for the many varied building structures/windows/doors assemblies, making it impossible to test all building envelope constructions.
- **Mr Sim's Opinion**: Claimed small joint sealer was present. Argued flashing was unnecessary because the windows used commercial grade sections, sub-heads, and sub-sills acting as flashing. Stated no additional flashing was required for heads, jambs, or sills if installed correctly per the Schlegel Test Report.
- **Schlegel Test Report Context**: A performance certification test report issued by Schlegel Pty Ltd (an NATA accredited laboratory) in 2010 for a sample window.

## Tribunal Conclusions & Determination on Ground 1
- The Tribunal made a finding of fact that the windows required flashing and that this flashing had not been installed.
- The Tribunal concluded the windows leaked due to the absent small joint sealant, rendering them defective and in need of replacement. Consequently, determining who was responsible for flashing installation was irrelevant to the appellant's liability for replacement costs.
- Even if the absence of flashing contributed to leakage severity, it could not change the fundamental conclusion of defectiveness.
- **Final Ruling on Ground 1**: Rejected. The argument involved neither an error of law nor a conclusion that was unfair, inequitable, or contrary to the weight of evidence.
- **Contract Interpretation Clarification**: Regardless of whether Clause 14 excluded original contract references, the explicit provision in Clause 7 means Clause 14 cannot be construed to exclude the original contract terms when determining the appellant's obligation scope.
