---
description: Notes regarding a 3-day trip to Japan with language school friends in
  April 2023 that included a traditional tea ceremony. Details concerning an upcoming
  solo trip to Seoul in July 2023 departing from Tokyo, considering budget airlines
  such as Peach Aviation and T'way Air, and selecting Myeong-dong accommodation for
  its tourist-friendly amenities.
name: seoul-trip-planning-and-japan-trip
session_id: e44a5733_1
source_conversation: '[[session/dialog/e44a5733_1.jsonl]]'
---

### Past Japan Trip
- In April 2023 (referred to as "last month"), the user went on a 3-day trip to an unspecified city in Japan with friends from their language school. 
- Activities during this trip included exploring the city, tasting various delicious foods, and participating in a traditional Japanese tea ceremony.
[[session/dialog/e44a5733_1.jsonl#L1-L1,L11-L11]]

### Upcoming Seoul Trip Planning (July 2023)
#### Travel Details & Preferences
- The user plans a solo trip to Seoul in July 2023.
- Departure city is Tokyo.
- The user has flexible travel dates and is open to booking budget airlines. There are no strict requirements regarding flight times or layovers.
[[session/dialog/e44a5733_1.jsonl#L3-L3]]

#### Flight Recommendations
- To save costs, several budget airlines were identified for direct flights from Tokyo Narita (NRT) to Seoul Incheon (ICN):
  - **Peach Aviation**: ~$140–$230 USD one-way.
  - **Jetstar Japan**: ~$160–$270 USD one-way.
  - **T'way Air**: ~$180–$310 USD one-way.
  - **Air Seoul**: ~$200–$360 USD one-way.
- An alternative destination airport is Gimpo Airport (GMP), which is closer to the city center but may incur additional transportation costs.
- Search platforms recommended for comparing fares include Skyscanner, Google Flights, and Expedia.
[[session/dialog/e44a5733_1.jsonl#L4-L4]]

#### Accommodation Selection
- The user chose to stay in the **Myeong-dong** neighborhood due to its highly central location, extensive shopping options, dining availability, and overall convenience for tourists.
- Notable landmarks within walking distance include N Seoul Tower, Gyeongbokgung Palace, and Bukchon Hanok Village.
- Public transit access is facilitated through nearby subway stations: Myeong-dong Station, Euljiro 1-ga Station, and Hoehyeon Station.
- The area provides strong tourist infrastructure, though the user acknowledges the high volume of visitors and recommends booking accommodations early to secure rates. Exploring the surrounding side streets is also advised to find smaller shops and cafes.
[[session/dialog/e44a5733_1.jsonl#L7-L10]]
