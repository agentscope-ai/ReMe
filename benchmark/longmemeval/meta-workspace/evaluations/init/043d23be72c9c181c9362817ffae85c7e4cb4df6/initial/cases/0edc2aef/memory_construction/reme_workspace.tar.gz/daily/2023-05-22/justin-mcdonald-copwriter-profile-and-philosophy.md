---
description: Comprehensive notes on copywriter Justin McDonald documenting his multi-channel
  service offerings (monthly $100 newsletter, consulting, eBooks, affiliate marketing),
  daily habit of handwriting historical advertisements, and foundational business
  philosophies. Key teachings include the rejection of the "Build it and they will
  NOT come" mindset, strong criticism of traditional public and MBA education for
  teaching poverty and inventing from scratch, mandates for consumer-first marketing
  strategies, distinctions between authentic marketing and mass advertising, and the
  critical necessity of proper timing and segmentation to prevent resource waste.
name: justin-mcdonald-copwriter-profile-and-philosophy
session_id: sharegpt_9EM9xb8_46
source_conversation: '[[session/dialog/sharegpt_9EM9xb8_46.jsonl]]'
---

## Justin McDonald Professional Overview & Services [[session/dialog/sharegpt_9EM9xb8_46.jsonl#L1-L2]]
- Justin McDonald operates as a freelance copywriter and consultant providing remote services accessible through justinmcdonald.medium@gmail.com, JustinMcDonald.Copywriting@gmail.com, and JustinMcDonald.Consulting@gmail.com.
- On May 22, 2023, Justin communicated availability for consulting work featuring decent pricing structures and a special promotional offer valid for the subsequent few weeks.
- Revenue generation utilizes multiple parallel channels: a monthly printed newsletter priced at $100/month, daily email tips, authored books and eBooks, affiliate marketing partnerships, joint venture collaborations, and frequent product discounts covering copywriting, small business management, entrepreneurship, personal selling, and personal development.

## Daily Copywriting Practice [[session/dialog/sharegpt_9EM9xb8_46.jsonl#L1-L2]]
- To continuously develop professional abilities and preserve a connection to industry history, Justin rewrites hundreds of historical advertisements by long-hand each day strictly for recreation. These manually transcribed advertisements are published publicly across his dedicated website and distributed across various social media platforms.

## Core Business & Marketing Philosophy [[session/dialog/sharegpt_9EM9xb8_46.jsonl#L3-L4]]
- Justin fundamentally rejects the concept "Build it and they will NOT come," explicitly labeling the phrase as total nonsense and asserting that this specific educational mindset directly causes individuals to desire quitting formal schooling.
- Justin heavily criticizes public school systems and corporate business degree programs (specifically MBAs) for instructing individuals on how to remain poor, and explicitly warns entrepreneurs never to invent or innovate a product completely from scratch due to resulting hamster-wheel inefficiencies.
- Sustainable commercial success requires designing strategy exclusively around the identified consumer and prospect before manufacturing any deliverable; attempting to force sales exclusively through grandmothers, parents, siblings, neighbors, and coworkers yields immediately terminated demand with zero recurring revenue.
- Authentic business marketing differs completely from mass-market advertising formats seen during television half-times or internet streaming commercial breaks; enduring enterprises depend entirely on established internal processes engineered specifically to sell products.
- Implementing a comprehensive marketing architecture requiring precise chronological timing and demographic segmentation remains operationally critical, because executing incorrect strategic methodologies during misaligned temporal windows instantly squanders accumulated financial capital and developmental hours.
