---
description: Discussion documenting the selection of a title for a lofi hip hop track
  reinterpreting "A Change Is Gonna Come". After rejecting literal options like "Chaos
  Theory" for being "too on the nose," the title "Shuffle the Deck" was selected for
  its metaphorical meaning of rearrangement and unpredictability. Includes recommendations
  for public domain blues tracks ("Sweet Little Angel", "Hound Dog", "St. Louis Blues",
  "The Fat Man", "I'm A Man") featuring shuffle-style drum beats suitable for sampling,
  alongside general notes on copyright clearance.
name: lofi-track-naming-shuffle-the-deck
session_id: sharegpt_qmHagii_15
source_conversation: '[[session/dialog/sharegpt_qmHagii_15.jsonl]]'
---

## Track Titling Process

### Original Concept
- **Project**: Creation of a lofi hip hop track that combines subversion with memorability, specifically playing off the themes found in Sam Cooke's "A Change Is Gonna Come". [[session/dialog/sharegpt_qmHagii_15.jsonl#L1-L1]]

### Iterations and Decision
- **Initial Suggestions**: Titles focusing directly on the theme of change and unexpectedness were proposed, such as "Change Unhinged", "Gone Wrong", "The Unexpected Change", "Disorderly Change", and "Chaos Theory". [[session/dialog/sharegpt_qmHagii_15.jsonl#L1-L1]]
- **Feedback**: The user rejected these initial options because they were considered "too on the nose" and lacked subtlety. [[session/dialog/sharegpt_qmHagii_15.jsonl#L2-L2]]
- **Refined Suggestions**: Alternative titles emphasizing intrigue and complexity were suggested: "Shuffle the deck", "The remix of change", "Echoes of change", "Intertwined", and "Serendipity". [[session/dialog/sharegpt_qmHagii_15.jsonl#L3-L3]]
- **Final Selection**: The title "Shuffle the Deck" was adopted. This phrase serves as a metaphor for the card-shuffling process, representing the rearrangement and re-imagining of the original song's message and musical elements. It effectively conveys a sense of unpredictability, surprise, and subversion while remaining catchy and memorable. [[session/dialog/sharegpt_qmHagii_15.jsonl#L4-L5]]

## Production and Sampling Resources

### Requirements
- **Goal**: Identification of a public domain track featuring a shuffle-style drum beat suitable for creating a loop foundation for the lofi hip hop track. [[session/dialog/sharegpt_qmHagii_15.jsonl#L6-L6]]

### Recommended Recordings
- **"Sweet Little Angel"** by Lucille Bogan: Released in 1935; features a blues track with a strong, shuffling rhythm section. [[session/dialog/sharegpt_qmHagii_15.jsonl#L7-L7]]
- **"Hound Dog"** by Big Mama Thornton: Released in 1952; features a strong shuffle-style drum beat characteristic of its genre. [[session/dialog/sharegpt_qmHagii_15.jsonl#L7-L7]]
- **"St. Louis Blues"** by Louis Armstrong: Written originally by W. C. Handy in 1914; a jazz standard with a strong shuffling rhythm section. [[session/dialog/sharegpt_qmHagii_15.jsonl#L7-L7]]
- **"The Fat Man"** by Fats Domino: Released in 1949; a rhythm and blues track known for its strong shuffling rhythm section. [[session/dialog/sharegpt_qmHagii_15.jsonl#L7-L7]]
- **"I'm A Man"** by Bo Diddley: Released in 1955; a rhythm and blues track with a prominent, strong shuffling rhythm section. [[session/dialog/sharegpt_qmHagii_15.jsonl#L7-L7]]

### Licensing Considerations
- While classic blues and rock'n'roll tracks are valuable sources for rhythmic loops, there is a reminder that utilizing samples from copyrighted materials generally requires proper clearance, seeking permission from right holders, or relying on transformative usage exemptions. [[session/dialog/sharegpt_qmHagii_15.jsonl#L7-L7]]
