---
description: Answers and explanations for multiple-choice questions covering categorization
  models (prototype vs exemplar), cognitive heuristics (anchoring, triangle inequality
  constraints, attraction effect), Moravec's paradox, abstract perceptual learning,
  synaptic plasticity, and distinctions between materialism and dualism.
name: cognitive-science-concepts
session_id: sharegpt_TcUL15d_19
source_conversation: '[[session/dialog/sharegpt_TcUL15d_19.jsonl]]'
---

## Categorization Models [[session/dialog/sharegpt_TcUL15d_19.jsonl#L1-L1,L6-L15]]
- **Prototype models**: These models demonstrate that category prototypes "can be learned by processing every instance in the category" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L1]].
- **Exemplar models**: These hold that "instances are more important than prototypes" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L12-L13]]. Category membership is determined by comparing a new instance to all previously encountered exemplars stored in memory—rather than relying on a single abstract prototype—including their unique features and context of occurrence [[session/dialog/sharegpt_TcUL15d_19.jsonl#L7,L15]].

## Cognitive Bias and Decision Effects [[session/dialog/sharegpt_TcUL15d_19.jsonl#L2-L3,L4-L11,L16-L17]]
- **Triangle inequality and similarity**: The relationship is such that the triangle inequality demonstrates that "models of similarity judgements require constraints (e.g., attentional weighting as in Tversky’s contrast model)" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L2-L3]].
- **Anchoring effects**: Occur when individuals "rely too heavily on the first piece of information encountered (the 'anchor') when making subsequent judgments or decisions" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L5]]. An example case involved Andrew telling Christina that the meaning of life is the number 42, which subsequently biased Christina's estimate of her ideal number of children to 38 [[session/dialog/sharegpt_TcUL15d_19.jsonl#L4-L5,L8-L11]].
- **Attraction effect**: Demonstrates how "two choices with the same overall utility can be affected by an attractor choice close to one of the choices" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L16-L17]]. In the reviewed scenario, the answer indicated that the attractor choice is chosen despite being less desirable on all dimensions than the choice it is near [[session/dialog/sharegpt_TcUL15d_19.jsonl#L17]].

## Perception and Neuroscience [[session/dialog/sharegpt_TcUL15d_19.jsonl#L18-L19,L20-L27]]
- **Moravec's paradox**: Identifies that the parts of the mind most difficult to simulate with a computer are "(c) perceptual systems including vision and locomotion" and "(d) 'Smart' features of the body including complex organs and muscles" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L18-L19]]. This highlights that tasks trivial for humans (like walking) are computationally difficult for machines [[session/dialog/sharegpt_TcUL15d_19.jsonl#L19]].
- **Abstract perceptual learning**: Refers to "developing representations of abstract entities including description of shape" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L24-L25]]. This involves creating abstract representations of complex stimuli not easily reducible to simple features [[session/dialog/sharegpt_TcUL15d_19.jsonl#L21]].
- **Synaptic plasticity**: Defined as the form of learning that "involves changes to the structure of neuron connections" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L26-L27]].

## Philosophy of Mind [[session/dialog/sharegpt_TcUL15d_19.jsonl#L28-L31]]
- **Classical mind-body problem**: Explores distinctions between "Materialism" and "Dualism" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L29-L31]]. In the context of the quiz discussion, Materialism was characterized as stating that "brain processes and mental processes are two interacting physical substances," whereas Dualism posits that "brain processes and mental behaviors are not (or very loosely) causally related" [[session/dialog/sharegpt_TcUL15d_19.jsonl#L29-L31]].
