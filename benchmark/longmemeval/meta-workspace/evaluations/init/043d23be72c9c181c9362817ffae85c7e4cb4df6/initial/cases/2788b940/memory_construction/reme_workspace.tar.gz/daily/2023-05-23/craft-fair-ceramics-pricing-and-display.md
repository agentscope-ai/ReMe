---
description: Strategic preparation guide for vending handmade decorative ceramic ware
  at an upcoming craft fair occurring shortly after May 2023. Documents the artist's
  trajectory as a sculpting student reaching a three-month proficiency milestone,
  the strategic decision to prioritize decorative over functional pieces to mitigate
  durability and food-safety risks, detailed cost-accounting and dynamic pricing formulas
  alongside published retail benchmarks ranging from $10 to over $100, architectural
  booth styling protocols utilizing natural timber surfaces and botanical accents
  such as eucalyptus and ferns, standardized product tagging systems, and direct-to-consumer
  retention tactics involving business cards, email lists, and QR code integration.
name: craft-fair-ceramics-pricing-and-display
session_id: afe0aed9
source_conversation: '[[session/dialog/afe0aed9.jsonl]]'
---

## Pricing Methodology & Market Benchmarks [[session/dialog/afe0aed9.jsonl#L1-L2]]
- **Cost Accounting**: Compute total production expenses including raw materials (clay, glazes), kiln fuel, supplies, and labor hours dedicated to design, construction, and firing.
- **Market Research**: Survey prices of equivalent works at local art galleries, online marketplaces, and competing craft fairs to align with buyer willingness-to-pay.
- **Skill Calibration**: Begin with conservative pricing to build reputation as a novice; increase rates progressively as technical mastery and public recognition accumulate.
- **Valuation Models**: Synthesize hourly wage calculations with flat-rate multipliers derived from object dimensions, structural intricacy, and material rarity.
- **Premium Factors**: Charge higher rates for specialty/rare materials or complex processes such as hand-painting or sculpting.
- **Packaging Costs**: Include overhead allocations for protective shipping containers, branded textile wraps, and custom crating structures directly in the final shelf price.
- **Base Pricing Strategy**: Anchor every catalog entry to a fixed base tier before applying upward or downward modifiers for weight, firing difficulty, or aesthetic uniqueness.
- **Psychological Formatting**: Utilize round integer values (e.g., $20, $50, $100) to trigger cognitive comfort signals among walk-in shoppers.
- **Negotiation Tactics**: Remain open to reasonable bargaining during live sessions while defending fair value thresholds.
- **Dynamic Adjustment**: Monitor sales velocity continuously throughout operating hours; raise prices for fast-moving items and apply promotional markdowns for stagnant inventory.
- **Industry Benchmark Ranges**:
    - Small/Simple (ornaments, magnets): $10–$30.
    - Medium (mugs, small vases): $20–$50.
    - Large/Complex (sculptures, platters): $50–$100+.
    - Functional (plates, bowls): $20–$50.
    - Decorative (wall art, figurines): $30–$100+.

## Product Selection: Decorative Over Functional [[session/dialog/afe0aed9.jsonl#L3-L4]]
- **Creator Profile**: User enrolled in sculpting classes approximately three months prior to the planning date (early May 2023) and has achieved comfort with ceramic clay handling.
- **Strategic Decision**: Commitment to selling exclusively decorative ceramic pieces for the immediate craft fair appearance rather than functional ware.
- **Rationale for Decorative Focus**:
    - **Reduced Pressure**: Bypasses stringent health-code compliance mandates governing food-contact surfaces and dishwasher-resistant durability standards.
    - **Creative Freedom**: Provides unrestricted latitude for experimenting with unconventional geometries and experimental glaze interactions.
    - **Market Testing**: Offers a lower-risk environment to gauge consumer preference and revenue potential before scaling production.
- **Functional Piece Risks**: High volume of competition at fairs and rigorous quality control requirements (durability, food safety) make them less ideal for initial seller entries.

## Booth Architecture & Visual Merchandising [[session/dialog/afe0aed9.jsonl#L5-L8]]
- **Cohesion**: Enforce a unified thematic direction spanning color palettes and stylistic motifs to guarantee immediate category recognition by pedestrians.
- **Elevation**: Deploy graduated platforms constructed from risers, pedestals, and shelves to transform horizontal planes into dynamic three-dimensional showcases.
- **Grouping**: Aggregate compatible subsets (matching vase pairs, coordinated tile mosaics, sequential portrait series) within designated radius zones to signal collection continuity.
- **Balance**: Distribute mass evenly across the footprint by interlocking massive gravity-defying forms with pocket-sized hand-held objects, occasionally enforcing bilateral mirror symmetry.
- **Lighting**: Install directed parabolic fixtures emitting cool-white lumens to eradicate shadow casting beneath protruding ridges and amplify reflective gloss.
- **Backgrounds**: Drape primary support surfaces with untextured cotton canvas dyed in slate gray or muted oat to absorb peripheral distraction.
- **Labeling**: Affix rigid placards to every artifact displaying the registered designation, exact monetary value, and origin narrative covering clay sourcing and oxidation history.
- **Spatial Awareness**: Preserve minimum clearance intervals between adjacent artifacts to enable unhindered circulation; designate a central apex feature as a visual magnet.
- **Adaptability**: Audit spatial configurations every four hours during active trading windows to shift lagging categories toward high-traffic corridor edges.
- **Natural Aesthetic Execution**:
    - **Primary Surface**: Wooden table with a natural wood tone to project warmth and organic harmony.
    - **Botanical Accents**: Insert biotic matrices consisting primarily of silver-dollar eucalyptus cuttings and sword-fern fronds to inject chlorophyll-rich chromatic spikes.
    - **Arrangement Style**: Keep layouts simple to prioritize ceramics; utilize golden-ratio proportional spacing to steer pedestrian gazing patterns inward.

## Marketing & Customer Acquisition [[session/dialog/afe0aed9.jsonl#L9-L12]]
- **Informational Tags**: Attach standardized polypropylene sleeves to each piece containing registered artwork title, final purchase cost, and raw ingredient composition logs. [[session/dialog/afe0aed9.jsonl#L9-L10]]
- **Networking Assets**: Circulate lithographed corporate identifier sheets embedded with machine-readable scannable patches routing mobile devices to external portfolio hosts. [[session/dialog/afe0aed9.jsonl#L11-L12]]
- **Lead Generation**: Deploy paper-based registration ledgers stationed near exit trajectories to collect handwritten mailing addresses destined for monthly digest pipelines. [[session/dialog/afe0aed9.jsonl#L11-L12]]
- **Retention Strategy**: Transmit routine broadcast transmissions outlining newly completed inventory batches, geographically relocated exhibition stops, and early-access holiday discount windows. [[session/dialog/afe0aed9.jsonl#L11-L12]]
- **Brand Consistency**: Align all typographic treatments, logo placements, and margin measurements across print assets to mirror existing Instagram and Pinterest account formatting for unified ecosystem recognition. [[session/dialog/afe0aed9.jsonl#L11-L12]]

## Creator Proficiency & Timeline [[session/dialog/afe0aed9.jsonl#L9-L10]]
- **Milestone Achievement**: Artist officially reaches the ninety-day threshold in formal sculpting instruction concurrent with pre-event preparations.
- **Skill Application**: Transition from academic classroom exercises to commercial outdoor exhibition capabilities.
