---
description: 'Detailed character backstory for Alaric Davenport. Includes full names
  and profiles of deceased family members (Father: Dr. Aric Davenport; Mother: Dr.
  Sariel Davenport; Sister: Lyra Davenport, age 10). Documents the timeline and consequences
  of the pirate raid two years prior to the story''s start which killed his family
  and neighbors. Profiles his mentor and father figure, Gaius (an engineer from Andromeda).
  Captures objectives related to building a ship and seeking vengeance.'
name: alaric-davenport-backstory
session_id: sharegpt_EX0p0tj_19
source_conversation: '[[session/dialog/sharegpt_EX0p0tj_19.jsonl]]'
---

## Alaric Davenport Backstory & Character Profile

### Immediate Family (Deceased)
*   **Father ("Dr. Aric Davenport")**: Profession: Respected engineer and healer. Maintained a highly guarded secret project developing revolutionary new energy technology for space travel and power generation. Upon his death, Alaric inherited only vague clues and unfinished blueprints regarding this research. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L13-L13,L7-L7]]
*   **Mother ("Dr. Sariel Davenport")**: Profession: Skilled healer and scientist. Possessed a deep passion for exploring forests and jungles on nearby planets to study rare and exotic plant species for new medicinal and therapeutic cures. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L15-L15,L9-L9]]
*   **Younger Sister ("Lyra Davenport")**: At the time of death, she was 10 years old. Bright, spirited, and highly intelligent. Aspired to become a zoologist and studied biology. Frequently expressed curiosity through drawings of a rare and mysterious forest creature. Her memory drives Alaric's quest for justice. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L19-L19,L3-L3,L11-L11]]

### Timeline of the Piracy Raid
*   **Occasion**: A group of ruthless space pirates attacked the family's remote and peaceful settlement, destroying infrastructure and killing many inhabitants. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L5-L5]]
*   **Relative Timing**: The tragedy occurred two years before the beginning of the story timeline. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L5-L5]]
*   **Alaric's Status**: Alaric survived because he was away attending a conference on a neighboring planet during the attack. He returned home to discover his family murdered and the settlement destroyed. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L5-L5]]
*   **Post-Raid Actions**: Driven by grief and a desire for vengeance, Alaric dedicated the following years to mastering engineering skills and constructing a powerful ship to track down the pirates responsible. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L5-L5,L23-L23]]

### Mentor Profile: Gaius
*   **Relationship**: An old, wise engineer who functioned as a mentor, close friend, and father figure to Alaric. Instilled values of hard work, perseverance, and creativity. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L1-L1]]
*   **Origins and Education**: Originally from the planet Andromeda. Received elite training at the Andromeda Institute of Technology, gaining expertise in mechanical engineering, robotics, and artificial intelligence. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L23-L23]]
*   **Setting and Support**: Established a workshop on a small planet on the outskirts of the galaxy (where Alaric resided). Guided Alaric throughout the period of building his ship after the tragic losses. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L23-L23]]

### Community Connections
*   **Social Standing**: The Davenport family was widely respected and well-liked in their local community. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L1-L1]]
*   **Collective Losses**: In addition to the immediate family, numerous close community members—including fellow engineers, healers, and traders—were slaughtered during the same pirate raid. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L1-L1]]
*   **Extended Kinship**: Relatives were dispersed across various galaxies and planetary systems; interactions were limited to occasional childhood meetings. [[session/dialog/sharegpt_EX0p0tj_19.jsonl#L1-L1]]
