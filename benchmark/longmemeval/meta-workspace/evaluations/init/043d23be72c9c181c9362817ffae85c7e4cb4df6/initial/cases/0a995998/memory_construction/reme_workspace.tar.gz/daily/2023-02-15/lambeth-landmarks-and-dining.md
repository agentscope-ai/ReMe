---
description: Comprehensive archival record of historical landmarks, cultural institutions,
  parks, and dining establishments in Lambeth, London. Documents establishment dates,
  architectural components, specific museum collections, sports histories, and detailed
  menu items including vegetarian accommodations. Captures participant travel itinerary
  decisions and dining preferences recorded during the February 2023 information retrieval
  session.
name: lambeth-landmarks-and-dining
session_id: ultrachat_128918
source_conversation: '[[session/dialog/ultrachat_128918.jsonl]]'
---

## Lambeth Historical Landmarks
- Lambeth Palace was constructed in 1197 and operates as the official London residence for the Archbishop of Canterbury, leader of the Church of England. The compound historically sheltered national monarchs and high-ranking clerics while providing asylum to Protestant and Catholic minorities escaping religious persecution. Site infrastructure encompasses the medieval Chapel of St. Mary, the Great Hall, the Gatehouse, and maintained garden landscapes. [[session/dialog/ultrachat_128918.jsonl#L1-L2]]
- The Imperial War Museum commenced operations in 1917 to chronicle armed conflict history and civilian societal impacts. Exhibition holdings feature armored vehicles, aviation assets, and firearms. Programming evolved to encompass human rights advocacy, international peacekeeping operations, and post-war reconstruction studies through interactive media installations and survivor oral histories. [[session/dialog/ultrachat_128918.jsonl#L1-L2]]
- The Old Vic Theatre inaugurated stage operations in 1818 and catalyzed professional British theatrical advancement. Featured performers included industry pioneers Laurence Olivier and Judi Dench. Repertoire selections spanned classical Shakespearean dramatizations to modern experimental productions while functioning as an educational incubator for performance directors and playwrights. [[session/dialog/ultrachat_128918.jsonl#L1-L2]]
- The Florence Nightingale Museum maintains archival operations inside St. Thomas' Hospital facilities. The institution commemorates Florence Nightingale, acknowledged for revolutionizing battlefield medical triage during the Crimean War campaign. Preserved materials feature personal correspondence manuscripts, daily operational journals, and historical clinical instrumentation tracing United Kingdom healthcare modernization. [[session/dialog/ultrachat_128918.jsonl#L1-L2]]

## Cultural Institutions and Recreational Spaces
- The Southbank Centre administers performance and exhibition venues along the River Thames waterfront district. Complex architecture houses the Royal Festival Hall, the Hayward Gallery, and the Queen Elizabeth Hall. Event calendars schedule orchestral concerts, dramatic theater runs, visual art retrospectives, and municipal cultural festivals. [[session/dialog/ultrachat_128918.jsonl#L3-L4]]
- The Garden Museum maintains a central Lambeth campus dedicated to landscape architecture theory and horticultural preservation. Gallery spaces curate British botanical illustration archives and antique agricultural tools. Temporary installations examine contemporary ecological planning methodologies and sustainable urban farming techniques. [[session/dialog/ultrachat_128918.jsonl#L3-L4]]
- Archbishop's Park extends adjacent territory bordering Lambeth Palace grounds and delivers elevated riverside sightlines toward the London Eye observation tower. Public amenities include children's play apparatus, regulated tennis surfaces, specialized concrete skate zones, and memorial plaques surrounded by botanical plantings. [[session/dialog/ultrachat_128918.jsonl#L3-L4]]
- The Oval Cricket Ground activated sporting operations in 1845 and retains classification among international cricket's premier competitive venues. The facility hosted the inaugural Test Match tournament organized on English soil and currently serves as the administrative base and playing field for the Surrey County Cricket Club. [[session/dialog/ultrachat_128918.jsonl#L3-L4]]

## Pubs and Restaurants in Lambeth
- The Anchor & Hope manages a gastropub enterprise positioned on The Cut thoroughfare, specializing in traditional British gastronomy and regional craft brewery distributions. Culinary frameworks prioritize locally sourced agricultural yields emphasizing standard preparations like roasted beef carvings and battered marine products. Dietary accommodation menus feature vegetarian categories including a roasted squash and chestnut pie configuration paired with buttered greens and mashed potato supplements, wild mushroom risotto entrees, and grilled chicory salad plates. Recipe rotations adjust quarterly based on commercial harvest availability windows. [[session/dialog/ultrachat_128918.jsonl#L7-L8,L9-L10]]
- The Crown & Anchor operates a heritage tavern property situated proximal to The Oval sporting complex. Beverage inventories highlight imported cask ale varieties, international wine vintages, and concentrated spirit portfolios. Food service protocols deliver standardized pub appetizers and domestic comfort meal categories. [[session/dialog/ultrachat_128918.jsonl#L7-L8]]
- Morley's coordinates a network of quick-service dining outlets distributed across Lambeth municipal boundaries. Commercial operations have sustained continuous market presence exceeding forty calendar years focused exclusively on breaded poultry strips and French fry accompaniments. [[session/dialog/ultrachat_128918.jsonl#L7-L8]]
- Cotto functions as a privately administered Italian culinary establishment presenting handcrafted pasta assemblies, timber-fired flatbread pizza variations, and bespoke confectionary dessert lines utilizing traditional Mediterranean baking protocols. [[session/dialog/ultrachat_128918.jsonl#L7-L8]]

## Conversation Timeline and Participant Logistics
- At 19:21:00 UTC on 2023-02-15, an informational query session commenced targeting geographic tourism resources. [[session/dialog/ultrachat_128918.jsonl#L1]]
- The information requester formally designated the Southbank Centre and the Garden Museum as mandatory itinerary stops. [[session/dialog/ultrachat_128918.jsonl#L5]]
- The information requester prioritized The Anchor & Hope gastropub for evening meal consumption and submitted a targeted dietary restriction inquiry concerning non-animal protein menu classifications. [[session/dialog/ultrachat_128918.jsonl#L7-L9]]
