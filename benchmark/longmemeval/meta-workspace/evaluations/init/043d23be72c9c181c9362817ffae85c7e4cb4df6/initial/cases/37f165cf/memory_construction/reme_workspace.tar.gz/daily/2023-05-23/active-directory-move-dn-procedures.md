---
description: Detailed procedures for moving Organizational Units (OUs) and Distinguished
  Names (DNs) within Windows Active Directory, covering both the PowerShell command-line
  approach using `Move-ADObject` and the graphical interface method using Apache Directory
  Studio.
name: active-directory-move-dn-procedures
session_id: sharegpt_wohQ2LX_0
source_conversation: '[[session/dialog/sharegpt_wohQ2LX_0.jsonl]]'
---

# Active Directory Move Procedures

## PowerShell Methodology [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L1-L2]]
* Use the `Move-ADObject` cmdlet in PowerShell to move Active Directory objects, such as Organizational Units (OUs), from one location to another [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
* Establish a connection to the Active Directory domain by running the command `Connect-ADDomain -Server <AD_server_name>` [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
* Retrieve the Distinguished Names (DNs) using `Get-ADObject` with the `-Filter` parameter; for example, `$sourceOUs = Get-ADObject -Filter 'Name -like "Sales*"' -SearchBase '<DN_of_parent_OU>'` retrieves OUs starting with "Sales" [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
* Move the retrieved objects using the command `Move-ADObject -Identity $sourceOUs -TargetPath '<DN_of_destination_OU>'` [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].

## Apache Directory Studio Methodology [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L3-L4]]
* Utilize Apache Directory Studio, a free, open-source LDAP browser and directory client, to manage and navigate the Active Directory directory [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
* Open the application and connect to the Active Directory server [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
* Navigate to the target Organizational Unit in the "LDAP Browser" view [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
* Right-click the entry and select "Move" from the context menu to open the "Move Entry" dialog box [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
* Click "Browse" to select the destination Organizational Unit in the dialog box, then click "Finish" to relocate the entries [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
