---
description: Structural planning and stylistic directives for Kadence's autobiographical
  book 'The Journey'. Covers the drafted 'Who is Kadence' origins chapter, the proposed
  next section 'The Origin of Kadence's Passion for Music', and comprehensive writing
  guidelines focusing on a movie-narration tone, hero's journey transition themes,
  and targeted reader emotions.
name: kadence-journey-framework
session_id: sharegpt_aVExml0_92
source_conversation: '[[session/dialog/sharegpt_aVExml0_92.jsonl]]'
---

## Kadence Profile & Background Facts
[[session/dialog/sharegpt_aVExml0_92.jsonl#L1-L2]]
- Kadence is a 25-year-old musician currently residing in New York City, originally raised in Jamaica.
- Kadence launched a rap career under the stage name 'Kadence' in 2012.
- Early success included gaining recognition in Mandeville, Jamaica, as a producer, vocalist, and songwriter.
- In 2015, Kadence relocated to Toronto, Canada, to fully commit to a professional music career.
- Kadence independently produces and records original music, blending genres including rap, hip-hop, R&B, dancehall, and pop.
- Brand identity rests on core attributes: authenticity, empathy, passion, creativity, resilience, and humility.
- Strategic career objectives include achieving global recognition, maintaining financial independence and profitability, forming friendships with musical idols, and a steadfast commitment to releasing high-quality lyrical work.

## Project Architecture & Chapter Progression
[[session/dialog/sharegpt_aVExml0_92.jsonl#L3-L4]]
- The overarching manuscript is titled "The Journey".
- The foundational section is titled "Who is Kadence", focusing on biographical origins and establishing the artist's identity.
- The subsequent planned chapter is titled "The Origin of Kadence's Passion for Music".
- This upcoming chapter will chronicle early musical influences, track the evolution of rap and hip-hop interests, analyze childhood upbringing impacts, and detail the shift from casual interest to professional dedication.

## Stylistic Guidelines & Thematic Framework
[[session/dialog/sharegpt_aVExml0_92.jsonl#L7]]
- **Primary Function:** Serves as an ever-deepening internal framework for behind-the-scenes development with Kadence, acting as a concluding reference anchor for all future derivative content.
- **Narrative Mode:** Structured as an autobiographical story utilizing a cinematic movie narration style to overlay visual context with textual history.
- **Core Philosophical Theme:** Maps Kadence arriving at the critical narrative threshold of stepping out of the "ordinary world" and entering the next major phase of the hero's journey.
- **Emotional Resonance Targets:** Designed to inspire readers, evoke genuine emotional touching, provoke intrigue through Kadence's whimsical personality, and compel continued reading.
- **Subject Matter Integration:** Explicitly requires weaving in formative life encounters covering love, sexual experiences, substance use, musical discoveries, friendship dynamics, betrayal, envy, and jealousy.
- **Character Arc Strategy:** Demonstrates how lived experiences forge a uniquely distinct worldview, deliberately refining and maturing the protagonist's character profile within the audience's perception.
- **Drafting Methodology:** The initial draft intentionally leaves structural placeholders and blank spaces for Kadence to manually insert highly specific personal anecdotes, which will trigger a subsequent comprehensive rewrite pass.
