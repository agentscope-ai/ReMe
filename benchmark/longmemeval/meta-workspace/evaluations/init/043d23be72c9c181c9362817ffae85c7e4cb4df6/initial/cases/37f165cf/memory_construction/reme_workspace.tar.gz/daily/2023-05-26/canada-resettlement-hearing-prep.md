---
description: Extraction of Canadian resettlement support services (RAP, ISAP, LINC,
  settlement agencies like COSTI and VAST), child integration resources (ESL/FSL,
  SWIS, community programs), and personal preparations for a refugee claim hearing
  (language training, lawyer Mrs. Smith advice, journey timeline compilation). Captures
  detailed structural mechanics of the Resettlement Assistance Program (RAP), its
  eligibility categories (GARs, PSRs, BVOR), fixed monthly allowance distribution
  over 12 months via Service Provider Organizations (SPOs), and strategic methodologies
  for overcoming language barriers ahead of the March 20th hearing.
name: canada-resettlement-hearing-prep
session_id: a41d46df
source_conversation: '[[session/dialog/a41d46df.jsonl]]'
---

### Family Resettlement Overview and Support Services [[session/dialog/a41d46df.jsonl#L1-L2]]
- User gathers information regarding resettlement support services for User's family planned to arrive in Canada. [[session/dialog/a41d46df.jsonl#L1-L1]]
- Government of Canada support programs include the Immigrant Settlement and Adaptation Program (ISAP) for language training and job search support, the Resettlement Assistance Program (RAP) for financial support covering food, shelter, and clothing for up to one year, and Language Instruction for Newcomers to Canada (LINC) for free language training. [[session/dialog/a41d46df.jsonl#L2-L2]]
- Settlement agencies providing cultural orientation, housing assistance, healthcare access, and job search support include COSTI Immigrant Services (Ontario), Vancouver Association for Survivors of Torture (VAST) (British Columbia), Centre for Newcomers (Alberta), and YMCA of Greater Toronto (Ontario). [[session/dialog/a41d46df.jsonl#L2-L2]]
- General supports encompass community organizations (cultural associations, places of worship, volunteer groups), healthcare services (medical check-ups, vaccinations, mental health support), and education/training programs including adult education and vocational training. [[session/dialog/a41d46df.jsonl#L2-L2]]

### Resettlement Assistance Program (RAP) Structure and Eligibility [[session/dialog/a41d46df.jsonl#L3-L6]]
- RAP provides temporary financial support during the initial settlement period and distributes funds over up to 12 months. [[session/dialog/a41d46df.jsonl#L4-L4,L6-L6]]
- Eligibility extends to Government-Assisted Refugees (GARs), Privately Sponsored Refugees (PSRs), and Blended Visa Office-Referred (BVOR) Program participants referred by the United Nations High Commissioner for Refugees (UNHCR) and sponsored privately. [[session/dialog/a41d46df.jsonl#L4-L4]]
- Payments consist of a monthly allowance calculated based on family size and specific needs by Service Provider Organizations (SPOs), defined as non-profit organizations contracted by Immigration, Refugees and Citizenship Canada (IRCC). [[session/dialog/a41d46df.jsonl#L4-L4,L6-L6]]
- Upon arrival, families receive initial orientation from SPOs including bank account assistance, accommodation guidance, and introductions to local services. Ongoing support entails regular check-ins, progress monitoring, and assistance accessing healthcare, social services, and employment opportunities. [[session/dialog/a41d46df.jsonl#L4-L4]]
- Although the monthly allowance functions as a fixed amount, SPOs retain the capacity to adjust payments based on evolving needs such as specialized medical services. Additional one-time coverages include start-up costs for furniture, rent security deposits, and essential medical services like dental care. [[session/dialog/a41d46df.jsonl#L6-L6]]

### Children's School and Community Integration Resources [[session/dialog/a41d46df.jsonl#L7-L8]]
- Educational institutions offer English as a Second Language (ESL) and French as a Second Language (FSL) programs, newcomer orientation weeks featuring language assessments, and the Settlement Workers in Schools (SWIS) program delivering in-school support and community linkages. [[session/dialog/a41d46df.jsonl#L8-L8]]
- Community youth resources feature YMCA Newcomer Youth Programs (mentorship, recreational activities), Boys and Girls Clubs of Canada (after-school programs, newcomer integration), and local community centers hosting cultural activities and recreational programming. [[session/dialog/a41d46df.jsonl#L8-L8]]
- Government-funded youth initiatives include the Immigrant Settlement and Adaptation Program (ISAP) and the Youth Settlement Program (YSP) funding organizations providing specialized services for newcomer youth. Digital platforms such as Welcome to Canada, Newcomer Kids, and Settlement.org provide age-appropriate digital resources. [[session/dialog/a41d46df.jsonl#L8-L8]]
- Adjustment recommendations advise encouraging children to ask questions, parental involvement in educational and extracurricular activities, and establishing networks with other newcomer families for mutual support. [[session/dialog/a41d46df.jsonl#L8-L8]]

### Language Skills and Refugee Claim Hearing Preparation [[session/dialog/a41d46df.jsonl#L9-L12]]
- At the time of the conversation, User attends English language classes at a local community center and seeks supplementary resources for a refugee claim hearing. [[session/dialog/a41d46df.jsonl#L9-L9]]
- Specialized language training options include Language Instruction for Newcomers to Canada (LINC), Enhanced Language Training (ELT), and Refugee-Specific Language Training delivered by entities like the Canadian Refugee Hearing Preparation Centre, emphasizing legal terminology and interview techniques. [[session/dialog/a41d46df.jsonl#L10-L10]]
- Preparation tactics utilize the Canadian Language Benchmarks (CLB) website, digital learning applications (Duolingo, Babbel, Rosetta Stone), online tutors, conversation clubs, and authentic news media. Recording spoken responses tracks progress while targeted practice focuses on legal vocabulary and frequently asked hearing inquiries. [[session/dialog/a41d46df.jsonl#L10-L10]]
- Hearing formally scheduled for March 20th; notification call arrived during the calendar week preceding 2023-05-26. [[session/dialog/a41d46df.jsonl#L1-L1]]
- Meeting scheduled with legal counsel Mrs. Smith to review case strategy and anticipated board member interrogations. [[session/dialog/a41d46df.jsonl#L11-L11]]
- Counsel Mrs. Smith mandates strict honesty, expansive detailing of experiences, and submission of corroborating evidence. User constructs a chronological timeline documenting departure from home country through arrival in Canada, capturing exact dates, times, geographical routes, witness contact information, alongside documentary and photographic evidence. [[session/dialog/a41d46df.jsonl#L11-L12]]
