---
description: A comprehensive technical summary of the Student's $t$ distribution,
  detailing its mathematical properties (small sample size utility, heavy tails, degrees
  of freedom dependence, convergence to normal), its applications in hypothesis testing
  and confidence intervals, and a structured overview of a critical values table mapping
  Degrees of Freedom (DF) to various percentile, one-sided, and two-sided significance
  levels.
name: student-t-distribution-reference
session_id: sharegpt_0UggBZu_32
source_conversation: '[[session/dialog/sharegpt_0UggBZu_32.jsonl]]'
---

### Student's T-Distribution: Characteristics and Definitions
- The $t$ distribution functions as a probability distribution utilized to perform inferences regarding the population mean specifically within contexts featuring a small sample size and/or an unidentified population standard deviation [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- The distribution exhibits a bell-shaped geometric curve that mirrors the standard normal distribution while possessing distinctively heavier tails [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- The physical geometry of the $t$ distribution relies upon the degrees of freedom metric, mathematically derived by subtracting one from the total sample size [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- Architectural features include symmetry around a mean value of zero and a standard deviation of unity for the standard $t$ distribution [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- As the degrees of freedom increase toward infinity, the $t$ distribution undergoes a progression converging upon the shape of the standard normal distribution [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].

### Statistical Applications
- Within hypothesis testing procedures, practitioners utilize the $t$ test to calculate a test statistic evaluating whether a sample mean significantly diverges from a known or hypothesized population mean; comparing this statistic against established critical values yields a p-value for null hypothesis decision-making [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- In confidence interval estimation protocols, the $t$ distribution determines the width of value ranges likely to contain the true population mean at specified confidence levels, relying on metrics such as sample size, sample mean, and sample standard deviation [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].

### Critical Values Reference Table Structure
- Table 1 documents critical value entries representing percentiles for the $t$ distribution [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]].
- The row axis denotes Degrees of Freedom (DF), spanning integer values from 1 through 100, extending to 200, 500, and concluding with infinity ($\infty$) [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]].
- Column metrics categorize thresholds into three distinct statistical classifications:
  - **Percent**: Represents $100 \times \mbox{cumulative}$ distribution function outcomes, listing exact benchmarks at 75, 90, 95, 97.5, 99, 99.5, 99.75, 99.9, 99.95, 99.975, 99.99, and 99.995 [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]].
  - **One-sided $\alpha$**: Catalogues significance levels applied to one-sided upper critical values, identifying boundaries at .25, .10, .05, .025, .01, .005, .0025, .001, .0005, .00025, .0001, and .00005 [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]].
  - **Two-sided $\alpha$**: Enumerates significance levels applied to two-sided critical values, recording metrics at .50, .20, .10, .05, .02, .01, .005, .002, .001, .0005, .0002, and .0001 [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]].
