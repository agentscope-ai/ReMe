---
description: Collection of sales scripts and objection-handling techniques for financial
  advisors, specifically addressing client concerns regarding annuities (complexity,
  fees, illiquidity, inflexibility, market risk) and providing iterative phone outreach
  scripts for scheduling annual 403(b) financial reviews under the name "Denis from
  Equitable".
name: financial-advisor-sales-scripts
session_id: sharegpt_vgBnRfE_0
source_conversation: '[[session/dialog/sharegpt_vgBnRfE_0.jsonl]]'
---

## Annuity Objections & Handling
- **Common Client Objections**: Clients frequently object to purchasing annuities due to Complexity (confusing features and language), Fees (upfront, management, surrender charges reducing returns), Illiquidity (surrender charges for early withdrawals, preference for stocks/mutual funds), Inflexibility (limits on contributions or investment options), and Market Risk (preference for taking on risk for higher returns over guaranteed income). Advisors are advised to use simple terms to explain features and weigh fees against benefits.
[[session/dialog/sharegpt_vgBnRfE_0.jsonl#L1-L2]]
- **Addressing Fee Objections**: To overcome client objections regarding high fees, advisors should explain the unique benefits (guaranteed income, tax-deferred growth, protection against downturns), compare fees favorably against other investments, break down specific fee types (surrender charges, mortality/expenses fees, administrative fees), offer lower-fee alternatives like no-load or index mutual funds, or negotiate directly with the insurance company for larger investments.
[[session/dialog/sharegpt_vgBnRfE_0.jsonl#L3-L4]]

## Closing Scripts & Phone Outreach
- **Drafting a Closing Script**: Initial draft for closing an annuity sale emphasizes the guaranteed income stream, inflation-adjusted income riders, and peace of mind, ending with a direct question asking if the client is ready to purchase.
[[session/dialog/sharegpt_vgBnRfE_0.jsonl#L5-L6]]
- **Refining Tone**: Adjustments were made to the closing script to remove the direct question about readiness, instead framing the decision as the client's choice and offering to proceed with paperwork at their convenience.
[[session/dialog/sharegpt_vgBnRfE_0.jsonl#L7-L8]]
- **Phone Script for Annual Review (Short & Direct)**: Iteration shifts focus entirely to scheduling an annual financial review for a client's 403(b) retirement account. The script introduces the caller as Denis from Equitable, frames the review as critical for aligning strategy with goals, and asks for availability.
[[session/dialog/sharegpt_vgBnRfE_0.jsonl#L9-L10]]
- **Phone Script for Annual Review (Inviting & Relational)**: Further refinement makes the call more inviting. Denis from Equitable expresses hope that the client is having a great day, outlines the agenda (discussing goal changes, reviewing performance, making adjustments, catching up), acknowledges the client's time is valuable, and asks for available times.
[[session/dialog/sharegpt_vgBnRfE_0.jsonl#L11-L12]]
