---
description: Methods for moving Distinguished Names (DNs) within Active Directory,
  specifically detailing procedures using PowerShell cmdlets (Move-ADObject) and the
  Apache Directory Studio GUI interface.
name: active-directory-move-dns
session_id: sharegpt_wohQ2LX_0
source_conversation: '[[session/dialog/sharegpt_wohQ2LX_0.jsonl]]'
---

# Moving Active Directory Distinguished Names (DNs)

## PowerShell Method
*   Use the `Move-ADObject` cmdlet to move AD objects, such as organizational units (OUs), within the directory [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
*   **Connection**: Execute `Connect-ADDomain -Server <AD_server_name>` in PowerShell to connect to the target domain [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
*   **Retrieval**: Use `Get-ADObject` with the `-Filter` parameter to select specific DNs; an example retrieves OUs starting with "Sales": `$sourceOUs = Get-ADObject -Filter 'Name -like "Sales*"' -SearchBase '<DN_of_parent_OU>'` [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
*   **Execution**: Run `Move-ADObject -Identity $sourceOUs -TargetPath '<DN_of_destination_OU>'` to transfer the collected OUs to the specified destination path [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].

## Apache Directory Studio Method
*   Utilize Apache Directory Studio, described as a free, open-source LDAP browser and directory client for managing Active Directory [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
*   Launch the application and connect to the AD server [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
*   In the "LDAP Browser" view, locate the OU containing the target DNs [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
*   Right-click the target item and select "Move" from the context menu to open the "Move Entry" dialog box [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
*   Within the "Move Entry" dialog, click "Browse" to select the destination OU, then click "Finish" to complete the operation [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
