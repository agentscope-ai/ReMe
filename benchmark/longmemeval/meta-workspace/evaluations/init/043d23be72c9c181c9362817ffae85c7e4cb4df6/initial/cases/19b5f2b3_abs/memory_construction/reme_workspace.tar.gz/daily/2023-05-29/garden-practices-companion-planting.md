---
description: Explanations of companion planting mechanisms including shading, repellence,
  nutrient uptake, and growth habits. A curated list of effective plant pairings such
  as basil with tomatoes, mint with lemon balm, and thyme with strawberries. Strategic
  guidelines for dividing vegetable garden beds into sections and rotating families
  like brassicas, solanaceae, legumes, root vegetables, and alliums across four seasons
  to optimize soil fertility and manage pests.
name: garden-practices-companion-planting
session_id: 9f8fa5e4_2
source_conversation: '[[session/dialog/9f8fa5e4_2.jsonl]]'
---

## Companion Planting Techniques [[session/dialog/9f8fa5e4_2.jsonl#L6-L12]]
* **Mechanisms**: Plants interact to improve growth, health, and productivity through four primary methods: 
  * Shading taller plants over shorter ones to reduce soil temperature and moisture loss.
  * Repellence of harmful insects or attraction of beneficial predatory insects.
  * Nutrient sharing where varying requirements allow complementary uptake or direct provision between roots.
  * Efficient spatial usage via contrasting growth habits like sprawling versus upright forms.
* **Plant Pairings & Examples**: 
  * Basil with Tomatoes improves tomato flavor and repels whiteflies and aphids.
  * Mint with Lemon Balm shares compatible conditions, creating dense fragrant borders.
  * Chives with Roses deter aphids while enhancing floral scent profiles.
  * Marigolds with Carrots neutralize soil nematodes and scare away rabbits and deer.
  * Dill with Cucumbers provides structural shade and boosts cucumber flavor.
  * Thyme with Strawberries repels ground-dwelling slugs and snails.
  * Oregano with Peppers enhances pepper taste and offers antifungal protection.
  * Borage alongside most herbs attracts bees and butterflies for pollination support.
* **Execution Strategy**: Select compatible species sharing identical space needs. Plan for mature plant sizes rather than seedling dimensions. Group plants by strict light, water, and nutrient requirements. Continuously monitor performance metrics to refine spatial layouts.

## Garden Bed Crop Rotation [[session/dialog/9f8fa5e4_2.jsonl#L7-L16]]
* **Benefits & Purpose**: Rotating crops across defined land areas breaks pest and disease life cycles, optimizes localized nutrient extraction rates, encourages diverse soil microorganisms, minimizes soil erosion risks, and maintains overall soil structure integrity.
* **Bed Configuration**: Partition gardens into three to four distinct sections based on total available area.
* **Vegetable Family Classifications**: 
  * Brassicas (includes broccoli, cauliflower, kale)
  * Solanaceae (includes tomatoes, peppers, eggplants)
  * Legumes (includes beans, peas, lentils)
  * Root vegetables (includes carrots, beets, radishes)
  * Alliums (includes onions, garlic, leeks)
* **Rotation Protocol**: Shift every family exactly one section clockwise each season (e.g., Season 1 moves all families to Section 2; Season 2 moves them to Section 3). Always position heavy feeders directly after light feeders. Place nitrogen-demanding crops immediately following nitrogen-fixing legume sections. Record historical layout maps to track progress. Incorporate green manures or cover crops in empty beds to restore nutrients and attract helper insects. Amend soil consistently using aged manure and compost inputs.
