---
description: A comprehensive guide extracted from a conversation regarding photography
  techniques for capturing urban environments, city landscapes, and street art. Covers
  fundamental equipment usage, specific protocols for daytime versus nighttime shooting
  conditions, managing harsh light and shadows, methods for researching historical
  locations and urban transformation, and ethical guidelines for documenting street
  art scenes. Includes recommendations for the Local History Museum and general post-processing
  workflows.
name: cityscape-and-street-art-tips
session_id: cb2f5565_3
source_conversation: '[[session/dialog/cb2f5565_3.jsonl]]'
---

## Photography Goals and Exhibition Context [[session/dialog/cb2f5565_3.jsonl#L1-L1,L5-L5,L11-L11]]
- On 2023-02-15, the user attended a photography exhibition at the Local History Museum, lasting approximately two and a half hours.
- The exhibit displayed works depicting the city's architectural and cultural transformation over the past century.
- Viewing the exhibition inspired the user to improve personal photography skills, with specific interests in capturing cityscapes, historical urban changes, and street art/graffiti documentation.

## General Cityscape Composition and Technique [[session/dialog/cb2f5565_3.jsonl#L2-L2]]
- Master camera operations by utilizing manual mode, aperture priority, and shutter priority settings to dictate exposure parameters.
- Shoot during the golden hour (dawn or dusk) to utilize soft, warm lighting; avoid harsh midday sun to prevent unflattering shadows.
- Construct compositions utilizing leading lines, symmetry, framing, and the rule of thirds to achieve balance.
- Identify distinct textures, patterns, and interesting architectures to add depth to the image.
- Experiment with unconventional angles, including looking upward at structures or shooting from low/high vantage points like rooftops or skyscrapers.
- Incorporate reflective surfaces such as puddles, mirrors, or glass windows to layer visual interest.
- Integrate artificial city lights, such as neon signs and streetlights, to provide color and atmosphere.
- Always shoot in RAW format to maximize data retention for flexible editing later.
- Utilize exposure bracketing to capture diverse dynamic ranges suitable for High Dynamic Range (HDR) software merging.
- Mount the camera on a tripod to stabilize equipment and allow for slower shutter speeds without camera shake.
- Execute post-production processing using Adobe Lightroom or Photoshop to adjust exposure, contrast, and color balance.
- Study the portfolios of other professional photographers found in galleries or online publications.
- Include human activity or panning techniques to inject energy and motion into the static cityscape.

## Nighttime Cityscape Photography Protocols [[session/dialog/cb2f5565_3.jsonl#L4-L4]]
- Rely heavily on a sturdy tripod to support camera weight and ensure absolute stability during long exposures.
- Decrease shutter speed to the 10-30 second range to capture motion blur and light trails effectively.
- Maintain ISO sensitivity at its lowest setting (100-400) to eliminate digital noise and artifacts.
- Use wide-angle lenses ranging between 10-24mm to encompass vast urban spaces from lower perspectives.
- Set precise white balance configurations (tungsten or fluorescent) to accurately reflect artificial lighting sources.
- Engage bulb mode functionality when exposure times must exceed the standard 30-second limit.
- Schedule shoots during the blue hour—the interval immediately following sunset—for optimal ambient lighting conditions.
- Manage power and storage logistics by carrying spare batteries and memory cards for extended sessions.
- Scout locations beforehand to identify optimal vantage points such as bridges, alleys, and elevated rooftops.
- Minimize physical camera disturbance using remote shutter releases or self-timers.
- Select locations distant from excessive light pollution to capture clearer skies and stars.
- Apply noise reduction techniques or dark frame subtraction during post-processing phases.
- Capture the energetic dynamics of the urban environment by including pedestrians and moving traffic.

## Daytime Cityscape and Lighting Management [[session/dialog/cb2f5565_3.jsonl#L6-L6]]
- Take advantage of overcast weather conditions, which naturally diffuse harsh sunlight and reduce extreme contrasts.
- Attach a polarizing filter to reduce surface glare, deepen blue tones in the sky, and increase overall color saturation.
- Position the photographer within the shade of surrounding structures to mitigate direct solar impact.
- Actively seek out shadow formations that contribute geometric shapes or narrative context to the scene.
- Utilize reflectors or diffusion panels to manipulate ambient light intensity.
- Implement graduated neutral density filters to balance exposure differences between bright skylines and darker ground-level foregrounds.
- Incorporate cloud formations to enhance atmospheric texture and visual depth.
- Aim for high-angle perspectives from hills or buildings to capture macro layouts of the city.
- Capture intimate details of architectural features, materials, and active street life rather than only grand vistas.
- Prefer shooting during weekdays to avoid peak weekend crowds and chaotic street activity.
- Adapt patience to shifting daylight conditions, modifying composition to suit changing illumination.
- Ensure safety measures are taken, including wearing sunscreen, hats, and maintaining hydration.

## Researching Urban Transformation and History [[session/dialog/cb2f5565_3.jsonl#L8-L8]]
- Conduct archival research utilizing resources available at the Local History Museum or public domains like the Library of Congress Chronicling America database.
- Leverage geographic technology tools such as Google Earth and Google Street View to analyze spatial changes over decades.
- Consult local historians, licensed architects, and urban planners to identify historically significant redevelopment zones.
- Target areas exhibiting juxtaposed architectural styles where modern construction overlaps with historic remnants.
- Document districts undergoing rapid gentrification, repurposing of former industrial facilities, or urban renewal projects.
- Record municipal infrastructure evolution, specifically monitoring highway networks, water reclamation systems, and transit hubs.
- Visit municipal libraries to access physical newspapers, archives, and vintage photography collections.
- Interview lifelong residents to gather oral histories regarding observed urban shifts.
- Monitor local community forums and social media networks to discover undocumented transformation sites.
- Focus photographic attention on historic landmarks, abandoned facilities being renovated, and notable public art installations.

## Street Art and Graffiti Documentation Guidelines [[session/dialog/cb2f5565_3.jsonl#L10-L10,L12-L12]]
- Locate artistic works by investigating dedicated online platforms such as Instagram, Facebook, and Flickr galleries.
- Participate in organized local street art collectives and attend public festivals to meet creators.
- Scavenge through alleyways and backstreets where spontaneous graffiti often appears.
- Exclusively photograph legally sanctioned and authorized murals to respect private property rights and artist intent.
- Exercise caution to avoid compromising artist anonymity or altering the integrity of the physical work.
- Schedule captures during the golden hour to enhance the vibrancy of pigments against building facades.
- Use wide-angle optics (10-24mm) to contextualize the artwork within its immediate physical environment.
- Emphasize detailed close-ups highlighting paint textures, intricate colors, and layered spray patterns.
- Apply monochrome or black-and-white conversion techniques to strip away distractions and focus on structural geometry.
- Document broader environmental factors—neighborhood attributes and adjacent architecture—to preserve the societal context of the piece.
- Investigate and record active creation processes, allowing viewers insight into the raw methodology behind finished pieces.
