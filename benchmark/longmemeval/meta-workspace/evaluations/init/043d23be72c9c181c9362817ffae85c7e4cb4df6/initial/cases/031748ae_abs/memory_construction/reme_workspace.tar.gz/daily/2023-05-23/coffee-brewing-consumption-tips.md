---
description: Documents user plans to explore local coffee shops, decision to switch
  to afternoon decaf for caffeine reduction, and established French press ratio preference
  of 1 tablespoon per 6 ounces. Captures comprehensive guidelines on coffee bean preservation
  (airtight containers, room temperature 60-70°F/15-21°C, immediate pre-brew grinding,
  odor avoidance, 3-6 month freezer shelf life), French press brewing parameters (standard
  1:15 to 1:17 ratio, 195°F-205°F/90°C-96°C water temperature, grind/steep/time variable
  tuning), decaf beverage characteristics (solvent-processing, 0.1-0.3% residual caffeine,
  nuanced flavor profile), and subscription service evaluation frameworks listing
  market providers (Blue Bottle Coffee, Intelligentsia Coffee, Angels' Cup, MistoBox,
  BeanBox).
name: coffee-brewing-consumption-tips
session_id: ea909af1
source_conversation: '[[session/dialog/ea909af1.jsonl]]'
---

## Finding Local Coffee Shops
- User plans to explore new coffee shops located downtown [[session/dialog/ea909af1.jsonl#L1-L2]].
- Recommended discovery methods involve checking online review platforms (Yelp, Google Reviews, TripAdvisor), browsing social media profiles (Instagram, Facebook), consulting local residents, utilizing directory sites (Coffee Shop Finder, Coffee Review), and conducting physical area exploration [[session/dialog/ea909af1.jsonl#L1-L2]].
- Contacting establishments directly to verify menus, operating hours, and atmospheres is recommended prior to visiting [[session/dialog/ea909af1.jsonl#L1-L2]].

## Coffee Bean Preservation
- Beans require storage in airtight glass or plastic containers situated in cool, dark environments such as pantries or cupboards [[session/dialog/ea909af1.jsonl#L3-L4]].
- Optimal storage maintains room temperature around 60-70°F/15-21°C; exposure to heat sources, direct sunlight, moisture, and strong odors (including onions, garlic, and spices) must be avoided [[session/dialog/ea909af1.jsonl#L3-L4]].
- Opened batches should be consumed within 7-14 days to maintain peak flavor; freezing extends availability up to 3-6 months when sealed properly and thawed at room temperature or in a refrigerator [[session/dialog/ea909af1.jsonl#L3-L4]].
- Beans should be ground immediately prior to brewing to prevent rapid flavor degradation; stale indicators include dull or musty aromas [[session/dialog/ea909af1.jsonl#L3-L4]].

## French Press Brewing Parameters
- Standard coffee-to-water benchmark sits between 1:15 and 1:17 (coffee mass to water mass) [[session/dialog/ea909af1.jsonl#L5-L6]].
- Serving benchmarks specify: 1 cup (8 oz) uses 17-20 grams coffee with 255-340 ml water; 2 cups utilize 34-40 grams coffee with 510-680 ml water; 3 cups employ 51-60 grams coffee with 765-1020 ml water [[session/dialog/ea909af1.jsonl#L5-L6]].
- Adjustments depend on origin and roast type (African/lighter roasts often require higher water ratios, South American/darker roasts tolerate lower ratios), grind size (coarser grinds demand higher water ratios), and steeping duration [[session/dialog/ea909af1.jsonl#L5-L6]].
- User reports success utilizing a 1 tablespoon coffee to 6 ounces water configuration, calculating approximately a 1:60 ratio assuming 1 tablespoon equals 10-12 grams, yielding a stronger brew than standard guidelines [[session/dialog/ea909af1.jsonl#L5-L8]].
- Additional tuning variables encompass grind consistency (achieved via burr grinders), steeping durations, bean origins, roasting levels, and water temperature maintained strictly between 195°F and 205°F (90°C to 96°C) [[session/dialog/ea909af1.jsonl#L5-L8]].

## Decaf Coffee Habits
- User reduced daily caffeine consumption by substituting afternoon beverages with decaf options [[session/dialog/ea909af1.jsonl#L9-L10]].
- Processing removes majority of alkaloids through solvent soaking methods, leaving trace amounts ranging from 0.1% to 0.3% caffeine retention [[session/dialog/ea909af1.jsonl#L9-L10]].
- Sensory profiles typically present nuanced, subtle notes with smoother mouthfeels compared to fully caffeinated equivalents; preparation follows standard water-to-bean proportions despite requiring minor grind or timing tweaks for optimal extraction [[session/dialog/ea909af1.jsonl#L9-L10]].

## Subscription Service Evaluation
- User evaluates adopting a recurring delivery model to access fresh roasted inventory from various commercial producers [[session/dialog/ea909af1.jsonl#L11-L12]].
- Selection frameworks prioritize establishing preferred intensity levels (light, medium, dark), geographic sourcing interests (single-origin versus regional blends), customization controls (frequency pausing, quantity modification, cancellation terms), pricing structures relative to weight/cup yield, and ethical production accreditations (Fair Trade, Organic, Rainforest Alliance certifications) [[session/dialog/ea909af1.jsonl#L11-L12]].
- Market examples identified include Blue Bottle Coffee, Intelligentsia Coffee, Angels' Cup, MistoBox, and BeanBox [[session/dialog/ea909af1.jsonl#L11-L12]].
