---
description: Detailed log of collaborative March Madness bracket predictions based
  on user-supplied statistical data. Documents seeding, win/loss ratios, and metric-based
  reasoning for first-, second-, and third-round matchups. Captures specific statistical
  tie-breakers (strength of schedule, rebounding margins, shooting percentages), dataset
  formatting notes, and user override decisions.
name: march-madness-bracket-predictions
session_id: sharegpt_8qFtl50_53
source_conversation: '[[session/dialog/sharegpt_8qFtl50_53.jsonl]]'
---

# March Madness Bracket Predictions

On 2023-05-21, the user collaborated with an AI assistant to fill out a college basketball tournament bracket based on datasets previously provided by the user. The predictions relied heavily on seeding order, win/loss percentages, strength of schedule, shooting metrics, and rebounding numbers.

## Reference Statistics and Dataset Notes
- Elon's statistical profile from the user's dataset records 15 wins and 17 losses, yielding a 0.469 win/loss percentage. 
- The underlying dataset uses the full "State" designation for universities rather than the abbreviated "St." format. 
[[session/dialog/sharegpt_8qFtl50_53.jsonl#L4-L7,L34-L35]]

## Round 1 Matchups and Selections
- **1 Alabama vs 16 Texas A&M**: Alabama predicted to win as the favored higher-seeded team. 
- **5 San Diego State vs 12 Charleston**: San Diego State selected due to a higher win percentage compared to Charleston and its higher seed.
- **4 Virginia vs 13 Furman**: Virginia predicted to win based on a higher win/loss percentage.
- **6 Creighton vs 11 NC State**: The AI suggested a slight edge to Creighton citing a better overall record and shooting percentages, while acknowledging NC State's defensive and rebounding strengths. The user overrode this and selected NC State, referencing a historical trend where 11 seeds upset 6 seeds in 7 of the last 10 tournament years.
- **3 Baylor vs 14 UCSB**: Baylor selected due to a significantly better record and favorable key statistics.
- **7 Missouri vs 10 Utah State**: Missouri chosen as the stronger team with a higher win percentage and better overall statistics.
- **2 Arizona vs 15 Princeton**: Arizona predicted to win against the lower-seeded Princeton.
- **8 Memphis vs 9 Florida Atlantic**: Memphis favored due to a slightly better win percentage, higher scoring average, and stronger strength of schedule.
- **5 Duke vs 12 Oral Roberts**: Duke identified as the clear favorite to win.
- **4 Tennessee vs 13 Louisiana**: Tennessee predicted to win the matchup.
- **6 Kentucky vs 11 Providence**: Kentucky selected to win.
- **7 Michigan State vs 10 USC**: Slight edge given to Michigan State for a better overall record, higher scoring average, and superior three-point shooting percentage, despite USC having a better field goal percentage and rebounding margin.
- **2 Marquette vs 15 Vermont**: The advantage given to Marquette.
[[session/dialog/sharegpt_8qFtl50_53.jsonl#L10-L39]]

## Round 2 Matchups and Selections
- **San Diego State vs Virginia**: Virginia selected to win based on a higher win percentage and higher strength of schedule than San Diego State.
- **NC State vs Baylor**: Baylor selected as the winner.
- **Missouri vs Arizona**: Arizona chosen as the winning team.
- **Purdue vs Florida Atlantic**: Purdue selected to win.
- **Duke vs Tennessee**: Duke picked to win, backed by a superior win/loss record, higher field goal percentage, and higher three-point percentage.
- **USC vs Marquette**: Marquette selected to win following an acknowledgment of an earlier oversight regarding the matchup pairings.
[[session/dialog/sharegpt_8qFtl50_53.jsonl#L42-L57]]

## Round 3 Matchups and Selections
- **Maryland vs Virginia**: Virginia selected to advance due to a slightly better win percentage.
- **Baylor vs Arizona**: Baylor picked to win the matchup.
- **Purdue vs Duke**: Duke given a slight edge to advance, cited for having more historical success in March Madness and a higher win percentage.
- **Kentucky vs Marquette**: The AI initially misidentified the bracket path but corrected itself after the user pointed out the matchup was Kentucky vs Marquette per previous selections. Both teams showed similar conference win percentages, making a definitive statistical prediction difficult.
[[session/dialog/sharegpt_8qFtl50_53.jsonl#L58-L67]]
