---
description: Detailed records of indie-rock music discovery initiated by Glass Animals,
  user habits involving Spotify commuting playlists, established preferences for music
  podcasts (All Songs Considered, Pitchfork), plus extensive recommendations for additional
  podcasts, alternative live event tracking platforms, specific upcoming live shows
  (The Black Keys and The 1975 in July), closely aligned musical acts and tracks mirroring
  The 1975's style, comprehensive categorized lists of music documentaries suitable
  for YouTube viewing, and technical clarification regarding the streaming exclusivity
  and historical context of Beyoncé's Homecoming film.
name: indie-rock-music-recommendations
session_id: bf2ca4d8
source_conversation: '[[session/dialog/bf2ca4d8.jsonl]]'
---

### Music Discovery & Recommendations [[session/dialog/bf2ca4d8.jsonl#L1-L2]]
- On 2023-05-27, the user expressed interest in indie-rock music and mentioned recently discovering the band Glass Animals.
- Recommended similar artists for fans of Glass Animals include: Tame Impala, Unknown Mortal Orchestra, Foals, alt-J, MGMT, Temples, Pond, King Gizzard & the Lizard Wizard, The Black Angels, and Mild High Club.

### Music Listening Habits & Podcasts [[session/dialog/bf2ca4d8.jsonl#L3-L5]]
- The user utilizes Spotify to discover new music and creates playlists for daily commutes.
- The user is already subscribed to music podcasts "All Songs Considered" (NPR) and "Pitchfork".
- Additional recommended music podcasts include: KCRW's Morning Becomes Eclectic, The Needle Drop, NME's New Music Show, Indiecast, The Fader's The Mix, Song Exploder, KEXP's Song of the Day, and The Adam Buxton Podcast.

### Concerts & Live Event Tracking [[session/dialog/bf2ca4d8.jsonl#L6-L7]]
- On 2023-05-27, the user confirmed having purchased tickets to see The Black Keys and The 1975 perform live in July.
- Platforms and methods recommended for tracking local concerts and festivals include: Songkick, Bandsintown, monitoring local venue websites, searching festival websites, following artists and promoters on Facebook/Instagram/Twitter, reading local music blogs/newspapers, and using targeted Google searches.

### Similar Artists & Songs to The 1975 [[session/dialog/bf2ca4d8.jsonl#L8]]
- Artists sharing stylistic similarities with The 1975 (noted for blending indie rock, pop, and electronica) include: Pale Waves, The Neighbourhood, Two Door Cinema Club, Walk the Moon, and COIN.
- Suggested similar songs to listen to are: Arctic Monkeys - "Do I Wanna Know?", The XX - "Intro", Foals - "My Number", Panic! At The Disco - "High Hopes", and Bleachers - "Don't Take the Money".

### Music Documentaries & Streaming Availability [[session/dialog/bf2ca4d8.jsonl#L9-L12]]
- On 2023-05-27, the user expressed interest in watching music documentaries on YouTube.
- Genre-spanning documentary recommendations included:
  - Classic Rock/Iconic: The Last Waltz (1978), Gimme Shelter (1970), The Song Remains the Same (1976).
  - Indie/Alternative: The Punk Rock Movie (1978), Hype! (1996), The Decline of Western Civilization (1981).
  - Hip-Hop/R&B: Style Wars (1983), The Art of Rap (2012), The Soul of a Man (2003).
  - Festivals/Concerts: Woodstock (1970), Coachella: 20 Years in the Desert (2020), Stop Making Sense (1984).
- The user intended to stream Beyoncé's documentary "Homecoming" on YouTube, but clarified it is exclusive to Netflix. "Homecoming: A Film by Beyoncé" chronicles her 2018 Coachella performance honoring historically black colleges and universities (HBCUs).
