---
description: Documentation of preparation steps for the upcoming performance in the
  musical Les Misérables. Key actions include picking up the script from the theater
  office on 2023-05-28 and inquiring about the rehearsal schedule. Establishes a routine
  for script review, line memorization, staging visualization, and vocal practice.
  Records specific strategy for drafting a 50-75 word program biography, emphasizing
  past acting credits while excluding the immediate audition timeline.
name: les-miserables-preparation-plan
session_id: 8fa624b2_3
source_conversation: '[[session/dialog/8fa624b2_3.jsonl]]'
---

### Production Context [[session/dialog/8fa624b2_3.jsonl#L1-L3]]
- The user is performing in the cast of the musical *Les Misérables*. 
- A costume fitting for the character took place recently on a Thursday.

### Administrative Tasks [[session/dialog/8fa624b2_3.jsonl#L5-L6]]
- **Action**: Retrieve the official script from the Theater Office on 2023-05-28.
- **Inquiry**: During the visit, ask the staff for any updates regarding the rehearsal schedule and confirm preparation requirements.

### Rehearsal & Study Schedule [[session/dialog/8fa624b2_3.jsonl#L4]]
- **Script Mastery (1–2 hours)**: Devote time to reviewing scenes, memorizing lines, studying stage directions, and visualizing blocking/movements.
- **Vocal Training (30 mins – 1 hour)**: Focus on pitch, tone, emotion, and harmonies. Record oneself to identify areas for improvement.
- **Choreography**: Set aside specific time to review and practice dance moves.
- **Process Habits**: Arrive early before rehearsals to settle. Actively take notes during sessions and review them afterward.

### Program Biography Drafting [[session/dialog/8fa624b2_3.jsonl#L7-L12]]
- **Guidelines**: Biographies should be concise (1–2 sentences or 50–75 words). Highlight relevant prior theater experience, training, and awards. Include a brief personal element regarding the role and proofread strictly.
- **Timeline Clarification**: Although the user auditioned approximately three weeks ago, the recent costume fitting indicates the rehearsal phase is just beginning.
- **Decision**: To avoid confusion and adhere to brevity, the biography will focus solely on established background qualifications rather than the immediate audition and recent rehearsal timeline.
