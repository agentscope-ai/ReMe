---
description: 'Summary of Financial Management and Decision Making Assignment #5 reflection
  constructed for Maiko Haga. Covers assignment parameters (100 points, text entry
  box submission, Friday March 31st 11:59pm deadline), complete course curriculum
  (six topics: Capital Budgeting, Financial Markets & Stocks, Risk and Return & Bond
  Valuation, Projections & Sustainable Growth Rate, Corporate Valuation, and Performance
  Management/KPIs/Integrated Reporting) and faculty profile for Professor Claudia
  Sonz Roehl (Hult International Business School instructor, Certified Public Accountant,
  prior experience at Deloitte, JPMorgan, and Fitch Investors). Extracts full professional
  and educational timeline for Maiko Haga (San Francisco Bay Area-based aspiring data
  analyst and STEM MBA candidate, detailing degrees from Hult International Business
  School, Tokyo University of Foreign Studies, and UCLA Extension, plus roles at Infor,
  Infosys, PwC, JBS USA, Calsoft Systems, Century & Yanai, Mitsubishi Electric Mechatronics
  Software Corporation, The Dai-ichi Life Insurance Company, and ING Life Insurance
  Ltd Japan). Documents the explicit application of four course frameworks—Risk and
  Return & Bond Valuation, Projections & Sustainable Growth Rate, Capital Budgeting
  – Processes & Metrics, and Performance Management Systems & Key Performance Indicators—to
  align with Maiko''s target career as a data analyst.'
name: financial-management-assignment-reflection
session_id: sharegpt_dabXXRO_10
source_conversation: '[[session/dialog/sharegpt_dabXXRO_10.jsonl]]'
---

### Assignment Overview
- Financial Management and Decision Making Assignment #5 carried a point value of 100, required submission via a text entry box, and carried a deadline of Friday, March 31st by 11:59pm. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L1-L1]]
- The assignment required a reflection piece identifying two distinct financial topics or concepts learned during the course that the student intends to apply during their next internship or career path. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L1-L1]]

### Course Structure and Faculty Information
- The Financial Management and Decision Making course at Hult International Business School prepares students to understand and contribute to financial processes and decisions, covering profit planning, breakeven analysis, operating budgets, capital budgets, and variance analysis. Course Learning Outcome 1 (CLO1) focuses on learning and applying financial decision-making tools to managerial scenarios, while Course Learning Outcome 2 (CLO2) targets the creation of budgets and performance measurement processes. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L1-L1]]
- Official Course Topics include: 1. Capital Budgeting – Processes & Metrics, 2. Introduction to Financial Markets & Stocks, 3. Risk and Return & Bond Valuation, 4. Projections & Sustainable Growth Rate, 5. Capital Budgeting & Corporate Valuation, 6. Performance Management Systems & Key Performance Indicators, & Integrated Reporting. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L1-L1]]
- Professor Claudia Sonz Roehl serves as the acclaimed faculty member for accounting and finance at Hult International Business School. Professor Roehl holds over ten years of financial industry experience working in public accounting as a Certified Public Accountant (CPA) at Deloitte and Wall Street firms, including JPMorgan and Fitch Investors, frequently evaluating esoteric financial investment instruments. Professor Roehl teaches by distilling complex financial and business topics into understandable concepts through real-world examples and maintains active involvement with non-profit organizations focused on community engagement, women in the field of finance, and broader access to financial literacy. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L1-L1]]

### Student Profile: Maiko Haga
- Maiko Haga operates as an aspiring data analyst located in the San Francisco Bay Area, currently pursuing an STEM MBA through Hult International Business School with a graduation target of August 2023, and actively seeking an internship in 2023. Educational credentials include a Master of Business Administration from Hult International Business School, a Bachelor of Arts in English from Tokyo University of Foreign Studies, and a General Business Studies Certificate in Accounting from UCLA Extension. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L1-L1]]
- Maiko Haga characterizes professional identity as a former English-major linguist combined with an MBA and a Master in Analytics within the enterprise systems consulting space, positioning themselves as a liaison across cultural and functional borders, with self-described traits including recovering perfectionism, newfound compassion, and die-hard attention to detail. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L1-L1]]
- Professional tenure spans multiple global locations and sectors: Senior Consultant at Infor (2020-2022); On-site Business Analyst Consultant at Infosys (2019-2020); Management and Technology Consultant at PwC (2019) in Tokyo, Japan; tenures at JBS USA in Torrance, California (2015-2019) and Calsoft Systems in Torrance, California (2014-2015) involving Microsoft Power BI, Dynamics GP, and Dynamics NAV; Auditor Intern at Century & Yanai in Los Angeles, California conducting periodic financial review, auditing, financial analysis/forecast, and Quickbooks bookkeeping (2014); Bilingual Technical Writer specializing in industrial software localization and mechanical/technical translation at Mitsubishi Electric Mechatronics Software Corporation in Nagoya, Aichi, Japan (January 2012 - February 2013); Corporate Planning Analyst focusing on Investor Relations at The Dai-ichi Life Insurance Company, Limited in Tokyo, Japan managing quarterly investor conferences, statutory disclosure, and corporate website overhaul project management (February 2009 - March 2011); and Project Management Office Coordinator for Bancassurance Strategy at ING Life Insurance, Ltd Japan in Tokyo, Japan (April 2006 - December 2008). [[session/dialog/sharegpt_dabXXRO_10.jsonl#L1-L1]]

### Application of Financial Frameworks to Career Path
- Risk and Return & Bond Valuation connects directly to data analyst responsibilities by enabling the evaluation of investment performance metrics and the formulation of client recommendations aligned with specific risk tolerances and investment goals. Proficiency in bond valuation provides capability to assess fixed-income asset worth for corporate portfolio management. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L2-L2]]
- Projections & Sustainable Growth Rate equips data analysts with data-driven forecasting techniques to produce reliable strategic planning insights. Understanding sustainable growth rate facilitates determination of optimal expansion pacing that avoids resource strain and preserves financial stability. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L2-L2]]
- Capital Budgeting – Processes & Metrics applies to long-term investment decision evaluation, requiring data analysts to analyze project potential returns on investment and provide metric-backed insights for management regarding business expansion, product development, or infrastructure investments. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L4-L4]]
- Performance Management Systems & Key Performance Indicators (KPIs) framework allows assessment of organizational project effectiveness and efficiency. Familiarity enables optimization of data-driven initiatives, establishment and monitoring of performance indicators, clear communication of financial-to-business performance relationships to stakeholders, and direct contribution to informed managerial decision-making. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L4-L4]]
- Generated reflection outputs were explicitly tailored for Maiko Haga, deliberately mapping every discussed Financial Management and Decision Making course concept to the specific operational realities and future trajectory of an aspiring data analyst. [[session/dialog/sharegpt_dabXXRO_10.jsonl#L6-L6]]
