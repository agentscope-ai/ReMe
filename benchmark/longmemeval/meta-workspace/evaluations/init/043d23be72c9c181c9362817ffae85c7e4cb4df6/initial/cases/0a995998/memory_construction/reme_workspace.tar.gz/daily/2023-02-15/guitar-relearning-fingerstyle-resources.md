---
description: Notes documenting the resumption of acoustic-electric guitar practice
  after a prolonged hiatus, encompassing purchasing guidelines for acoustic-electric
  models, comparisons of group versus private instructional formats, enrollment in
  a 6-week adult course, metronome integration for rhythmic precision, foundational
  fingerstyle techniques (including thumb anchoring and T-I-T-I patterns), and a curated
  bibliography of digital video channels, educational websites, reference books, and
  community forums.
name: guitar-relearning-fingerstyle-resources
session_id: ad3d0815_1
source_conversation: '[[session/dialog/ad3d0815_1.jsonl]]'
---

## Relearning Guitar & Purchasing Considerations [[session/dialog/ad3d0815_1.jsonl#L1-L2]]
- An acoustic-electric guitar has been storing unused in the corner of a room for years due to a prior busy schedule, prompting a return to active practice.
- Evaluation criteria for acoustic-electric guitar acquisition emphasize body shape and scale length, tonewood selection (spruce for neutral balance, mahogany for warmth), integrated electronics (Fishman, LR Baggs, Taylor Expression System), fretboard ergonomics, string action clearance, manufacturer heritage (Taylor, Martin, Yamaha, Epiphone), financial parameters, and supplementary hardware like cutaways or onboard tuners.
- Highlighted candidate instruments include the Taylor GS Mini-e, Yamaha FGX800C, Martin LX1E Little Martin, and Epiphone Hummingbird PRO.

## Lesson Structure & Rhythm Development [[session/dialog/ad3d0815_1.jsonl#L3-L6]]
- Comparative analysis indicates that group instruction delivers communal motivation, peer-derived insights, reduced tuition fees, sequential curriculum mapping, live performance simulation, and routine adherence, whereas individual tutoring yields customized pacing, objective-specific drilling, and advanced technical calibration.
- Confirmation exists for participation in a six-week adult ensemble program operating out of a local music retail establishment commencing the week of 2023-02-22.
- Consistent metronome application drastically accelerates temporal accuracy, metric steadiness, bimanual synchronization, and overall performance assurance.
- Optimal metronome deployment initiates at 60-80 BPM increments, incorporates subdivision clicks, layers drone or backing track audio, preserves natural swing over rigid quantization, and establishes uninterrupted daily rehearsal slots.

## Fingerstyle Execution Protocols [[session/dialog/ad3d0815_1.jsonl#L7-L8]]
- Core preparatory drills isolate individual digit mobility, enforce unclenched wrist architecture, and mandate either sustained natural keratin growth or synthetic plastic overlay adoption.
- Preliminary repertoire construction anchors the right-hand thumb on the three lowest strings (Low-E, A, D), cycling through primary alternations defined as T-I-T-I, T-I-M-I, and T-M-I-T, while deploying middle, ring, and pinky digits across the G, B, and High-E strings.
- Intermediate progression targets smooth arpeggiated voicings and shattered triads based on open A-major, C-major, and G-major shapes, supplemented by analytical listening of documented practitioners Andy McKee, Tommy Emmanuel, and James Taylor.
- Daily conditioning begins with constrained ten-to-fifteen minute windows to suppress muscular strain, expanding temporal allocation incrementally as neuromuscular pathways fortify.

## Educational Asset Catalog [[session/dialog/ad3d0815_1.jsonl#L9-L10]]
- Video tutorial repositories aggregate masterclass feeds from Andy McKee, Tommy Emmanuel, James Taylor, Fingerstyle Guitar Academy, GuitarLessons365, Marty Music, and Fingerpicking Guitar.
- Web-based instructional hubs comprise standalone domains Fingerstyle Guitar and Guitar Salon International, aggregator networks Fingerpicking.net and Guitar Tricks, plus Justin Sandercoe's Justin Guitar pedagogical portal.
- Physical reference archives contain printed manuals titled The Art of Fingerstyle Guitar (authored by David Hamburger) and Fingerstyle Guitar: A Comprehensive Guide (authored by Stephen Bennett).
- Peer networking occurs primarily within the Reddit forum designated r/FingerstyleGuitar.
