---
description: Comprehensive photographic guidance for urban environments extracted
  from a consultation involving a user's visit to the Local History Museum exhibition
  on city transformation. Covers technical camera fundamentals, specific protocols
  for capturing cityscapes during daylight (managing harsh sun/contrast using filters
  and shade) versus nighttime (long exposure, low ISO, white balance), methodologies
  for researching historical urban change locations via archives and digital tools,
  and ethical standards for documenting authorized street art and graffiti including
  composition and legal considerations.
name: cityscape-street-art-photography-guide
session_id: cb2f5565_3
source_conversation: '[[session/dialog/cb2f5565_3.jsonl]]'
---

## Exhibition Visit and Context [[session/dialog/cb2f5565_3.jsonl#L1-L1,L5-L5,L11-L11]]
- On 2023-02-15, spent approximately two and a half hours visiting the Local History Museum for a photography exhibition showcasing the city's architectural and social transformation over the past century.
- Viewing the exhibition works served as primary inspiration for improving personal photography skills, specifically targeting urban landscapes, historical documentation, and street art.

## Fundamental Cityscape Photography Techniques [[session/dialog/cb2f5565_3.jsonl#L2-L2]]
- Operate camera using manual mode, aperture priority, and shutter priority to control depth of field and exposure.
- Schedule shoots during the golden hour (dawn or dusk) to utilize soft, warm illumination; avoid harsh midday sun to prevent unflattering shadows.
- Construct compositions utilizing leading lines, symmetrical layouts, framing devices, and the rule of thirds.
- Capture interesting architectural details, repeating patterns, and surface textures to add visual depth.
- Incorporate reflective surfaces such as glass facades, puddles, or mirrors to introduce secondary layers of interest.
- Integrate artificial urban lighting sources like neon signs and streetlights to provide chromatic variety.
- Record images exclusively in RAW format and utilize bracketing to capture high dynamic range for post-processing.
- Stabilize equipment on a sturdy tripod to enable slower shutter speeds without camera shake.
- Perform post-production editing using Adobe Lightroom or Photoshop to adjust exposure, contrast, and color balance.
- Study the work of other photographers found in galleries or online to analyze successful composition techniques.

## Nighttime Cityscape Protocols [[session/dialog/cb2f5565_3.jsonl#L4-L4]]
- Deploy specialized wide-angle lenses ranging between 10mm and 24mm to encompass grand urban structures.
- Configure sensors to lowest ISO settings (100-400) to minimize digital noise and artifacts.
- Engineer long exposures using slow shutter speeds (10-30 seconds) or dedicated "bulb" mode to capture motion blur and light trails.
- Calibrate white balance to match specific lighting conditions, applying tungsten or fluorescent presets for artificial lights and daylight or shade presets for outdoor scenes.
- Execute shoots during the blue hour—the period shortly after sunset—to capture balanced ambient light.
- Implement noise reduction techniques including dark frame subtraction and algorithmic software processing.
- Pre-scout locations to identify optimal vantage points such as rooftops, bridges, and alleys.
- Ensure logistical readiness by carrying backup batteries and memory cards due to power-intensive night operations.
- Utilize remote shutter releases or self-timers to eliminate trigger-induced camera vibration.

## Daytime Cityscape and Harsh Lighting Management [[session/dialog/cb2f5565_3.jsonl#L6-L6]]
- Exploit overcast weather conditions as natural diffusers that soften harsh sunlight and reduce extreme contrasts.
- Attach polarizing filters to suppress glare, enhance color saturation, and deepen atmospheric sky tones.
- Position the photographer within architectural shade zones to mitigate direct solar impact while preserving shadow definition.
- Identify interesting shadow formations created by buildings to add structural geometry and texture.
- Use reflectors or diffusion panels to redirect ambient light onto darker subject areas.
- Monitor cloud cover for potential aesthetic contributions to composition and depth.
- Employ graduated neutral density filters to equalize exposure differences between bright skylines and terrestrial foregrounds.
- Capture intimate architectural details and street life alongside broader metropolitan vistas.
- Prefer shooting on weekdays to avoid weekend pedestrian congestion and chaotic movement.
- Maintain physiological protection measures including sunscreen, hats, and hydration when operating in direct sunlight.

## Urban Transformation Research and Documentation [[session/dialog/cb2f5565_3.jsonl#L8-L8]]
- Conduct archival research utilizing physical repositories at the Local History Museum and digital aggregators like the Library of Congress Chronicling America database.
- Navigate spatial changes using geographic tools such as Google Earth and Google Street View.
- Consult local experts including historians, architects, and urban planners to identify significant redevelopment zones.
- Target areas exhibiting contrasting architectural styles where historic structures exist alongside modern developments.
- Document neighborhoods undergoing gentrification, former industrial sites repurposed for commercial use, or abandoned buildings converted into art spaces.
- Trace infrastructure evolution including public transportation expansions, highway networks, and waterfront redevelopments.
- Interview long-time residents to gather oral histories regarding neighborhood shifts.
- Monitor social media and community forums to discover undocumented or trending transformation sites.

## Street Art and Graffiti Documentation Guidelines [[session/dialog/cb2f5565_3.jsonl#L10-L10,L12-L12]]
- Locate artworks by searching platforms like Instagram, Facebook, and Flickr, or by joining local street art collectives and attending festivals.
- Focus exclusively on legally authorized and sanctioned murals to respect intellectual property rights.
- Adhere to strict ethical protocols that prioritize artist anonymity and preserve the integrity of the artwork.
- Capture images during the golden hour to maximize color vibrancy and minimize harsh shadows.
- Use wide-angle optics (10-24mm) to contextualize the artwork within its surrounding environment.
- Experiment with unique angles and perspectives rather than relying solely on flat frontal shots.
- Apply black and white conversion techniques to emphasize shapes, textures, and patterns within the mural.
- Document the immediate neighborhood context to establish the cultural significance of the piece.
- Engage with the local artistic community to gain deeper insight into the scene and its motivations.
