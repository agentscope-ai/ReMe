---
description: Comprehensive notes on a user's plan to purchase a primary residence.
  Includes user profile (income $60k, savings $20k, turning 30), specific property
  goals ($250k-$300k, 1-hour commute radius), detailed budget allocations ($3,150-$4,400
  essentials, $1,500+$ savings), down payment strategies ($50k-$60k target), and extensive
  comparative analysis of mortgage instruments (Fixed-Rate vs Adjustable-Rate vs FHA
  vs Conventional loans) along with FHA loan limit thresholds across US locations.
name: house-buying-planning-and-finances
session_id: 7652f851_1
source_conversation: '[[session/dialog/7652f851_1.jsonl]]'
---

## User Profile & Real Estate Objectives [[session/dialog/7652f851_1.jsonl#L1-L3]]
*   **Demographics & Milestones**: The user turned 30 years old recently, specifically noting a celebration on February 12th, marking a period of reflection on post-college progress.
*   **Financial Standing**: Annual income stands at approximately $60,000 with liquid savings totaling roughly $20,000.
*   **Target Acquisition**: Aiming to purchase residential property valued between $250,000 and $300,000.
*   **Location Preference**: Open to various specific areas, provided the property falls within a maximum one-hour commute distance from the user's current place of employment.

## Budget Framework & Capital Accumulation [[session/dialog/7652f851_1.jsonl#L4]]
*   **Monthly Budget Allocations**:
    *   **Essential Expenses**: Projected at $3,150–$4,400 per month (comprising rent $1,500–$2,000, utilities $150–$200, groceries $500–$700, transportation $500–$700, and minimum debt repayments $500–$1,000).
    *   **Savings & Accelerated Repayment**: Allocated $1,500–$2,500 monthly toward saving $1,000–$1,500 for the down payment and paying an additional $500–$1,000 toward existing debts beyond minimums.
    *   **Discretionary Spending**: Cap set between $900 and $2,000 monthly for entertainment, travel, and miscellaneous items.
*   **Down Payment Targets**: Requirement calculated at $50,000–$60,000 (representing 20% of the target price range). Closing costs estimated separately at 2–5% of the final purchase price.
*   **Execution Strategy**: Implementation of automatic bank transfers to high-yield savings or certificates of deposit (CDs), aggressive elimination of high-interest credit card balances, potential lifestyle adjustments (e.g., reducing dining out or acquiring roommates), and pursuing raises or side hustles to increase income velocity. Timeline projections suggest saving $1,500/month for 36 months yields ~$54,000.

## Comparative Mortgage Instruments [[session/dialog/7652f851_1.jsonl#L6-L8]]
*   **Fixed-Rate Mortgages**: Carries a static interest rate over 15–30 years. Offers total predictability in monthly payments and shields against market volatility; however, typically commands higher initial rates compared to ARMs and includes penalties for early refinancing. The user currently expresses a strong preference for this instrument due to a desire to avoid the uncertainty associated with variable rates.
*   **Adjustable-Rate Mortgages (ARMs)**: Features fluctuating rates tied to market conditions. Provides lower initial interest rates and monthly payments but exposes the borrower to significant rate risk and payment increases in the future.
*   **Federal Housing Administration (FHA) Loans**: Government-backed mortgages designed for accessibility.
    *   **Requirements**: Minimum down payment of 3.5%; minimum credit score of 580 for maximum financing; allows for more lenient debt-to-income ratios.
    *   **Cost Structure**: Requires Mortgage Insurance Premiums (MIP) which are ongoing, plus an upfront mortgage insurance premium (financable into the loan). Generally higher interest rates than conventional loans for equivalent borrowers.
    *   **Drawbacks**: Stricter appraisal standards and localized loan limit caps.
*   **Conventional Loans**: Standard non-government-backed products. Require credit scores between 620–740 and down payments ranging from 5% to 20%. Advantages include the absence of mandatory mortgage insurance once 20% equity is reached and generally lower base interest rates for qualified candidates.
*   **Other Programs**: VA Loans (for military veterans, competitive rates/no down payment possible) and USDA Loans (rural areas, favorable rates/low down payment).

## FHA Loan Specifics & Geographic Thresholds [[session/dialog/7652f851_1.jsonl#L10-L11]]
*   **National Limit Spectrum**: FHA loan limits scale dynamically based on regional median home prices, ranging nationally from $331,760 (low-cost areas) to $765,600 (very high-cost areas).
*   **Representative Metropolitan Examples**: New York City and Los Angeles operate at the maximum tier of $765,600; Chicago sits at $365,700; Houston and Phoenix sit at the floor of $331,760.
*   **Verification Resources**: Users are directed to utilize the official Federal Housing Administration portal via `www.hud.gov`—specifically navigating to Resources > FHA Loan Limits—to identify precise eligibility boundaries for their specific state and county jurisdictions.

## Current Status & Decision Points [[session/dialog/7652f851_1.jsonl#L9-L12]]
*   The user has expressed intent to proceed primarily with fixed-rate structures and is actively investigating FHA loans to balance lower entry costs against the burden of insurance premiums.
*   Immediate action item requires the user to research the exact FHA dollar limits applicable to their target geographic zone and crunch the comparative numbers regarding monthly cash flow implications before committing to a lender.
