---
description: Comprehensive guide to Vietnamese coffee (Cà phê sữa đá), detailing its
  late 19th-century French colonial origins, preparation methods using a phin filter
  for hot and iced servings, recommended online retailers (including Trung Nguyen
  Coffee, Nguyen Coffee Supply, Amazon, VinaCafe, and The Coffee Bean & Tea Leaf),
  and precise brewing parameters such as fine grinding, sub-boiling water temperatures,
  and spice additions.
name: vietnamese-coffee-guide
session_id: ultrachat_173041
source_conversation: '[[session/dialog/ultrachat_173041.jsonl]]'
---

# Vietnamese Coffee (Cà phê sữa đá)

## History and Origins [[session/dialog/ultrachat_173041.jsonl#L1-L2]]
- This popular coffee blend originated during the late 19th-century French colonial period in Vietnam.
- The French introduced coffee to the region. Due to the high cost, locals began mixing the coffee with condensed milk to make it significantly more affordable.

## Traditional Equipment and Serving Styles [[session/dialog/ultrachat_173041.jsonl#L2]]
- **Phin Filter**: Authentic preparation requires brewing Vietnamese coffee using a small metal drip filter, also known as a phin filter. Hot water passes through the device to extract the grounds.
- **Hot Preparation**: Brew the coffee using the phin filter and place a small amount of condensed milk in the cup beforehand. Pour the hot coffee into the cup, then stir the mixture to combine the ingredients into a rich, sweet, and creamy drink.
- **Iced Preparation (Cà phê sữa đá)**: Brew the coffee directly into a glass already filled with ice cubes. Add the condensed milk before pouring the hot coffee over the ice to stir and chill the beverage instantly.
- **Flavor Customization**: While standard preparations focus on coffee and condensed milk, adding traditional spices like cinnamon or cardamom provides an additional unique flavor profile.

## Availability and Purchasing Channels [[session/dialog/ultrachat_173041.jsonl#L3-L4]]
- Vietnamese coffee is not as ubiquitously available in general establishments as other common coffee types.
- Consumers seeking to try this blend should look for a local Vietnamese restaurant or a dedicated coffee shop that specializes in regional varieties.
- For long-term enjoyment, purchasing Vietnamese coffee beans and a phin filter from online marketplaces or physical specialty stores is the standard recommendation.

## Recommended Online Retailers [[session/dialog/ultrachat_173041.jsonl#L6]]
- **Trung Nguyen Coffee**: A prominent and well-known Vietnamese coffee brand that sells authentic coffee beans and phin filters directly through its official website.
- **Amazon**: A major marketplace platform hosting a wide variety of Vietnamese coffee beans and phin filters sourced from numerous independent brands.
- **Nguyen Coffee Supply**: An internet retailer specializing entirely in Vietnamese coffee operations, distributing an extensive catalog of beans and necessary brewing equipment.
- **VinaCafe**: Another highly recognized commercial brand offering direct-to-consumer sales of beans and filtration hardware online.
- **The Coffee Bean & Tea Leaf**: A global franchise chain that maintains an e-commerce storefront stocking Vietnamese-origin roasts and brewing accessories.

## Expert Brewing Parameters [[session/dialog/ultrachat_173041.jsonl#L10]]
- **Bean Quality**: Use freshly roasted coffee beans for the best flavor output.
- **Grind Size**: Ensure the coffee beans are ground extremely finely, as this specific texture is required for optimal extraction results within a phin filter.
- **Water Temperature and Timing**: Use hot water that sits just below the boiling point to brew the coffee, and allow it to sit for a few seconds before pouring it into the filter.
- **Dairy Substitution**: Utilize sweetened condensed milk for authentic traditional Vietnamese coffee recipes, adjusting the exact dosage to match individual taste preferences.
- **Mixing Technique**: Stir the finished brew thoroughly to guarantee the condensed milk and dark coffee extract are completely integrated.
- **Iced Glassware Selection**: When preparing iced variants, utilize a tall glass to pour the brewing coffee directly over the ice cubes, a method designed to preserve complex flavors while chilling the drink instantaneously.
- **Recipe Customization**: Continuously experiment with diverse coffee bean origins and varying blend ratios to engineer a highly personalized flavor profile.
