---
description: 'A breakdown of the core features of the annotation system (Roles: Admin,
  Tagger, Checker, Data Scientist; Features: Task Management, Annotation Tool, API
  Export) and a comprehensive proposal for training videos structured around specific
  user workflows and action-oriented tutorials (Creating Tasks, Annotating, Verifying,
  Changing Status).'
name: annotation-system-video-plans
session_id: sharegpt_vbNrVtS_293
source_conversation: '[[session/dialog/sharegpt_vbNrVtS_293.jsonl]]'
---

## System Architecture & Features

The platform serves multiple distinct user types, defined by specific capabilities:
* **Admin**: Maintains full system control. Functions include managing datasets, generating tasks, allocating users, and overseeing project timelines.
* **Tagger**: Executes the annotation phase. Duties include accessing assigned documents, applying labels and classifications, and saving results.
* **Checker**: Oversees quality assurance. Duties involve reviewing submissions from Tagers and validating or rejecting their work.
* **Data Scientist**: Consumes the finalized data. Utilizes the Application Programming Interface (API) to query datasets containing metadata, labels, and classification results.

### Workflow Mechanics
* **Task Administration**: Administrators initialize tasks by assigning specific Tagers and Checkers, setting deadlines, and monitoring completion rates.
* **Document Lifecycle**: Items move through defined stages during processing. Examples cited include statuses "Not Started," "In Progress," and "Ready for Review."
* **Data Retrieval**: External systems query the API to download processed datasets.
* **Error Protocols**: Known error conditions include "Data not found" and "Data already downloaded." Technical issues are directed to the help page support channel.
[[session/dialog/sharegpt_vbNrVtS_293.jsonl#L1]]

## Instructional Video Strategies

Following a request on 2023-05-24 to map out user actions and visual aids, a hierarchy of video tutorials was designed.

### Standardized Curriculum Structure
* **Introduction Module**: Define the software’s utility, describe the Admin/Tagger/Checker hierarchy, and summarize capabilities.
* **Onboarding Module**: Demonstrate the login sequence and provide navigational tours of the main interfaces (Dataset Screen, Task Management, Specific Task details, Annotation Tool).

### Role-Based Functional Guides
* **Administrator Tracks**:
    * **Dataset Ingestion**: Procedures for uploading source files and defining metadata fields.
    * **Resource Allocation**: Methods for distributing tasks among staff and tracking milestones.
    * **Workflow Adjustment**: Instructions for modifying global task states (e.g., switching from "Not Started" to "In Progress").
* **Tagger Tracks**:
    * **Workload Monitoring**: Locating assigned items.
    * **Annotating Documents**: Navigating the editor to tag content accurately.
    * **Progress Reporting**: Transitioning document states to reflect current activity (e.g., moving from "Not Started" to "In Progress").
* **Checker Tracks**:
    * **Review Queues**: Finding items requiring validation.
    * **Audit Procedures**: Analyzing tags and making acceptance decisions.
    * **Process Advancement**: Pushing verified items forward (e.g., transitioning from "In Progress" to "Ready for Review").

### Targeted Tutorial Titles
Specific "How-To" videos were prioritized for complex operations:
* Creating a Task
* Annotating Documents
* Verifying Annotations
* Changing Document Status

### Production Directives
Videos should prioritize strict adherence to annotation standards, optimize user speed, clearly articulate system restrictions, and solicit viewer input for updates.
[[session/dialog/sharegpt_vbNrVtS_293.jsonl#L2-L3]]
