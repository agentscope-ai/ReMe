---
description: 'Conversation detailing plans for a large-group family game night and
  exploration of strategic board games. Key topics include party game recommendations
  (e.g., Taboo, What Do You Meme), deep dives into Azul mechanics (designed by Michael
  Kiesling in 2017), and Ticket to Ride history and expansion strategies (Europe and
  Märklin expansions). Personal gaming milestones recorded: playing Scattergories
  at a cousin''s party on 2023-05-01, trying Azul at a board game cafe on 2023-05-14,
  viewing intent for a Ticket to Ride expansion seen in April 2023, and defeating
  roommate Mike in a Ticket to Ride match on 2023-05-08 by completing 6 of 8 destination
  tickets.'
name: family-game-night-planning
session_id: c3023a45_1
source_conversation: '[[session/dialog/c3023a45_1.jsonl]]'
---

## Family Game Night & Party Games
User is planning a family game night soon for a large group. Assistant recommended Charades, Pictionary, Taboo, What Do You Meme, Jenga, Two Truths and a Lie, Would You Rather, Group Storytelling, Karaoke Contest, Minute to Win It, Group Trivia, Wits & Wagers, Deception: Murder in Hong Kong, Spyfall, Codenames, and Junk Art. User specifically liked Taboo and What Do You Meme.
[[session/dialog/c3023a45_1.jsonl#L1-L3,L12-L12]]

## Strategic Board Game Recommendations
User requested strategic games comparable to Ticket to Ride. Assistant suggested Settlers of Catan, Carcassonne, Forbidden Island/Forbidden Desert, Pandemic, Codenames, Deception, Mysterium, Azul, 7 Wonders, Dixit, Elfenland, Trains, Russian Railroads, Age of Steam, Rails of Europe, and Power Grid. User expressed interest in trying Forbidden Island, Pandemic, Azul, Elfenland, and Trains.
[[session/dialog/c3023a45_1.jsonl#L3-L4,L5-L5,L8-L8,L9-L9]]

## Azul Gameplay & Experience
Azul is a tile-laying game designed by Michael Kiesling, released in 2017 for 2–4 players with a 30–45 minute playtime. Player objective involves scoring points by drafting tiles from a central pool to create lines of matching colors, complete sets, and form patterns on a player board. User had a positive experience playing Azul at a local board game cafe on 2023-05-14 and planned to purchase the base game.
[[session/dialog/c3023a45_1.jsonl#L5-L7]]

## Ticket to Ride History & Expansion Plans
User saw a Ticket to Ride expansion pack at a local game store on 2023-04-22 but had not yet purchased it. User won a match against roommate Mike on 2023-05-08 by completing 6 out of 8 destination tickets after a sneaky lucky move at the end. Assistant recommended the "Europe" expansion (adding new train cars and routes) and the "Märklin" expansion (adding a passengers mechanic). User planned to test Ticket to Ride expansions with Mike.
[[session/dialog/c3023a45_1.jsonl#L7-L11]]

## Past Gaming Milestones
User played Scattergories with family on 2023-05-01 at a cousin's birthday party. Performance was poor, but the session proved highly enjoyable.
[[session/dialog/c3023a45_1.jsonl#L1-L1]]
