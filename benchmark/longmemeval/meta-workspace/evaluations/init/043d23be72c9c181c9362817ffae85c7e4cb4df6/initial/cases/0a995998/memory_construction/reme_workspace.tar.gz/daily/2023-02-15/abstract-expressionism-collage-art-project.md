---
description: Research notes for an ongoing mixed-media art project planned on 2023-02-15.
  Covers inquiries about Abstract Expressionist artists (Pollock, Rothko, de Kooning,
  etc.), comprehensive texture creation techniques (impasto, glazing, sgraffito, etc.),
  application and supply recommendations for impasto, guidelines for integrating collage
  elements with impasto, referenced artists utilizing botanical illustrations (Gallagher,
  Mutu, etc.), and artists incorporating personal drawings (Basquiat, Rauschenberg,
  etc.). Includes specific instructional tips for material preparation, adhesion,
  layering, and manipulation.
name: abstract-expressionism-collage-art-project
session_id: 2f310ba0
source_conversation: '[[session/dialog/2f310ba0.jsonl]]'
---

## Art Project Inspiration: Abstract Expressionism
On 2023-02-15, the user seeks inspiration for an upcoming art project focusing on the Abstract Expressionist movement. Recommended artists to explore include:
- Jackson Pollock: Known for drip paintings characterized by intricate webs of splattered paint and a process-oriented technique [[session/dialog/2f310ba0.jsonl#L1-L2]].
- Mark Rothko: Signature style features large rectangular fields of color evoking emotion and introspection [[session/dialog/2f310ba0.jsonl#L1-L2]].
- Willem de Kooning: Pioneer of the movement featuring bold gestural brushstrokes, vibrant colors, and blended figurative/abstract elements [[session/dialog/2f310ba0.jsonl#L1-L2]].
- Franz Kline: Large-scale action-packed paintings with bold expressive brushstrokes focusing on color and gesture [[session/dialog/2f310ba0.jsonl#L1-L2]].
- Clyfford Still: Paintings characterized by dark brooding colors and bold geometric forms exploring nature and human experience [[session/dialog/2f310ba0.jsonl#L1-L2]].
- Helen Frankenthaler: Prominent female artist featuring large gestural brushstrokes and focus on color and texture [[session/dialog/2f310ba0.jsonl#L1-L2]].
- Robert Motherwell: Famous for the *Elegy to the Spanish Republic* series featuring bold black forms on white background; explores politics and emotion [[session/dialog/2f310ba0.jsonl#L1-L2]].
- Barnett Newman: Bold geometric forms and focus on color/composition exploring the relationship between the individual and the universe [[session/dialog/2f310ba0.jsonl#L1-L2]].
- Ad Reinhardt: Geometric forms often in square formats, focusing on color/composition, exploring the spiritual and abstract [[session/dialog/2f310ba0.jsonl#L1-L2]].
- Joan Mitchell: Expressive gestural brushstrokes and focus on color/emotion, exploring the relationship between nature and human experience [[session/dialog/2f310ba0.jsonl#L1-L2]].

## Texture Creation Techniques for Paintings
The user asks for methods to create textures in paintings. Provided techniques include:
- Impasto: Applying thick layers of paint using a palette knife or heavy brush for raised three-dimensional texture [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Scraping: Removing paint with a palette knife or scraper to reveal underlying layers or create scratched textures [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Drybrushing: Dragging an almost-dry brush across the canvas to create rough scratchy textures, works well with acrylic or oil paint [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Glazing: Applying multiple thin transparent layers to create depth, luminosity, and smooth glass-like texture [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Collage: Incorporating materials like paper, fabric, or found objects for tactile textured surfaces [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Modeling Paste: Mixing a thickening agent with paint to create heavy three-dimensional texture [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Spattering: Flicking or spattering paint using a brush or toothbrush for dynamic expressive textures [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Raking: Using a palette knife or comb to create linear ridged textures by dragging through wet paint [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Pumice Gel: Mixing pumice gel with paint for rough rocky texture [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Gel Medium: Adding gel medium to increase viscosity and create textured three-dimensional effect [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Sgraffito: Applying a layer of paint, letting it dry, then scratching through to reveal underlying layers or create intricate patterns [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Fabric Impression: Pressing fabric into wet paint to create a textured pattern [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Paper Towel Technique: Using a paper towel to blot and lift paint off the canvas for a soft mottled texture [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Stenciling: Using stencils to create geometric or organic patterns with a textured raised effect [[session/dialog/2f310ba0.jsonl#L3-L4]].
- Material Experimentation: Incorporating unusual materials like sand, coffee grounds, or found objects into the paint [[session/dialog/2f310ba0.jsonl#L3-L4]].

## Impasto Technique Application
The user decides to try the impasto technique and requests associated artists and supplies.
Recommended artists for impasto mastery:
- Vincent van Gogh: Post-Impressionist famous for thick heavy brushstrokes; works like "Starry Night" and "Wheat Field with Cypresses" showcase bold expressive impasto [[session/dialog/2f310ba0.jsonl#L5-L6]].
- Willem de Kooning: Abstract expressionist paintings feature thick chunky paint layers creating highly textured three-dimensional effects [[session/dialog/2f310ba0.jsonl#L5-L6]].
- Lucian Freud: Figurative paintings characterized by thick heavy brushstrokes adding depth and psychological intensity to portraits [[session/dialog/2f310ba0.jsonl#L5-L6]].
- Franz Kline: Abstract expressionist paintings with bold gestural brushstrokes and thick impasto textures creating dynamic energetic effects [[session/dialog/2f310ba0.jsonl#L5-L6]].
- Jean-Michel Basquiat: Mixed-media paintings combining graffiti, collage, and impasto for vibrant textured expressive works [[session/dialog/2f310ba0.jsonl#L5-L6]].
- Anselm Kiefer: Large-scale paintings and sculptures using thick impasto textures created with materials like straw, canvas, and paint [[session/dialog/2f310ba0.jsonl#L5-L6]].
- Gerhard Richter: Abstract paintings featuring thick impasto textures created with a squeegee or scraper to add chance and unpredictability [[session/dialog/2f310ba0.jsonl#L5-L6]].
Suggested impasto supplies and workflow: medium to thick-bodied paint (acrylic or oil), a palette knife or heavy brush, a painting surface (canvas, board, or paper), and optional modeling paste, gel medium, or heavy texture paste to enhance texture. Workflow advice includes working in layers to build up texture gradually and experimenting with different tools [[session/dialog/2f310ba0.jsonl#L5-L6]].

## Integrating Collage Elements
The user plans to combine impasto with collage elements for the next piece. Guidelines for incorporation:
- Select materials complementing the theme and color palette, such as paper, fabric, found objects, or photographs [[session/dialog/2f310ba0.jsonl#L7-L8]].
- Ensure the painting surface is primed and ready, utilizing gessoed canvas, board, paper, or ensuring a previously painted surface is dry and stable [[session/dialog/2f310ba0.jsonl#L7-L8]].
- Apply suitable adhesive like acrylic matte medium, decoupage medium, or spray adhesive to the back of the material or the painting surface [[session/dialog/2f310ba0.jsonl#L7-L8]].
- Arrange collage elements cohesively within the composition before securing them [[session/dialog/2f310ba0.jsonl#L7-L8]].
- Secure elements by applying additional adhesive around edges, and blend them with the surrounding area using impasto paint applied with a palette knife or brush [[session/dialog/2f310ba0.jsonl#L7-L8]].
- Build up alternating layers of paint and collage elements, allowing each layer to dry completely before adding the next [[session/dialog/2f310ba0.jsonl#L7-L8]].
- Experiment with transparent or semi-transparent materials like tracing paper or vellum to add depth [[session/dialog/2f310ba0.jsonl#L7-L8]].
- Embrace unpredictable behaviors from materials to explore new textures and effects [[session/dialog/2f310ba0.jsonl#L7-L8]].
- Seal the completed painting with varnish or sealant to protect collage elements and ensure secure attachment [[session/dialog/2f310ba0.jsonl#L7-L8]].
Additional explored collage techniques include Decollage (applying material then removing parts to reveal underlying layers), Transfer printing (using a transfer process to apply images or textures), and Assemblage (attaching found objects to create three-dimensional collage) [[session/dialog/2f310ba0.jsonl#L7-L8]].

## Incorporating Botanical Illustrations
The user considers using personal botanical illustrations as collage elements within the painting. Referenced artists successfully using botanical illustrations:
- Ellen Gallagher: Mixed-media paintings featuring collaged botanical illustrations combined with paint, ink, and paper for intricate layered compositions [[session/dialog/2f310ba0.jsonl#L9-L10]].
- Wangechi Mutu: Work incorporating African and Asian botanical illustrations combined with paint, ink, and collage to create vibrant surreal landscapes [[session/dialog/2f310ba0.jsonl#L9-L10]].
- Lynette Yiadom-Boakye: Paintings featuring botanical illustrations of plants and flowers used to explore themes of identity, history, and memory [[session/dialog/2f310ba0.jsonl#L9-L10]].
- Julie Mehretu: Large-scale paintings and prints incorporating botanical illustrations alongside architectural drawings and abstract shapes [[session/dialog/2f310ba0.jsonl#L9-L10]].
- Ana María Maiolino: Work featuring botanical illustrations combined with sculpture, installation, and performance to explore nature, culture, and the human condition [[session/dialog/2f310ba0.jsonl#L9-L10]].
- Walton Ford: Large-scale watercolors featuring botanical illustrations of plants and animals exploring nature, history, and the human condition [[session/dialog/2f310ba0.jsonl#L9-L10]].
- Hilma af Klint: Abstract paintings and drawings featuring botanical illustrations used to explore spirituality, nature, and life mysteries [[session/dialog/2f310ba0.jsonl#L9-L10]].
Guidance for integrating botanical illustrations includes selecting imagery that resonates with the intended theme, experimenting with varying scales to create depth, mixing illustrations with paint or ink, using illustration colors to inform the overall palette or contrasting them with bold vibrant colors, and embracing imperfection by tearing, cutting, or manipulating the illustrations for an organic expressive feel [[session/dialog/2f310ba0.jsonl#L9-L10]].

## Incorporating Personal Drawings into Collage
The user considers using their own sketches and drawings as collage elements in the painting. Artists successfully using self-drawn elements include:
- Jean-Michel Basquiat: Mixed-media paintings featuring his own drawings, scribbles, and writings combined with paint, collage, and other materials [[session/dialog/2f310ba0.jsonl#L11-L12]].
- Robert Rauschenberg: Combines series featuring his own drawings and paintings combined with found objects and materials [[session/dialog/2f310ba0.jsonl#L11-L12]].
- Ellsworth Kelly: Paintings featuring his own drawings and sketches used to explore color, form, and composition [[session/dialog/2f310ba0.jsonl#L11-L12]].
- Cy Twombly: Paintings featuring his own scribbles, doodles, and drawings combined with paint and other materials [[session/dialog/2f310ba0.jsonl#L11-L12]].
- Anselm Kiefer: Paintings featuring his own drawings and sketches used to explore themes of history, mythology, and the human condition [[session/dialog/2f310ba0.jsonl#L11-L12]].
- Julie Mehretu: Large-scale paintings and prints featuring her own drawings and sketches combined with architectural drawings and maps [[session/dialog/2f310ba0.jsonl#L11-L12]].
- Kerry James Marshall: Paintings featuring his own drawings and sketches used to explore themes of identity, history, and the African American experience [[session/dialog/2f310ba0.jsonl#L11-L12]].
Guidance for integrating personal drawings mirrors the botanical approach: choosing drawings that resonate with the theme, experimenting with scale (enlarging or reducing for drama or intimacy), combining with paint or other materials, playing with transparency for depth, and embracing imperfection by tearing, cutting, or manipulating drawings for an organic expressive feel [[session/dialog/2f310ba0.jsonl#L11-L12]].
