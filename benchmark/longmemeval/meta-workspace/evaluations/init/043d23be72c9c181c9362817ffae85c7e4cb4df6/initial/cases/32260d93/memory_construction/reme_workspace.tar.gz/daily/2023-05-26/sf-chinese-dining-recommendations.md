---
description: Curated list of highly recommended Chinese restaurants and dessert places
  in San Francisco, featuring specific culinary specialties, popular dishes at Z &
  Y Restaurant, and confirmed dining preferences for spicy Sichuan cuisine.
name: sf-chinese-dining-recommendations
session_id: ultrachat_507667
source_conversation: '[[session/dialog/ultrachat_507667.jsonl]]'
---

## San Francisco Chinese Restaurant Recommendations [[session/dialog/ultrachat_507667.jsonl#L4-L4]]
- Z & Y Restaurant: Recommended for spicy Sichuan cuisine.
- R&G Lounge: Recommended for salt and pepper crab.
- China Live: A high-end marketplace and restaurant featuring modern Chinese cuisine.
- House of Nanking: Known for delicious and affordable family-style dishes.
- Yank Sing: Famous for dim sum.
- Mission Chinese Food: Known for creative take on classic Chinese dishes.

## Dining Choices at Z & Y Restaurant [[session/dialog/ultrachat_507667.jsonl#L5-L7]]
- Z & Y Restaurant selected as primary dining destination due to specializing in spicy Sichuan cuisine.
- Menu highlights at Z & Y Restaurant include spicy fried chicken, mapo tofu, and dry fried green beans.
- Additional spicy dishes available at Z & Y Restaurant include Chongqing Spicy Chicken and boiled fish in hot sauce.
- Confirmed strong preference for spicy food resulting in explicit order selection of Chongqing Spicy Chicken.

## San Francisco Chinese Dessert Place Recommendations [[session/dialog/ultrachat_507667.jsonl#L10-L10]]
- Golden Gate Bakery: Specializes in Chinese-style pastries, particularly egg tarts.
- U:Dessert Story: Provides modern and traditional Chinese desserts, including shaved ice, mango pudding, and mochi.
- Sheng Kee Bakery: Offers Chinese-style cakes, buns, sweet pastries, along with bubble tea and other beverages.
- Twisted Donuts & Coffee: Patisserie specializing in Chinese-style donuts with taro and red bean flavors.
- Chantal Guillon: Serves macarons inspired by Chinese flavors, specifically green tea and lychee varieties.
