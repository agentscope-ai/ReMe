---
description: A detailed record of a screenwriter's travel plans to Toronto for January
  2023, focusing on scriptwriting locations and film festival participation. Includes
  specific recommendations for seven Toronto coffee shops suitable for creative work,
  three major local film attractions, and a schedule of five major Toronto-area film
  festivals occurring throughout 2023. Contains extensive details about Hot Docs Canadian
  International Documentary Festival logistics, industry conferences, pitch forums,
  and accreditation options. Also documents the participant's previous attendance
  at TIFF, SXSW, and Berlinale.
name: toronto-trip-festivals-coffee-spots
session_id: 565929a2_2
source_conversation: '[[session/dialog/565929a2_2.jsonl]]'
---

## User Profile & Trip Plans
- Screenwriter plans a trip to Toronto in January 2023 to write a script and attend film festivals [[session/dialog/565929a2_2.jsonl#L1-L3]].
- Identifies as a huge film buff [[session/dialog/565929a2_2.jsonl#L1]].

## Past Film Festival Experiences
- Attended the 'Dune' screening at the Toronto International Film Festival in 2022, standing in line for 6 hours [[session/dialog/565929a2_2.jsonl#L1]].
- Attended the South by Southwest (SXSW) festival panel discussion titled "The Future of Independent Film Distribution" [[session/dialog/565929a2_2.jsonl#L7]].
- Watched documentary films through the Berlinale online program, including the Golden Bear winner "Alcarras" [[session/dialog/565929a2_2.jsonl#L11]].
- Previously attended documentary screenings at multiple international film festivals [[session/dialog/565929a2_2.jsonl#L5]].

## Recommended Toronto Coffee Shops
- Dark Horse Espresso Bar (flagship location on Queen Street West): Favored by writers and students due to strong atmosphere, high-quality coffee, and abundant electrical outlets [[session/dialog/565929a2_2.jsonl#L2]].
- Jimmy's Coffee (original location on Spadina Avenue): Delivers relaxed environment, extensive specialty coffee selection, and excellent people-watching opportunities [[session/dialog/565929a2_2.jsonl#L2]].
- Sam James Coffee Bar (Harbord Street location): Boasts modern industrial aesthetics and superior local coffee; attracts many writers and freelance professionals [[session/dialog/565929a2_2.jsonl#L2]].
- Neo Coffee Bar (Kensington Market): Provides intimate cozy space and expertly prepared beverages [[session/dialog/565929a2_2.jsonl#L2]].
- The Coffee Lab (Ossington Avenue area): Features laboratory-style decor suitable for focused creative work; organizes coffee cupping sessions and educational workshops [[session/dialog/565929a2_2.jsonl#L2]].
- Page One Cafe (The Annex near University of Toronto campus): Characterized by charming literary aesthetic, bookshelves, and comfortable seating areas [[session/dialog/565929a2_2.jsonl#L2]].
- Mercury Espresso Bar (Riverside neighborhood): Offers spacious industrial-chic design and broad variety of coffee drinks [[session/dialog/565929a2_2.jsonl#L2]].

## Toronto Film Attractions
- TIFF Bell Lightbox: Functions as the primary headquarters for the Toronto International Film Festival, hosting year-round exhibitions, screenings, and public events [[session/dialog/565929a2_2.jsonl#L2]].
- Toronto Film Reference Library: Houses comprehensive archives comprising film literature, historical scripts, and reference materials [[session/dialog/565929a2_2.jsonl#L2]].
- Revue Cinema: Operates as a historic independent movie theater hosting regular screenings, genre festivals, and industry gatherings [[session/dialog/565929a2_2.jsonl#L2]].

## Toronto Film Festival Schedule & Opportunities
- Toronto International Film Festival maintains continuous operations at the TIFF Bell Lightbox venue throughout the calendar year [[session/dialog/565929a2_2.jsonl#L4]].
- Hot Docs Canadian International Documentary Festival operates between late April and early May 2023; ranks among the world's largest documentary showcases [[session/dialog/565929a2_2.jsonl#L4,L5]]. The user intends to attend this event alongside its professional industry tracks [[session/dialog/565929a2_2.jsonl#L5,L6]].
- Inside Out Toronto LGBT Film Festival runs from late May to early June 2023, showcasing LGBTQ+ filmmakers and cinematic works [[session/dialog/565929a2_2.jsonl#L4]].
- Toronto Japanese Film Festival takes place from late June to early July 2023, presenting Japanese motion pictures spanning blockbuster releases and independent productions [[session/dialog/565929a2_2.jsonl#L4]].
- Reel Asian International Film Festival occurs during late October to early November 2023, emphasizing Asian and Asian-Canadian cinema across feature, short, and documentary categories [[session/dialog/565929a2_2.jsonl#L4]].

## Hot Docs Industry Programming & Logistics
- Hot Docs Industry Conference spans 5 days during the festival period, featuring educational panels, skill-building workshops, and professional networking centered on documentary storytelling, production methods, and distribution pathways [[session/dialog/565929a2_2.jsonl#L6]].
- Docs Xchange delivers industry panels concentrating on commercial documentary operations, covering financing structures, marketing campaigns, distribution models, and success case studies [[session/dialog/565929a2_2.jsonl#L6]].
- Hot Docs Forum operates as a project pitching competition where documentary creators present concepts to broadcast executives, distribution agents, and funding bodies [[session/dialog/565929a2_2.jsonl#L6]].
- Dedicated Workshops and Masterclasses provide hands-on instruction from experienced professionals in areas including narrative construction, camera operation, and post-production editing [[session/dialog/565929a2_2.jsonl#L6]].
- Official accreditation passes grant participants entry to restricted professional functions and preferred seating assignments for high-demand screenings [[session/dialog/565929a2_2.jsonl#L6]].
- Complete screening schedule and selected film roster typically release during late March or early April 2023, representing a 4 to 6 week advance window before festival opening [[session/dialog/565929a2_2.jsonl#L10]]. Preliminary teasers appear periodically on official digital channels and social media accounts [[session/dialog/565929a2_2.jsonl#L10]].
- Standard festival programming includes global premieres, international submissions, and domestic Canadian entries covering feature and short durations addressing topics like political activism, cultural heritage, artistic expression, and biographical narratives [[session/dialog/565929a2_2.jsonl#L10]].
