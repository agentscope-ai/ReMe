---
description: Generation of meta titles, meta descriptions, and pending Open Graph
  (OG) titles and descriptions for an article targeting homeowners regarding latent
  conditions in construction, hidden building services, cost blowouts, and legal disputes.
name: construction-latent-conditions-seo-tags
session_id: sharegpt_G9RAbBH_0
source_conversation: '[[session/dialog/sharegpt_G9RAbBH_0.jsonl]]'
---

## SEO and Social Media Tag Generation Requirements
- **Objective**: Create compelling, click-teasing headlines and summaries for an article focused on latent conditions in construction, hidden building services, residential construction projects, home renovation, and new builds. The goal is protecting homeowners' investments and preventing cost blowouts and legal disputes [[session/dialog/sharegpt_G9RAbBH_0.jsonl#L1-L2,L3-L4,L5-L5]].
- **Character Limits** (spaces included in counts):
  - Meta Titles: Maximum 70 characters
  - Meta Descriptions: Maximum 155 characters
  - Open Graph (OG) Titles: Maximum 60 characters
  - Open Graph (OG) Descriptions: Maximum 110 characters [[session/dialog/sharegpt_G9RAbBH_0.jsonl#L1-L2,L3-L4,L5-L5]]

## Completed Outputs
### Meta Titles
1. "Understanding Latent Conditions in Construction: A Homeowner's Guide"
2. "Don't Let Hidden Building Services Derail Your Dream Home Project"
3. "Protect Your Home Investment: A Homeowner's Guide to Latent Conditions in Construction" [[session/dialog/sharegpt_G9RAbBH_0.jsonl#L2-L2]]

### Meta Descriptions
1. "Discover the ins and outs of latent conditions in construction and learn how to protect yourself as a homeowner. Read our guide now."
2. "Are you embarking on a residential construction project? Learn how to avoid cost blowouts and legal disputes with our homeowner's guide to latent conditions."
3. "Don't let unforeseen issues ruin your home renovation or new build. Get ahead of the game with our comprehensive guide to latent conditions in construction." [[session/dialog/sharegpt_G9RAbBH_0.jsonl#L4-L4]]

## Pending Actions
- Generate 3 Open Graph (OG) titles adhering to the 60-character limit and 3 corresponding OG descriptions adhering to the 110-character limit, utilizing the previously established construction and homeowner-focused angles [[session/dialog/sharegpt_G9RAbBH_0.jsonl#L5-L5]].
