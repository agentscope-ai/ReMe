---
description: Documentation of converting a Creamy Chicken Thighs recipe into a lower-carb,
  lower-cholesterol version suitable for a fan-forced oven. Contains the original
  recipe source and data, the converted recipe details (ingredient substitutions like
  reduced-fat coconut cream and skinless chicken, metric conversions), and a side-by-side
  nutritional comparison per serving showing significant caloric and fat reductions.
name: creamy-chicken-thighs-recipe-modification
session_id: sharegpt_twtm4bF_0
source_conversation: '[[session/dialog/sharegpt_twtm4bF_0.jsonl]]'
---

## Original Recipe Source
- Link: https://www.copymethat.com/r/OPaC5j1YK/creamy-chicken-thighs/ [[session/dialog/sharegpt_twtm4bF_0.jsonl#L1-L1]]

## Original Recipe Data [[session/dialog/sharegpt_twtm4bF_0.jsonl#L2-L2]]
### Ingredients
- 4-6 bone-in, skin-on chicken thighs
- Salt and pepper, to taste
- 2 tbsp butter
- 1/2 cup chicken broth
- 1/2 cup heavy cream
- 2 tbsp Dijon mustard
- 1 tbsp honey
- 1 tsp dried thyme

### Instructions
1. Preheat oven to 400°F.
2. Season chicken thighs with salt and pepper.
3. Melt butter in a large skillet over medium-high heat.
4. Cook chicken thighs until browned on both sides (~5 minutes per side).
5. Remove chicken from skillet.
6. Add chicken broth, heavy cream, Dijon mustard, honey, and dried thyme to skillet; whisk sauce and bring to a simmer.
7. Return chicken to skillet, spooning sauce over the top.
8. Bake in preheated oven for 25-30 minutes until chicken is cooked through and sauce is thickened/bubbly.
9. Cool slightly and serve.

## Converted Recipe (Lower Carbs & Cholesterol) [[session/dialog/sharegpt_twtm4bF_0.jsonl#L3-L4]]
### Modifications Applied
- Goal: Fewer carbs, less cholesterol.
- Format: Metric units, fan-forced oven.
- Ingredient Substitutions:
  - Switched to **skinless** chicken thighs.
  - Replaced butter with **olive oil**.
  - Replaced heavy cream with **reduced-fat coconut cream**.
  - Replaced regular Dijon with **whole grain mustard**.
  - Broth changed to **low-sodium**.
  - Sweetener option expanded to include **sugar-free sweetener**.

### Ingredients
- 4-6 bone-in, skinless chicken thighs
- Salt and pepper, to taste
- 2 tbsp olive oil
- 1/2 cup low-sodium chicken broth
- 1/2 cup reduced-fat coconut cream
- 2 tbsp whole grain mustard
- 1 tbsp honey or sugar-free sweetener
- 1 tsp dried thyme

### Instructions
1. Preheat **fan-forced oven to 200°C**.
2. Season chicken thighs with salt and pepper.
3. Heat olive oil in a large **oven-proof skillet** over medium-high heat.
4. Brown chicken thighs on both sides (~5 minutes per side).
5. Remove chicken from skillet.
6. Whisk together low-sodium chicken broth, reduced-fat coconut cream, whole grain mustard, honey/sweetener, and dried thyme in skillet; bring to a simmer.
7. Return chicken to skillet, spooning sauce over the top.
8. Bake for 25-30 minutes until cooked through and sauce thickened.
9. Cool slightly and serve.

## Nutritional Comparison Per Serving [[session/dialog/sharegpt_twtm4bF_0.jsonl#L5-L6]]
### Original Recipe Values
- Calories: 540
- Fat: 43g
- Carbohydrates: 10g
- Fiber: 0g
- Sugar: 8g
- Protein: 27g
- Cholesterol: 205mg
- Sodium: 580mg

### Modified Recipe Values
- Calories: 360
- Fat: 23g
- Carbohydrates: 6g
- Fiber: 0g
- Sugar: 4g
- Protein: 31g
- Cholesterol: 110mg
- Sodium: 240mg
