---
description: Production preparation details for Les Misérables, encompassing immediate
  administrative tasks (script pickup on 2023-05-28), a structured rehearsal study
  schedule (acting, blocking, vocals), and strategies for composing a concise program
  biography based on prior professional experience.
name: les-miserables-preparation-tasks
session_id: 8fa624b2_3
source_conversation: '[[session/dialog/8fa624b2_3.jsonl]]'
---

## Production Context [[session/dialog/8fa624b2_3.jsonl#L1-L3]]
- The user is performing in the musical *Les Misérables*.
- A costume fitting for the character took place on a Thursday.

## Administrative & Immediate Tasks [[session/dialog/8fa624b2_3.jsonl#L5-L6]]
- **2023-05-28 Task**: Pick up the script from the theater office.
- While at the office, inquire whether there are any updates on the rehearsal schedule.

## Study & Rehearsal Schedule [[session/dialog/8fa624b2_3.jsonl#L4]]
- **Script Review**: Block **1–2 hours** daily to focus on memorizing lines, reviewing scenes, and studying stage directions/blocking. Visualize movements on stage.
- **Vocal Practice**: Allocate **30 minutes to 1 hour** daily to practice singing, focusing on pitch, tone, emotion, and harmonies. Record oneself to identify improvements.
- **Choreography**: Set aside time to work on dance moves.
- **General Habits**: Arrive early before rehearsals to settle in. Take notes during sessions and review them afterward.

## Program Biography Strategy [[session/dialog/8fa624b2_3.jsonl#L7-L11]]
- **Goal**: Draft a bio for the performance program.
- **Length Constraints**: Limit to **1–2 sentences** or **50–75 words**.
- **Content Guidelines**: Focus on previous theater experience, training, notable roles, and awards. Add a personal touch. Ensure error-free grammar.
- **Timeline Correction**: Initial drafts considered mentioning an audition that occurred approximately **three weeks ago**. It was noted that a recent costume fitting implies rehearsals are currently just beginning.
- **Final Decision**: Exclude the immediate audition timeline; focus solely on past qualifications and professional history.
