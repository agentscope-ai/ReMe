---
description: Documentation outlining the development of a science fiction protagonist
  named Maya tasked with saving her planet from an alien invasion. Captures a disciplined
  2-hour morning writing routine (warm-ups, Pomodoro cycles, targeted sessions, reflection),
  a categorized bibliography of online resources and reference texts, a granular breakdown
  of the 12-section Reedsy Character Profile template, and structured cognitive exercises
  for mapping motivations, conflicts, and character evolution.
name: sci-fi-character-development-maya
session_id: 7a2bdd15_1
source_conversation: '[[session/dialog/7a2bdd15_1.jsonl]]'
---

## Writing Routine
- Committed to dedicating two hours every morning, Monday through Friday, exclusively for crafting a science fiction novel [[session/dialog/7a2bdd15_1.jsonl#L1-L1]].
- Optimize productive writing windows using the following protocols:
  - Execute 10–15 minute warm-up exercises or unrestricted freewriting to rapidly adopt the protagonist's psychological state [[session/dialog/7a2bdd15_1.jsonl#L2-L2]].
  - Assign highly specific character development deliverables to each dedicated writing session [[session/dialog/7a2bdd15_1.jsonl#L2-L2]].
  - Implement the Pomodoro Technique utilizing concentrated 25-minute work intervals separated by mandatory 5-minute rest periods to prevent cognitive fatigue [[session/dialog/7a2bdd15_1.jsonl#L2-L2]].
  - Dedicate the concluding 10–15 minutes of every session to audit completed tasks and evaluate developmental progress [[session/dialog/7a2bdd15_1.jsonl#L2-L2]].

## Curated Resources & Literature
- Domain-specific writing platforms featuring character development guides: Writers Digest ([https://www.writersdigest.com/write-better-characters](https://www.writersdigest.com/write-better-characters)), The Creative Penn ([https://www.thecreativepenn.com/character-development/](https://www.thecreativepenn.com/character-development/)), Helping Writers Become Authors ([https://www.helpingwritersbecomeauthors.com/category/character-development/](https://www.helpingwritersbecomeauthors.com/category/character-development/)) [[session/dialog/7a2bdd15_1.jsonl#L2-L2]].
- Dedicated exercise repositories: The Write Practice ([https://thewritepractice.com/character-development-exercises/](https://thewritepractice.com/character-development-exercises/)), Novel Writing Help ([https://novelwritinghelp.com/character-development-exercises/](https://novelwritinghelp.com/character-development-exercises/)) [[session/dialog/7a2bdd15_1.jsonl#L2-L2]].
- Digital profiling utilities: Reedsy Character Profile Template ([https://reedsy.com/character-profile-template](https://reedsy.com/character-profile-template)), 16 Personalities ([https://www.16personalities.com/free-personality-test](https://www.16personalities.com/free-personality-test)) [[session/dialog/7a2bdd15_1.jsonl#L2-L2]].
- Foundational reference texts: *Characters & Viewpoint* authored by Orson Scott Card (systematic methodology for constructing credible figures), *The Writer's Journey: Mythic Structure for Writers* penned by Christopher Vogler (examines epic journeys and archetype systems), *How to Write Short Stories and Use Them to Further Your Writing Career* compiled by James Scott Bell (integrates character construction modules) [[session/dialog/7a2bdd15_1.jsonl#L2-L2]].

## Protagonist Construction: Maya
- Established narrative premise positioning Maya as the central figure defending her planetary ecosystem against extraterrestrial incursion [[session/dialog/7a2bdd15_1.jsonl#L7-L7]].
- Structural focus requires delineating immediate tactical steps neutralizing the threat alongside enduring strategic objectives (survival, resettlement, coalition building), while rigorously auditing personal catalysts (kinship obligations, ethical mandates, liberty advocacy) and the physiological/psychological price tags attached to victory [[session/dialog/7a2bdd15_1.jsonl#L8-L8]].
- Dramatic friction must emerge from examining how ambitious targets collide with allied factions, hostile forces, or intimate partners, simultaneously tracking how insurmountable environmental variables fracture original plans and compel strategic recalibration [[session/dialog/7a2bdd15_1.jsonl#L8-L8]].

## Reedsy Character Profile Architecture
- Framework design: A complimentary 12-category matrix engineered to balance concise data entry with profound analytical scrutiny [[session/dialog/7a2bdd15_1.jsonl#L4-L4]].
- Component specifications:
  - Basic Info: Designation, chronological age, vocational status, summary identifier.
  - Physical Appearance: Stature metrics, mass distribution, chromatic attributes, cranial structure, anomalous identifiers.
  - Personality: Value hierarchies, operational drives, target outcomes, intrinsic deficiencies.
  - Backstory: Formative environments, familial structures, scholastic backgrounds, paradigm-shifting historical incidents.
  - Motivations: Primary engines, aspirational endpoints, restrictive barriers.
  - Conflict: Psychological paradoxes, circumstantial confrontations, adaptive responses to hostility.
  - Relationships: Bloodline connections, friendship networks, romantic engagements, antagonistic alignments.
  - Skills and Abilities: Functional competencies, specialized knowledge, debilitating limitations.
  - Fears and Phobias: Trauma triggers, anxiety-inducing stimuli, panic-driven reaction patterns.
  - Habits and Quirks: Compulsive behaviors, idiosyncratic ticks, humanizing mannerisms.
  - Emotional Landscape: Regulatory mechanisms, psychological fragility, affective resilience.
  - Evolution: Anticipated developmental arcs, maturity thresholds, transformative narrative progression [[session/dialog/7a2bdd15_1.jsonl#L4-L4]].
- Deployment instructions: Engage deliberately with prompting queries, reconfigure structural segments to align with genre conventions, iteratively expand initial drafts, engineer parallel documentation for ancillary ensembles and antagonistic entities [[session/dialog/7a2bdd15_1.jsonl#L4-L4]].

## Ideation & Cognitive Drills
- Network Visualization: Deploy branching diagrams to trace linkages between motivational vectors, objective matrices, and friction nodes [[session/dialog/7a2bdd15_1.jsonl#L6-L6]].
- Counterfactual Simulation: Engineer alternate reality propositions (objective failures, ethical impasses) to forecast adaptive modifications [[session/dialog/7a2bdd15_1.jsonl#L6-L6]].
- Interrogative Roleplay: Facilitate simulated dialogues centering on intent rationalization and stress-test reactions to aggressive questioning [[session/dialog/7a2bdd15_1.jsonl#L6-L6]].
- Situational Drafting: Architect narrative vignettes demonstrating choice execution under severe pressure [[session/dialog/7a2bdd15_1.jsonl#L6-L6]].
- Introspective Logging: Generate first-person diary submissions exposing raw cognitive processing sequences and volatile emotional states [[session/dialog/7a2bdd15_1.jsonl#L6-L6]].

## System Interaction Correction
- A procedural misalignment occurred wherein the platform temporarily queried the author about finalized trait selections regarding Maya before immediately rectifying the error and re-establishing its designated function as a facilitative advisor rather than an autonomous co-author [[session/dialog/7a2bdd15_1.jsonl#L11-L12]].
