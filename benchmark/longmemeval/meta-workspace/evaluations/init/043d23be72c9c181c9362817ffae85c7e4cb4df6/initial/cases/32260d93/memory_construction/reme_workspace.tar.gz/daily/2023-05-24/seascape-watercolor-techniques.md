---
description: Creative planning notes for a 2023-05-24 watercolor seascape project
  titled "Moonlit Waves". Covers selecting the core concept, advanced methods for
  rendering silvery highlights (masking fluid, drybrushing, gouache, iridescent pigments),
  critical watercolor paper specifications (Hot Press surface, high ISO brightness
  ≥90, preference for Arches), techniques for capturing soft moonlight aesthetics
  (cool washes, wet-on-wet blending, salt sprinkling, negative painting), and a comprehensive
  catalog of texture-building strategies (wash and scrape, pumice gel, collage, wax
  resist) drawn from an art fair attended by the artist.
name: seascape-watercolor-techniques
session_id: b84b7a2b_2
source_conversation: '[[session/dialog/b84b7a2b_2.jsonl]]'
---

## Art Fair Inspiration & Seascapes
On 2023-05-24, the user attended a local art fair where they saw amazing works by local artists, which provided inspiration for a new art piece. [[session/dialog/b84b7a2b_2.jsonl#L1-L2]] The user requested suggestions for a watercolor seascape painting, exploring ideas such as moonlit waves, coastal cliffs, beachcombers, lighthouse scenes, whimsical mermaids, seaside villages, stormy seas, sandy shores, sea spray, and abstract waves. [[session/dialog/b84b7a2b_2.jsonl#L2-L2]] The "Moonlit Waves" concept was selected as the focal point for the artwork. [[session/dialog/b84b7a2b_2.jsonl#L3-L3]]

## Achieving Silvery Highlights
The user plans to combine masking fluid and drybrushing techniques to produce silvery highlights on the ocean waves. [[session/dialog/b84b7a2b_2.jsonl#L5-L5]] Alternative methods discussed for creating these highlights include applying masking fluid (Winsor & Newton's Art Masking Fluid or Holbein's Masking Fluid) to protect the white paper, flicking almost-dry brushes loaded with white gouache or opaque watercolor onto wave crests, mixing white gouache with blue or gray for soft silvery tones, using iridescent pigments (Daniel Smith's Iridescent White or Schmincke's Horadam Aquarellum Iridescent White), applying transparent glazes over previously painted areas, gently lifting pigment with a damp brush to create feathery edges, and reserving the white of the paper during initial washes. [[session/dialog/b84b7a2b_2.jsonl#L4-L4]]

## Watercolor Paper Selection
To ensure crisp, sharp highlights suitable for delicate drybrushing, the decision was made to use Hot Press watercolor paper. [[session/dialog/b84b7a2b_2.jsonl#L7-L7]] The user noted previous positive experiences using Arches paper and intends to proceed with Arches Hot Press or comparable options like Winsor & Newton Cotman Hot Press, Fabriano Artistico Hot Press, and Saunders Waterford Hot Press. [[session/dialog/b84b7a2b_2.jsonl#L6-L6]] Recommended specifications for this project include a smooth surface, medium to low tooth for balanced color vibrancy and highlight precision, and a high whiteness and brightness level (ISO brightness rating of 90 or higher). [[session/dialog/b84b7a2b_2.jsonl#L6-L6]]

## Capturing Moonlight Effects
Techniques recommended for rendering the soft, dreamy quality of moonlight on water involve applying soft, gentle washes with highly diluted pigments, building depth through glazing, utilizing wet-on-wet blending to merge colors, and softening edges with a damp brush to avoid hard lines. [[session/dialog/b84b7a2b_2.jsonl#L8-L8]] The suggested color palette relies on cool tones, specifically Ultramarine, Payne's Gray, and Cerulean Blue, while emphasizing subtlety, accurate value shifts between light and dark areas, and the strategic use of unpainted white paper for luminosity. [[session/dialog/b84b7a2b_2.jsonl#L8-L8]] Supplementary ethereal techniques include sprinkling salt onto wet washes for speckled textures, lifting pigment to mimic gentle wave action, and practicing negative painting to imply light rather than depicting it directly. [[session/dialog/b84b7a2b_2.jsonl#L8-L8]]

## Creating Textures in Watercolors
Drawing further inspiration from the textures observed at the local art fair, the exploration expanded to general watercolor texture methods. [[session/dialog/b84b7a2b_2.jsonl#L9-L10]] Viable techniques catalogued include salt sprinkling (experimenting with kosher or sea salt variants), wash and scrape methods using a credit card or scraper while the paint is wet, dragging almost-dry brushes for scratchy surfaces, applying thick impasto mixtures of gesso or modeling paste with a palette knife, incorporating collage materials like paper or fabric, spreading pumice gel, utilizing inherently rough cold press or rough papers, spattering paint with a brush or toothbrush, employing wax resist with melted wax, and experimenting with non-standard brushes such as fan, scrub, or bristle brushes. [[session/dialog/b84b7a2b_2.jsonl#L10-L10]] For the specific goal of enhancing the seascape composition, salt sprinkling, wash and scrape, and drybrushing were identified as optimal for simulating wave movement and energy, whereas collage elements and pumice gel provide opportunities for experimental, three-dimensional surface qualities. [[session/dialog/b84b7a2b_2.jsonl#L11-L12]]
