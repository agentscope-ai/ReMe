---
description: 'Two complete dessert recipes documented on 2023-05-30. Cherry Clafoutis
  serves 6–8; ingredients: 2 cups pitted cherries (fresh or frozen), 1½ cups granulated
  sugar, ½ cup all-purpose flour, ½ tsp baking powder, ½ tsp salt, ½ cup whole milk,
  2 large eggs, 2 tbsp melted unsalted butter, 1 tsp vanilla extract; bake at 375°F
  for 35–40 min in a 9×13-inch dish, then dust with powdered sugar. Cherry Crisp serves
  6–8; cherry filling includes ½ cup sugar, 2 tbsp cornstarch, ¼ cup flour, ½ tsp
  cinnamon, ¼ tsp nutmeg, ¼ tsp salt; crumb topping combines ½ cup rolled oats, ½
  cup brown sugar, ½ cup cold cut unsalted butter; bake at 375°F for 40–45 min in
  a 9×9-inch dish until golden and bubbly; serve warm with vanilla ice cream or whipped
  cream. Four detailed substitution protocols for clafoutis: (1) granulated sugar
  → light brown sugar adds caramel/molasses depth, increases moisture yielding denser
  cake-like texture requiring 1¼ cups instead of 1½ cups, cover with foil during final
  10–15 minutes to prevent over-browning; (2) all-purpose flour → almond flour produces
  gluten-free low-carb result with pound-cake dense moist crumb and pronounced nutty
  flavor, reduce baking powder to ¼ tsp, sift flour beforehand, add extra milk or
  eggs if needed, avoid overmixing; (3) sliced almond topping uses ¼–½ cup thinly
  sliced almonds (slivers) sprinkled evenly over fruit surface before baking, optional
  brown sugar sprinkle on top encourages caramelization; (4) fresh cherries → thawed
  frozen cherries requires room-temperature or microwave thawing followed by thorough
  paper-towel drying to remove excess moisture preventing sogginess, gentle folding
  avoids mashing fragile fruit, sugar quantity reduction may be necessary if excess
  water present, expect increased juice release and less firm shape retention after
  baking. On 2023-05-30, the speaker decided to execute all four modifications simultaneously
  and communicated intent to report results upon completion.'
name: cherry-clafoutis-recipes-and-modifications
session_id: 87aaee77
source_conversation: '[[session/dialog/87aaee77.jsonl]]'
---

## Cherry Clafoutis Recipe [[session/dialog/87aaee77.jsonl#L1-L2]]
Serves 6–8 people. A classic French dessert resembling a cobbler but with a lighter, fluffier texture profile.

**Ingredients:**
- 2 cups fresh or frozen cherries, pitted
- 1 ½ cups granulated sugar
- ½ cup all-purpose flour
- ½ teaspoon baking powder
- ½ teaspoon salt
- ½ cup whole milk
- 2 large eggs
- 2 tablespoons unsalted butter, melted
- 1 teaspoon vanilla extract

**Step-by-step instructions:**
1. Preheat oven to 375°F (190°C).
2. In a large bowl, whisk together the sugar, flour, and baking powder.
3. In a separate bowl, whisk together the milk, eggs, and melted butter.
4. Combine wet and dry ingredients, whisking until the batter is smooth.
5. Pour batter into a 9x13-inch baking dish and arrange the cherries on top.
6. Bake for 35–40 minutes or until the clafoutis is puffed and golden brown.
7. Dust with powdered sugar and serve warm.

## Cherry Crisp Recipe [[session/dialog/87aaee77.jsonl#L1-L2]]
Serves 6–8 people. A classic American dessert suitable for warm weather conditions.

**Ingredients:**
- 2 cups fresh or frozen cherries, pitted
- ½ cup granulated sugar
- 2 tablespoons cornstarch
- ¼ cup all-purpose flour
- ½ teaspoon cinnamon
- ¼ teaspoon nutmeg
- ¼ teaspoon salt
- ½ cup rolled oats
- ½ cup brown sugar
- ½ cup cold unsalted butter, cut into small pieces

**Step-by-step instructions:**
1. Preheat oven to 375°F (190°C).
2. In a large bowl, mix together the cherries, granulated sugar, cornstarch, and flour.
3. Transfer the mixture to a 9x9-inch baking dish.
4. In a separate bowl, combine the rolled oats, brown sugar, cinnamon, nutmeg, and salt.
5. Add the cold butter to the oat mixture and use fingers or a pastry blender to work it into a crumbly texture.
6. Spread the crumb topping evenly over the cherry mixture.
7. Bake for 40–45 minutes or until the topping is golden brown and the fruit is bubbly.
8. Serve warm with vanilla ice cream or whipped cream.

## Granulated Sugar → Brown Sugar Substitution [[session/dialog/87aaee77.jsonl#L3-L4]]
Substituting granulated sugar with brown sugar alters both the flavor and texture of the cherry clafoutis.

**Flavor impact:** Brown sugar delivers a richer, deeper taste featuring caramel and molasses notes that complement the sweetness of the cherries well. The flavor becomes more complex and nuanced relative to granulated sugar usage.

**Texture impact:** Brown sugar contains higher moisture levels than granulated sugar, resulting in a slightly denser and moister batter. The final product exhibits a heavier, more cake-like consistency with noticeably reduced puffing during baking, though the texture remains tender.

**Application guidelines:** Use light brown sugar rather than dark brown sugar to avoid overwhelming the cherry character. Reduce the measured quantity from 1 ½ cups to 1 ¼ cups since brown sugar provides greater sweetness intensity. Monitor the baking process closely and cover the clafoutis top with aluminum foil during the final 10–15 minutes to prevent excessive browning. For adherents seeking traditional French clafoutis characteristics, retain granulated sugar. Brown sugar substitution offers a flavorful variation option.

## All-Purpose Flour → Almond Flour Substitution [[session/dialog/87aaee77.jsonl#L5-L6]]
Replacing all-purpose flour with almond flour produces significant alterations to the clafoutis texture and flavor profile while accommodating gluten intolerance or sensitivity dietary requirements.

**Flavor impact:** Almond flour imparts a distinct nutty flavor that complements the cherries effectively. The almond quality becomes more pronounced when utilizing high-quality blanched almond flour products.

**Texture impact:** As a low-carb, high-fat flour alternative, almond flour yields a denser, moister, and more tender crumb structure comparable to pound cake. The finished product demonstrates a more delicate and fragile quality with a slightly crumbly consistency.

**Application guidelines:** Maintain a 1:1 substitution ratio while anticipating heightened liquid absorption requiring supplementary milk or egg additions for proper consistency attainment. Decrease the baking powder quantity to ¼ teaspoon since almond flour reacts differently to leavening agents than wheat-based flours. Employ high-quality finely ground blanched almond flour and perform sieving operations beforehand to eliminate lumps and incorporate air volume. Avoid overmixing the batter to prevent development of toughness. Exercise caution during baking since the denser batter transitions rapidly between perfect doneness and burn conditions. Retain all-purpose flour when pursuing authentic traditional clafoutis textural expectations.

## Sliced Almonds Topping Addition [[session/dialog/87aaee77.jsonl#L7-L8]]
Placing sliced almonds atop the cherries before baking introduces complementary crunchy texture and visual enhancement that pairs with the sweet fruit and dense cake base.

**Application guidelines:** Select thinly sliced almonds approximating sliver thickness to promote uniform toasting and preclude excessive crunch or bitterness development. Distribute the almonds evenly across the entire fruit surface layer, employing approximately ¼ cup to ½ cup volume depending on individual preference thresholds. When brown sugar has been substituted in the recipe, consider dispersing an additional pinch of brown sugar over the almond layer before introduction to the oven to encourage caramelization and produce a crunchy sweet crust formation. Maintain close observation throughout the baking cycle as almond layers transition rapidly from toasted states to burnt states, applying the standard aluminum foil shielding technique during the concluding 10–15 minutes when necessary. The integration of brown sugar, almond flour, and sliced almond topping collectively generates a distinctive cherry clafoutis variant characterized by layered flavors and varied textures.

## Frozen Cherries Preparation Protocol [[session/dialog/87aaee77.jsonl#L9-L10]]
Frozen cherries constitute a viable alternative ingredient substitute for fresh cherries within the clafoutis formulation. Frozen cherries frequently reach peak ripeness achievement prior to flash-freezing procedures, thereby preserving both flavor integrity and structural quality.

**Required preparation steps:** Thaw the frozen cherries either by maintaining ambient room temperature exposure for several hours duration or by executing microwave thawing per package-specific instructions. Completely pat-dry the thawed fruit using paper towels to evacuate surplus moisture, which prevents generation of an excessively soggy clafoutis base. Apply careful handling techniques during mixing with sugar and flour components to preclude crushing or mashing damage since frozen-derived cherries exhibit fragility exceeding their fresh counterparts.

**Baking adjustment considerations:** Frozen cherries discharge elevated juice quantities during the baking operation and demonstrate inferior shape retention compared to fresh fruit. When thawed frozen cherries manifest particularly high moisture or ice content levels, proportionally decrease the recipe sugar quantity to maintain balanced sweetness proportions. These compositional alterations do not adversely affect the overall flavor outcome or textural characteristics of the finished clafoutis.

## Execution Decision and Follow-up Intent [[session/dialog/87aaee77.jsonl#L11-L12]]
On 2023-05-30, the speaker confirmed having assembled all required materials and determined to prepare the cherry clafoutis incorporating all four documented substitutions concurrently: brown sugar replacing granulated sugar, almond flour replacing all-purpose flour, addition of a sliced almond topping layer, and utilization of thawed frozen cherries substituting for fresh fruit variants. The speaker expressed communication intent to relay results once the preparation and baking process concludes.
