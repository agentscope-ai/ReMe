---
description: Summary of the religious and spiritual practices in Königsberg (modern-day
  Kaliningrad), covering its historical diversity, the destruction and repurposing
  of religious sites during World War II and the Soviet era, and current restoration
  efforts alongside notable surviving landmarks like Immanuel Kant's Grave, the Cathedral
  of Christ the Savior, the Holy Family Catholic Church, and the Kaliningrad Mosque.
name: kaliningrad-religious-history
session_id: ultrachat_187883
source_conversation: '[[session/dialog/ultrachat_187883.jsonl]]'
---

### Historical Religious Landscape
*   Königsberg was historically a culturally and religiously diverse city with significant contributions from various religious groups, including Lutherans, Catholics, Jews, and Tatars [[session/dialog/ultrachat_187883.jsonl#L2-L2]].
*   The city boasted several major religious buildings spanning different faiths, featuring Lutheran, Catholic, and Orthodox churches alongside synagogues and mosques [[session/dialog/ultrachat_187883.jsonl#L2-L2]].

### Destruction and Repurposing (WWII and Soviet Era)
*   During World War II, Königsberg was subjected to heavy bombing, resulting in the widespread destruction of the city's religious structures [[session/dialog/ultrachat_187883.jsonl#L2-L2]].
*   Following the war, the region became part of the Soviet Union, leading to the suppression of existing religious communities and a subsequent decline in religious practice within the city [[session/dialog/ultrachat_187883.jsonl#L2-L2]].
*   Efforts to preserve religious structures hit during the war were severely limited; many surviving buildings were subsequently demolished to make room for new urban development [[session/dialog/ultrachat_187883.jsonl#L4-L4]].
*   In the Soviet era, a lack of interest in preserving cultural heritage resulted in the secular repurposing of religious buildings. The primary Lutheran church, the Cathedral of Christ the Savior, was notably converted into a swimming pool [[session/dialog/ultrachat_187883.jsonl#L4-L4]].
*   Since the collapse of the Soviet Union, a renewed focus on protecting cultural and religious heritage has emerged in Kaliningrad, leading to the restoration of certain churches and broader protection efforts for historic buildings [[session/dialog/ultrachat_187883.jsonl#L4-L4]].

### Contemporary Religious Sites and Notable Landmarks
*   Modern-day Kaliningrad accommodates the Christian community through a small number of active churches, and supports small Muslim and Jewish populations [[session/dialog/ultrachat_187883.jsonl#L2-L2]].
*   A prominent landmark in Kaliningrad is the Cathedral of Christ the Savior, which has been fully reconstructed after its decades-long operation as a swimming pool; recognized for its towering spire, impressive neo-Gothic design, and intricate stained glass windows [[session/dialog/ultrachat_187883.jsonl#L6-L6]].
*   The grave of the celebrated philosopher Immanuel Kant, who resided and conducted his work in Königsberg, is situated in the Königsberg Cathedral and serves as an attraction and pilgrimage site for academic scholars and philosophy admirers [[session/dialog/ultrachat_187883.jsonl#L6-L6]].
*   The Holy Family Catholic Church stands as another notable religious landmark, constructed during the 20th century [[session/dialog/ultrachat_187883.jsonl#L6-L6]].
*   The Kaliningrad Mosque provides religious services for the city's Muslim residents [[session/dialog/ultrachat_187883.jsonl#L6-L6]].
*   The broader religious and cultural heritage of the city is further documented and showcased across various local museums, art galleries, and cultural centers [[session/dialog/ultrachat_187883.jsonl#L6-L6]].
