---
description: A dataset of 10 European cities ranked by availability of outbound flights
  under 100 euros and one-bedroom flat rental costs, including city-proper populations,
  monthly rent averages in Euros, and a note that figures are seasonal estimates.
name: european-budget-living-estimates
session_id: sharegpt_InpElqr_0
source_conversation: '[[session/dialog/sharegpt_InpElqr_0.jsonl]]'
---

## European Cities Budget Estimates [[session/dialog/sharegpt_InpElqr_0.jsonl#L2-L4]]

The following table presents estimated metrics for ten European cities, focusing on two primary criteria for location selection: outbound flight affordability and housing costs. Flight counts represent outbound tickets priced under 100 euros. Rental figures indicate the average monthly cost for a one-bedroom flat within the city limits. All figures are estimates subject to seasonal variation and external market factors. Population data reflects only the administrative city proper, excluding broader metropolitan statistical areas.

1. **Budapest, Hungary**: 1,752,704 population | 20 flights under 100 euros | €300 avg. rent/month
2. **Bucharest, Romania**: 2,106,144 population | 15 flights under 100 euros | €250 avg. rent/month
3. **Krakow, Poland**: 769,498 population | 12 flights under 100 euros | €400 avg. rent/month
4. **Sofia, Bulgaria**: 1,238,153 population | 10 flights under 100 euros | €250 avg. rent/month
5. **Prague, Czech Republic**: 1,333,690 population | 8 flights under 100 euros | €500 avg. rent/month
6. **Vilnius, Lithuania**: 537,152 population | 7 flights under 100 euros | €350 avg. rent/month
7. **Riga, Latvia**: 632,614 population | 6 flights under 100 euros | €400 avg. rent/month
8. **Tallinn, Estonia**: 442,196 population | 5 flights under 100 euros | €450 avg. rent/month
9. **Belgrade, Serbia**: 1,180,930 population | 4 flights under 100 euros | €300 avg. rent/month
10. **Bratislava, Slovakia**: 437,725 population | 3 flights under 100 euros | €550 avg. rent/month

Additional considerations for relocation or stay duration beyond purely financial metrics include local job opportunities, cultural environments, and regional safety records.
