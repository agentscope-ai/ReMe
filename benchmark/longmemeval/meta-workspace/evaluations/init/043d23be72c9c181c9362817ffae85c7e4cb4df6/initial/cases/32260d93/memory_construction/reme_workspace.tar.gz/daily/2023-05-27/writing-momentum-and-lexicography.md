---
description: Actionable techniques for overcoming writer's block—including manuscript
  scene management—alongside linguistic guidelines prohibiting redundant constructions
  like "continue on", standardized abbreviations for document pagination, and summaries
  of referenced online literary resources.
name: writing-momentum-and-lexicography
session_id: sharegpt_Z35PJ8x_2
source_conversation: '[[session/dialog/sharegpt_Z35PJ8x_2.jsonl]]'
---

## Strategies for Maintaining Writing Momentum

- Actively seeking inspiration by reading established literary works or documenting personal interests effectively neutralizes initial writer's block phases [[session/dialog/sharegpt_Z35PJ8x_2.jsonl#L2-L2]].
- Structural roadblocks within ongoing manuscripts require decisive editing actions: completely unworkable scenes demand immediate deletion to preserve workflow momentum, while viable material intended for separate projects necessitates isolation through replication into independent files [[session/dialog/sharegpt_Z35PJ8x_2.jsonl#L1-L1]].
- Enforcing strict compliance with Tip #17 prevents substandard narrative segments from obstructing overall project completion by mandating the immediate commencement of physical writing activities regardless of creative uncertainty [[session/dialog/sharegpt_Z35PJ8x_2.jsonl#L1-L1]].

## English Syntactical Regulations

- Established grammatical commentary recorded within Merriam-Webster's *Dictionary of English Usage* systematically invalidates the compound phrase "continue on." Historical analysis tracing critique from Ayres in 1881 through Chambers in 1985 uniformly characterizes the appended preposition "on" as linguistically superfluous and unnecessary [[session/dialog/sharegpt_Z35PJ8x_2.jsonl#L1-L1]].

## Professional Typesetting Conventions

- Standard document pagination protocols dictate utilizing "cont." as the definitive abbreviation for the term continued. The variant "contd." remains formally acceptable but categorizes technically as a contraction rather than an abbreviation. Comprehensive manuscript drafting requires expanding the continuous marker phrase "continued on next page" entirely rather than resorting to truncated shorthand representations [[session/dialog/sharegpt_Z35PJ8x_2.jsonl#L1-L1]].

## Catalog of Reference Materials

- Diverse digital repositories facilitate professional writing support. Motivational content advocating sustained creative output exists on the Medium platform, featuring publications by The Partnered Pen, alongside specialized instructional guides hosted on GetNovelize tailored specifically for novelists navigating stalled projects [[session/dialog/sharegpt_Z35PJ8x_2.jsonl#L1-L1]]. Further foundational guidance concerning stylistic nuances and typographical regulations appears across authoritative lexicographical archives and community-driven discussion forums [[session/dialog/sharegpt_Z35PJ8x_2.jsonl#L1-L1]].
