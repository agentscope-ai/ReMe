---
description: 'Records a user-defined protocol for instructing an AI assistant to act
  as an SVG designer. The workflow mandates generating internal SVG code, converting
  it to a Base64 data URL, and outputting strictly a Markdown image tag with absolutely
  no surrounding text or code blocks. Documents three specific visual requests executed
  under these rules: "red nosed deer", "the earth seen from the moon", and "the earth
  seen from the moon with atmosphere".'
name: svg-generation-prompt-workflow
session_id: sharegpt_k31ZA2H_0
source_conversation: '[[session/dialog/sharegpt_k31ZA2H_0.jsonl]]'
---

## SVG Designer Workflow Configuration

The user established a strict operational framework for the AI assistant to function specifically as an SVG designer [[session/dialog/sharegpt_k31ZA2H_0.jsonl#L1-L1]].

### Execution Rules
1. **Processing Logic**: The assistant must generate the appropriate SVG code based on the user's prompt, convert the code into a Base64 Data URL, and prepare the resource [[session/dialog/sharegpt_k31ZA2H_0.jsonl#L1-L1]].
2. **Response Formatting**: The output must consist **only** of a Markdown image tag pointing to the generated Data URL. Conversational text, greetings, and Markdown code blocks containing the raw SVG source are explicitly prohibited [[session/dialog/sharegpt_k31ZA2H_0.jsonl#L1-L1]].

### Request Log
Three specific image generation tasks were processed adhering to the rules above [[session/dialog/sharegpt_k31ZA2H_0.jsonl#L3-L5]]:
*   **Prompt 1**: "red nosed deer" [[session/dialog/sharegpt_k31ZA2H_0.jsonl#L1-L1]]
*   **Prompt 2**: "the earth seen from the moon" [[session/dialog/sharegpt_k31ZA2H_0.jsonl#L3-L3]]
*   **Prompt 3**: "the earth seen from the moon with atmosphere" [[session/dialog/sharegpt_k31ZA2H_0.jsonl#L5-L5]]

All executions occurred on timestamp 2023-05-29T20:39:00 [[session/dialog/sharegpt_k31ZA2H_0.jsonl#L1-L6]].
