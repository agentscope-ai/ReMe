---
description: An ASCII art representation of a house created using text symbols.
name: ascii-art-house
session_id: sharegpt_86llQ0z_0
source_conversation: '[[session/dialog/sharegpt_86llQ0z_0.jsonl]]'
---

## ASCII Art Request and Response

- A request was made to create text symbols representing a house. An ASCII art representation using text characters was provided.
```bash
      /\ 
     /  \
    /    \
   /______\
  |        |
  |        |
  |        |
  |________|
```
[[session/dialog/sharegpt_86llQ0z_0.jsonl#L1-L2]]
