---
description: Curated recommendations for art supplies (specific paints, brushes, canvases,
  and online retailers), museum visit strategies, biographical insights regarding
  Frida Kahlo's marriage to Diego Rivera, and comprehensive learning resources (books,
  websites, video channels) tailored for creating art in Kahlo's style.
name: frida-kahlo-art-supplies-and-resources
session_id: e9fb10e7_1
source_conversation: '[[session/dialog/e9fb10e7_1.jsonl]]'
---

## Art Supply Recommendations for Kahlo's Style
- **Paints & Pigments:** Acrylic paints featuring high pigment loads and matte finishes best replicate Kahlo's vibrant aesthetic. Recommended brands include Golden High Flow Acrylics (USA), Daler-Rowney System 3 Acrylics (UK), and Holbein Acryla Gouache (Japan). Essential colors encompass earth tones (Burnt Sienna, Raw Umber, Yellow Ochre) and bold shades (Cadmium Red, Phthalo Blue, Hansa Yellow) [[session/dialog/e9fb10e7_1.jsonl#L2-L2]].
- **Brushes:** Natural hair brushes (Sable or mongoose) like Winsor & Newton Series 7 and Daler-Rowney System 3 deliver the expressive texture characteristic of Kahlo's technique. Flat brushes, specifically Holbein Flat Brushes in 1/2 inch, 1 inch, and 2 inch sizes, facilitate Kahlo's signature broad strokes [[session/dialog/e9fb10e7_1.jsonl#L2-L2]].
- **Supports & Surfaces:** Small to medium canvas panels measuring 8x10 or 11x14 inches, crafted from birch or gessoed hardboard, accurately reflect Kahlo's preference for compact working formats. Palettes equipped with built-in wells, removable mixing zones, non-stick coatings, or disposable pads accommodate Kahlo's cluttered methodological approach [[session/dialog/e9fb10e7_1.jsonl#L2-L2]].
- **Retailers:** Materials are accessible via online merchants Amazon, Dick Blick Art Materials, and Jerry's Artarama [[session/dialog/e9fb10e7_1.jsonl#L2-L2]].

## Museum Visitation Strategies
- **Metropolitan Museum of Art (The Met):** The institution maintains an extensive rotating collection, meaning permanent exhibitions like "Women in Art" do not exist [[session/dialog/e9fb10e7_1.jsonl#L4-L4]]. Visitors aiming to view works by artists such as Georgia O'Keeffe or Kahlo must consult the official digital archives prior to arrival [[session/dialog/e9fb10e7_1.jsonl#L4-L4]]. To bypass peak congestion, schedule weekday visits during opening hours (10:00 AM) or late afternoon blocks (3:00 PM–4:00 PM), deliberately avoiding summer tourism surges (June–August) and school holiday periods [[session/dialog/e9fb10e7_1.jsonl#L4-L4]]. Utilizing guided tours and scheduling frequent rest intervals further optimizes the navigational experience within the massive facility [[session/dialog/e9fb10e7_1.jsonl#L4-L4]].
- **Brooklyn Museum:** Hosted a biography-focused Kahlo lecture approximately one month prior to March 26, 2023 (circa late February 2023) under the program title "Art and Identity" [[session/dialog/e9fb10e7_1.jsonl#L7-L8]].

## Biographical Context & Major Works
- **Marriage to Diego Rivera:** The partnership commenced in 1929, encompassing approximately twenty-five years interrupted by a single divorce [[session/dialog/e9fb10e7_1.jsonl#L6-L6]]. Rivera, a Mexican muralist two decades senior to Kahlo, served as Kahlo's primary mentor upon meeting [[session/dialog/e9fb10e7_1.jsonl#L6-L6]].
- **Artistic Impact:** Rivera introduced rigorous muralist methodologies and a dedication to Mexican cultural iconography, fundamentally expanding Kahlo's chromatic and symbolic vocabulary [[session/dialog/e9fb10e7_1.jsonl#L6-L6]]. Kahlo's canvas became a vessel for psychological documentation, translating physical agony from a 1925 bus collision and interpersonal distress stemming from Rivera's extramarital affairs into visceral self-portraiture [[session/dialog/e9fb10e7_1.jsonl#L6-L6]]. Concurrent professional ambition generated productive competitive friction between the dual creators [[session/dialog/e9fb10e7_1.jsonl#L6-L6]].
- **Canonical Works:** "The Two Fridas" (painted 1939) and "Self-Portrait with Thorn Necklace and Hummingbird" (painted 1940) stand as definitive visual narratives of the marital dynamic [[session/dialog/e9fb10e7_1.jsonl#L6-L6]].

## Recommended Learning Resources
- **Digital Archives & Tutorials:** Comprehensive biographical data resides on the official Frida Kahlo Museum website (Mexico City), Google Arts & Culture, the Met's digital portal, and Tate Modern [[session/dialog/e9fb10e7_1.jsonl#L10-L10]]. Technical skill acquisition is supported by educational platforms Skillshare, Craftsy, and Artists Network, which host coursework centered on folk art traditions, portrait rendering, and mixed-media integration [[session/dialog/e9fb10e7_1.jsonl#L12-L12]].
- **Video Instruction:** YouTube educator channels The Art Sherpa, Lena Danya, and Art by LTM supply foundational acrylic applications and abstract techniques relevant to replicating Kahlo's expressive methods [[session/dialog/e9fb10e7_1.jsonl#L12-L12]].
- **Literature Collections:** Foundational reading lists include "The Diary of Frida Kahlo: An Intimate Self-Portrait", Hayden Herrera's "Frida: A Biography of Frida Kahlo", Catherine Reef's "The Life and Times of Frida Kahlo", and Luis-Martín Lozano's "Frida Kahlo: The Paintings" [[session/dialog/e9fb10e7_1.jsonl#L10-L10]]. Specialized technique manuals comprise Mary-Anne Martin's "Frida Kahlo: The Artist's Materials" and Christine M. Rodriguez's "The Art of Frida Kahlo" [[session/dialog/e9fb10e7_1.jsonl#L12-L12]].
- **Methodological Principles:** Developing authentic Kahlo-inspired work requires systematic analysis of original compositional structures, active synthesis of disparate materials (acrylics, textiles, paper collages, three-dimensional found artifacts), and sustained creative iteration to establish autonomous artistic voice [[session/dialog/e9fb10e7_1.jsonl#L12-L12]].
