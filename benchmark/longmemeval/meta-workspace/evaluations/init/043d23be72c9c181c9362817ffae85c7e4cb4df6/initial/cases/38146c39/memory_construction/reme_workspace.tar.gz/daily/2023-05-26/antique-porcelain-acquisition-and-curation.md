---
description: The user shares their interest in studying 19th-century Chinese porcelain
  following the recent successful sale of an antique vase to a collector for a substantial
  profit. The dialogue establishes a comprehensive framework for navigating the antique
  market, detailing essential reference materials (academic texts, museum archives,
  auction house databases, and collector forums) used for identification and valuation.
  It outlines specific evaluation criteria focusing on marks, glaze finishes, historical
  motifs, and structural integrity, while cataloging highly prized artifact classifications
  such as Qianlong period, Famille Rose/Verte, Ru Guanyao, Doucai, and Imperial Yellow
  wares. Furthermore, the conversation codifies standardized professional procedures
  for engaging the art market—including dealership networking, comparable sales benchmarking,
  and ethical negotiation protocols—and defines strict multi-phase workflows for third-party
  authentication (featuring forensic testing and credential verification) and physical
  conservation/restoration (utilizing non-invasive diagnostic imaging and stabilization
  techniques).
name: antique-porcelain-acquisition-and-curation
session_id: 28116d8a_1
source_conversation: '[[session/dialog/28116d8a_1.jsonl]]'
---

## User Context and Sale Records [[session/dialog/28116d8a_1.jsonl#L1-L2,L11-L12]]
- On 2023-05-26, the user declared an intent to study 19th-century Chinese porcelain, citing prior exposure.
- The user stated possessing recent experience selling an antique vase to a collector for a substantial financial return.

## Core Identification and Valuation Resources [[session/dialog/28116d8a_1.jsonl#L1-L2]]
- Academic texts: "The Concise Encyclopedia of Chinese Ceramics" by Wang Qingzheng; "Chinese Ceramics: A New Comprehensive Survey" by Wang Qingzheng; "The Handbook of Chinese Ceramics" by Soame Jenyns.
- Institutional archives: The Metropolitan Museum of Art's Heilbrunn Timeline of Art History (Chinese Ceramics); The British Museum's Collection Online (Chinese Ceramics).
- Commercial data: Christie's and Sotheby's auction house websites tracking past sales and auction results.
- Community hubs: Gotheborg.com (comprehensive database); ChinesePorcelainCollector.com (discussion forum); Antique Chinese Porcelain Collectors Group on Facebook.

## Identification and Valuation Methodology [[session/dialog/28116d8a_1.jsonl#L1-L2]]
- Mark recognition: Search for imperial reign marks, factory stamps, and artist signatures to establish dates and prove authenticity.
- Ceramic finishes: Identify 19th-century glaze profiles and palette choices, notably famille rose, famille verte, and Canton enamel.
- Architectural forms: Catalog prevalent 19th-century silhouettes including vases, storage jars, sculptural figurines, and plates.
- Iconographic analysis: Decode recurring decorative themes indicating geographic origin and chronological placement, such as dragons, phoenixes, and plum blossoms.
- Substrate analysis: Assess base compositions (porcelain, ceramic, bisque) and physically examine for structural alterations like repairs or restorations.
- Pricing methodology: Compile historical auction results, sales logs, and current market trajectories to benchmark comparable assets.
- Condition metrics: Track physical integrity and verified lineage, both serving as critical value multipliers.
- Authenticity verification: Confirm genuineness through third-party expert reviews, laboratory chemical analysis, or documented provenance chains.
- Scarcity premiums: Note unusual geometric variants or rare iconographic executions commanding elevated market prices.
- Demand tracking: Monitor shifting collector appetites influencing real-time asset liquidity.
- Advisory consultations: Collaborate with veteran traders, private collectors, and certified appraisers for independent assessments.

## Rare and High-Value Artifact Categories [[session/dialog/28116d8a_1.jsonl#L3-L4]]
- Qianlong Mark and Period Porcelain (spanning 1736-1795): Renowned for superior craftsmanship, extreme scarcity, and historical relevance. Authenticate via characters spelling "Qianlong nian zhi" or "Qianlong zhong bao".
- Famille Rose and Famille Verte Porcelain: Distinguished by vivid pink or green overglaze enamel applications. Flawless specimens boasting complex patterns and delicate tonal transitions fetch premium valuations.
- Ru Guanyao: Recognizable by distinctive crackled surface finishes, originating from the Northern Song dynasty (960-1127). Represents an exceptionally rare classification heavily favored by serious enthusiasts.
- Doucai Porcelain: Defined by cobalt blue underglaze sketches overlaid with multicolored enamel paint. Peak value clusters around masterworks crafted during the Yongzheng (1723-1735) and Qianlong eras.
- Imperial Yellow Porcelain: Pigmented exclusively for sovereign consumption, exhibiting an intense golden-yellow coating. Carries monumental financial worth due to severe supply restrictions.

## Systematic Asset Evaluation Checklist [[session/dialog/28116d8a_1.jsonl#L3-L4]]
- Verified inscriptions and copyright signatures.
- Uniform glazing surfaces exhibiting zero defects.
- Complex iconography involving mythological fauna or botanical elements.
- Unconventional dimensional proportions or bespoke manufacturing traits.
- Traceable custodial history including public gallery loans.
- Intact status free from cracks, artificial aging, or clumsy interventions.
- Statistical rarity relative to mass-produced counterparts.
- Base mineral composition quality.
- Chronological seniority correlating positively with baseline worth.
- Authoritative third-party professional endorsements.

## Commerce Ecosystem and Dealer Network Development [[session/dialog/28116d8a_1.jsonl#L5-L6]]
- Direct engagement at global trade shows, gallery openings, and live bidding rooms.
- Digital intermediary utilization via Artsy, 1stdibs, and Artnet to access institutional inventories and algorithmic market intelligence.
- Social graph amplification leveraging Instagram, Facebook, and Twitter community participation.
- Seminar attendance at technical lectures and executive workshops designed for vertical networking.
- Warm introduction solicitation deriving referral pipelines from established peers.

## Quantitative Pricing Methodologies [[session/dialog/28116d8a_1.jsonl#L5-L6]]
- Deep-dive archival investigations targeting creator biographies, stylistic evolution maps, and epoch-specific demand curves.
- Transactional benchmarking compiling recent transfer logs from brokerage firms and peer-to-peer exchanges.
- Independent fee-for-service expert valuations bypassing dealer bias.
- Algorithmic data aggregation pulling feeds from Artnet's Price Database, Bonhams archival repositories, and Blouin Artinfo historical ledgers.
- Macro-condition filtering applying depreciation or appreciation coefficients based upon preservation status and documented ownership chains.

## Operational Ethics and Negotiation Protocol [[session/dialog/28116d8a_1.jsonl#L5-L6]]
- Long-term relationship building prioritizing reciprocal value exchange mechanisms.
- Continuous curriculum updating addressing emergent macroeconomic pressures affecting fine arts liquidity.
- Contractual openness demanding complete disclosure of hidden defects, acquisition costs, and repair histories.
- Flexible bargaining posture prepared to abandon non-viable deal structures without emotional attachment.
- Institutional reputation management enforcing absolute ethical compliance standards.

## Media Intelligence and Trade Association Directories [[session/dialog/28116d8a_1.jsonl#L5-L6]]
- Editorial tracking subscriptions maintained through Artforum, Art in America, and The Art Newspaper.
- Primary exchange monitoring accessing Christie's, Sotheby's, and Bonhams live catalogs and post-auction analytics.
- Peer consultation routing through Artnet message boards and Reddit's r/artmarket subcommunities.
- Compliance registration pursuing membership within The Art Dealers Association of America (ADAA) and the International Association of Dealers in Ancient, Oriental and Primitive Art (IADAOPA).

## Formal Authentication Lifecycle [[session/dialog/28116d8a_1.jsonl#L7-L8]]
Phase 1: Desktop preliminary surveys investigating ancestral backgrounds, exhibition histories, and secondary market velocity. Local broker consultations initiate baseline projections.
Phase 2: Vendor qualification requiring verified accreditation from bodies such as the Appraisers Association of America or International Society of Appraisers. Mandatory academic pedigrees, domain-specific portfolio reviews, and peer reputation audits precede contract signing. Parallel expert engagement guarantees triangulated conclusions.
Phase 3: Forensic examination deploying multispectral imaging, radiometric decay analysis (radiocarbon dating, thermoluminescence dating), morphological matching against canonical reference datasets, and rigorous stylistic forensics mapping. Cross-departmental collaboration integrates perspectives from materials scientists and archival historians.
Phase 4: Archival deliverable generation producing exhaustive written manifests cataloging physical measurements, material assays, authenticity verdicts, monetary estimates, empirical proof bundles, and remedial action roadmaps.
Phase 5: Redundancy validation procedures challenging initial assertions through independent audit panels, rival institutional reports, and granular spot-market indexing studies.
Role Classification Matrix: Monetary evaluators (Appraisers), Genuineness certifiers (Authenticators), Decay preventers (Conservators), Cataloging stewards (Curators), Cultural chronologists (Historians).
Strategic Documentation Exploitation: Legal shielding, insurance indemnification triggers, provenance pedigree establishment, and marketability enhancement vehicles.

## Technical Preservation and Remediation Cycles [[session/dialog/28116d8a_1.jsonl#L9-L10]]
Trigger Identification: Surface topology scanning detecting fracture propagation, textile delamination, chromatic degradation, oxidative corrosion, biological colonization (mycological growth, arthropod activity), prior crude intervention attempts, and abiotic stressors (thermal cycling, relative humidity fluctuations, ultraviolet radiation bombardment).
Specialist Procurement: Credential auditing against American Institute for Conservation and International Institute for Conservation rosters. Demanding pedagogical qualifications, analogous artifact repair histories, and irrefutable success track records. Seeking redundant operational blueprints prevents execution failures.
Diagnostic Profiling: Non-invasive penetration testing utilizing gamma radiation transmission (X-rays), subsurface pigment mapping (infrared reflectography), volatile organic compound sniffing (gas chromatography), alongside macroscopic morphology reviews and canonical comparison databases. Generating targeted therapeutic protocols follows immediately.
Intervention Execution: Microbial eradication sequences, hydrogel desalination treatments, synthetic polymer reinforcement injections, displaced fragment reintegration, destructive legacy modification reversals, and protective housing fabrication. Mandated operating principles prioritize maximum retention of original manufacturing signatures coupled with absolute future-proof mechanical resilience.
Perishable Data Logging: Masterpiece-grade manifest recording pre-intervention structural baselines, chemical agent inventories, execution sequencing, timestamped optical capture arrays, and perpetual maintenance directives.
Quality Assurance Auditing: Document scrutiny demanding linguistic precision regarding methodologies employed, professional license verification, and outcome reproducibility assessments against external benchmarks.
Functional Classification Taxonomy: Structural stabilizers (Conservators), Cosmetic rejuvenators (Restorers), Display strategists (Curators), Temporal contextualizers (Historians).
Administrative Utility Vectors: Chain-of-custody verification, liability shield deployment, intrinsic value affirmation, and liquidity acceleration mechanisms.
