---
description: On 2023-05-28, the user requested book recommendations after finishing
  the audiobook version of "American Gods". The assistant provided ten urban fantasy
  and mythological titles, leading to a comparative deep dive into "The First Fifteen
  Lives of Harry August" and "The Golem and the Jinni". The discussion covered narrative
  premises, core themes, pacing classifications, and prose styles, including a direct
  comparison of Claire North's writing to Neil Gaiman's. The user ultimately selected
  "The First Fifteen Lives of Harry August" to read in print format as a change from
  recent audiobooks, citing interest in its reincarnation philosophy and faster, plot-driven
  structure.
name: book-recs-after-american-gods
session_id: 5faf5962_3
source_conversation: '[[session/dialog/5faf5962_3.jsonl]]'
---

## Reading History & Preferences [[session/dialog/5faf5962_3.jsonl#L1-L3]]
- On 2023-05-28 at 10:13:00, the user completed listening to the audiobook adaptation of "American Gods" and described the experience as amazing [[session/dialog/5faf5962_3.jsonl#L1-L1]].
- The assistant noted that George Guidall provides the audiobook narration for "American Gods", adding significant depth and atmosphere to Neil Gaiman's vivid prose [[session/dialog/5faf5962_3.jsonl#L12-L12]].
- The user expressed admiration for Neil Gaiman's lyrical and imaginative writing style as demonstrated in "American Gods" [[session/dialog/5faf5962_3.jsonl#L9-L9]].
- Following heavy recent consumption of audiobooks, the user intends to switch to print reading formats for upcoming selections [[session/dialog/5faf5962_3.jsonl#L11-L11]].

## Book Recommendations Delivered [[session/dialog/5faf5962_3.jsonl#L2-L2]]
The assistant provided ten titles sharing thematic, stylistic, or genre elements with "American Gods":
- "The Night Circus" by Erin Morgenstern: Blends fantasy, mythology, and magical realism within a mystical nocturnal circus competition.
- "The Lies of Locke Lamora" by Scott Lynch: Adventure-focused fantasy featuring complex characters, con artists, and thieves in a Renaissance-inspired city.
- "The First Fifteen Lives of Harry August" by Claire North: Explores reincarnation, time travel, and the cascading consequences of human actions across multiple lifetimes.
- "The City & The City" by China Miéville: Police procedural fantasy examining two distinct societies occupying the same physical geographic space.
- "The Golem and the Jinni" by Helene Wecker: Historical fantasy set in early 20th-century New York City tracking a clay golem and a fire jinni navigating identity and community integration.
- "The House of Shattered Wings" by Aliette de Bodard: Post-apocalyptic dark fantasy in Paris involving fallen angels and rival houses vying for territorial control.
- "The Iron Druid Chronicles" by Kevin Hearne: Urban fantasy series featuring a 2,000-year-old druid combating supernatural entities in modern-day Arizona.
- "The Dresden Files" by Jim Butcher: Urban fantasy series following a wizard detective resolving supernatural crimes in modern-day Chicago.
- "The Rivers of London" series by Ben Aaronovitch: Urban fantasy combining magic, mythology, and police procedures set in London.
- "The October Daye" series by Seanan McGuire: Urban fantasy following a half-fae private investigator handling faerie politics in modern-day San Francisco.

## Deep Dive: The First Fifteen Lives of Harry August by Claire North [[session/dialog/5faf5962_3.jsonl#L3-L4,L8-L8,L10-L10]]
- Narrative Premise: Protagonist Harry August experiences continuous reincarnation, retaining memories of all prior lives while attempting to comprehend his existence and prevent global catastrophe [[session/dialog/5faf5962_3.jsonl#L4-L4]].
- Thematic Focus: Examines reincarnation as a natural phenomenon where consequences transit across lifetimes, the intricate butterfly effects linking disparate eras, the psychological weight of accumulated knowledge, and the existential search for purpose [[session/dialog/5faf5962_3.jsonl#L8-L8]].
- Prose Characteristics: Characterized by lyrical, poetic, and introspective qualities marked by elegant simplicity, meticulous world-building detail, and philosophical undertones prompting reader reflection [[session/dialog/5faf5962_3.jsonl#L4-L4]]. Claire North's style shares Gaiman's use of vivid, evocative language and respect for mythology, but differs by being more subdued, serious, and grounded in reality rather than playful and fantastical [[session/dialog/5faf5962_3.jsonl#L10-L10]].
- Structural Approach: Utilizes a non-linear narrative weaving through distinct temporal periods, demanding attentive engagement to track the intricate cause-and-effect web [[session/dialog/5faf5962_3.jsonl#L4-L4]].
- Pacing Classification: Operates as a faster-paced, plot-driven narrative prioritizing dynamic action and suspenseful sequencing [[session/dialog/5faf5962_3.jsonl#L6-L6]].

## Deep Dive: The Golem and the Jinni by Helene Wecker [[session/dialog/5faf5962_3.jsonl#L3-L4,L6-L6]]
- Narrative Premise: Follows Chava (a clay construct obligated to obedience) and Ahmad (a fire elemental adjusting to humanity) within early 20th-century New York City as they navigate societal expectations and inherent nature [[session/dialog/5faf5962_3.jsonl#L4-L4]].
- Thematic Focus: Investigates identity formation, diaspora communities, the immigrant experience, boundaries between creator and creation, and narrative power [[session/dialog/5faf5962_3.jsonl#L4-L4]].
- Prose Characteristics: Rich, highly descriptive, and deeply immersive, utilizing dual perspective narration to establish nuanced internal states [[session/dialog/5faf5962_3.jsonl#L4-L4]].
- Pacing Classification: Functions as a deliberate slow burn focusing on atmospheric development and character psychology over rapid plot progression, structured across four expansive chronological parts [[session/dialog/5faf5962_3.jsonl#L6-L6]].

## Final Selection & Decision Factors [[session/dialog/5faf5962_3.jsonl#L5-L7,L11-L11]]
- The user committed to reading "The First Fifteen Lives of Harry August" as the immediate next book [[session/dialog/5faf5962_3.jsonl#L7-L7]].
- Selection drivers included strong interest in the novel's specific treatment of reincarnation philosophy and a preference for the accelerated, plot-forward pacing relative to the deliberative character focus of "The Golem and the Jinni" [[session/dialog/5faf5962_3.jsonl#L6-L7]].
- The commitment includes a conscious format shift from audiobooks to print reading for this title [[session/dialog/5faf5962_3.jsonl#L11-L11]].
