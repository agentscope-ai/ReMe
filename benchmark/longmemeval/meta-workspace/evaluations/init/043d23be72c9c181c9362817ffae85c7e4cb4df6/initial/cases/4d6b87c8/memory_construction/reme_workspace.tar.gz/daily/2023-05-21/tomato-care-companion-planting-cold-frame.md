---
description: Detailed documentation of the user's tomato cultivation setup, comprehensive
  soil maintenance protocols, a complete list of recommended companion plants and
  plants to avoid, extensive strategies for utilizing and controlling invasive comfrey,
  and precise construction guidelines for a New England-style cold frame using recycled
  materials and eco-friendly insulation for seasonal extension.
name: tomato-care-companion-planting-cold-frame
session_id: 40d74f35_2
source_conversation: '[[session/dialog/40d74f35_2.jsonl]]'
---

## Tomato Cultivation & Soil Maintenance [[session/dialog/40d74f35_2.jsonl#L1-L2]]
- The user is successfully growing tomatoes due to regular watering, regular fertilizing, nutrient-rich soil, and the addition of a natural substance to improve soil structure and fertility [[session/dialog/40d74f35_2.jsonl#L1]].
- To maintain soil quality over time:
  - Add organic matter regularly using compost, well-rotted manure, or leaf mold [[session/dialog/40d74f35_2.jsonl#L2]].
  - Apply a 2-3 inch layer of organic mulch (straw, bark chips, grass clippings) to retain moisture, suppress weeds, and regulate temperature [[session/dialog/40d74f35_2.jsonl#L2]].
  - Rotate crops to avoid nutrient depletion and reduce pest and disease buildup [[session/dialog/40d74f35_2.jsonl#L2]].
  - Test soil pH regularly; optimal range for tomatoes is 6.0-6.8. Adjust pH with lime (to raise), or elemental sulfur or peat moss (to lower) [[session/dialog/40d74f35_2.jsonl#L2]].
  - Use cover crops like legumes (clover, beans) or grasses during the off-season [[session/dialog/40d74f35_2.jsonl#L2]].
  - Minimize tilling to preserve soil structure and ecosystem [[session/dialog/40d74f35_2.jsonl#L2]].
  - Add beneficial microorganisms such as mycorrhizal fungi or bacteria [[session/dialog/40d74f35_2.jsonl#L2]].
  - Monitor soil moisture to avoid overwatering, which causes nutrient leaching and soil erosion [[session/dialog/40d74f35_2.jsonl#L2]].
  - Avoid over-fertilizing by using organic, slow-release fertilizers at recommended application rates [[session/dialog/40d74f35_2.jsonl#L2]].
  - Observe soil performance and adjust strategies based on plant growth, soil structure changes, and pest or disease issues [[session/dialog/40d74f35_2.jsonl#L2]].

## Companion Planting & Beneficial Plants [[session/dialog/40d74f35_2.jsonl#L3-L8]]
- Considerations for adding companion plants for pest control and growth support were discussed [[session/dialog/40d74f35_2.jsonl#L3]].
- Recommended companion plants for tomatoes include:
  - **Basil**: Repels whiteflies, aphids, and mites [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Borage**: Attracts beneficial insects, improves tomato flavor, acts as natural fertilizer [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Chives**: Repels aphids and adds nutrients [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Marigold**: Repels nematodes, whiteflies, aphids [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Oregano**: Repels pests, improves soil health [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Parsley**: Repels carrot flies, improves soil health [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Radish**: Repels cucumber beetles, serves as trap crop [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Nasturtium**: Repels aphids and whiteflies [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Dill**: Repels aphids, mites, flies; improves growth and flavor of nearby plants [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Comfrey**: Fertilizer plant, provides habitat for beneficial insects [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Calendula**: Attracts beneficial insects, repels pests [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Bee Balm**: Attracts pollinators, repels pests [[session/dialog/40d74f35_2.jsonl#L4]].
- Plants to avoid planting near tomatoes:
  - **Fennel**: Inhibits tomato growth, can cross-pollinate with tomatoes [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Potatoes**: Can spread diseases to tomatoes [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Eggplants**: Compete with tomatoes for water and nutrients [[session/dialog/40d74f35_2.jsonl#L4]].
  - **Okra**: Can provide a habitat for pests that target tomatoes [[session/dialog/40d74f35_2.jsonl#L4]].
- **Comfrey benefits for soil structure and fertility**:
  - Deep taproot (up to 10 feet deep) taps into deep soil nutrients bringing them to the surface [[session/dialog/40d74f35_2.jsonl#L6]].
  - Leaves rich in nutrients like nitrogen, phosphorus, and potassium release into soil upon decomposition [[session/dialog/40d74f35_2.jsonl#L6]].
  - Adds organic matter improving water-holding capacity and overall fertility [[session/dialog/40d74f35_2.jsonl#L6]].
  - Roots help break up compacted soil, improving aeration and allowing air and water penetration [[session/dialog/40d74f35_2.jsonl#L6]].
- Other soil-improving plants: Clover, Alfalfa (legume that fixes nitrogen), Buckwheat, Winter rye (cover crop reducing erosion), Daikon radish (long taproot breaking compacted soil) [[session/dialog/40d74f35_2.jsonl#L6]]. These plants function effectively as cover crops, compost plants, mulch plants, or intercrop plants [[session/dialog/40d74f35_2.jsonl#L6]].
- Additional uses for comfrey minimizing invasiveness:
  - **Comfrey tea**: Steeped in water for foliar spray or soil drench [[session/dialog/40d74f35_2.jsonl#L8]].
  - **Compost activator**: Added to compost pile to speed decomposition and create nutrient-dense compost [[session/dialog/40d74f35_2.jsonl#L8]].
  - **Mulch**: Broken down quickly adding organic matter and nutrients [[session/dialog/40d74f35_2.jsonl#L8]].
  - **Fertilizer**: Dried and chopped leaves mixed directly into soil [[session/dialog/40d74f35_2.jsonl#L8]].
  - **Potting mix additive**: Provides nutrients and improves soil structure [[session/dialog/40d74f35_2.jsonl#L8]].
  - **Erosion control**: Stabilizes slopes and hillsides [[session/dialog/40d74f35_2.jsonl#L8]].
  - **Living fertilizer factory**: Planted in designated areas for leaf harvesting without allowing plant spread [[session/dialog/40d74f35_2.jsonl#L8]].
  - **Animal feed**: Nutritious feed supplement for chickens, rabbits, and small animals [[session/dialog/40d74f35_2.jsonl#L8]].
  - **Medicinal uses**: Anti-inflammatory and wound-healing properties utilized in herbal medicine [[session/dialog/40d74f35_2.jsonl#L8]].
  - **Boundary control**: Prevents weeds and other invasive plants from encroaching [[session/dialog/40d74f35_2.jsonl#L8]].
- Methods to control comfrey's invasive tendencies:
  - Plant in contained areas like raised beds or sunken pots [[session/dialog/40d74f35_2.jsonl#L8]].
  - Regularly harvest leaves to prevent flowering and seed production [[session/dialog/40d74f35_2.jsonl#L8]].
  - Divide and replant every 3-4 years preventing excessive density [[session/dialog/40d74f35_2.jsonl#L8]].
  - Grow sterile varieties like 'Bocking 14' which do not produce viable seeds [[session/dialog/40d74f35_2.jsonl#L8]].

## Cold Frame Construction [[session/dialog/40d74f35_2.jsonl#L9-L12]]
- Plans to build a cold frame with a sloping top and hinged lid (New England design) to extend the growing season and gain a head start on spring planting [[session/dialog/40d74f35_2.jsonl#L9]].
- Preference established for using recycled materials, specifically looking for reclaimed wood or repurposed materials for the frame [[session/dialog/40d74f35_2.jsonl#L11]].
- General cold frame design and construction guidelines:
  - Simple rectangular box design with a sloping top facing south (in northern hemisphere) at a 30-40° angle for maximum sunlight capture [[session/dialog/40d74f35_2.jsonl#L10]].
  - Frame material should utilize rot-resistant lumber (cedar, redwood) or recycled plastic; avoid pressure-treated wood to prevent chemical leaching into soil [[session/dialog/40d74f35_2.jsonl#L10]].
  - Optimal dimensions: at least 3-4 feet wide and 6-8 feet long to accommodate multiple plants and allow easy access [[session/dialog/40d74f35_2.jsonl#L10]].
  - Placement requires full sun exposure (minimum 6 hours direct sunlight) and protection from strong winds [[session/dialog/40d74f35_2.jsonl#L10]].
  - Ensure proper drainage via a sloped bottom and addition of a gravel or sand layer [[session/dialog/40d74f35_2.jsonl#L10]].
  - Utilize transparent, UV-stable glazing materials (glass, polycarbonate, acrylic) paired with ventilation mechanisms (automatic vent openers or manual vents) to prevent overheating [[session/dialog/40d74f35_2.jsonl#L10]].
  - Line the frame with insulating materials like foam board, straw, or shredded newspaper to reduce heat loss [[session/dialog/40d74f35_2.jsonl#L10]].
- Eco-friendly insulation options for cold frames:
  - **Recycled denim insulation**: Eco-friendly, non-toxic, provides high R-value (thermal resistance) [[session/dialog/40d74f35_2.jsonl#L12]].
  - **Straw or hay bales**: Inexpensive, abundant, provides effective insulation for lining walls and bottom [[session/dialog/40d74f35_2.jsonl#L12]].
  - **Shredded newspaper or cardboard**: Readily available, free, usable for temporary wall and bottom lining [[session/dialog/40d74f35_2.jsonl#L12]].
  - **Foam board insulation**: Widely used; recommend searching for recycled foam board or pairing with natural alternatives like recycled denim [[session/dialog/40d74f35_2.jsonl#L12]].
- Insulation quantity guidelines for walls and bottom:
  - Minimum: 1-2 inches (2.5-5 cm) [[session/dialog/40d74f35_2.jsonl#L12]].
  - Recommended: 2-4 inches (5-10 cm) [[session/dialog/40d74f35_2.jsonl#L12]].
  - Maximum: 4-6 inches (10-15 cm) [[session/dialog/40d74f35_2.jsonl#L12]].
- Installation and maintenance considerations:
  - Leave adequate spacing between installed insulation and the glazing for air circulation and to prevent moisture buildup [[session/dialog/40d74f35_2.jsonl#L12]].
  - Install insulation correctly eliminating gaps ensuring full contact with the wooden frame [[session/dialog/40d74f35_2.jsonl#L12]].
  - Apply protective vapor barriers (plastic sheeting or waterproof membranes) shielding insulation from moisture damage [[session/dialog/40d74f35_2.jsonl#L12]].
  - Select durable materials capable of weathering external conditions; avoid materials prone to rot or degradation over time [[session/dialog/40d74f35_2.jsonl#L12]].
