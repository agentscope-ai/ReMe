---
description: 'Drafted a formal rejection email for an ArcGIS Online (AGOL) Story Map
  submission submitted on 2023-05-29. The rejection was mandated by the ERH policy
  established in 2020, which strictly prohibits making "live/dynamic" AGOL pages public
  within the ER environment. The drafted email utilizes the exact subject line "ArcGIS
  Online Story Map Submission - Rejection" and includes four key components: (1) explicit
  notification that the submission will not receive approval due to the 2020 policy
  restriction, (2) acknowledgment of significant effort invested in creating the Story
  Map accompanied by an apology for inconvenience, (3) justification for enforcement
  citing the necessity of preserving overall system security and data integrity, and
  (4) an invitation for the recipient to raise questions or concerns and discuss the
  decision further.'
name: agol-story-map-rejection-policy-2020
session_id: sharegpt_6ZpPBwe_0
source_conversation: '[[session/dialog/sharegpt_6ZpPBwe_0.jsonl]]'
---

## ArcGIS Online Story Map Submission Denial

* An ArcGIS Online (AGOL) Story Map submitted for review was denied approval because it violates the ERH policy established in 2020, which explicitly mandates that there will be no "live/dynamic" AGOL pages made public in the ER environment. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L1-L1]]

## Drafted Rejection Email Structure

* The composed message utilizes the precise subject header: "ArcGIS Online Story Map Submission - Rejection". [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
* The opening paragraph formally notifies the recipient that the submitted AGOL Story Map will not receive approval due to the aforementioned 2020 ERH regulatory restriction against publishing live or dynamic AGOL interfaces in ER. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
* The second paragraph acknowledges substantial developmental effort invested in constructing the Story Map and extends an apology for any operational inconvenience resulting from the non-approval ruling. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
* The third paragraph articulates the enforcement rationale, emphasizing that preserving comprehensive system security and data integrity necessitates strict adherence to existing architectural boundaries. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
* The closing paragraph prompts the recipient to submit inquiries or reservations and declares readiness to deliberate the administrative determination in subsequent communications. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
