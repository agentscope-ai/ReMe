---
description: Establishes best practices for crafting effective image prompts for Midjourney's
  artificial intelligence program, including formatting rules that prioritize comma-separated
  descriptive phrases over narrative storytelling, the inclusion of cinematic camera
  directions, and technical quality specifications such as 4K resolution. Captures
  verified prompt templates developed for multiple visual themes including futuristic
  sci-fi battles, mystical nature landscapes featuring dragons, underwater exploration
  scenes, and deep-sea environments, alongside documented system limitations encountered
  during iterative refinement.
name: midjourney-prompt-generation-strategies
session_id: sharegpt_XCIKBKE_0
source_conversation: '[[session/dialog/sharegpt_XCIKBKE_0.jsonl]]'
---

## Midjourney Prompt Generation Framework

* Purpose involves providing detailed and creative descriptions designed to inspire unique and visually interesting images through Midjourney's artificial intelligence engine [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L1-L1]].
* The AI system demonstrates capacity to interpret abstract linguistic concepts and wide-ranging language, enabling highly imaginative and elaborate descriptive outputs [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L1-L1]].

## Formatting Guidelines for Effective Prompts

* Replace traditional narrative storytelling structures with lists of comma-separated descriptive keywords and phrases [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L3-L4,L9-L10]].
* Incorporate explicit camera direction terminology including specified positioning angles (such as aerial views positioned high above subjects), dynamic movement instructions (panning and tilting), and shot type specifications (close-up framing) [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L7-L8,L10-L10]].
* Embed technical quality descriptors within prompts, specifically requiring "4K resolution" notation to enforce high-definition rendering standards and emphasize intricate visual details [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L7-L8,L10-L10]].

## Generated Visual Scene Templates

**Futuristic Sci-Fi Combat Scenario**
* Template string: "Futuristic battle, droids and humans, explosions, ships, aerial view, 4K resolution, intricate details, smoke and fire, pan and tilt, full scale, destruction, close-up, droid and human, intense fight, determination, intensity" [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L10-L10]].

**Mystical Nature Landscape Composition**
* Template string: "Mystical forest, foggy morning, misty veil, golden light, autumn leaves, old tree, creaky branches, twisted roots, moss-covered, wildlife, birds chirping, camera positioned low, 4K resolution, slow-motion, close-up, movement of leaves, texture of the bark, dew droplets" [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L12-L12]].

**Fantasy Encounter Scene**
* Template string: "Dragon, mystical forest, scales glistening, sunlight filtering through trees, wings beating fiercely, fiery breath, brave warriors, weapons ready, village, powerful jaws" [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L4-L4]].

**Underwater Exploration Environment**
* Template string: "An underwater city, glowing lights, futuristic technology, submarines, sea creatures, schools of fish, divers, deep sea exploration, ancient ruins" [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L6-L6]].

## Operational Constraints Encountered

* System processing reached rate-limit threshold after executing multiple sequential prompt generation iterations within an hour window, resulting in error message indicating too many requests in 1 hour [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L13-L14]].
* Initial prompt request regarding a "present Japanese woman" was blocked due to rate limiting before generation could occur [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L13-L14]].
