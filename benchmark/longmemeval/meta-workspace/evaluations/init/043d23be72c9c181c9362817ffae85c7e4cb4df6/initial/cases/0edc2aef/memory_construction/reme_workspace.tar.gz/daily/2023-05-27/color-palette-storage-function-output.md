---
description: A requested color palette for the conceptual design of "Storage", "Function",
  and "Output". Includes primary colors alongside matching background and border colors
  specified in both Hex and Oklch formats.
name: color-palette-storage-function-output
session_id: sharegpt_AsgRx0A_0
source_conversation: '[[session/dialog/sharegpt_AsgRx0A_0.jsonl]]'
---

## Color Palette Concepts

* **Storage**: Represents stability and growth; intended to symbolize storing something safely and securely, such as data or information. Primary color is a muted, earthy green. Hex code: `#8F9779`. [[session/dialog/sharegpt_AsgRx0A_0.jsonl#L1-L2]]
* **Function**: Represents activity and dynamism; intended to represent functions or processes happening in the background, such as computing or programming. Primary color is a bright, energetic yellow. Hex code: `#F7DC6F`. [[session/dialog/sharegpt_AsgRx0A_0.jsonl#L1-L2]]
* **Output**: Represents clarity and precision; intended to symbolize outputting something clearly and precisely, such as a report or a result. Primary color is a deep, rich blue. Hex code: `#2E4053`. [[session/dialog/sharegpt_AsgRx0A_0.jsonl#L1-L2]]

## Background and Border Colors (Hex)

* **Storage**: Uses a light beige or cream background (`#F5F5DC`) to complement the earthy green. The border is a darker shade of that green (`#5B6430`) to create contrast and draw attention. [[session/dialog/sharegpt_AsgRx0A_0.jsonl#L3-L4]]
* **Function**: Uses a light or mid-tone gray background (`#D3D3D3`) to balance the bright yellow. The border is a darker, cooler gray or black (`#2F4F4F`) to help define the edges. [[session/dialog/sharegpt_AsgRx0A_0.jsonl#L3-L4]]
* **Output**: Uses a light blue or sky blue background (`#ADD8E6`) to complement the deep blue. The border is a slightly lighter deep blue (`#45698E`) to create subtle contrast and define boundaries. [[session/dialog/sharegpt_AsgRx0A_0.jsonl#L3-L4]]

| Concept   | Background Color | Border Color | Primary Color |
| --------- | ---------------- | ------------ | ------------- |
| Storage   | `#F5F5DC`        | `#5B6430`    | `#8F9779`     |
| Function  | `#D3D3D3`        | `#2F4F4F`    | `#F7DC6F`     |
| Output    | `#ADD8E6`        | `#45698E`    | `#2E4053`     |

[[session/dialog/sharegpt_AsgRx0A_0.jsonl#L5-L8]]

## Oklch Values

Colors converted to the Oklch color space, which is perceptually uniform and accounts for lightness, chroma, and hue consistently. Values are ordered as Lightness (L), Chroma (C), and Hue Angle (H).

* **Storage**
  * Background: `85.56 2.55 111.48`
  * Border: `48.18 5.63 117.16`
  * Primary: `57.69 12.18 102.16`
* **Function**
  * Background: `76.52 -0.08 295.70`
  * Border: `23.03 -0.46 285.64`
  * Primary: `90.24 13.50 102.45`
* **Output**
  * Background: `78.15 -7.07 201.17`
  * Border: `17.63 -4.04 214.80`
  * Primary: `10.47 15.06 222.19`

[[session/dialog/sharegpt_AsgRx0A_0.jsonl#L9-L10]]
