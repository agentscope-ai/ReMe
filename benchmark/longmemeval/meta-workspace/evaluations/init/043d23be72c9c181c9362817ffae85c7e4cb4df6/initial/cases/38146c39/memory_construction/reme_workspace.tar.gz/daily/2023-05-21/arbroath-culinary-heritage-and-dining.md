---
description: Overview of Arbroath's coastal fishing industry and its historical influence
  on the local gastronomy, with detailed focus on the origin, production methodology,
  vendor locations, and culinary applications of Arbroath Smokies. Compiles a curated
  directory of local establishments—including traditional smokehouses, seafood-focused
  restaurants, pubs, tea rooms, and the monthly farmers market—highlighting signature
  dishes such as smoked haddock, regional fish and chips, Scottish beef, and seasonal
  shellfish.
name: arbroath-culinary-heritage-and-dining
session_id: ultrachat_233519
source_conversation: '[[session/dialog/ultrachat_233519.jsonl]]'
---

## Coastal Fishing Industry & Local Gastronomy
- The commercial fishing sector in Arbroath has functioned as the economic foundation of the town for centuries, supporting local household incomes while fundamentally shaping the region's food culture [[session/dialog/ultrachat_233519.jsonl#L1-L2]].
- Haddock, cod, sole, and plaice form the core of the local marine catch, commercially distributed through independent fishmongers and featured prominently across town restaurant menus [[session/dialog/ultrachat_233519.jsonl#L2]].

## Arbroath Smokies: Production, Retail Sources & Preparation
- Arbroath Smokies represent a historically significant smoked haddock product with documented production spanning more than two centuries [[session/dialog/ultrachat_233519.jsonl#L1-L2]].
- Historical production began as a practical preservation technique for surplus catches; modern fabrication utilizes a specialized smokehouse apparatus that cooks haddock exclusively over hardwood logs, adhering to an unaltered generational methodology [[session/dialog/ultrachat_233519.jsonl#L2]].
- Retail and tasting availability includes Iain Spink's Smokehouse (operating continuously since the late 1800s utilizing authentic techniques), Alex Spink & Sons (manufacturing for over a century with both retail storefront and direct-to-consumer shipping), The Old Boatyard Restaurant, The Bellrock pub, plus distribution through regional fishmongers and select grocery outlets [[session/dialog/ultrachat_233519.jsonl#L4]].
- Traditional consumption prioritizes eating the product directly without secondary heat application; however, the cured fish integrates effectively into alternative preparations: simmering flaked meat within a potato-based vegetable chowder, binding flaked meat with mashed potatoes and botanical herbs before shallow-frying into patties, folding flaked meat into egg custard tarts, or emulsifying flaked meat with dairy cheese, citrus juice, and greens to formulate a bread spread [[session/dialog/ultrachat_233519.jsonl#L6]].

## Regional Culinary Establishments & Market Schedule
- Arbroath Fish Bar provides classic battered fish accompanied by fried potato strips prepared to achieve a crisp exterior texture [[session/dialog/ultrachat_233519.jsonl#L8]].
- Kerr's Miniature Railway Tea Room operates adjacent to a local model rail layout, maintaining a menu centered on baked pastry items, sweet scones, and midday meal offerings [[session/dialog/ultrachat_233519.jsonl#L8]].
- The West Port Bar and Kitchen curates a rotating menu built upon agricultural sourcing protocols, emphasizing regional oceanic proteins and terrestrial cattle cuts [[session/dialog/ultrachat_233519.jsonl#L8]].
- The Vineyards functions as a multi-generational hospitality venue supplying grilled meats, marine proteins, dough-baked pies, and a curated beverage roster containing fermented grape drinks and brewed barley drinks [[session/dialog/ultrachat_233519.jsonl#L8]].
- The Harbour Nights occupies a coastal premises proximate to maritime docks, executing a focused kitchen program revolving around bivalves, cephalopods, and crustaceans [[session/dialog/ultrachat_233519.jsonl#L8]].
- The Arbroath Farmers Market conducts operations on the concluding calendar Saturday of each standard Gregorian month, facilitating public access to indigenous horticultural products and handcrafted consumables [[session/dialog/ultrachat_233519.jsonl#L8]].
