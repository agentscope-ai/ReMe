---
description: 'Overview of standard industrial dimensions for nuclear fuel rods across
  different reactor types. Notes that rods are cylindrical, generally ranging from
  8 to 16 mm in diameter. Provides specific metrics for Pressurized Water Reactors
  (PWR: ~3.7 m length, ~1 cm diameter) and Boiling Water Reactors (BWR: ~4 m length,
  ~1.27 cm diameter). Highlights that exact dimensions depend on fuel type, design,
  and operating conditions, all governed by standardized safety and performance specifications.'
name: nuclear-fuel-rod-dimensions
session_id: sharegpt_S5qxLQF_0
source_conversation: '[[session/dialog/sharegpt_S5qxLQF_0.jsonl]]'
---

### General Fuel Rod Geometry
- Standard nuclear fuel rods are manufactured in a cylindrical shape [[session/dialog/sharegpt_S5qxLQF_0.jsonl#L5-L6]]
- Typical rod diameters fall within a range of 8 millimeters to 16 millimeters [[session/dialog/sharegpt_S5qxLQF_0.jsonl#L6-L6]]
- Physical lengths vary significantly depending on configuration, spanning from tens of centimeters up to several meters [[session/dialog/sharegpt_S5qxLQF_0.jsonl#L6-L6]]

### Reactor-Specific Measurements
- Pressurized Water Reactors (PWR) utilize fuel rods measuring approximately 3.7 meters in length with a diameter near 1 centimeter [[session/dialog/sharegpt_S5qxLQF_0.jsonl#L6-L6]]
- Boiling Water Reactors (BWR) utilize fuel rods measuring approximately 4 meters in length with a slightly larger diameter of roughly 1.27 centimeters [[session/dialog/sharegpt_S5qxLQF_0.jsonl#L6-L6]]

### Industry Context
- Exact physical dimensions change based on the specific fuel formulation, overall reactor engineering design, and operational environmental conditions [[session/dialog/sharegpt_S5qxLQF_0.jsonl#L6-L6]]
- Established standard dimensions govern manufacturing to guarantee all components satisfy rigid nuclear safety and operational performance specifications [[session/dialog/sharegpt_S5qxLQF_0.jsonl#L6-L6]]
