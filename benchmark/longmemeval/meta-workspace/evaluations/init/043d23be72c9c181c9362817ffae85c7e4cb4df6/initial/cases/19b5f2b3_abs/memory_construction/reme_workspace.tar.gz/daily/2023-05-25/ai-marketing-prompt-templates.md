---
description: A compiled list of ten specific AI prompt templates for marketing applications,
  covering social media campaigns, customer sentiment analysis, targeted email marketing,
  sales and revenue prediction, chatbot scripting, e-commerce personalization, ROI
  forecasting, PPC ad optimization, blog content ideation, and customer journey mapping.
name: ai-marketing-prompt-templates
session_id: sharegpt_wJtfpky_0
source_conversation: '[[session/dialog/sharegpt_wJtfpky_0.jsonl]]'
---

## AI Marketing Prompt Templates [[session/dialog/sharegpt_wJtfpky_0.jsonl#L1-L2]]

A user requested a compilation of effective artificial intelligence prompts focused on marketing applications. The assistant provided a curated list encompassing ten distinct marketing functions:
1. "Generate a social media campaign for a new product launch"
2. "Analyze customer sentiment towards a brand and recommend strategies for improvement"
3. "Create a targeted email marketing campaign for a specific customer segment"
4. "Predict sales and revenue for a new marketing initiative"
5. "Develop a chatbot script for customer service and support"
6. "Design a personalized shopping experience for e-commerce customers"
7. "Forecast the ROI of a marketing budget"
8. "Optimize PPC ad copy and landing pages to increase conversion rates"
9. "Generate content ideas for a company blog"
10. "Create a customer journey map and identify touchpoints for targeted messaging"
