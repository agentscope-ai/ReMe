---
description: Comprehensive tutorial on using arrays in ChucK for music programming,
  covering basic syntax, melody generation, and chord progressions. Provides a comparative
  overview of music programming languages (Max/MSP, Pure Data, SuperCollider, Csound,
  Swift, Sonic Pi, Python) tailored for beginners, culminating in a recommended onboarding
  path for Sonic Pi with specific resources (tutorials, examples, community platforms).
name: music-programming-tutorial-sd
session_id: ultrachat_243337
source_conversation: '[[session/dialog/ultrachat_243337.jsonl]]'
---

## ChucK Array Fundamentals
- Arrays in ChucK have a fixed size determined at declaration and utilize zero-based indexing. The `.cap()` method returns the total number of elements.
- Standard integer declaration: `int myArray[5];` followed by index assignment (e.g., `myArray[0] = 5;`).
- Implicit sizing initialization for floats: `float myFloatArray[] = [1.5, 2.6, 3.7];`
- Iteration uses standard `for` loops combined with `.cap()`: `for (int i = 0; i < myArray.cap(); i++) { ... }`
- Console output utilizes the print operator: `<<<"Element 2 of the array is ", myArray[2]>>>;`
[[session/dialog/ultrachat_243337.jsonl#L1-L2]]

## Musical Applications in ChucK
- **Melody Generation**: Define an array of MIDI pitch values and iterate to trigger notes. Convert pitch to frequency using `Note.freq()`. Insert timing gaps using the `now` operator (e.g., `1::second => now;`).
  - Example base melody array: `int melody[] = [60, 62, 64, 65, 67, 69, 71, 72];`
- **Chord Progressions**: Utilize 2D arrays where each inner array represents the constituent pitches of a single chord. Nested loops play individual note frequencies for a specified duration while outer loops handle progression timing between chords.
  - Structure: `int chords[][] = [[60, 64, 67], [57, 60, 64], [55, 59, 62], [62, 65, 69]];` (representing C major, F major, G major, A minor).
  - Play syntax includes duration: `play(Note.freq(chords[i][j]), 1::second);`
  - Inter-chord spacing example: `2::second => now;`
[[session/dialog/ultrachat_243337.jsonl#L3-L4]]
[[session/dialog/ultrachat_243337.jsonl#L5-L6]]

## Alternative Music Programming Languages
- **Max/MSP**: Visual programming environment heavily utilized in electronic music production for building modular instruments and effects via virtual patch cables.
- **Pure Data (PD)**: Free, open-source alternative to Max/MSP designed for interactive music and multimedia installations. Features a node-based patching interface.
- **SuperCollider**: specialized language/platform prioritizing real-time audio synthesis and algorithmic composition, widely adopted for experimental music and sound art.
- **Csound**: Legacy software synthesis system (active for over 30 years) using a C-like language to create complex custom sound generators and effects.
- **Swift**: Apple's native programming language increasingly used for developing iOS and macOS music applications.
[[session/dialog/ultrachat_243337.jsonl#L7-L8]]

## Beginner Recommendations for Music Programming
- Recommended starting criteria include low learning curves, accessible documentation, and strong community support.
- **Sonic Pi**: Free, open-source live coding environment featuring simple syntax and real-time audio feedback. Highly recommended as a first step.
- **Python**: General-purpose language with massive community adoption and extensive documentation, frequently applied to music tech development.
- **Max/MSP** and **Pure Data**: Visual alternatives beneficial for those preferring graphical interfaces over traditional text-based coding.
- **ChucK**: Noted as having a simple syntax and robust built-in audio synthesis tools, suitable for dedicated music programming exploration.
[[session/dialog/ultrachat_243337.jsonl#L9-L10]]

## Sonic Pi Onboarding and Resources
- User decision: Selected Sonic Pi as the initial programming environment due to its accessibility.
- **Interface Familiarization**: Explore the live-coding tab structure to understand synchronous code execution and real-time result visualization.
- **Built-in Documentation**: Access instructional content via the "Help" menu dropdown → "Tutorial" for structured syntax lessons.
- **Sample Library**: Reference existing functional code directly through the "Help" menu → "Examples" directory.
- **Community Hubs**: Active engagement occurs on the official Sonic Pi forums, Twitter, and an unofficial Discord server.
- **Live Streaming Education**: The "Sonic Pi Live Stream" series on Twitch offers ongoing practical demonstrations.
- **Local Events**: Music schools and community centers occasionally host hands-on workshops utilizing the platform.
[[session/dialog/ultrachat_243337.jsonl#L11-L12]]
