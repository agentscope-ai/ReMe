---
description: 'On 2023-05-29T20:46:00, a request was processed to draft a formal rejection
  email for an ArcGIS Online (AGOL) Story Map submission. The denial is grounded in
  the 2020 ERH policy prohibiting the publication of live or dynamic AGOL pages within
  the ER environment. The drafted email incorporates five structural elements: explicit
  non-approval notification referencing the specific 2020 regulation, acknowledgment
  of developer effort with an accompanying apology, justification centered on system
  security and data stability requirements, and an open invitation for follow-up discussion
  regarding the administrative decision.'
name: agol-rejection-erh-policy-2020
session_id: sharegpt_6ZpPBwe_0
source_conversation: '[[session/dialog/sharegpt_6ZpPBwe_0.jsonl]]'
---

## Administrative Request & Regulatory Basis [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L1-L1]]

* At 2023-05-29T20:46:00, a directive was received to compose an official correspondence declining approval for an ArcGIS Online (AGOL) Story Map submission.
* The submitted AGOL Story Map conflicts with the ERH policy enacted in 2020, which explicitly mandates that there will be no "live/dynamic" AGOL pages made public in ER.

## Composed Rejection Email Architecture [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L7]]

* The message utilizes the precise subject header: "ArcGIS Online Story Map Submission - Rejection".
* The opening paragraph formally notifies the recipient that the AGOL Story Map will not secure approval due to the documented 2020 ERH regulatory restriction against publishing live or dynamic AGOL interfaces in ER.
* The second paragraph acknowledges substantial developmental effort invested in constructing the Story Map and extends an apology for any operational inconvenience resulting from the non-approval ruling.
* The third paragraph articulates the enforcement rationale, emphasizing that preserving comprehensive system security and data integrity necessitates strict adherence to existing architectural boundaries.
* The closing paragraph prompts the recipient to submit inquiries or reservations and declares readiness to deliberate the administrative determination in subsequent communications.
