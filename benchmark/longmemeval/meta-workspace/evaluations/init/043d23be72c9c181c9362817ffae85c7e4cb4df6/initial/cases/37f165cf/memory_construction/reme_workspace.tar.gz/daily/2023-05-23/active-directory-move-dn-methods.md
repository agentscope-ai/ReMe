---
description: Documentation of methods for moving Organizational Units (OUs) and Distinguished
  Names (DNs) within Windows Active Directory, specifically utilizing the PowerShell
  cmdlet Move-ADObject and the Apache Directory Studio graphical interface.
name: active-directory-move-dn-methods
session_id: sharegpt_wohQ2LX_0
source_conversation: '[[session/dialog/sharegpt_wohQ2LX_0.jsonl]]'
---

# Moving Active Directory Entries (PowerShell and Apache Directory Studio)

## PowerShell Implementation
*   **Primary Cmdlet**: Use `Move-ADObject` to relocate Active Directory objects (e.g., Organizational Units) to different paths within the directory [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
*   **Connection Protocol**: Establish connection to the Active Directory domain by executing:
    ```powershell
    Connect-ADDomain -Server <AD_server_name>
    ```
    [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
*   **Retrieval Strategy**: Utilize `Get-ADObject` with the `-Filter` parameter to isolate specific entries; example retrieval of OUs starting with "Sales":
    ```powershell
    $sourceOUs = Get-ADObject -Filter 'Name -like "Sales*"' -SearchBase '<DN_of_parent_OU>'
    ```
    [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
*   **Execution Command**: Transfer the identified objects using the syntax:
    ```powershell
    Move-ADObject -Identity $sourceOUs -TargetPath '<DN_of_destination_OU>'
    ```
    [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].

## Apache Directory Studio Implementation
*   **Software Definition**: Identify Apache Directory Studio as a free, open-source LDAP browser and directory client utilized for managing and navigating Active Directory [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
*   **Initial Setup**: Launch the application and establish a connection to the target AD server [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
*   **Navigation**: Locate the relevant entries within the "LDAP Browser" view interface [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
*   **Move Action**:
    1.  Right-click the target Organizational Unit or entry and select "Move" from the context menu to open the "Move Entry" dialog [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
    2.  In the dialog box, utilize the "Browse" button to identify and select the destination Organizational Unit [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
    3.  Confirm the operation by clicking "Finish" [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
