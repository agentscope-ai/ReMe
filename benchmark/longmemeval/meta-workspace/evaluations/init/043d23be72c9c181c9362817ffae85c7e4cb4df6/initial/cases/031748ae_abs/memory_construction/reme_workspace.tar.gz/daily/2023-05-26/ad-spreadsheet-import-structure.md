---
description: Iterative design discussion for an Excel schema used by a Bulksheet system
  to manage advertising imports. Covers transitions from a flat structure to a hierarchical
  row-based layout separating Campaigns, Ad Groups, Keywords, and Product Ads. Details
  include handling independent campaign states, specialized fields for book vendors
  (ASIN, SKU, Custom Text), match types (Broad, Exact, Phrase), and incorporating
  an Action column to facilitate simultaneous updates and creation of new objects
  in a single import.
name: ad-spreadsheet-import-structure
session_id: sharegpt_Us1zWGN_19
source_conversation: '[[session/dialog/sharegpt_Us1zWGN_19.jsonl]]'
---

## Advertising Spreadsheet Structure Evolution

### Initial Flat Structure Proposal
Proposes an initial flat Excel file structure where campaign and ad group details repeat across rows representing keywords or product ads. The first column identifies the Object Type (Keyword or Product Ad). Within Product Ad rows, distinct fields handle unique identifiers such as ASIN, SKU, and a Custom Text field reserved for book vendors. [[session/dialog/sharegpt_Us1zWGN_19.jsonl#L1-L1]]

### Incorporating Independent Campaign State
Recognizes that campaign states allow independent modification relative to the contained ad groups and keywords. Introduces a dedicated "Campaign State" column into the spreadsheet schema to accommodate these independent updates. [[session/dialog/sharegpt_Us1zWGN_19.jsonl#L2-L3]]

### Transition to Hierarchical Row-Based Format
Adopts the recommendation to separate distinct entities—Campaigns, Ad Groups, Keywords, and Product Ads—into individual rows instead of repeating parent details. This hierarchical layout propagates parent IDs downward through the document:
- Dedicated Campaign rows establish top-level parameters including ID, Name, State, and Budget.
- Ad Group rows link to the Campaign ID and specify unique attributes such as Default Bid.
- Keyword and Product Ad rows attach to the corresponding Ad Group ID, holding granular data like Keyword text, Match Type (Broad, Exact, Phrase), ASIN, and SKU. [[session/dialog/sharegpt_Us1zWGN_19.jsonl#L4-L7]]

### Optimizing for Mixed Operations (Updates vs. New Imports)
Addresses a specific use case requiring customers to update existing campaigns alongside creating entirely new campaigns within a singular import event. Adds an explicit "Action" column to the schema to define the required operation (e.g., "Create" or "Update"). The Bulksheet system utilizes this column to verify whether the import should generate new objects based on provided IDs or modify existing records. [[session/dialog/sharegpt_Us1zWGN_19.jsonl#L8-L9]]
