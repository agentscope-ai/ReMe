---
description: Reference materials on the Student's t-distribution including its mathematical
  properties (used for small samples or unknown population standard deviation, bell-shaped
  with heavier tails than normal distribution), applications in hypothesis testing
  and confidence intervals, convergence behavior toward the normal distribution as
  degrees of freedom increase, and a comprehensive critical values table mapping Degrees
  of Freedom (1 through 500 and infinity) to various percentiles and alpha levels
  (one-sided and two-sided).
name: t-distribution-reference
session_id: sharegpt_0UggBZu_32
source_conversation: '[[session/dialog/sharegpt_0UggBZu_32.jsonl]]'
---

## T-Distribution Overview

### Properties and Definition
- The $t$ distribution is a probability distribution used to make inferences about the population mean when sample size is small and/or population standard deviation is unknown [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- The $t$ distribution is bell-shaped, similar to the standard normal distribution, but has heavier tails [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- The shape of the $t$ distribution depends on the degrees of freedom, which equals sample size minus one [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- The $t$ distribution is symmetric about the mean, with a mean of 0 and a standard deviation of 1 for the standard $t$ distribution [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- As degrees of freedom increase, the $t$ distribution approaches the standard normal distribution [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].

### Statistical Applications
- In hypothesis testing, a $t$-test calculates a test statistic to determine whether the sample mean is significantly different from a known or hypothesized population mean; the test statistic is compared to critical values from the $t$ distribution to determine the p-value and make a decision about the null hypothesis [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].
- In confidence interval estimation, the $t$ distribution is used to calculate the width of the confidence interval, which depends on sample size, sample mean, and sample standard deviation [[session/dialog/sharegpt_0UggBZu_32.jsonl#L2-L2]].

### Critical Values Table Structure
- Table 1 contains critical values (percentiles) for the $t$ distribution, where column headed DF gives degrees of freedom for values in that row [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]].
- Three types of percentile columns are provided:
  - **Percent**: Represents $100 \times$ cumulative distribution function, where the table entry is the corresponding percentile [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]].
  - **One-sided $\alpha$**: The significance level for the one-sided upper critical value, where the table entry is the critical value [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]].
  - **Two-sided $\alpha$**: The two-sided significance level, where the table entry is the corresponding two-sided critical value [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]].
- Column categories include:
  - Percent values: 75, 90, 95, 97.5, 99, 99.5, 99.75, 99.9, 99.95, 99.975, 99.99, 99.995
  - One-sided $\alpha$ values: .25, .10, .05, .025, .01, .005, .0025, .001, .0005, .00025, .0001, .00005
  - Two-sided $\alpha$ values: .50, .20, .10, .05, .02, .01, .005, .002, .001, .0005, .0002, .0001
- Degrees of freedom in the table range from 1 to 100, with additional entries for 200, 500, and $\infty$ [[session/dialog/sharegpt_0UggBZu_32.jsonl#L1-L1]]
