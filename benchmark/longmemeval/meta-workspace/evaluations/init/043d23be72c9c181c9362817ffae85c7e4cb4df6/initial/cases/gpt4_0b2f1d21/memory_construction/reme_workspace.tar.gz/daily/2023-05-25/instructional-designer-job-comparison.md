---
description: Systematic extraction of a 56-item Instructional Designer skills checklist
  compared against a specific Ivy League university job posting for a hybrid 6-month
  contract role in Boston. Includes complete job description responsibilities, required
  qualifications, exact matching findings (items 1, 2, 3, 8, 12, 47) with supporting
  verbatim quotes, and a definitive list of non-matching skills from the baseline
  checklist.
name: instructional-designer-job-comparison
session_id: sharegpt_XYtuANl_9
source_conversation: '[[session/dialog/sharegpt_XYtuANl_9.jsonl]]'
---

## Instructional Designer Job Description Analysis

### Goal, Methodology, and Inputs
- **Objective**: Compare a master list of 56 desired skills, knowledge areas, and qualifications for an Instructional Designer against a specific job description sourced from LinkedIn Jobs.
- **Output Requirement**: Generate a report indicating match status for each list item. Matched items must include the list item number, a "MATCH" indicator, and exact quotes verifying the match. Unmatched items are excluded from the detailed match list.
- **Methodology**: Direct comparison of the requested skill list with the provided job description text.
- **Target Job Description**: Sourced from a prestigious Ivy League university hiring for a hybrid Instructional Designer role in Boston, Massachusetts. Local candidates are required. The position is a 6-month initial contract with extension or conversion opportunities. Core duties involve collaborating with faculty or business subject matter experts to design, create, and deliver online, blended, and instructor-led classroom courses using instructional design and adult learning theories. Additional duties include conducting learning and business needs analysis, drafting expected learning outcomes aligned with course goals, determining content scope and sequence, identifying impacted audiences and prerequisites, designing and implementing course evaluation plans, devising assessment modes to measure course effectiveness, writing copy and instructional materials, producing multi-format media (print, graphics, audio, video), utilizing e-learning authoring tools to upload content to websites or learning management systems (LMS), developing train-the-trainer programs, delivering in-person instruction, and training others on instructional technologies. Requirements specify a Master's degree or formal training/certification in Instructional Design (preferred), 3–5 years professional experience in Instructional Design or Development, demonstrated proficiency in Adobe Captivate, Articulate Storyline, and Camtasia, working knowledge of HTML, and strong communication skills.
- **Baseline Checklist**: A 56-item list served as the comparison baseline, encompassing topics such as instructional design models (ADDIE, Dick and Carey), adult learning theory, organizational development, gamification, blended learning techniques, agile methodology (Scrum), e-learning standards (SCORM), copyright laws, accessibility software (JAWS), Six Sigma, and twenty-first-century skills frameworks (P21). [[session/dialog/sharegpt_XYtuANl_9.jsonl#L2-L2]]

### Comparison Results and Findings
- **Exact Matches**: Six specific items from the baseline checklist directly matched explicit language in the job description:
  - **Instructional design models & principles (Item 1)**: MATCH. Quote: "using principles and practices of instructional design"
  - **Adult learning theory (Item 2)**: MATCH. Quote: "and adult learning theory."
  - **Needs analysis (Item 3)**: MATCH. Quote: "Conduct learning and business needs analysis"
  - **Course evaluation (Item 8)**: MATCH. Quote: "Devise modes of assessment to measure the effectiveness of the course"
  - **Instructional copy and media scripts (Item 12)**: MATCH. Quote: "Write effective copy, instructional materials, and audio/video scrips to help participants meet learning objectives"
  - **Web and e-learning authoring tools (Item 47)**: MATCH. Quote: "Use e-learning authoring tools to upload instructional content to websites, e-learning platforms, or learning management systems"
- **Non-Matching Areas**: List Items 4, 5, 6, 7, 9 through 11, 13 through 16, 18 through 22, 25 through 26, 28 through 29, 31 through 36, 38 through 41, 44 through 50, 52 through 54, and 56 were explicitly noted as absent from the target job description.
- **Referenced Technologies**: Adobe Captivate, Articulate Storyline, Camtasia, HTML, general e-learning platforms, and multimedia formats. [[session/dialog/sharegpt_XYtuANl_9.jsonl#L3-L3]]
