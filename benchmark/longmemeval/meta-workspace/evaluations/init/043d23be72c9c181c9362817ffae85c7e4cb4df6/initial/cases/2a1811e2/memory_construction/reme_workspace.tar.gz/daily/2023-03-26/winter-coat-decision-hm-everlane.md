---
description: User sought recommendations for a high-quality winter coat to serve as
  a long-term investment. After evaluating multiple brands (Canada Goose, The North
  Face, Patagonia, Uniqlo, etc.) regarding materials, insulation types, sustainability,
  and discount strategies, the user selected The North Face Thermoball Parka (~$170)
  for its balance of features and price. The session also documents recent wardrobe
  acquisitions, including $39.99 H&M distressed jeans, H&M graphic tees, and a frequently-worn
  Everlane cashmere blend cardigan.
name: winter-coat-decision-hm-everlane
session_id: cfd21744_1
source_conversation: '[[session/dialog/cfd21744_1.jsonl]]'
---

# Winter Coat Search & Wardrobe Updates

## Wardrobe Purchases & Clothing Preferences
- **H&M Distressed Denim Jeans**: Acquired approximately three weeks prior to 2023-03-26 for $39.99. Highly valued for comfort and versatility, already worn at least five times. `[[session/dialog/cfd21744_1.jsonl#L1-L1,L9-L9]]`
- **H&M Graphic T-Shirts**: Purchased concurrently with the jeans; utilized as base layers under cardigans for casual styling. `[[session/dialog/cfd21744_1.jsonl#L3-L3]]`
- **Everlane Cashmere Blend Cardigan**: Currently a primary work garment, noted for receiving frequent compliments. `[[session/dialog/cfd21744_1.jsonl#L5-L5]]`

## Winter Coat Evaluation & Purchase Decision
- **Investment Objective**: Actively seeking a premium winter coat designed for exceptional durability and longevity, indicating a strong willingness to allocate significant funds for high-end construction. `[[session/dialog/cfd21744_1.jsonl#L3-L3]]`
- **Primary Brand Analysis**: Compared Canada Goose and The North Face extensively. Canada Goose offered extreme Arctic-grade performance, premium down insulation, classic utilitarian styling, and a projected 10–15 year lifespan, commanding prices between $500 and $1,500+. The North Face provided broader outdoor versatility, modern aesthetics, advanced synthetic Thermoball insulation alternatives to down, and a flexible price range starting around $100 up to $800+. `[[session/dialog/cfd21744_1.jsonl#L4-L6]]`
- **Secondary Models Examined**: Evaluated alternative parka and jacket models including Patagonia Tres 3-in-1 Parka (~$230), Uniqlo HEATTECH Parka (~$70), Old Navy puffer coats (~$40), Zara puffer coats (~$100), Columbia OutDry Ex Gold Insulated Jacket (~$130), Marmot Precip Eco Jacket (~$100), Burberry The Kensington Trench Coat (~$1,000), and J.Crew Trench Coat (~$200). `[[session/dialog/cfd21744_1.jsonl#L2-L2]]`
- **Cost-Saving Strategies**: Researched mechanisms to acquire Canada Goose products at reduced costs, identifying end-of-season clearances (up to 30% off), authorized retail partner promotions, last-season inventory clearance, certified pre-owned options, and seasonal discount events like Black Friday and Cyber Monday. `[[session/dialog/cfd21744_1.jsonl#L7-L8]]`
- **Acquisition Commitment**: Finalized decision to purchase The North Face Thermoball Parka (approximately $170). Selection driven by the combination of reliable DryVent water-resistant breathable fabric, effective Thermoball insulation, customizable fit adjustments, and an accessible price point. Acknowledged that The North Face sizing runs slightly small, requiring careful measurement verification before checkout. `[[session/dialog/cfd21744_1.jsonl#L10-L12]]`
