---
description: Planning a Lake Michigan fishing trip including recommended fishing spots,
  boat launch facilities suitable for larger vessels, statewide largemouth bass regulations
  and tackle recommendations, bowfishing rules for carp control, and kid-friendly
  fishing gear advice for a friend's 10-year-old son.
name: lake-michigan-fishing-trip-planning
session_id: 1fe34a92
source_conversation: '[[session/dialog/1fe34a92.jsonl]]'
---

# Lake Michigan Fishing Trip Planning and Locations

Planning a fishing trip to Lake Michigan to try out a different spot from previous visits [[session/dialog/1fe34a92.jsonl#L1-L2]].

* **Top Fishing Spot Recommendations on Lake Michigan:**
	+ St. Joseph, Michigan (southwest shore): Abundance of salmon and trout near the St. Joseph River flow.
	+ Grand Haven, Michigan (west coast): Famous for pier fishing (salmon, trout, walleye).
	+ Chicago, Illinois: Navy Pier and Chicago River offer coho salmon, chinook salmon, and smallmouth bass.
	+ Milwaukee, Wisconsin: Harbor and Milwaukee River provide coho salmon, chinook salmon, and brown trout.
	+ Door County, Wisconsin (northeast shore): Peninsula State Park and Sturgeon Bay Canal target smallmouth bass, walleye, and northern pike.
	+ Indiana Dunes National Park, Indiana: East Chicago Marina and Indiana Dunes State Park pier hold coho salmon, chinook salmon, and smallmouth bass.
	+ Saugatuck, Michigan (west coast): Salmon, trout, and walleye are abundant.
	+ Manistee, Michigan: Manistee River attracts salmon, trout, and steelhead.
	+ Kenosha, Wisconsin: Kenosha Harbor and Kenosha Sand Dunes yield coho salmon, chinook salmon, and smallmouth bass.
	+ Michigan City, Indiana: Michigan City Pier and Trail Creek area produce coho salmon, chinook salmon, and smallmouth bass.
* **Pre-Trip Preparation:** Check local regulations, obtain licenses/permits, familiarize with seasons and bag limits, consider hiring a local guide or charter service, and practice safe/responsible fishing practices. Check weather forecasts as the lake is unpredictable.

# Boat Launch Facilities for Larger Boats

Seeking locations with boat launches and parking suitable for accommodating a larger boat [[session/dialog/1fe34a92.jsonl#L3-L4]].

* **Michigan:**
	+ St. Joseph Public Boat Launch: Large parking lot, accommodates boats up to 30 feet.
	+ St. Joseph Marina: Launch ramp, large boat parking, transient docking.
	+ Grand Haven State Park Boat Launch: Large parking lot, accommodates boats up to 26 feet.
	+ Grand Haven Municipal Marina: Launch ramp, large boat parking, transient docking.
	+ Saugatuck Township Boat Launch: Large parking lot, accommodates boats up to 26 feet.
	+ Manistee County Marina: Launch ramp, large boat parking, transient docking.
	+ Manistee Municipal Marina: Launch ramp, large boat parking, transient docking.
* **Wisconsin:**
	+ Milwaukee Harbor Boat Launch: Large parking lot, accommodates boats up to 30 feet.
	+ McKinley Marina: Launch ramp, large boat parking, transient docking.
	+ Sturgeon Bay Yacht Club Marina: Accommodates larger boats in the Sturgeon Bay Canal.
	+ Kenosha Marina: Launch ramp, large boat parking, transient docking.
	+ Simmons Island Marina: Launch ramp, large boat parking, transient docking.
* **Illinois:**
	+ Navy Pier Boat Launch: Limited parking, best suited for smaller boats. Private marinas like Chicago Marina City Marina or Belmont Harbor Marina accommodate larger boats.
* **Indiana:**
	+ East Chicago Marina: Launch ramp, large boat parking, transient docking.
	+ Indiana Dunes State Park Boat Launch: Large parking lot, accommodates boats up to 26 feet.
	+ Michigan City Marina: Launch ramp, large boat parking, transient docking.
	+ Washington Park Marina: Launch ramp, large boat parking, transient docking.

# Largemouth Bass Regulations and Tackle

Inquiry regarding largemouth bass regulations and effective baits/lures on Lake Michigan [[session/dialog/1fe34a92.jsonl#L5-L6]].

* **Regulations by State:**
	+ **Michigan:** Minimum size limit is 14 inches; daily possession limit is 5 bass (only 1 can be over 24 inches); open season is year-round but catch-and-immediate-release is required from May 15 to June 15.
	+ **Wisconsin:** Minimum size limit is 14 inches; daily possession limit is 5 bass (only 1 can be over 24 inches); open season is May 4 to March 3, but catch-and-immediate-release is required from May 4 to June 15.
	+ **Illinois:** Minimum size limit is 15 inches; daily possession limit is 6 bass; open season is April 1 to February 28, but catch-and-immediate-release is required from April 1 to June 15.
	+ **Indiana:** Minimum size limit is 14 inches; daily possession limit is 5 bass; open season is April 1 to December 31, but catch-and-immediate-release is required from April 1 to June 15.
* **Effective Baits and Lures:** Soft plastics (curly tail grubs, plastic worms, lizards in green pumpkin, watermelon, chartreuse); shad-shaped crankbaits (silver, gold, chrome); jigs (1/8 to 1/2 oz with curly tail/swim bait trailer in white, chartreuse, yellow); spinnerbaits (white, chartreuse, yellow with slow to medium retrieve); topwater baits (frogs, poppers, spoons); live bait (worms, minnows, leeches suspended under a bobber or on bottom).
* **Tips and Techniques:** Focus on submerged structures (rocks, weed beds, drop-offs); water temperature between 65°F and 85°F increases activity; fish near shore during spawn; use medium to heavy action rods and reels with 10-15 lb test line; adaptability to nomadic fish behavior requires moving to different locations.

# Bowfishing Regulations and Locations

Exploration of bowfishing as an alternative fishing method on Lake Michigan [[session/dialog/1fe34a92.jsonl#L7-L8]].

* **Bowfishing Regulations (Carp Only):** All four bordering states permit bowfishing strictly for carp in specific areas/times. Michigan requires a free Carp/Suckers Bowfishing Permit. Wisconsin requires a fishing license and a free Carp Control Permit. Illinois requires a fishing license and a free Asian Carp Bowfishing Permit. Indiana requires a fishing license and a free Asian Carp Bowfishing Permit.
* **Recommended Spots:** Saginaw Bay (large carp population); southern end of Green Bay; Chicago River. Generally, shallow waters with abundant vegetation near marinas, bays, or river mouths are ideal along the Lake Michigan shorelines.
* **Safety and Ethics:** Wear life jackets, maintain equipment, avoid damaging aquatic vegetation, target invasive carp to aid ecosystem health, harvest only intended fish, and respect other anglers.

# Kid-Friendly Fishing Gear Recommendations

Acquiring gear for a friend's 10-year-old child for a future larger fishing trip on Lake Michigan or similar locations [[session/dialog/1fe34a92.jsonl#L9-L12]].

* **Rod and Reel Combos:** Spinning or youth-sized rods (4-5 feet long, lightweight) paired with reels featuring easy drag systems. Recommended models include the Zebco 33 Classic Spincast Combo, Zebco Lil' Angler Spincast Combo, Shimano Youth Spinning Combo, Shimano Catana Youth Spinning Combo, and Penn Battle II Spinning Combo. Zebco models are more affordable ($20-$30) with push-button casting and simple drags. Shimano models cost slightly more ($40-$50) and feature durable graphite/fiberglass construction with smooth drags. A spincast reel is highly recommended for beginners to prevent tangles, whereas spinning reels suit experienced kids.
* **Essential Accessories:** 10-15 lb test weight monofilament or fluorocarbon line; simple lures (spinners, spoons, soft plastics) or live bait (worms, minnows); size 2 to 6 hooks; pliers or forceps for hook removal; collapsible fishing net; kid-friendly fishing vest or bag for organization.
* **Selection and Usage Tips:** Prioritize durability against rough handling; ensure gear matches the child's size and strength; keep complexity low; allow the child to help pick out gear to build excitement and ownership; always supervise and teach young anglers about safety, etiquette, and responsible practices.
