---
description: 'Comprehensive technical guide documenting film development workflows
  and darkroom techniques for a user''s 1960s Rolleiflex TLR acquired from a local
  antique shop. Covers foundational resources including The Darkroom Handbook by Steve
  Anchell, video channels (The Darkroom, Film Dev, Analog Insights), online communities
  (Reddit r/Darkroom, r/AnalogPhotography), course platforms (Udemy, Skillshare, CreativeLive),
  and tracking apps (Darkroom Timer, FilmDev). Details equipment requirements: darkroom
  spaces or portable tents, developing tanks with reels, thermometers, measuring cups,
  and chemical supplies (developer, stop bath, fixer, wash solution). Explains the
  basic workflow of loading film in darkness, mixing chemicals per manufacturer instructions,
  washing and drying. Provides advanced exposure modification techniques: push processing
  increases development time by 10-20% for underexposure creating higher contrast
  more grain and cooler bluer tones; pull processing decreases development time by
  10-20% for overexposure producing reduced contrast less grain and maintained color
  accuracy. Documents detailed film stock profiles with ISO ratings and response characteristics:
  Kodak Tri-X 400 (high contrast, responds well to push, becomes too contrasty when
  pulled), Ilford HP5 Plus 400 (versatile medium contrast fine grain, beginner-friendly,
  responds well to both push and pull), Fuji Acros 100 (low contrast extremely fine
  grain, ideal for landscapes/portraits, less forgiving when pushed/pulled), Kodak
  Portra 400 (medium contrast smooth natural tone, good for portraits, responds well
  to pull but can become too contrasty when pushed), Agfa APX 400 (budget high contrast
  distinct grain, beginner-friendly, responds well to push but prone to overdevelopment),
  Kodak Gold 200 (budget medium contrast fine grain, general photography), Fuji Superia
  400 (medium contrast fine grain, modern commercial look). Addresses portrait-specific
  considerations: warm-toned films (Kodak Portra 400, Fuji Pro 400H, Agfa Vista 200)
  versus neutral-toned films (Ilford Pan 100, Kodak T-Max 100); ISO selection comparing
  higher ISO 800-1600 for low light flexibility faster shutter speeds shallower depth
  of field against lower ISO 100-400 for shadow detail preservation traditional aesthetic.
  Recommends developers matched to film types: D-76 (classic general-purpose for Portra/Tri-X/T-Max),
  HC-110 (simple forgiving developer), Ilford ID-11 (versatile consistent for HP5
  Plus/Pan 100), Fujifilm Neofine (high-end for Fuji Pro 400H/Acros 100), Rodinal
  (specialty high-contrast for APX 400). Emphasizes best practices: starting black
  and white before color, keeping accurate records of times/temperatures/concentrations,
  experimenting with small increments, scanning results for refinement, practicing
  patience throughout learning process.'
name: film-development-darkroom-techniques
session_id: 708e39b6_1
source_conversation: '[[session/dialog/708e39b6_1.jsonl]]'
---

## Equipment Acquisition and Learning Objectives [[session/dialog/708e39b6_1.jsonl#L1-L1]]
- User owns a vintage 1960s Rolleiflex Twin Lens Reflex (TLR) camera purchased from a local antique shop that functions properly
- Primary goal involves acquiring knowledge regarding analog film development workflows and darkroom printing operations

## Educational Resources and Community Platforms [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Authoritative reference material identified as *The Darkroom Handbook* authored by Steve Anchell containing comprehensive coverage of fundamental procedures and techniques
- Video tutorial sources comprise YouTube channels designated The Darkroom, Film Dev, and Analog Insights providing educational content on processes plus equipment evaluations
- Digital community forums exist within Reddit platform hosting subcommunities labeled r/Darkroom and r/AnalogPhotography enabling peer-to-peer knowledge exchange and question answering
- Structured course delivery platforms include Udemy, Skillshare, and CreativeLive websites offering organized curricula covering film development through paid enrollment programs
- Software applications assisting tracking include Darkroom Timer calculating precise intervals and FilmDev application managing experimental documentation parameters

## Physical Infrastructure Requirements [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Darkroom preparation necessitates establishing completely light-tight environments achievable through residential closet conversions room renovations or utilizing commercially available portable darkroom tents providing immediate temporary privacy solutions
- Essential mechanical apparatus encompasses stainless steel developing tanks containing plastic reels designed safely winding exposed light-sensitive media avoiding accidental photon contamination during processing stages
- Measurement instruments require calibrated digital or mercury thermometers monitoring solution temperatures accurately alongside graduated measuring cups dispensing exact chemical volumes precisely maintaining consistency across batches
- Chemical inventory mandates obtaining four primary agent types functioning sequentially throughout workflow: active developing solution reducing exposed silver halide crystals to visible metallic silver, neutralizing stop bath arresting reactions, stabilizing fixer compound removing unexposed crystals, final rinse washing fluid cleaning residual chemicals preventing degradation

## Basic Development Workflow Procedures [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Loading procedure requires transferring exposed film strip onto plastic reel inside complete darkness ensuring no ambient light contamination occurs during transfer operations
- Processing sequence demands preparing chemical solutions according to manufacturer specifications mixing correct dilution ratios maintaining optimal temperature ranges typically around 20 degrees Celsius standard recommendation
- Chemical immersion involves submerging loaded reel within developing tank sequentially introducing developer stop bath fixer each solution for prescribed duration intervals specified by guidelines
- Final steps encompass thorough water rinsing eliminating trace chemical remnants followed hanging film securely in dust-free environment allowing natural air drying without water spots contamination damage

## Beginner Recommendations and Operational Best Practices [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Starter approach suggests beginning black and white film varieties rather than color negative or reversal films due to simpler chemistry requirements reduced financial investment lower tolerance thresholds minimizing initial failure consequences
- Initial developer selections recommend straightforward formulations like Kodak D-76 or Ilford HC-110 providing reliable consistent results tolerating minor procedural variations gracefully suitable novice operators learning fundamentals
- Documentation protocols require maintaining detailed logs recording every variable including film stock identity development time elapsed temperature maintained chemical dilution ratio concentration percentage batch identification enabling pattern recognition troubleshooting analysis continuous improvement progression
- Experimentation mindset encourages testing various developers techniques printing methods finding optimal personal workflow preferences balancing artistic vision with technical capability limitations accepting mistakes as learning opportunities rather than failures
- Safety compliance necessitates wearing protective gloves reading Material Safety Data Sheets handling all chemical agents using proper ventilation disposing waste materials according local environmental regulations protecting personal health

## Push and Pull Processing Techniques [[session/dialog/708e39b6_1.jsonl#L4-L4]]
Push processing modifies development parameters intentionally compensating insufficient photon exposure occurring when filming at lower ASA rating than nominal emulsion speed or achieving specific aesthetic intentions increasing overall developed image contrast intensifying visible grain structure producing cooler bluer color cast shifts altering original tonal reproduction characteristics faithfully captured scene [[session/dialog/708e39b6_1.jsonl#L4-L4]].

Practical push implementation involves rating standard 400 ASA film材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材材
