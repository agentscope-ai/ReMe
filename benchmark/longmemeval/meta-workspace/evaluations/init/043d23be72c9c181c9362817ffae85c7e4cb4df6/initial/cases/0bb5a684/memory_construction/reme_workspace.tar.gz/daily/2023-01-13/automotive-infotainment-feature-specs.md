---
description: 'Feature specifications and design advice for four automotive topics:
  1. Cockpit Displays (TFT vs OLED trade-offs, 12.3"/7" layouts, ASIL-B safety, DMS
  integration); 2. Camera Monitoring Systems (heated lenses, aerodynamic drag reduction,
  blind-spot elimination logic); 3. Smartphone Mirroring (wireless protocols like
  Apple CarPlay/Android Auto, resolution requirements); 4. Voice Control Systems (noise-cancelled
  recognition, Siri/Google integration, safety overrides). Includes comparative benefits
  and functional needs for each subsystem.'
name: automotive-infotainment-feature-specs
session_id: sharegpt_AzkYB5s_0
source_conversation: '[[session/dialog/sharegpt_AzkYB5s_0.jsonl]]'
---

## Automotive Cockpit Displays [[session/dialog/sharegpt_AzkYB5s_0.jsonl#L3-L4]]
### Feature Description & Technology
- The cockpit utilizes touch and non-touch screens surrounding the driver and passengers.
- Screens support conventional functions (Driver Information, Infotainment, HVAC controls) and new E-Mirror technologies (video feeds from exterior cameras rendered on interior displays).
- **Digital Rear View Mirror (DRVM):** Replaces the physical interior windshield mirror; its feed shares space with the Driver Information Display.
- **Camera Monitoring System (CMS):** Replaces exterior door mirrors; video renders on side displays near the Cluster.
- **Technology Comparison:**
    - **TFT (Proposed):** Benefit is access to multiple off-the-shelf components from various suppliers. Con is being perceived as "old technology" by the 2025+ sales timeframe.
    - **OLED (Alternative):** Benefit is brilliant color reproduction, crisp graphics, and ability to achieve non-conventional shapes/curvatures. Con is high expense and lack of mainstream adoption in the automotive industry.
- **Hardware Specifications:**
    - Two physical display sizes used: **12.3"** (for Cluster, Center, Co-Driver packages) and **7"** (for CMS and Rear Occupant packages).
    - Orientation: All displays are landscape except the center stack screen, which is portrait.
- **Safety & Compliance:**
    - The Driver Information Display reserves UI space for the DRVM. Both the main system and CMS require **ASIL-B** compliance ratings.
    - Behind the glass packaging: Integration of the **Driver Monitoring System**, including a camera and infrared LEDs.
- **Passenger Interfaces:**
    - Front row: Embedded touch displays. Second row: Optional portable after-market devices (tablets) dockable into front seat backs for IVI connection.
    - Standard rear interface is limited to HVAC controls via a center-mounted touch display.
- **Co-Diver Experience:** Higher specification vehicles add two additional displays adjacent to the Co-Driver Display, mirroring the driver's setup.

### Advice Summary
- Weigh TFT versus OLED based on cost and projected consumer perception for 2025+. Ensure strict adherence to the required ASIL-B safety ratings and specific landscape/portrait orientations. Develop detailed GUIs that parallel hardware development.

## Camera Monitoring System (E-Mirrors) [[session/dialog/sharegpt_AzkYB5s_0.jsonl#L5-L6]]
### Feature Description & Benefits
- Cameras mount on the door or A-pillar similar to traditional mirrors, streaming live video inside the car.
- **Weather Resistance:** Lens covers can be designed to heat up to prevent blockage from rain or frost.
- **Aerodynamics:** Smaller size than traditional mirrors reduces aerodynamic drag.
- **Visibility:** Provides a wider angle of view than standard mirrors.

### Functional Needs
- **Blind Spot Management:** When turn indicators are active or reverse gear is selected, the display automatically switches to an extended view alongside/behind the car to eliminate blind spots; reverts to standard when action completes.
- **Adjustments:** Accessible via touchscreen, interactive controls, or traditional buttons; settings include brightness, sensitivity, and imaging adjustments.
- **Alerts:** Displays warnings if the system identifies vehicles in the blind spot.
- **Guidance Lines:**
    - **Parking:** Lines indicate distances from the rear bumper and sides.
    - **Highway:** Reference lines help judge safe distances from other traffic.
- **View Modes:** Users can switch manually or automatically between normal and wide-angle views.

## Smartphone Mirroring [[session/dialog/sharegpt_AzkYB5s_0.jsonl#L7-L10]]
### Feature Description
- Connects smartphones to the car's infotainment system, mirroring the phone screen onto the car display. Allows control of apps, music, and navigation directly from the car screen.
- **Tech:** Wireless connectivity (Bluetooth, Wi-Fi Direct, Apple CarPlay, Android Auto).
- **Pros:** Easy to use, no physical cable needed, multi-device compatibility.
- **Con:** Dependent on phone battery life; potential connectivity issues.
- **Functional Needs:** Clear full-resolution display, direct control capability, stable secure connection, broad brand compatibility, adjustable display settings (brightness/orientation), intuitive interface.

## Voice Control System [[session/dialog/sharegpt_AzkYB5s_0.jsonl#L11-L12]]
### Feature Description
- Controls vehicle functions (entertainment, navi, climate) using voice commands without physical interaction.
- **Integration:** Works with personal assistants like Siri or Google Assistant.
- **Functional Needs:** Recognizes wide ranges of commands, integrates with other systems (climate, nav), allows custom commands, accurate even in noise, connects to phones, includes safety features to prevent unintended commands, provides visual/auditory feedback.
