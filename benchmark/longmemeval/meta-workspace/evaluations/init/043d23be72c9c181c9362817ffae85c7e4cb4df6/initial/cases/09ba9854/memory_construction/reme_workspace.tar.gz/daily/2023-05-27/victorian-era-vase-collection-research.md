---
description: Research notes recording an inherited grandmother's antique vase collection
  inquiry on 2023-05-27. Details include identification methods (marks, materials,
  condition), valuation resources (auction houses, museums, online markets), and a
  comprehensive deep-dive into five key Victorian-era ceramic manufacturers (Worcester,
  Doulton, Minton, Spode, Derby). Specifically documents Worcester Royal Porcelain's
  design evolution across seven major movements (Japanese, Aesthetic, Renaissance,
  Moorcroft, Pomegranate, Gilt, Enameled), its chemical celadon glaze formulation
  involving cobalt oxide and feldspathic mixtures fired at 1200°C, the mechanics of
  intentional thermal shock crackling, artisan training hierarchies sourcing talent
  from France/Germany/Italy, and global export networks operating through treaty ports
  in China and North American trade routes via exhibitions like the 1851 Great Exhibition.
name: victorian-era-vase-collection-research
session_id: d99bab55_1
source_conversation: '[[session/dialog/d99bab55_1.jsonl]]'
---

### User Context & Antique Vase Collection Research
On 2023-05-27, the user requested information regarding their grandmother's inherited antique vase collection to understand the history and provenance of the pieces. The target historical period is defined as the Victorian era, spanning from 1837 to 1901, noted for significant creativity and innovation in the ceramics industry.
[[session/dialog/d99bab55_1.jsonl#L1-L2]]

### Major Victorian-Era Ceramic Manufacturers
To aid in identifying pieces, several prominent English ceramic firms active during the Victorian era were documented:
*   **Worcester Royal Porcelain (Established 1751):** One of England's oldest porcelain manufacturers, famous during the Victorian era for high-quality, ornate vases featuring intricate designs and patterns [[session/dialog/d99bab55_1.jsonl#L2]].
*   **Royal Doulton (Founded 1815):** Known for beautifully decorated vases often highlighting figurative and floral designs [[session/dialog/d99bab55_1.jsonl#L2]].
*   **Minton (Established 1793):** A Stoke-on-Trent, England manufacturer known for producing a wide range of ornate, highly decorated pieces with complex patterns and figurative elements [[session/dialog/d99bab55_1.jsonl#L2]].
*   **Spode (Founded 1767):** Renowned for high-quality vases utilizing a distinctive blue-and-white underglaze printing technique [[session/dialog/d99bab55_1.jsonl#L2]].
*   **Derby Porcelain (Established 1750):** Another historic manufacturer producing diverse ornate decorative pieces characterized by floral and figurative motifs [[session/dialog/d99bab55_1.jsonl#L2]].

### Identification & Appraisal Methodologies
Effective cataloging of antique ceramics requires specific investigative steps and utilization of external resources:
*   **Physical Inspection:** Examine bases and undersides for maker's marks, signatures, or stamps to verify manufacturer origin and production dates. Assess materials (porcelain, earthenware, ceramic), design motifs (geometric, florals, figurative scenes), and physical condition including signs of aging or prior restoration [[session/dialog/d99bab55_1.jsonl#L2]].
*   **Research Resources:** Utilize online marketplaces (eBay, Etsy, Ruby Lane), auction house archives (Christie's, Sotheby's, Bonhams), and museum collections such as the Victoria and Albert Museum in London or the Metropolitan Museum of Art in New York. Join collector's forums and reference published ceramics literature [[session/dialog/d99bab55_1.jsonl#L2]].
*   **Valuation:** Engage professional appraisers for written assessments and documentation while maintaining a dedicated archive of photographs and gathered data for each piece [[session/dialog/d99bab55_1.jsonl#L2]].

### Worcester Royal Porcelain: Detailed History & Design Evolution
Detailed research was conducted specifically on Worcester Royal Porcelain artifacts found within the collection [[session/dialog/d99bab55_1.jsonl#L3-L4]]:

**Iconic Design Movements:**
1.  **Japanese Inspiration (1860s-1880s):** Featured hand-painted natural motifs—such as cherry blossoms, chrysanthemums, and birds—frequently utilizing distinctive pale blue or celadon glazes [[session/dialog/d99bab55_1.jsonl#L4]].
2.  **Aesthetic Movement (1870s-1890s):** Characterized by sinuous, curvilinear lines emphasizing botanical motifs like leaves, branches, and flowers executed in mauve, sage green, and terracotta colors [[session/dialog/d99bab55_1.jsonl#L4]].
3.  **Renaissance Revival (1850s-1880s):** Drawn from Italian art and architecture, displaying ornate scrolling acanthus leaves, classical motifs, and elaborate borders [[session/dialog/d99bab55_1.jsonl#L4]].
4.  **Moorcroft-style (1880s-1900s):** Heavily influenced by artist William Moorcroft, showcasing intricate hand-painting in blue, green, and yellow tones, frequently employing a distinct "flambe" glaze [[session/dialog/d99bab55_1.jsonl#L4]].
5.  **Pomegranate and Floral Patterns (1860s-1890s):** Centered around raised, three-dimensional pomegranates and floral arrangements set against white or cream backgrounds [[session/dialog/d99bab55_1.jsonl#L4]].
6.  **Gilt and Enamel Decoration (1850s-1900s):** Utilized gold and enamel paints applied intricately onto white or cream grounds for a luxurious aesthetic effect [[session/dialog/d99bab55_1.jsonl#L4]].
7.  **Enameled Vases (1860s-1890s):** Employed advanced enameling techniques including cloisonné, champlevé, and plique-à-jour to render vibrant natural scenes featuring insects, birds, and flora [[session/dialog/d99bab55_1.jsonl#L4]].

**Key Artistic Personnel:**
*   **Charles Baldwyn (1821-1898):** Principal designer recognized for establishing Japanese-inspired compositions and early Aesthetic Movement works [[session/dialog/d99bab55_1.jsonl#L4]].
*   **George Owen (1845-1914):** Key architect of Renaissance Revival structures and Moorcroft-style vases [[session/dialog/d99bab55_1.jsonl#L4]].
*   **William Moorcroft (1855-1917):** Accomplished ceramic artist working at the factory who pioneered foundational Moorcroft-style techniques [[session/dialog/d99bab55_1.jsonl#L4]].

**Diagnostic Factory Marks:**
Pieces are authenticated primarily by locating a crown symbol paired with "Worcester" or "Royal Worcester" text, numeric dot codes indicating specific years of production, or individual artist autographs [[session/dialog/d99bab55_1.jsonl#L4]].

### Technical Analysis: Celadon Glaze Formulation & Mechanics
Addressing inquiries regarding specific visual characteristics of Japanese-inspired Worcester pieces, the following technical data regarding celadon glaze was recorded [[session/dialog/d99bab55_1.jsonl#L5-L6]]:
*   **Origins and Composition:** The style derives from Chinese Song dynasty techniques (960-1279 AD) known for soft pale blue-green hues. To replicate this, Worcester chemists formulated proprietary mixtures incorporating rare, costly cobalt oxide alongside feldspathic components (a blend of feldspar, quartz, and kaolin) [[session/dialog/d99bab55_1.jsonl#L6]].
*   **Application and Firing:** The glaze was deposited using brushing, pouring, and spraying methodologies before undergoing a controlled low-temperature firing process approximately reaching 1200°C [[session/dialog/d99bab55_1.jsonl#L6]].
*   **Visual Characteristics:** Genuine examples exhibit a soft, pale blue shade with greyish/greenish undertones, a delicate semi-translucent finish allowing underlying clay visibility, and a characteristic subtle crackle pattern [[session/dialog/d99bab55_1.jsonl#L6]].

**Mechanics of the Crackle Pattern:**
Responding to user curiosity concerning surface textures [[session/dialog/d99bab55_1.jsonl#L7-L8]], it was documented that the crackle represents a synthesis of controlled physics:
*   **Natural Fracturing:** As glazed ceramics cool post-firing, differential rates of thermal expansion and contraction cause spontaneous micro-cracking within the vitreous layer [[session/dialog/d99bab55_1.jsonl#L8]].
*   **Intentional Manipulation:** To achieve specific aesthetic effects mimicking ancient Asian antiquities, Worcester artisans deliberately enhanced fracturing by adjusting chemical coefficients for higher thermal expansion sensitivity, manipulating kiln duration and thermal shock resistance, varying glaze application thickness, and applying specialized post-firing treatments [[session/dialog/d99bab55_1.jsonl#L8]].

### Artisan Expertise & Manufacturing Infrastructure
Information regarding the human capital managing production was compiled [[session/dialog/d99bab55_1.jsonl#L9-L10]]:
*   **Recruitment and Training:** Workshops operated utilizing strict apprenticeship models integrating younger trainees alongside recruited master craftsmen arriving from competing European centers situated in France, Germany, and Italy [[session/dialog/d99bab55_1.jsonl#L10]].
*   **Specialized Skillsets:** Production teams required deep mastery over ceramic geometry drafting, mineralogical glaze chemistry, mechanical throwing/shaping procedures, multi-layered overglaze/enamel painting strategies, and precise kiln atmosphere management [[session/dialog/d99bab55_1.jsonl#L10]].
*   **Organizational Hierarchy:** Factories maintained hierarchical divisions overseen by senior masters delegating tasks among dedicated personnel pools specializing individually in design drafting, raw pottery forming, surface glazing, or final paint embellishments [[session/dialog/d99bab55_1.jsonl#L10]].
*   **Notable Workers:** Beyond designers, skilled operational figures included modeler George Owen (known for sculptural pomegranate detailing) and decorator William Moore, renowned for complex pigment execution across varied glaze substrates [[session/dialog/d99bab55_1.jsonl#L10]].

### International Trade Networks & Commercial Strategy
Historical distribution channels expanding beyond domestic boundaries were outlined [[session/dialog/d99bab55_1.jsonl#L11-L12]]:
*   **European Dominance:** Primary commercial focus remained heavily concentrated supplying aristocratic demand centers across France, Germany, and traditional United Kingdom partners [[session/dialog/d99bab55_1.jsonl#L12]].
*   **North American Expansion:** Recognizing lucrative economic potential early, exports increased significantly toward United States clients eager to purchase fine bone china dinner sets and exclusive ornamental display sculptures emulating European opulence standards [[session/dialog/d99bab55_1.jsonl#L12]].
*   **Asian Market Penetration:** Supply chains extended deeply throughout colonial India serving British administrative elites and Indian royalty seeking imported luxuries. Simultaneously, shipments targeted designated Chinese treaty ports—including Guangzhou (formerly Canton) and Shanghai—to sell directly to local merchant populations desiring western dining accoutrements [[session/dialog/d99bab55_1.jsonl#L12]].
*   **Additional Territories:** Minor logistics operations supplied regional nodes located throughout Africa, South America, and Australasia facilitated entirely by affiliated British trading corporations [[session/dialog/d99bab55_1.jsonl#L12]].
*   **Marketing Execution:** Aggressive brand promotion occurred via participation in landmark global expos—most notably hosting exhibits at the Great Exhibition held inside London in 1851, alongside participation at the Paris Exposition Universelle taking place two years later in 1855. Distribution relied upon expansive networks of overseas agents distributing printed catalogs and promotional trade cards locally [[session/dialog/d99bab55_1.jsonl#L12]].

### Metadata
*   **Keywords**: Antiques, Victorian Era, Worcester Royal Porcelain, Celadon Glaze, Ceramic Arts, Provenance Research.
*   **Persons Mentioned**: Queen Victoria, Charles Baldwyn, George Owen, William Moorcroft, William Moore.
*   **Entities**: Worcester Royal Porcelain, Royal Doulton, Minton, Spode, Derby Porcelain, East India Company, Victoria and Albert Museum, Metropolitan Museum of Art, Christie's, Sotheby's, Bonhams.
*   **Locations**: Stoke-on-Trent (England), London (Victoria and Albert Museum), New York (Metropolitan Museum of Art), China (Guangzhou/Canton, Shanghai), India, France, Germany, Italy, United States.
*   **Dates/Timestamps**: Victorian Era (1837-1901), Song Dynasty (960-1279 AD), 1751 (Worcester est.), 1815 (Doulton fond.), 1793 (Minton est.), 1767 (Spode fond.), 1750 (Derby est.), 1860s-1880s (Japanese style), 1870s-1890s (Aesthetic movement), 1850s-1880s (Renaissance revival), 1880s-1900s (Moorcroft style), 1851 (Great Exhibition), 1855 (Paris Exposition).
