---
description: Categorized catalog of cozy throw blanket retailers and price points
  (Budget, Mid-Range, Luxury) alongside detailed material composition breakdown and
  washing/maintenance protocols specifically for the Ugg Ansley Throw Blanket.
name: throw-blanket-shopping-and-care-guide
session_id: 42234f98
source_conversation: '[[session/dialog/42234f98.jsonl]]'
---

## Cozy Throw Blanket Recommendations [[session/dialog/42234f98.jsonl#L5-L6]]
- After acquiring a blanket from Target, the participant sought additional cozy throw blanket recommendations for the living room [[session/dialog/42234f98.jsonl#L5]].
- Affordable Options: Target Threshold (starts ~$10), Amazon Basics (~$15), IKEA KOLDING (~$10) [[session/dialog/42234f98.jsonl#L6]].
- Mid-Range Options: Boll & Branch Soft Fleece (~$30), Ugg Ansley (~$40), Coyuchi Cloud Soft (~$40) [[session/dialog/42234f98.jsonl#L6]].
- Luxury Options: Barefoot Bungalow Sherpa (~$60), L.L.Bean Wicked Plush (~$70), Pendleton Woolen Mills (~$80) [[session/dialog/42234f98.jsonl#L6]].
- Selection Criteria: Consider material type (fleece, cotton, wool), size relative to furniture footprint, color complementarity, texture (plush vs woven), and brand reputation [[session/dialog/42234f98.jsonl#L6]].

## Ugg Ansley Throw Blanket Care Instructions [[session/dialog/42234f98.jsonl#L7-L8]]
- The participant requested detailed information regarding materials and maintenance for the Ugg Ansley Throw Blanket [[session/dialog/42234f98.jsonl#L7]].
- Material Composition: Approximately 40% Merino wool, 30% Polyester, and 30% Acrylic (exact ratios vary by color/style) [[session/dialog/42234f98.jsonl#L8]].
    - Merino Wool provides breathability, softness, and temperature regulation [[session/dialog/42234f98.jsonl#L8]].
    - Polyester adds durability and prevents pilling [[session/dialog/42234f98.jsonl#L8]].
    - Acrylic enhances softness and warmth [[session/dialog/42234f98.jsonl#L8]].
- Washing Protocol: Machine wash cold (below 30°C / 86°F) on a gentle cycle using mild detergent designed for wool/delicates; avoid harsh chemicals or bleach [[session/dialog/42234f98.jsonl#L8]]. Reshape while wet to prevent shrinkage [[session/dialog/42234f98.jsonl#L8]]. Air dry away from direct sunlight and heat; never tumble dry or iron [[session/dialog/42234f98.jsonl#L8]]. Brush gently once dry to restore texture [[session/dialog/42234f98.jsonl#L8]].
- Maintenance Tips: Avoid rough surfaces to prevent pilling; spot clean stains immediately with a damp cloth and mild soap; store in a breathable bag or container to avoid moisture buildup [[session/dialog/42234f98.jsonl#L8]].
