---
description: Technical guidelines on wheel alignment frequency thresholds and mechanical
  warning indicators, paired with step-by-step protocols for automotive exterior polishing,
  waxy protection, and targeted tar/stain dissolution techniques. Incorporates user-reported
  steering drift issues and planned detailing workflows.
name: vehicle-alignment-and-exterior-detailing-procedures
session_id: d729b790_2
source_conversation: '[[session/dialog/d729b790_2.jsonl]]'
---

## Wheel Alignment Schedules and Diagnostic Indicators
- Verify manufacturer specifications directly within the vehicle owner's manual; standard industry intervals recommend realignments every 6,000 to 12,000 miles (9,656 to 19,312 kilometers) under normal operating conditions [[session/dialog/d729b790_2.jsonl#L5-L6]].
- Accelerate diagnostic intervals to every 3,000 to 6,000 miles when subjecting the chassis to severe environmental stressors including rough terrain surfaces, heavy cargo transport, aggressive cornering maneuvers, or aging suspension degradation [[session/dialog/d729b790_2.jsonl#L5-L6]].
- Monitor tire tread depth distribution patterns for asymmetrical erosion, track steering wheel geometric centering relative to road trajectory, detect cabin and directional controls exhibiting harmonic oscillations during highway transit, and measure lateral drift forces deviating vehicles toward single lanes [[session/dialog/d729b790_2.jsonl#L5-L6]].
- Trigger immediate re-alignment procedures following collision impacts, pavement curbstones strikes, or complete rubber tire assemblies replacements to guarantee uniform loading distributions [[session/dialog/d729b790_2.jsonl#L5-L6]].
- Execute systematic rotational cycles across all four tires equally to ensure maximum service life and schedule professional mechanic consultations whenever symptomatic deviations manifest [[session/dialog/d729b790_2.jsonl#L5-L6]].

## Automotive Exterior Restoration Protocols
- Initiate surface preparation sequences through meticulous soap application utilizing pH-neutral car wash solutions alongside soft woven microfiber applicators, followed immediately by accelerated air-blowing or absorption drying techniques preventing mineral spotting [[session/dialog/d729b790_2.jsonl#L7-L8]].
- Employ industrial-grade polymer clays infused with dedicated lubricants to mechanically shear loose atmospheric pollutants, petroleum tars, and biological insect accumulations from factory lacquer layers prior to compounding stages [[session/dialog/d729b790_2.jsonl#L7-L8]].
- Deploy rotary or orbital mechanical buffers equipped with progressively graded foam pads alongside abrasive correction pastes to dissolve oxidation matrices, swirl fingerprints, and superficial scratch networks [[session/dialog/d729b790_2.jsonl#L7-L8]].
- Seal recovered surfaces permanently using either natural plant-derived Carnauba paste blends or advanced synthetic polymeric coatings applied sequentially across manageable quadrant zones utilizing straight overlapping hand strokes without circular motion artifacts [[session/dialog/d729b790_2.jsonl#L7-L8]].
- Maintain peripheral aesthetics by conditioning unpainted plastic rubbers with specialized rejuvenators, buffing aluminum alloy rims post-brake-dust abatement using dedicated solvent sprays, and applying silicone-modified dressing fluids ensuring deep luster retention [[session/dialog/d729b790_2.jsonl#L7-L8]].

## Contaminated Surface Remediation Strategies
- Dissolve tenacious adhesive bonds directly utilizing proprietary chemical solvents manufactured by TarX or generic automotive formulations designed specifically breaking down hydrocarbon deposits, allowing mandatory dwell periods before wiping away via sterile textiles [[session/dialog/d729b790_2.jsonl#L9-L10]].
- Combat residual epoxy markers using household brand equivalents such as Goo Gone or multi-purpose lubricant sprays containing WD-40 formulation profiles [[session/dialog/d729b790_2.jsonl#L9-L10]].
- Supplement mechanical agitation processes by directing thermal energy sources toward impacted panels gently heating polymer chains loosening molecular grip before introducing secondary dissolving agents [[session/dialog/d729b790_2.jsonl#L9-L10]].
- Restrict abrasive interventions strictly to isolated patches initially verifying chemical compatibility against factory enamel layers, completely prohibit volatile combustion fluids like refined gasolines or traditional nitrocellulose thinners protecting underlying substrate integrity [[session/dialog/d729b790_2.jsonl#L9-L10]].

## Current Vehicle Observations
- On 2023-05-29, the operator noted chronic directional instability manifesting as consistent leftward trajectory deviation during high-speed freeway operations requiring imminent correction services [[session/dialog/d729b790_2.jsonl#L7-L8]].
- Planned remedial actions prioritize executing thorough base cleans combined simultaneously with clay decontamination runs across affected panel regions before undertaking future corrective grinding exercises involving handheld buffing machines tested safely on concealed subsections first [[session/dialog/d729b790_2.jsonl#L9-L10]].
