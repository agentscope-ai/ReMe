---
description: A recruitment task identifying core data science job responsibilities
  (data engineering, modeling, stakeholder collaboration) and generating a 'John Doe'
  CV template as a benchmark for evaluating applicant submissions.
name: data-science-recruitment-criteria
session_id: sharegpt_x6lm0qe_0
source_conversation: '[[session/dialog/sharegpt_x6lm0qe_0.jsonl]]'
---

## Recruitment Task Context
The assistant acts as a recruiter to provide strategies for sourcing qualified applicants based on specific job responsibilities [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L1-L1]].

## Core Job Responsibilities
The role requires candidates to meet the following criteria:
- Leverage critical thinking and problem statement definition, decomposition, and problem solving to ensure efforts are focused on delivering impactful and actionable outcomes [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L1-L1]].
- Adopt and develop data engineering methodologies including, but not limited to, data source and feature identification and integration, data pipelining, feature engineering, data munging, and analysis using script/code driven methods that can translate from research to production [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L1-L1]].
- Analyse and develop explanatory, predictive, and prescriptive models using appropriate mathematical methods like frequentist statistics, bayesian statistics, time-series analysis, supervised and unsupervised machine learning methods, natural language process (NLP), and semantic analysis [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L1-L1]].
- Collaborate across cross-functional stakeholder teams, managing opportunities and challenges that improve processes and help stakeholders become more data savvy [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L1-L1]].
- Develop and conduct experiments to validate findings from observational research. Communicate and visualize insights to multiple levels of stakeholders with clarity, informed decision-making [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L1-L1]].

## Model Candidate CV ("John Doe")
An example CV generated to reflect the required responsibilities and serve as a model for reviewing submissions [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L1-L2]]:
- **Personal Information**:
  - Name: John Doe
  - Email: johndoe@email.com
  - Phone: 555-555-5555 [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]]
- **Technical Proficiencies**:
  - Programming Languages: Python, R, SQL [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]]
  - Data Engineering Methods: Data source and feature identification, data pipelining, feature engineering, data munging [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]]
  - Tools and Frameworks: NumPy, Pandas, Scikit-learn, TensorFlow, Keras, PyTorch, Spark, Hadoop, SQL Server, Tableau, Power BI [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]]
- **Education**:
  - Master of Science in Data Science, University of XYZ (2018) [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]]
  - Bachelor of Science in Computer Science, University of ABC (2016) [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]]
- **Certifications**:
  - Certified Data Scientist, Data Science Council of America (2018) [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]]
  - Certified Analytics Professional, Institute for Operations Research and the Management Sciences (2019) [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]]
- **Professional Experience**:
  - Data Scientist at ABC Company (Jan 2020 - Present):
    - Responsibilities align with the core job requirements listed above, including modeling, data engineering, and stakeholder collaboration [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]].
  - Data Scientist at XYZ Company (Jan 2018 - Dec 2019):
    - Implemented data-driven solutions to improve business processes using regression, decision trees, and clustering [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]].
    - Conducted statistical analysis to identify trends and patterns in large datasets [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]].
    - Designed and implemented data visualizations to communicate insights to stakeholders [[session/dialog/sharegpt_x6lm0qe_0.jsonl#L2-L2]].
