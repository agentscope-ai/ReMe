---
description: Comprehensive guide on analog film development and darkroom techniques
  for a user's vintage 1960s Rolleiflex TLR acquired from a local antique shop. Covers
  learning resources (book 'The Darkroom Handbook' by Steve Anchell, YouTube channels
  like The Darkroom/Film Dev/Analog Insights, Reddit communities r/Darkroom/r/AnalogPhotography),
  required equipment (darkroom setup or portable tent, developing tank with reels,
  thermometer, measuring cups, chemicals including developer/stop bath/fixer/wash),
  basic workflow (loading film in darkness, developing in chemical solutions, washing
  and drying), beginner tips (starting with black and white film, using simple developers
  like D-76 or HC-110, keeping records), push/pull processing techniques (push increases
  development time 10-20% for underexposure creating higher contrast grain and cooler
  tones; pull decreases development time 10-20% for overexposure producing softer
  contrast less grain and better color accuracy), film stock characteristics and recommendations
  (Kodak Tri-X 400 high contrast good for push but not pull, Ilford HP5 Plus 400 versatile
  forgiving for beginners, Fuji Acros 100 fine grain low contrast not forgiving for
  push/pull, Kodak Portra 400 good for portraits responds well to pull, Agfa APX 400
  budget friendly good for push but prone to overdevelopment, Kodak Gold 200 Fuji
  Superia 400 recommendations), portrait-specific guidance (warm-toned films Kodak
  Portra 400/Fuji Pro 400H/Agfa Vista 200 vs neutral-toned films Ilford Pan 100/Kodak
  T-Max 100/Fuji Acros 100, ISO selection considerations comparing higher ISO 800-1600
  benefits vs lower ISO 100-400 advantages), developer recommendations matching film
  types (D-76 general purpose, ID-11 versatile, Fujifilm Neofine for Fuji films, Rodinal
  for high-contrast films).
name: film-development-guide
session_id: 708e39b6_1
source_conversation: '[[session/dialog/708e39b6_1.jsonl]]'
---

# Film Development and Darkroom Techniques Guide

## Personal Context
- **Equipment**: Vintage 1960s Rolleiflex TLR camera purchased from a local antique shop that still works properly [[session/dialog/708e39b6_1.jsonl#L1-L1]]
- **Interest**: Learning analog film development and darkroom techniques for portrait photography [[session/dialog/708e39b6_1.jsonl#L1-L1]]

## Learning Resources

### Recommended Reading
- *The Darkroom Handbook* by Steve Anchell - comprehensive resource covering basics of film development and darkroom techniques [[session/dialog/708e39b6_1.jsonl#L2-L2]]

### Video Tutorials
- YouTube channels providing film development tutorials: The Darkroom, Film Dev, Analog Insights [[session/dialog/708e39b6_1.jsonl#L2-L2]]

### Online Communities
- Reddit subreddits: r/Darkroom and r/AnalogPhotography [[session/dialog/708e39b6_1.jsonl#L2-L2]]

### Courses and Apps
- Online courses available through Udemy, Skillshare, CreativeLive [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Mobile apps: Darkroom Timer and FilmDev for calculating development times and tracking processes [[session/dialog/708e39b6_1.jsonl#L2-L2]]

## Required Equipment and Supplies

### Darkroom Setup
- Options: Convert closet/small room into darkroom or invest in portable darkroom tent [[session/dialog/708e39b6_1.jsonl#L2-L2]]

### Essential Gear
- Developing tank with reels [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Thermometer [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Measuring cups [[session/dialog/708e39b6_1.jsonl#L2-L2]]

### Chemical Supplies
- Four essential chemicals needed: developer, stop bath, fixer, wash solution [[session/dialog/708e39b6_1.jsonl#L2-L2]]

## Basic Film Development Process

1. **Loading film** - Learn to load film onto reel in complete darkness [[session/dialog/708e39b6_1.jsonl#L2-L2]]
2. **Developing** - Mix developer, stop bath, fixer according to manufacturer instructions and process film in darkroom or dark bag [[session/dialog/708e39b6_1.jsonl#L2-L2]]
3. **Washing and drying** - Wash film thoroughly and dry in dust-free environment [[session/dialog/708e39b6_1.jsonl#L2-L2]]

## Beginner Tips

- Start with black and white film - less expensive and easier to process than color [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Use simple developers like D-76 or HC-110 which are easy to use and forgiving [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Keep accurate records of development times, temperatures, and chemical concentrations [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Practice patience as film development requires experimentation [[session/dialog/708e39b6_1.jsonl#L2-L2]]

## Push and Pull Processing Techniques

### Push Processing
- **Definition**: Increasing development time to compensate for underexposure when shooting at lower ISO than intended [[session/dialog/708e39b6_1.jsonl#L4-L4]]
- **Effects**: Higher contrast, more visible grain, cooler/bluer color shifts [[session/dialog/708e39b6_1.jsonl#L4-L4]]
- **Implementation**: Rate film at lower ISO (e.g., rate 400ISO as 200ISO), increase development time by 10-20% (e.g., if normal time is 3 min, extend to 3.5-4 min) [[session/dialog/708e39b6_1.jsonl#L4-L4]]

### Pull Processing
- **Definition**: Decreasing development time to compensate for overexposure when shooting at higher ISO than intended [[session/dialog/708e39b6_1.jsonl#L4-L4]]
- **Effects**: Reduced contrast, less grain, better color accuracy [[session/dialog/708e39b6_1.jsonl#L4-L4]]
- **Implementation**: Rate film at higher ISO (e.g., rate 100ISO as 200ISO), decrease development time by 10-20% (e.g., if normal time is 3 min, reduce to 2.5-2.7 min) [[session/dialog/708e39b6_1.jsonl#L4-L4]]

### Experimentation Tips
- Start with small increments of 5-10% change in development time [[session/dialog/708e39b6_1.jsonl#L4-L4]]
- Keep accurate records of all parameters [[session/dialog/708e39b6_1.jsonl#L4-L4]]
- Try different film stocks to see how they respond [[session/dialog/708e39b6_1.jsonl#L4-L4]]
- Scan developed film to review results and refine technique [[session/dialog/708e39b6_1.jsonl#L4-L4]]

## Film Stock Characteristics and Recommendations

### High Contrast Films
- **Kodak Tri-X 400**: Classic film with distinctive grain, responds well to push processing but becomes too contrasty when pulled [[session/dialog/708e39b6_1.jsonl#L6-L6]]

### Versatile/Budget-Friendly Films
- **Ilford HP5 Plus 400**: Medium contrast, fine grain, forgiving for beginners, responds well to both push and pull processing - recommended for beginners [[session/dialog/708e39b6_1.jsonl#L6-L6]]
- **Agfa APX 400**: Budget-friendly, high contrast with distinct grain, forgiving for beginners, responds well to push but prone to overdevelopment [[session/dialog/708e39b6_1.jsonl#L6-L6]]
- **Kodak Gold 200**: Budget-friendly medium contrast with fine grain suitable for general photography [[session/dialog/708e39b6_1.jsonl#L6-L6]]

### Fine Grain/Low Contrast Films
- **Fuji Acros 100**: Low contrast extremely fine grain, ideal for landscapes and portraits, less forgiving when pushed or pulled [[session/dialog/708e39b6_1.jsonl#L6-L6]]
- **Fuji Superia 400**: Medium contrast fine grain modern commercial look, suitable for beginners [[session/dialog/708e39b6_1.jsonl#L6-L6]]

### Portrait-Oriented Films
- **Kodak Portra 400**: Medium contrast smooth natural tone, popular for portraits, responds well to pull processing but can become too contrasty when pushed [[session/dialog/708e39b6_1.jsonl#L6-L6]]

## Portrait Photography Recommendations

### Warm-Toned Films
- **Kodak Portra 400**: Natural warm tone complements skin tones beautifully with fine grain and high sharpness [[session/dialog/708e39b6_1.jsonl#L8-L8]]
- **Fuji Pro 400H**: Slightly warmer than Portra 400 with pronounced golden hue, ideal for fashion and portrait work [[session/dialog/708e39b6_1.jsonl#L8-L8]]
- **Agfa Vista 200**: Budget-friendly warm natural tone good for portraits [[session/dialog/708e39b6_1.jsonl#L8-L8]]

### Neutral-Toned Films
- **Ilford Pan 100**: Classic neutral tone excellent for accurate skin tones with fine grain and high sharpness [[session/dialog/708e39b6_1.jsonl#L8-L8]]
- **Kodak T-Max 100**: Neutral tonality known for high sharpness and fine grain, great for studio portraits [[session/dialog/708e39b6_1.jsonl#L8-L8]]
- **Fuji Acros 100**: High-quality neutral tone with exceptional sharpness fine grain ideal for detailed high-contrast portraits [[session/dialog/708e39b6_1.jsonl#L8-L8]]

### ISO Selection for Portraits

#### Higher ISO (800-1600)
**Benefits**: More flexibility in low light, faster shutter speeds to freeze motion, ability to use larger apertures for shallower depth of field [[session/dialog/708e39b6_1.jsonl#L10-L10]]

**Drawbacks**: Increased visible grain, potential loss of shadow detail, possible color shifts [[session/dialog/708e39b6_1.jsonl#L10-L10]]

**Best for**: Extremely low light conditions, fast-paced/dynamic scenes, artistic effects requiring high grain/gritty aesthetic [[session/dialog/708e39b6_1.jsonl#L10-L10]]

#### Lower ISO (100-400)
**Benefits**: Cleaner image with less grain, preserves shadow detail and subtle expressions, traditional classic aesthetic [[session/dialog/708e39b6_1.jsonl#L10-L10]]

**Drawbacks**: Requires sufficient lighting conditions [[session/dialog/708e39b6_1.jsonl#L10-L10]]

**Best for**: Good lighting conditions, portraits with subtle expressions/delicate skin tones, traditional classic look [[session/dialog/708e39b6_1.jsonl#L10-L10]]

#### Recommendations
- Beginners should start with lower ISO (100 or 400) and experiment with higher ISO as comfort increases [[session/dialog/708e39b6_1.jsonl#L10-L10]]

### Portrait Shooting Tips
- Use medium to wide aperture (f/2.8 or f/4) for shallow depth of field isolating subject [[session/dialog/708e39b6_1.jsonl#L8-L8]]
- Prefer natural light especially during golden hour avoiding harsh midday sun [[session/dialog/708e39b6_1.jsonl#L8-L8]]
- Focus sharply on subject's eyes using built-in focusing screen [[session/dialog/708e39b6_1.jsonl#L8-L8]]

## Developer Recommendations

### General Purpose Developers
- **Kodak D-76**: Classic developer working well with Kodak Portra, Tri-X, T-Max [[session/dialog/708e39b6_1.jsonl#L12-L12]]
- **Ilford ID-11**: Popular versatile consistent developer suitable for Ilford HP5 Plus and Pan 100 [[session/dialog/708e39b6_1.jsonl#L12-L12]]

### Specialty Developers
- **Fujifilm Neofine**: High-end developer specifically for Fuji films like Pro 400H and Acros 100 providing excellent sharpness and fine grain [[session/dialog/708e39b6_1.jsonl#L12-L12]]
- **Agfa Rodinal**: Specialty developer often used for high-contrast films like Agfa APX 400 [[session/dialog/708e39b6_1.jsonl#L12-L12]]

### Developer Selection Guidelines
- Read and follow manufacturer instructions and dilution ratios [[session/dialog/708e39b6_1.jsonl#L12-L12]]
- Start with general-purpose developer when new to film development [[session/dialog/708e39b6_1.jsonl#L12-L12]]
- Follow manufacturer recommendations for specific film stocks [[session/dialog/708e39b6_1.jsonl#L12-L12]]
- Experiment with different developers to observe effects on film stocks [[session/dialog/708e39b6_1.jsonl#L12-L12]]

## Additional Notes
- Safety guidelines should always be followed when working with chemicals [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Start with small batches to minimize waste and costs [[session/dialog/708e39b6_1.jsonl#L2-L2]]
- Consider local photography clubs, colleges, community centers for darkroom facilities and workshops [[session/dialog/708e39b6_1.jsonl#L2-L2]]
