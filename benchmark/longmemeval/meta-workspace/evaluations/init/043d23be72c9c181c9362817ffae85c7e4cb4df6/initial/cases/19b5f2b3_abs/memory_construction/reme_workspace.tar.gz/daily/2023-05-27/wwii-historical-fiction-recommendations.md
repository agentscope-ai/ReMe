---
description: Detailed breakdown of historical fiction book recommendations focusing
  on World War II settings and strong female protagonists, specifically analyzing
  Kate Quinn's "The Huntress". Includes user reading habits, format preferences, Audiobook
  narrator data, and publication metadata.
name: wwii-historical-fiction-recommendations
session_id: 762a4ba1_2
source_conversation: '[[session/dialog/762a4ba1_2.jsonl]]'
---

## User Profile and Preferences [[session/dialog/762a4ba1_2.jsonl#L1-L3,L7-L9,L11-L12]]
- The user completed reading "The Nightingale" by Kristin Hannah on Kindle approximately seven days prior to this conversation on 2023-05-27. 
- The user actively alternates between consuming e-books and audiobooks.
- The user utilizes the Audible platform extensively and consumes audiobooks during daily commutes to work; the user planned to initiate listening to "The Huntress" on 2023-05-28.
- The user explicitly prefers historical fiction narratives containing robust female characters situated within World War II environments.

## Initial Book Recommendations [[session/dialog/762a4ba1_2.jsonl#L2]]
- "All the Light We Cannot See" by Anthony Doerr: A Pulitzer Prize-winning novel detailing the intersecting paths of a blind French girl and a German boy during World War II.
- "The Alice Network" by Kate Quinn: Chronicles the efforts of a socialite and a female spy working together to assist downed airmen escaping Nazi-occupied Europe.
- "Those Who Save Us" by Jenna Blum: Examines complex maternal and filial relationships alongside themes of love, sacrifice, and survival against a World War II backdrop.
- "The Lost Girls of Paris" by Pam Jenoff: Takes place in 1946, centering on a widow who uncovers photographs documenting women participating in wartime resistance networks.
- "The Women in the Castle" by Jessica Shattuck: Chronicles the survival experiences of three distinct women and their struggles to rebuild society following World War II.
- "The Guernsey Literary and Potato Peel Pie Society" by Mary Ann Shaffer: An epistolary novel set on the island of Guernsey following the conclusion of World War II.
- "The Soldier's Wife" by Pam Jenoff: Situated in Nazi-occupied France, revolving around a young woman whose spouse is deployed fighting in the war.

## Supplementary Titles by Recommended Authors [[session/dialog/762a4ba1_2.jsonl#L4]]
- Anthony Doerr authored "About Grace" (featuring a protagonist capable of seeing the future) and the memoir "Four Seasons in Rome"; both titles are accessible as audiobooks.
- Kate Quinn penned "The Huntress" (focusing on female aviation, journalism, and socialite involvement during World War II) and "The Rose Code" (depicting codebreaking operations at Bletchley Park); both have corresponding audiobook releases.
- Jenna Blum wrote "The Stormchasers," a narrative regarding a family managing severe addiction challenges while engaging professionally in storm chasing, available as an audiobook.
- Pam Jenoff produced "The Orphan's Tale" (involving a young woman joining a traveling circus in Nazi-occupied Europe) and "The Ambassador's Daughter" (located in 1940s Poland amid underground resistance movements); both exist as audiobooks.
- Jessica Shattuck wrote "Perfect Life," concerning a woman forced to confront concealed familial history upon returning to her hometown, available as an audiobook.
- Mary Ann Shaffer authored "The Postscript Murders," a literary mystery set on Guernsey, which is available as an audiobook.

## In-Depth Analysis: "The Huntress" [[session/dialog/762a4ba1_2.jsonl#L5-L8]]
- The primary plot interweaves three distinct narratives: Nina Markova, a Russian Night Witch bomber pilot; Ian Graham, a British war correspondent relentlessly tracking a notorious Nazi assassin dubbed "The Huntress"; and Jordan McBride, an American socialite married to a British diplomat heavily involved in espionage and resistance.
- The audiobook edition is published by HarperAudio, spans 17 hours and 37 minutes in length, carries an official release date of February 26, 2019, and maintains an average rating of 4.5 out of 5 stars on Audible.
- Saskia Maarleveld serves as the sole narrator for the audiobook, successfully applying distinct vocal techniques and accents to differentiate the multiple character perspectives and maintain narrative pacing.
- "The Huntress" directly parallels Kristin Hannah's "The Nightingale" through deeply researched historical contexts, powerful female-led casting, and heavy emotional resonance; however, it distinguishes itself through accelerated pacing, prominent espionage mechanics, and adventure-driven suspense.

## Additional Historical Fiction Suggestions [[session/dialog/762a4ba1_2.jsonl#L9-L12]]
- "The Saboteur" by Paul Kix, narrated by P.J. Ochlan: Documents authentic sabotage campaigns executed by coordinated teams of American and British agents inside Nazi-occupied France.
- "The Room on Rue Amélie" by Kristin Harmel, narrated by Elizabeth Jasicki: Details the endeavors of an American volunteer coordinating the escape of downed allied airmen through occupied France.
- "The War Bride" by Pam Jenoff, narrated by Elizabeth Jasicki: Presents a romantic and suspenseful account of a young woman becoming intimately entangled in the concealed history of her British officer husband's lineage.
- "The Soldier's Wife" by Pam Jenoff, narrated by Elizabeth Jasicki: Reiterates the investigation by a young wife seeking truth regarding her absent, fighting husband.
- "The Women in the Castle" by Jessica Shattuck, narrated by Cassandra Campbell: Conducts a deeper examination of the post-war psychological recovery and secret-keeping behaviors exhibited by three female survivors.
- "Those Who Save Us" by Jenna Blum, narrated by Cassandra Campbell: Continues to highlight the profound generational impact of maternal bonds operating within extreme conflict parameters.
- "We Were the Lucky Ones" by Georgia Hunter, narrated by Kathleen McInerney: Recounts verifiable historical events surrounding a Jewish family's survival trajectories and desperate reunification attempts throughout World War II.
- "The Velvet Hours" by Alyssa Palombo, narrated by Cassandra Campbell: Centers operationally on a young woman directly engaging with the French Resistance apparatus within Parisian borders.
- Mary Ann Shaffer's "The Guernsey Literary and Potato Peel Pie Society" audiobook is additionally performed by voice actress Juliet Mills.
- Kate Quinn's "The Alice Network" audiobook version is concurrently voiced by Saskia Maarleveld.
- Pam Jenoff's "The Lost Girls of Paris" audiobook production relies on narration provided by Elizabeth Jasicki.
- The original standalone audiobook recording for Kristin Hannah's foundational text "The Nightingale" was produced under narration by Polly Stone.
