---
description: Extraction of tasks and strategies regarding preparation for the upcoming
  performance of Les Misérables. Includes schedule planning for script pickup, script
  review, and song practice. Captures guidelines and decisions made while drafting
  a biography for the performance program.
name: les-miserables-production-prep
session_id: 8fa624b2_3
source_conversation: '[[session/dialog/8fa624b2_3.jsonl]]'
---

### Performance Context [[session/dialog/8fa624b2_3.jsonl#L1-L3]]
- The user is participating in the cast of the musical Les Misérables. A costume fitting for the character's outfit took place recently on a Thursday.
- Preparation requires managing upcoming rehearsals alongside independent script reviews and song practices.

### Scheduling and Tasks [[session/dialog/8fa624b2_3.jsonl#L4-L6]]
- Task: Pick up the script from the theater office on 2023-05-28.
- Script Review: Block 1-2 hours to memorize scenes, learn lines, study stage directions/blocking, and review choreography or dance moves. Visualization of stage movements is recommended.
- Song Practice: Allocate 30 minutes to 1 hour for singing exercises focusing on pitch, tone, emotion, and harmonies/cast blending. Self-recording is suggested to identify areas for improvement.
- Rehearsal Habits: Arrive early to settle into focus before rehearsals begin. Taking notes during the rehearsal sessions and reviewing them afterward is necessary.

### Program Bio Writing [[session/dialog/8fa624b2_3.jsonl#L7-L12]]
- The user plans to draft a biography for the official performance program.
- Length Guidelines: The bio should be limited to 1-2 sentences or 50-75 words.
- Content Strategy: Highlight relevant theater experience, training, notable past roles, and awards. Add a personal touch regarding the inspiration for the role. Proofread for grammatical correctness.
- Timeline Correction: Initially, the user considered detailing an audition that occurred three weeks prior and subsequent nonstop rehearsals. It was established that program bios should emphasize prior background and qualifications rather than the current ongoing production timeline.
- Final Plan: The bio will focus exclusively on previous theater experience and training instead of current preparation activities.
