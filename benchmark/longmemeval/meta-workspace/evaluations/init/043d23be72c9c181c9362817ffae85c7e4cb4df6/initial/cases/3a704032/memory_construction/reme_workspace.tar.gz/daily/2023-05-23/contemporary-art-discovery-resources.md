---
description: Discussion about recommending contemporary art and emerging artist resources.
  User details past attendance at the Contemporary Art Space and a Modern Art Museum
  event featuring Sarah Johnson. Assistant provides comprehensive lists of online
  platforms including Artsy, Saatchi Art, Artspace, and Uprise Art for discovering
  artwork.
name: contemporary-art-discovery-resources
session_id: 0babf5b6_2
source_conversation: '[[session/dialog/0babf5b6_2.jsonl]]'
---

## User Interest and Past Experience
The user is interested in contemporary art exhibitions and emerging artists [[session/dialog/0babf5b6_2.jsonl#L1]].
The user previously attended a gallery opening at the **Contemporary Art Space** in October, featuring a renowned artist, spending over 2 hours there [[session/dialog/0babf5b6_2.jsonl#L1]].
The user visited the "**Contemporary Art Exhibition**" at the **Modern Art Museum**, viewing installations and paintings by emerging artist **Sarah Johnson** focused on climate change [[session/dialog/0babf5b6_2.jsonl#L5]].
The user enjoys finding thought-provoking work related to themes like social justice, environmentalism, and technology [[session/dialog/0babf5b6_2.jsonl#L2]].

## Online Resources for Art Discovery
### General Collections and Community Platforms
*   **Artsy**: Features vast collections and dedicated emerging artist sections with filtering tools [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Saatchi Art**: Focuses on emerging talent with curated collections; hosts online events like The Other Art Fair [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **ArtNet**: Offers news, exhibition coverage, and search capabilities for emerging artists [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Behance**: A portfolio site for creatives allowing searches by medium and location [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Instagram**: Social discovery via hashtags such as `#emergingartist` and `#artoftheday` [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Juxtapoz**: An online magazine covering interviews and profiles of established and emerging artists [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Hyperallergic**: Covers art world news and profiles of emerging talent [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **New American Paintings**: Highlights emerging US painters through a bi-monthly magazine and archive [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **The Artist's Institute**: Features essays, interviews, and exhibitions showcasing new artists [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Platform**: Global curation of emerging artworks and profiles [[session/dialog/0babf5b6_2.jsonl#L4]].

### Curated Contemporary Focused Platforms
*   **Artspace**: Specializes in contemporary art and emerging artists with purchasing options [[session/dialog/0babf5b6_2.jsonl#L8]].
*   **Uprise Art**: Focuses on emerging artists with curated collections and direct buying capabilities [[session/dialog/0babf5b6_2.jsonl#L8]].
*   **1stdibs**: Marketplaces partnering with galleries to display high-quality contemporary art and antiques [[session/dialog/0babf5b6_2.jsonl#L8]].
*   **Minted**: Showcases unique contemporary design and art from emerging creators [[session/dialog/0babf5b6_2.jsonl#L8]].
*   **Collecteurs**: Provides curated selections tailored to collector interests in contemporary art [[session/dialog/0babf5b6_2.jsonl#L8]].

## Next Steps
The user plans to explore **Artsy**, **Saatchi Art**, **Artspace**, and **Uprise Art** to discover relevant artists [[session/dialog/0babf5b6_2.jsonl#L9-L11]].
