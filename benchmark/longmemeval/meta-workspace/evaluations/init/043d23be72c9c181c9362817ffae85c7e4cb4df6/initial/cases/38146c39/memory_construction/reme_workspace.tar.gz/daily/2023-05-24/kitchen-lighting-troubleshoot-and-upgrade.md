---
description: Troubleshooting a failed 3-foot plug-in under-cabinet LED strip in the
  kitchen powered by a wall outlet; evaluating replacement options such as puck lights
  and under-shelf strip lighting, including considerations for installation, brightness
  (10-20 lumens/sq ft), color temperature, and CRI.
name: kitchen-lighting-troubleshoot-and-upgrade
session_id: 5a4fec9e
source_conversation: '[[session/dialog/5a4fec9e.jsonl]]'
---

### LED Strip Troubleshooting [[session/dialog/5a4fec9e.jsonl#L1-L4]]

*   A user maintains a 3-foot plug-in LED strip located under kitchen cabinets, powered directly by a wall outlet.
*   The entire LED strip ceased functioning completely starting a few days before 2023-05-24.
*   Prior troubleshooting attempts by the user included cleaning connection points and mistakenly attempting to replace batteries, which does not apply to a plug-in configuration.
*   Primary suspected causes include a general power issue (damaged power cord, inactive wall outlet), a failed LED driver, total LED strip failure, or overheating from blocked airflow or proximity to heat sources.
*   Diagnostic procedures recommend verifying wall outlet functionality, swapping in a known-good spare power cord, inspecting the strip for physical damage like cracks or burn marks, and reseating the LED driver. Failure to restore function suggests permanent hardware failure requiring LED strip replacement.

### Alternative Kitchen Lighting Options [[session/dialog/5a4fec9e.jsonl#L5-L6]]

*   The user evaluates transitioning current under-cabinet illumination to puck lights or under-shelf strip lights mounted below shelving units rather than inside cabinets.
*   Benefits of puck lights and under-shelf strips include enhanced position flexibility, focused task lighting directed onto countertops and cooking zones, potentially simpler installation avoiding extensive cabinetry rewiring, and a sleek modern aesthetic.
*   Relevant trade-offs involve the highly directional light pattern of puck lights compared to the ambient diffusion of cabinet strips, the necessity of verifying shelf thickness and lip geometry allows clearance, and maintaining compatibility with existing dimming systems.
*   Specification parameters for replacement fixtures recommend a warm white (2700K-3000K) or soft white (3000K-3500K) color temperature, a luminous density of 10 to 20 lumens per square foot of countertop area, and a Color Rendering Index (CRI) between 80 and 100 for accurate color representation.
