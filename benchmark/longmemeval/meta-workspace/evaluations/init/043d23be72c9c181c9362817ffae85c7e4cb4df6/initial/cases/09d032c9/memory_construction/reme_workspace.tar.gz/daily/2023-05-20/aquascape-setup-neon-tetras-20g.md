---
description: Comprehensive operational guidelines for reconfiguring a 20-gallon freshwater
  community aquarium inhabited primarily by an active school of neon tetras (initially
  nine specimens, later supplemented). Covers foundational layout principles emphasizing
  the rule of thirds, focal points, open swimming zones (30–40%), and layered depth.
  Details compatible aquatic flora selections including Java Moss, Anacharis, Water
  Wisteria, Cryptocorynes, and Cabomba, specifying light tolerance and nutrient competition
  traits. Provides precise cultivation metrics for establishing a Dwarf Hairgrass
  foreground carpet (clump spacing, perimeter clearance, trimming targets, and pathway
  carving), safety protocols for introducing untreated or commercial driftwood to
  mitigate tannin discoloration and alkalinity shifts (thermal processing, extended
  soaking, parameter tracking), and secure deployment strategies for ceramic ornamentation
  like treasure chests, rocks, and tunnels (aperture design, edge inspection, dechlorinated
  pre-rinsing, density restrictions).
name: aquascape-setup-neon-tetras-20g
session_id: 54c5a89c_2
source_conversation: '[[session/dialog/54c5a89c_2.jsonl]]'
---

## Tank Profile and Target Species
- Maintains a 20-gallon volume dedicated to community keeping [[session/dialog/54c5a89c_2.jsonl#L1-L1]].
- Houses a primary population of neon tetras; initial baseline consisted of exactly nine specimens prior to recent supplementary additions expanding the current school size [[session/dialog/54c5a89c_2.jsonl#L1-L1]].
- Observational records confirm high activity levels among these schooling fish warranting spatial arrangements permitting rapid darting maneuvers [[session/dialog/54c5a89c_2.jsonl#L1-L1]].

## Aquascaping Fundamentals
- Construct composition utilizing grid intersections dividing glass panels horizontally and vertically into equal thirds establishing visual equilibrium [[session/dialog/54c5a89c_2.jsonl#L2-L2]].
- Anchor attention toward singular focal landmarks positioned centrally directing gaze trajectories outward naturally [[session/dialog/54c5a89c_2.jsonl#L2-L2]].
- Build vertical dimensionality stacking substrate tiers, hardscape objects, and living tissue sequentially backward toward front boundaries [[session/dialog/54c5a89c_2.jsonl#L2-L2]].
- Generate chromatic and textural juxtaposition pairing smooth mineral surfaces against fibrous woody structures contrasting vivid foliage hues beneath opaque gravel beds [[session/dialog/54c5a89c_2.jsonl#L2-L2]].
- Scale imported architecture strictly according to cubic footage capacity preventing overcrowding syndrome triggering territorial aggression or suffocation risks [[session/dialog/54c5a89c_2.jsonl#L2-L2]].
- Allocate minimum thirty to forty percent total internal capacity exclusively reserved as unobstructed transit corridors allowing unrestricted horizontal locomotion cycles [[session/dialog/54c5a89c_2.jsonl#L2-L2]].
- Install protective coverations functioning both aesthetically pleasing screens blocking external stimuli threatening panic responses simultaneously shielding vulnerable inhabitants behind opaque matrices [[session/dialog/54c5a89c_2.jsonl#L2-L2]].
- Map fluid dynamics currents originating pump outlets rearranging barriers redirecting laminar flows generating eddies stimulating motion perception visually [[session/dialog/54c5a89c_2.jsonl#L2-L2]].
- Arrange botanical specimens ascending gradient tallest mature leaves nearest rear panes shrinking progressively approaching viewing windows optimizing perspective scaling effects [[session/dialog/54c5a89c_2.jsonl#L2-L2]].
- Iterate experimental arrangements continuously adapting configurations responding dynamically behavioral feedback loops exhibited occupants exploring novel territories [[session/dialog/54c5a89c_2.jsonl#L2-L2]].

## Suitable Plant Varieties
- Native habitat tracing connects modern domesticated strains directly back wild populations residing tropical Amazon drainage networks favoring heavily vegetated river margins rich shadow coverage [[session/dialog/54c5a89c_2.jsonl#L3-L4]].
- Illumination preferences skew strongly toward dimmer spectra rejecting direct overhead harsh fluorescent tubes demanding shade-tolerant cultivars installed nearby [[session/dialog/54c5a89c_2.jsonl#L3-L4]].
- Java Moss thrives attaching securely bark substrates stone formations delivering steady expansion rates limited pruning demands offering optimal refuge chambers [[session/dialog/54c5a89c_2.jsonl#L3-L4]].
- Anacharis executes aggressive filtration duties extracting dissolved waste products rapidly suppressing undesirable microbial blooms establishing secondary grazing stations [[session/dialog/54c5a89c_2.jsonl#L3-L4]].
- Water Wisteria exhibits flexible stem architectures trainable climbing supports dangling gracefully freely suspended midwater zones requiring consistent shearing interventions retain shape integrity [[session/dialog/54c5a89c_2.jsonl#L3-L4]].
- Cryptocoryne genus representatives demonstrate remarkable adaptability accommodating wide geographic spreads across global distribution networks surviving fluctuations temperature swings readily [[session/dialog/54c5a89c_2.jsonl#L3-L4]].
- Cabomba accelerates biomass production delivering abundant canopy layers shading underlying competitors supporting scavenger diets supplementing natural foraging instincts [[session/dialog/54c5a89c_2.jsonl#L3-L4]].
- Rapid excluders utilize excess nitrogenous compounds outcompeting filamentous invaders whereas deliberate pace setters stabilize existing equilibria resisting sudden chemical shocks better [[session/dialog/54c5a89c_2.jsonl#L3-L4]].
- Sequential integration schedules prevent catastrophic osmotic pressure changes shocking sensitive epiphytes necessitating incremental rollout phases observing survival rates first [[session/dialog/54c5a89c_2.jsonl#L3-L4]].

## Dwarf Hairgrass Implementation Guide
- Functions effectively grounding compositions replicating terrestrial lawns extending seamlessly throughout bottom sectors maximizing visibility angles upward correcting distortion problems typical rectangular enclosures [[session/dialog/54c5a89c_2.jsonl#L5-L6]].
- Anticipate vertical limitations reaching heights measuring approximately two to three inches potentially obstructing lower air pockets unless controlled properly [[session/dialog/54c5a89c_2.jsonl#L5-L6]].
- Procure genetically compressed lineages specifically bred minimizing stature attributes selecting *Eleocharis acicularis* ‘Mini’ variant alongside *Eleocharis parvula* hybrid alternatives guaranteeing uniformity standards met consistently [[session/dialog/54c5a89c_2.jsonl#L5-L6]].
- Deploy modular cluster formations spacing insertion nodes uniformly distributed distances ranging anywhere between one inch versus two inches separating individual centers maintaining perimeter setbacks equaling two to three inches away from pane edges preventing accidental damage [[session/dialog/54c5a89c_2.jsonl#L5-L6]].
- Execute periodic clipping routines targeting sustained vertical profiles capped precisely one to two inches tall preserving aesthetic neatness regulating photosynthesis efficiency evenly [[session/dialog/54c5a89c_2.jsonl#L5-L6]].
- Carve designated thoroughfares traversing densely packed sectors cutting linear channels guaranteeing uninterrupted highway links connecting distant corners preventing claustrophobic confinement sensations affecting flocking dynamics [[session/dialog/54c5a89c_2.jsonl#L5-L6]].

## Driftwood Placement Protocol
- Introduces complex geometric structures generating artificial forest ecosystems mimicking natural riparian landscapes providing multi-tiered nesting sites concealing fragile juveniles escaping predation attempts [[session/dialog/54c5a89c_2.jsonl#L7-L8]].
- Chemical interactions releasing polyphenolic substances staining liquid medium yellowish brown tint altering transparency decreasing readability disturbing optical calibration sensors mounted externally [[session/dialog/54c5a89c_2.jsonl#L7-L8]].
- Biological breakdown processes decomposing lignin fragments generating colloidal suspensions interfering gill function irritating mucosal linings promoting nuisance moss colonies proliferating excessively unchecked [[session/dialog/54c5a89c_2.jsonl#L7-L8]].
- Commodity acquisition channels restrict purchases solely verified retail suppliers certifying sterilization treatments applied removing hazardous pesticides residual toxins embedded deep within cellular matrixes [[session/dialog/54c5a89c_2.jsonl#L7-L8]].
- Sanitation execution requires thermal treatment regimes involving immersion baths lasting duration spanning sixty minutes minimum extending maximum two hundred twenty minutes ensuring complete pathogen eradication saturation penetration [[session/dialog/54c5a89c_2.jsonl#L7-L8]].
- Alternative cold preparation techniques utilizing ambient room temperatures soaking durations calculated spanning fourteen days baseline extending twenty-eight day maximum thresholds verifying clarity improvements achieved steadily [[session/dialog/54c5a89c_2.jsonl#L7-L8]].
- Phased introduction methodologies deploying single unit installations initially tracking diagnostic test strips reading baseline indicators continuously comparing results post-placement intervals identifying deviations early warning signs indicating systemic imbalance developing rapidly [[session/dialog/54c5a89c_2.jsonl#L7-L8]].
- Routine maintenance commitments scheduling frequent partial replacement events calculating percentages falling anywhere between ten percent ceiling fifteen percent floor executing frequency counts aligned monthly calendars distributing tasks weekly cadences stabilizing homeostatic conditions effectively [[session/dialog/54c5a89c_2.jsonl#L7-L8]].

## Ceramic Ornament Selection
- Manufactured constituents consist predominantly fired clay mixtures yielding exceptionally rigid frameworks resisting corrosion degradation long-term exposure moist environments permanently [[session/dialog/54c5a89c_2.jsonl#L9-L10]].
- Chemical inertness properties eliminate leaching risks dissolving trace metal ions contaminating reservoir supplies endangering physiological development stages disrupting endocrine regulatory mechanisms governing reproduction cycles [[session/dialog/54c5a89c_2.jsonl#L9-L10]].
- Surface texture characteristics enable effortless wiping operations scrubbing abrasive pads effortlessly removing adherent sludge deposits without damaging glaze finishes exposing porous cores underneath [[session/dialog/54c5a89c_2.jsonl#L9-L10]].
- Catalog availability encompasses numerous thematic representations imitating organic forms resembling aquatic flora constructs simulating fantasy narratives portraying buried riches guarded fiercely mythical guardians defending vast hoards amassed centuries past sculpted realistically capturing details accurately [[session/dialog/54c5a89c_2.jsonl#L9-L10]].
- Structural flaw inspection mandates rigorous examination screenings rejecting inventory items exhibiting irregularities manifesting protruding spikes capable piercing delicate fin membranes slicing through elastic tissue causing hemorrhagic infections spreading systemically if left untreated promptly [[session/dialog/54c5a89c_2.jsonl#L9-L10]].
- Entrance geometry optimization prioritizes aperture designs boasting dual entry portals enabling escape routes backing exits facilitating emergency retreats securing safety assurances instantly [[session/dialog/54c5a89c_2.jsonl#L9-L10]].
- Spatial density management enforces strict limits prohibiting excessive clustering confining movements restricting lateral translations forcing collisions impacting collision detection algorithms malfunctioning unpredictably resulting injuries accumulating overtime reducing lifespan expectations significantly [[session/dialog/54c5a89c_2.jsonl#L9-L10]].
- Post-production cleaning procedures dictate preliminary rinsing sequences flushing loose particulates suspended inside cavities utilizing preconditioned reservoir fluids stripped halogen additives neutralizing oxidative compounds protecting mucous barriers lining respiratory tracts absorbing oxygen diffused passively across membranes [[session/dialog/54c5a89c_2.jsonl#L9-L10]].
