---
description: This note captures the schema, context, and research objectives of a
  soccer referee-player dataset collected for the 2012-2013 season across England,
  Germany, France, and Spain. The goal is to determine if skin tone correlates with
  red card frequency. Additionally, it records the resolution of a Pandas deprecation
  issue where users transitioned from using the obsolete DataFrame.append method to
  pd.concat for expanding row counts from the dyad level to the game level.
name: soccer-bias-dataset-and-pandas-expansion
session_id: sharegpt_bvLUGdm_0
source_conversation: '[[session/dialog/sharegpt_bvLUGdm_0.jsonl]]'
---

## Dataset Context and Objectives

**Data Origin and Scope**
*   The dataset was obtained from a sports statistics company, covering the 2012-2013 season.
*   Population includes all male first-division soccer players (N = 2053) from England, Germany, France, and Spain, along with the professional referees (N = 3147) who officiated these players throughout their careers [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].
*   The total number of player-referee dyads recorded is 146028 [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].

**Research Objective**
*   The primary analytical goal is to investigate whether soccer players with dark skin tones are more likely to receive red cards from referees compared to those with light skin tones [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].

**Implicit and Explicit Bias Measures**
*   For each referee country, implicit bias scores were calculated using a race Implicit Association Test (IAT); higher values indicate faster white/good, black/bad associations [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].
*   Explicit bias scores were measured using a racial thermometer task; higher values indicate greater feelings of warmth toward whites versus blacks [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].

## Variable Schema

**Player and Game Attributes**
*   `playerShort`, `player`: Unique identifiers and names (e.g., julien-feret, Maxime Gonalons) [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].
*   `club`, `leagueCountry`: Player team and country of play (e.g., Paris Saint-Germain, Spain) [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].
*   `birthday`, `height`, `weight`: Demographic and physical attributes (e.g., 13.11.1985, 175.0 cm, 69.0 kg) [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].
*   `position`: Detailed playing role (e.g., Left Midfielder) [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].

**Match Statistics (Dyad Level)**
*   The following metrics count occurrences between a specific player and referee during their interactions: `games`, `victories`, `ties`, `defeats`, `goals`, `yellowCards`, `yellowReds`, `redCards` [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].

**Skin Tone Ratings**
*   Player photos (available for 1586 of 2053 players) were rated by two independent raters. `rater1` and `rater2` utilize a 5-point scale ranging from very light to very dark skin, with neither as the center value [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].

**Referee and Country Metadata**
*   `refNum`, `refCountry`: Unique anonymized IDs for the referee and their respective country [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].
*   `meanIAT`, `nIAT`, `seIAT`: Mean, sample size, and standard error of the implicit bias score for the referee's country [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].
*   `meanExp`, `nExp`, `seExp`: Mean, sample size, and standard error of the explicit bias score for the referee's country [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L1]].

## Python Pandas Implementation Notes

**Objective: Unit of Observation Expansion**
*   The analytical task involves transforming the dataframe's unit of observation from a "player-referee dyad" (where one row represents multiple matches) to a "player-referee-game" observation [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L3]].
*   For instance, a single dyad entry containing 8 games must be duplicated into 8 individual rows representing the individual matches [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L3]].

**Implementation Steps**
*   A new column named `games` is created by summing `victories`, `ties`, and `defeats` [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L4]].
*   Iterate through the original dataframe, copy each row, and duplicate it a number of times equivalent to the `games` value [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L4]].

**Resolving Pandas Deprecation Warnings**
*   Initial attempts using `expanded_df = expanded_df.append(new_row)` triggered a `FutureWarning` indicating the method is deprecated and will be removed [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L5]].
*   The recommended approach resolves this deprecation by replacing `.append()` with `pd.concat([expanded_df, new_row], ignore_index=True)` [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L6]].

**Complete Implementation Code**
```python
import pandas as pd

df = pd.read_csv('CrowdstormingDataJuly1st.csv')

# First, create a column counting the number of games played by each player-referee dyad
df['games'] = df['victories'] + df['ties'] + df['defeats']

# Initialize a new empty dataframe to hold the expanded observations
expanded_df = pd.DataFrame()

# Iterate through each player-referee dyad and duplicate the observation for each game played
for index, row in df.iterrows():
    for i in range(row['games']):
        # Create a copy of the current row
        new_row = row.copy()
        # Append the new row safely using pd.concat instead of the deprecated .append()
        expanded_df = pd.concat([expanded_df, new_row], ignore_index=True)

# Drop the games column from the final dataframe as it is no longer needed
expanded_df = expanded_df.drop(columns=['games'])

# Verify the expanded row count matches the total number of games played
print(len(expanded_df))
```
<br/>
*   *Note on performance:* Because the operation significantly increases the dataset size (memory issues may occur), running the expansion might require extended processing time [[session/dialog/sharegpt_bvLUGdm_0.jsonl#L4]].
