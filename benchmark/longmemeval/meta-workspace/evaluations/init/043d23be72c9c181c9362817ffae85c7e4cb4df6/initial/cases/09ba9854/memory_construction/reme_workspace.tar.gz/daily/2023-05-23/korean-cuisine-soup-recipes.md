---
description: A record of culinary planning on 2023-05-23 where the user explored new
  soup varieties beyond prior attempts at creamy broccoli, roasted butternut squash,
  and classic chicken noodle. The conversation focused heavily on developing a toolkit
  for Korean cuisine, detailing complete recipes and operational steps for Doenjang
  Jjigae (fermented soybean paste soup), homemade Baechu Kimchi (brining, paste blending,
  ambient fermentation protocols), and Jjamppong (spicy seafood noodle construction).
  Included companion serving suggestions and an expanded taxonomy of Korean broth-based
  dishes.
name: korean-cuisine-soup-recipes
session_id: 4079270e_2
source_conversation: '[[session/dialog/4079270e_2.jsonl]]'
---

## Culinary Exploration Overview
- On 2023-05-23, the user requested new soup recipes following a cooking session around 2023-04-23 featuring creamy broccoli, roasted butternut squash, and classic chicken noodle soups. [[session/dialog/4079270e_2.jsonl#L1-L1]]
- Initial recommendations encompassed Spicy Pumpkin Soup, Roasted Cauliflower Soup with Turmeric, Ethiopian Misir Wot, Smoky Black Bean Soup, Thai Coconut Soup, Peruvian Cilantro Soup, Butternut Squash and Apple Soup, and Ukrainian Borscht. [[session/dialog/4079270e_2.jsonl#L2-L2]]
- The dialogue narrowed scope entirely to Korean culinary preparations: Doenjang Jjigae, side dishes, homemade Kimchi, and Jjamppong. [[session/dialog/4079270e_2.jsonl#L3-L12]]

## Doenjang Jjigae (Korean Fermented Soybean Paste Soup)
- User requested a simplified preparation guide for Doenjang Jjigae to initiate familiarity with Korean fermented soybean paste soups.
  - Essential Components: 2 tablespoons doenjang (Korean fermented soybean paste), 2 tablespoons gochujang (Korean chili paste), minced garlic, diced onion, vegetable broth or anchovy broth, diced zucchini, carrots, potatoes, toasted sesame oil, green onions, Korean chili flakes (optional for heat).
  - Procedure: If starting with solid doenjang, crumble into a bowl and hydrate with 2 tablespoons water. Heat sesame oil and sauté garlic and onions. Introduce the gochujang and doenjang mixture, cooking briefly until fragrant. Incorporate broth and diced vegetables, simmering for 15-20 minutes until vegetables soften. Finish with green onion garnish and optional sesame oil drizzle.
[[session/dialog/4079270e_2.jsonl#L3-L6]]
- Recommended Accompaniments: Serve with steamed rice, noodles, or distinct Korean salad variations including Oi-sobagi (Cucumber and Onion Salad), Kongnamul Muchim (Bean Sprout Salad), Boiled Spinach (Sigeumchi), and Steamed Eggs (Gyeranjjim).

## Homemade Kimchi (Baechu Kimchi)
- User chose to produce Kimchi from scratch to function as a complementary side dish for the Doenjang Jjigae meal.
  - Essential Components: 2 lbs napa cabbage cut into 2-inch pieces, coarse salt, Korean chili flakes (gochugaru), minced garlic, fish sauce, gochujang, rice vinegar, water, chopped green onions, toasted sesame seeds.
  - Procedure: Create a coarse salt brine solution and submerge cut cabbage for 2-3 hours at room temperature. Rinse thoroughly to eliminate excess brine and drain completely. Process garlic, chili flakes, fish sauce, gochujang, vinegar, and water in a blender into a smooth application paste. Toss drained cabbage and green onions uniformly with the paste. Transfer to a glass jar packing firmly to release trapped air pockets while preserving 1 inch of vertical space.
  - Fermentation Rules: Seal the container and allow the mixture to undergo ambient fermentation at temperatures ranging between 70°F and 75°F for a duration of 1 to 5 days depending on preferred sourness and tang. Store finished product within the refrigerator to arrest further microbial activity, maintaining edibility for multiple weeks.
[[session/dialog/4079270e_2.jsonl#L7-L8]]

## Additional Korean Soup Variety Catalog
- Requested expansion into wider Korean soup varieties yielded categorized recommendations spanning distinct regional styles and ingredient bases.
  - Notable Entries: Jjamppong (hot seafood noodle soup), Haemultang (robust spicy seafood stew), Miyeokguk (traditional ceremonial birthday seaweed and meat broth), Samgyetang (restorative ginseng-infused poultry soup intended for summer consumption), Jjolmyeon (bouncy cold noodle soup with sweet-spicy liquid base), Budae Jjigae (communal spicy kimchi stew), and Gyeran-guk (delicate poached egg and vegetable consommé).
[[session/dialog/4079270e_2.jsonl#L9-L10]]

## Jjamppong (Spicy Seafood Noodle Soup)
- Demonstrating preference for high-intensity spice profiles, user sought step-by-step instructions for constructing Jjamppong using available seafood inventory and pasta variants.
  - Essential Components: Vegetable oil, diced onion, minced garlic, approximately 1 cup mixed shellfish/crustaceans (clams, mussels, squid, shrimp), 2 cups anchovy broth (or alternative fish stock), 1 cup Korean chili flakes, gochujang, soy sauce, granulated sugar, ground black pepper, salt, 200 grams wheat noodles (specifically ramyeon or Japanese udon), fresh scallions for finish.
  - Procedure: Wash selected marine components under chilled running water and portion appropriately. Melt oil in heavy-bottomed vessel over medium thermal input; fry diced onion until translucent before introducing minced garlic. Dump combined seafood into the pot alongside anchovy broth, gochugaru, gochujang, soy sauce, sugar, and dry seasonings. Boil aggressively then lower temperature to maintain rolling simmer for 10 to 15 minutes until protein denaturation completes. Meanwhile, boil noodles separately matching manufacturer guidelines, drain liquids completely. Merge heated noodles directly into the hot seafood concentrate, re-taste adjusting salinity levels, plate immediately topped with sliced green onion crowns.
[[session/dialog/4079270e_2.jsonl#L11-L12]]
