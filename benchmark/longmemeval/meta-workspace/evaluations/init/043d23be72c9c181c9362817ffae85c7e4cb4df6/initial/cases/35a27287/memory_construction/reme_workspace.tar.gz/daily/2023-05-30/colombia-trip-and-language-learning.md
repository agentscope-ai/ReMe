---
description: Planning a multi-week trip to Medellín, Colombia, including detailed
  culinary recommendations (Bandera Colombiana, Ajiaco, Lechona, etc.), local market
  visitation strategy (Mercado de San Andrés, Mercado Minorista, Mercado Bazurto),
  and street food safety tips. Additionally documents Spanish language acquisition
  progress under a tutor named Juan, recommended digital platforms for language exchange
  (Tandem, HelloTalk, iTalki), and strategic approaches to secure a native speaker
  partnership through Juan's professional network.
name: colombia-trip-and-language-learning
session_id: 880ee13e
source_conversation: '[[session/dialog/880ee13e.jsonl]]'
---

## Travel Plans and Destination
- On 2023-05-30, the user planned a trip to Colombia and confirmed intentions to reside in Medellín for a duration of a few weeks.
[[session/dialog/880ee13e.jsonl#L1-L1,L5-L5]]

## Colombian Cuisine Recommendations
- **Bandera Colombiana**: Traditional plate consisting of rice, beans, ground beef, chorizo, fried egg, plantain, and avocado.
- **Ajiaco**: Hearty chicken soup prepared with potatoes, corn, herbs, and cream.
- **Empanadas**: Meat-filled pastries (commonly beef, chicken, cheese, or chorizo), available fried or baked.
- **Lechona**: Roasted pork dish originating from Tolima, stuffed with rice, peas, and spices; served with boiled cassava and avocado.
- **Sancocho**: Rich stew made with beef, chicken, or fish combined with vegetables and root vegetables such as yuca and plantain.
- **Arroz con Pollo**: Chicken and rice comfort food frequently accompanied by vegetables and spices.
- **Patacones**: Fried green plantains that have been physically flattened.
- **Chicharrón**: Deep-fried pork rinds.
- **Tamales**: Steamed corn dough filled with meat, cheese, or vegetables and wrapped in banana leaves.
- **Arepa de Huevo**: Breakfast staple featuring a cornmeal flatbread filled with scrambled eggs, chorizo, and cheese.
- **Ceviche**: Fresh seafood marinated in citrus juices, onions, and spices.
- **Tortas**: Sandwiches constructed with crusty bread, meat (chicken, beef, or chorizo), cheese, and vegetables.
- **Fruits**: Guayabas (guavas), maracuyá (passionfruit), pitahaya (dragon fruit), and guanábana (soursop).
- **Drinks**: Agua de Panela (sugarcane juice), Limonada (fresh limeade), coffee, and hot chocolate.
- **Desserts**: Arequipe (caramel), Brevas con Cajeta (caramelized plantains with sweetened condensed milk), Rosquillas (sweet fried doughnuts), and Churros con Chocolate.
[[session/dialog/880ee13e.jsonl#L2-L2]]

## Local Markets and Street Food
- **Mercado de San Andrés (Bogotá)**: Situated in the La Candelaria district; offers produce, meats, and traditional prepared items including tamales and ajiaco.
- **Mercado Minorista (Medellín)**: Located in the El Poblado neighborhood; specializes in local snacks, fruits, fresh orange juice, and arepas.
- **Mercado Bazurto (Cartagena)**: Historic marketplace renowned for fresh seafood, fried fish preparations, and coconut rice.
- **Street Food Highlights**: Patacones and Chicharrón distributed at bus terminals and sports venues; Arepas de Huevo available at morning carts; Churros con Chocolate sourced from urban vendors; Empanandas obtainable at bakeries and sidewalks.
- **Procurement and Dining Guidelines**: Prioritize stalls occupied by local patrons for safety and authenticity, consume fresh seasonal juices, negotiate bulk commodity pricing, and actively engage with the vibrant public environments.
[[session/dialog/880ee13e.jsonl#L4-L4]]

## Language Exchange Platforms and Digital Tools
- **Mobile Applications**: Tandem (facilitates text, voice, and video interactions with correction mechanisms); HelloTalk (mirrors Tandem functionality with integrated grammar tools); iTalki (bridges users with certified tutors and exchange partners).
- **Web-Based Portals**: Conversation Exchange, My Language Exchange, and Language Exchange.org (operate as databases for establishing text, email, or voice communication partnerships).
- **Community Organizers**: Medellín Language Exchange (Facebook group host) and Language Exchange Medellín (Meetup group organizer).
- **Auxiliary Learning Assets**: Duolingo, SpanishDict, and the "Coffee Break Spanish" audio podcast.
[[session/dialog/880ee13e.jsonl#L6-L6]]

## Tutor Collaboration and Partnership Development
- The user participated in language exchange coursework at an unspecified local institution under the guidance of a tutor named Juan, who originates from Colombia.
- Juan delivered direct instructional commentary regarding Colombian social norms and historical traditions, providing contextual frameworks for linguistic comprehension.
- The user encountered persistent difficulties locating a native Spanish speaker for reciprocal practice via digital channels and initiated inquiries to Juan regarding potential introductions to English speakers seeking Spanish conversation.
- Operational strategies discussed encompassed soliciting peer referrals, structuring mutually beneficial tutoring arrangements (English instruction for Juan's students in exchange for Spanish dialogue practice), and formally proposing institutional meetups at the academic venue.
- Strategic advantages identified included logistical convenience, verified partner reliability, enhanced cultural exposure beyond classroom materials, and sustained motivational support networks.
- Status update on 2023-05-30 indicated measurable advancement in Spanish fluency, high satisfaction levels regarding instructional quality, and strong appreciation for cross-cultural educational value.
- Supplementary pedagogical advice involved incorporating domestic musical compositions and audiovisual productions (television series, feature films) into daily study routines.
[[session/dialog/880ee13e.jsonl#L3-L3,L7-L12]]
