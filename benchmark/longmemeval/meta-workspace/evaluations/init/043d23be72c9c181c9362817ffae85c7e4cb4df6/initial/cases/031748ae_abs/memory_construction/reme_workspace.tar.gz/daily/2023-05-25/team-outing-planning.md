---
description: 'Detailed planning record for a team outing at City View Rooftop using
  the Corporate Team Building Package ($500 weekday afternoon rate, 2-hour private
  rental, outdoor games, drink tickets). Contact established with Events Manager Samantha.
  Event agenda targets a 2-3 hour duration on a weekday afternoon/evening, balancing
  structured team-building exercises with free-form outdoor gaming (Giant Jenga, Cornhole,
  Ring Toss, Giant Chess) and snack service. Total confirmed attendance is 5 participants:
  the lead Senior Software Engineer, 3 fellow engineers, and the team manager Rachel.'
name: team-outing-planning
session_id: answer_8748f791_abs_1
source_conversation: '[[session/dialog/answer_8748f791_abs_1.jsonl]]'
---

## Venue Selection and Booking Details [[session/dialog/answer_8748f791_abs_1.jsonl#L3-L6]]
- **Chosen Venue**: City View Rooftop is located in a trendy neighborhood and offers breathtaking city views. It can accommodate groups up to 20 people and provides outdoor games including Giant Jenga and Ring Toss.
- **Venue Contact**: Samantha is the Events Manager. Reachable via email at events@cityviewrooftop.com or by phone at 555-555-5555.
- **Booking Package**: The Corporate Team Building Package pricing starts at $500 for a weekday afternoon event. This package includes a 2-hour private rooftop rental, a selection of outdoor games (including Giant Jenga), and a complimentary drink ticket for each guest, accommodating up to 20 people.

## Event Format and Agenda [[session/dialog/answer_8748f791_abs_1.jsonl#L7-L8]]
- **Duration and Timing**: Plan for a 2-3 hour event scheduled during a weekday afternoon or early evening to avoid crowds.
- **Activity Structure**: Combine structured teamwork activities (such as scavenger hunts or team trivia contests) with free-form mingling time, pacing in 30-45 minute segments. Outdoor games will include Giant Jenga, Cornhole, Ring Toss, and Giant Chess. Bring additional board games or card games for a designated area.
- **Food and Drinks**: Provide light snacks and appetizers such as veggie platters, cheese and charcuterie, and sweet treats. Offer soft drinks, beer, wine, and water to cater to different tastes and maintain hydration.
- **Photography**: Set up a selfie station or hire a photographer to capture memories and encourage team bonding.

## Team Composition and Roles [[session/dialog/answer_8748f791_abs_1.jsonl#L10-L12]]
- **User Role**: The user holds a new role as Senior Software Engineer and leads a team of 4 engineers. All 4 engineers will attend the outing, including the user.
- **Manager Attending**: Rachel is the user's manager and will join the outing.
- **Total Attendees**: There will be 5 participants total for the team outing: 4 engineers from the user's team and 1 manager.
