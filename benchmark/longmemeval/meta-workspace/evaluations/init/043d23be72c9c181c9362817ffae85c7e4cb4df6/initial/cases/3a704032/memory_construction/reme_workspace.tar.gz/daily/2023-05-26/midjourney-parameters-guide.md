---
description: Reference documentation for the Midjourney bot parameters `--seed`, `--stop`,
  and `--stylize` (or `--s`), detailing their functions, accepted value ranges, default
  values across different model versions (V1-V4, niji, test), deterministic versus
  non-deterministic behaviors, and methods for retrieving job seed numbers.
name: midjourney-parameters-guide
session_id: sharegpt_zvmX9pX_29
source_conversation: '[[session/dialog/sharegpt_zvmX9pX_29.jsonl]]'
---

# Midjourney Bot Parameters

## --seed Parameter [[session/dialog/sharegpt_zvmX9pX_29.jsonl#L1-L1]]
- **Purpose**: Provides a starting point for image generation based on visual noise; functions similarly to television static. Influences the initial image grid.
- **Parameters**: Specified via `--seed` or `--sameseed`.
- **Accepted Values**: Whole numbers ranging from 0 to 4294967295.
- **Behavior by Model Version**:
  - **Non-Deterministic (Versions 1, 2, 3, test, testp)**: Using the same prompt and seed produces similar, but not identical, images.
  - **Deterministic (Version 4, niji)**: Using the exact same prompt, seed, and parameters produces identical images.
- **Operational Differences**:
  - **--seed**: Generates a separate random seed for each image within the grid.
  - **--sameseed**: Applies a single large random noise field across all images in the initial grid, resulting in very similar generated images.
- **Retrieving a Job's Seed Number**:
  - Discord Emoji Reaction: React to the Job message with the envelope emoji (✉️).
  - Show Command: Copy a past Job ID and run `/show <Job ID #>`, then react to the regenerated job with the envelope emoji.
- **Usage Examples**:
  - `/imagine prompt celadon owl pitcher --seed 123`

## --stop Parameter [[session/dialog/sharegpt_zvmX9pX_29.jsonl#L3-L3]]
- **Purpose**: Allows the user to finish a Job partway through the generation process.
- **Accepted Values**: Integer values from 10 to 100.
- **Visual Impact**: Lower values result in blurrier and less detailed results compared to higher values.
- **Upscaling Interaction**:
  - The parameter does not affect a Job while it is currently upscaling.
  - Using a lower stop value creates a softer initial grid image, which affects the detail level in the final upscaled result.
- **Usage Examples**:
  - `/imagine prompt splatter art painting of acorns --stop 90`
  - Comparative examples exist for values 20, 80, 90, and 100.

## --stylize / --s Parameter [[session/dialog/sharegpt_zvmX9pX_29.jsonl#L4-L4]]
- **Purpose**: Controls the intensity of the bot's internal training regarding artistic color, composition, and forms.
- **Usage Trade-offs**:
  - **Low Stylization**: Images closely match the textual prompt but appear less artistic.
  - **High Stylization**: Images become very artistic but lose connection to specific details in the prompt.
- **Configuration Methods**:
  - **Prompt Syntax**: Append `--stylize` or `-s` followed by a value to the prompt. Example: `/imagine prompt illustrated figs --s 100`.
  - **Menu Interface**: Use the `/settings` command to set a preferred value globally.
- **Values and Defaults by Model**:
  - **Model Version 4 (Default)**: Default value is `100`. Accepted range is `0–1000`.
  - **Model Version 3**: Default value is `2500`. Accepted range is `625–60000`.
  - **Model Test / Testp**: Default value is `2500`. Accepted range is `1250–5000`.
  - **Model niji**: Stylization is not applicable.
- **Common Stylization Settings**:
  - `--stylize 50` (Low)
  - `--stylize 100` (Default)
  - `--stylize 250` (Medium)
  - `--stylize 750` (Very High)
