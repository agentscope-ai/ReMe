---
description: Archival data regarding the 'Mad Gasser' incidents, including verified
  quotes from witnesses Willamina 'Blackie' Haisley and Harold A. Mangold, analysis
  of potential chemical agents such as chlorine and mustard gas, hypotheses on distribution
  methods involving spray devices, systemic flaws in the investigation including inter-agency
  friction, profiles of cleared suspects Farley Llewellyn and Theodore Durrant, cross-referenced
  examples of mass hysteria phenomena ranging from Salem to Tanganyika, and biographical
  summaries of prominent figures native to Mattoon, Illinois such as Burl Ives and
  William L. Enloe.
name: mad-gasser-case-analysis-and-regional-facts
session_id: sharegpt_kFcVnSx_15
source_conversation: '[[session/dialog/sharegpt_kFcVnSx_15.jsonl]]'
---

## Verified Statements Regarding the 1944 Incidents
- Willamina "Blackie" Haisley, a resident of Mattoon experiencing reported symptoms in 1944, described the events as the most unusual occurrence she had ever encountered, comparing the nature of the incident to something from a storybook.
- Harold A. Mangold, a gas company inspector who conducted investigations into the episodes, stated definitively that the substance experienced was not standard natural gas but rather a significantly more potent agent.
- W.H. Harrison, editor of the Mattoon Daily Journal Gazette, characterized the individual responsible as the greatest single threat to health and safety in the community's recorded history.
[[session/dialog/sharegpt_kFcVnSx_15.jsonl#L1-L1]]

## Potential Chemical Constituents from Wartime Facilities
- Investigators considered the possibility that chemicals produced at local war plants during World War II were responsible for the symptoms.
- Specific substances analyzed as potential culprits included chlorine gas, historically utilized as a weapon; mustard gas, a blistering agent used by Allied and Axis forces; phosgene gas; hydrogen cyanide, employed in industrial fumigation and other capacities; and ammonia, frequently used for refrigeration and explosives production.
[[session/dialog/sharegpt_kFcVnSx_15.jsonl#L3-L3]]

## Documented Cases of Mass Psychological Events
- Historical precedents for mass hysteria include the Salem witch trials of 1692, which resulted in twenty executions following accusations against over two hundred individuals driven by complex social and religious factors.
- European outbreaks of dancing mania occurred throughout the 14th and 15th centuries, causing groups of individuals to dance uncontrollably for days.
- A wave of satanic ritual abuse accusations swept through the United States during the 1980s and 1990s, leading to wrongful convictions based on fabricated evidence.
- The Tanganyika laughter epidemic began in 1962 at a Tanzanian boarding school, spreading to hundreds of individuals and disrupting communities for months.
- The Pokémon panic emerged in Japan in 1997 when rumors linked the video game to children's seizures, resulting in bans despite subsequent debunking.
[[session/dialog/sharegpt_kFcVnSx_15.jsonl#L5-L5]]

## Prominent Individuals Associated with Mattoon
- Burl Ives, a renowned folk singer and actor known for his distinctive voice and contributions to American culture, was born in Jasper County in 1909 and passed away in 1995.
- John Malkovich, an acclaimed actor and director known for productions such as "Being John Malkovich," was born in Christopher, Illinois, and spent his childhood in nearby Benton.
- William L. Enloe, born in Mattoon in 1917, became a recognized World War II hero awarded the Medal of Honor for actions during the Battle of Okinawa before passing away in 1997.
- Robert Ridgway, a respected ornithologist who grew up in Mattoon, was born in Mount Carmel, Illinois in 1850 and died in 1929.
- Michael Finke, a professional basketball player active in the National Basketball Association during the 1970s and 1980s, was born in Mattoon in 1952.
[[session/dialog/sharegpt_kFcVnSx_15.jsonl#L7-L7]]

## Hypotheses Regarding Substance Dispersion Methods
- Theoretical models proposed that the perpetrator utilized specialized equipment, such as spray guns or devices shooting vapor into dwellings.
- Alternative mechanisms suggested release through ventilation systems or wall penetrations, while some eyewitness accounts mentioned a "flute-like" instrument used to project the vapor.
- Police investigators hypothesized that the substance might have been a heavy gas comparable to carbon disulfide pooling in low areas, or a pulmonary irritant similar to tear gas causing choking reactions.
[[session/dialog/sharegpt_kFcVnSx_15.jsonl#L9-L9]]

## Systemic Deficiencies in Law Enforcement Response
- The primary obstacle hindering resolution was a complete absence of physical evidence, preventing definitive identification of the perpetrator.
- Witness testimonies were fundamentally unreliable due to contradictory descriptions regarding the suspect's stature, appearance, and usage of facial coverings.
- Public anxiety generated numerous false alarms and hoaxes, complicating the separation of genuine incidents from unrelated occurrences.
- Coordination failures between the Mattoon Police Department, the Illinois State Police, and the Federal Bureau of Investigation prevented the development of a unified investigative strategy.
[[session/dialog/sharegpt_kFcVnSx_15.jsonl#L11-L11]]

## Primary Suspects Under Scrutiny
- Farley Llewellyn was investigated as a former employee discharged for stealing chemicals from a war plant; despite vehicle sightings near crime scenes, he possessed valid alibis and was cleared.
- Theodore Durrant, a traveling salesman present in the region during the attacks, was questioned regarding witness statements matching his description but was exonerated due to confirmed alibis.
- An unverified theory suggested the involvement of a mentally unstable individual observed wandering the city wearing a gas mask and carrying a flashlight.
- Authorities also posited that some reported incidents were deliberate pranks or copycat attempts by individuals capitalizing on the prevailing public fear.
[[session/dialog/sharegpt_kFcVnSx_15.jsonl#L13-L13]]
