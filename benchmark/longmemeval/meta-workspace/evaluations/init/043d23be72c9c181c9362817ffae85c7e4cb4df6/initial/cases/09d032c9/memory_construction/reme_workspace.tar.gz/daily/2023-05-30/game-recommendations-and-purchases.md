---
description: Recommendations for action-adventure titles similar to The Last of Us,
  emphasizing multi-platform availability across PC and consoles. Includes evaluation
  criteria for purchasing Resident Evil Village immediately versus waiting for price
  reductions and DLC accumulation.
name: game-recommendations-and-purchases
session_id: 87e8ec02
source_conversation: '[[session/dialog/87e8ec02.jsonl]]'
---

## Action-Adventure Game Recommendations [[session/dialog/87e8ec02.jsonl#L1-L4]]
- User requests action-adventure games resembling The Last of Us [[session/dialog/87e8ec02.jsonl#L1-L1]]. User successfully replayed The Last of Us Part II on hard difficulty [[session/dialog/87e8ec02.jsonl#L1-L1]]. Suggested titles include Uncharted 4: A Thief's End, Horizon Zero Dawn, God of War (2018), Days Gone, The Witcher 3: Wild Hunt, Dying Light, Ghost of Tsushima, Death Stranding, Tomb Raider (2013), and Sea of Solitude [[session/dialog/87e8ec02.jsonl#L2-L2]].
- User prefers multi-platform releases across PC and consoles instead of console exclusives [[session/dialog/87e8ec02.jsonl#L3-L3]]. Alternate recommendations include Tomb Raider franchise installments (Tomb Raider 2013, Rise of the Tomb Raider, Shadow of the Tomb Raider), Dishonored stealth-action series, Assassin's Creed Odyssey and Valhalla, Far Cry 5 and New Dawn, Just Cause 4, Days Gone (originally PS4 exclusive, now available on PC), and survival horror entries featuring strong action-adventure components such as Resident Evil 7: Biohazard and Resident Evil Village [[session/dialog/87e8ec02.jsonl#L4-L4]].

## Resident Evil Village Purchase Consideration [[session/dialog/87e8ec02.jsonl#L5-L6]]
- User watched Let's Play videos of Resident Evil Village and plans to decide between immediate purchase and waiting for a discount [[session/dialog/87e8ec02.jsonl#L5-L5]]. Acquiring the game immediately offers deep immersion, substantial sound design, visual fidelity, high replay value through varied difficulty settings and the Mercenaries mode, and early participation in community discourse [[session/dialog/87e8ec02.jsonl#L6-L6]]. Deferring purchase suits restricted budgets, captures future free DLC expansions released by Capcom, and permits completion of existing backlog titles first [[session/dialog/87e8ec02.jsonl#L6-L6]].
