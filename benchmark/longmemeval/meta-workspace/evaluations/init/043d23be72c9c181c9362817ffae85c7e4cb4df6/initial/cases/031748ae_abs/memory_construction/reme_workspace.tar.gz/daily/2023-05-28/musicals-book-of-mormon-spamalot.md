---
description: A session recording musical theatre recommendations resembling The Book
  of Mormon (which the user began listening to on 2023-05-28), followed by detailed
  inquiries regarding the Spamalot touring production. Topics covered include Spamalot's
  international and domestic schedules, ticketing resources, Tim Hatley's set and
  costume design (compared favorably by the user to The Great and Bridgerton), the
  musical score by Eric Idle and John Du Prez, character profiling of the Lady of
  the Lake, and the specific roster of the current touring cast and creative team
  personnel.
name: musicals-book-of-mormon-spamalot
session_id: feba9363_1
source_conversation: '[[session/dialog/feba9363_1.jsonl]]'
---

### Musical Recommendations & User Preferences
- On 2023-05-28, the user began listening to the soundtrack for *The Book of Mormon* and requested recommendations for musicals featuring similar humor, satire, and irreverent styles.
- Recommended productions included *South Park: Bigger, Longer & Uncut*, *Avenue Q*, *The Producers*, *Spamalot*, *Urinetown*, *Something Rotten!*, *The Full Monty*, *Young Frankenstein*, *The Addams Family*, and *Bat Out of Hell*.
- The user confirmed having previously attended performances of *Avenue Q* and *The Producers*, finding both productions hilarious.
- Creators Trey Parker and Matt Stone were identified as the writers behind *South Park* and *The Book of Mormon*.[[session/dialog/feba9363_1.jsonl#L1-L2]]

### Spamalot Tour Schedule & Ticket Information
- The UK and Ireland Tour 2023 included scheduled stops in London, Manchester, Birmingham, and Dublin.[[session/dialog/feba9363_1.jsonl#L3-L4]]
- An anticipated United States Tour for the 2023–2024 season was discussed, though specific city and date announcements had not yet been finalized at the time of the conversation.
- Historical and planned international runs have taken place in Australia, Canada, and Germany.
- Official ticketing channels recommended include ATG Tickets, Ticketmaster, and Telecharge.
- Tracking official updates via Facebook, Twitter, and Instagram is advised for new tour announcements.

### Production Design (Set & Costumes)
- The user expressed strong appreciation for large-scale visual aesthetics, citing the production design of *The Great* and *Bridgerton* as examples of preferred grandeur.[[session/dialog/feba9363_1.jsonl#L5-L6]]
- Both the set and costume designs for the stage production of *Spamalot* were executed by designer Tim Hatley.
- Core set elements consist of King Arthur's Castle (including a functional drawbridge), a dense forest environment, The French Castle, and the Knights' Campground.
- The physical staging intentionally employs exaggerated scale, projection mapping, theatrical lighting, and special effects to emphasize comedic absurdity.
- Costume wardrobes feature heavily stylized knight armor, dramatic wigs, rustic peasant outfits, and intricate French court garments incorporating lace, ruffles, and feathers.
- While differing in historical accuracy, the design shares an appreciation for period-inspired elements and clever anachronism.

### Music & Composition
- The user maintains a regular habit of listening to musical theatre soundtracks, most recently focusing on *The Book of Mormon*.[[session/dialog/feba9363_1.jsonl#L7-L8]]
- The *Spamalot* musical score was written collaboratively by Eric Idle and John Du Prez.
- Prominent featured tracks include "The Song That Goes Like This", "Always Look on the Bright Side of Life", "Find Your Grail", and "The Diva's Lament".
- The musical arrangement integrates historical medieval motifs with standard theatrical structures and modern pop-rock rhythms.
- While *The Book of Mormon* utilizes a contemporary pop-soundbase driven primarily by satire, this score prioritizes narrative propulsion through conventional musical theatre songwriting frameworks.
- Eric Idle is a founding member of Monty Python known for the iconic song "Always Look on the Bright Side of Life"; John Du Prez is a long-time film score and musical collaborator.

### Character Focus: The Lady of the Lake
- The user noted that *The Book of Mormon* frequently frames its female leads through heavy-handed satirical lenses.[[session/dialog/feba9363_1.jsonl#L9-L10]]
- Within the stage adaptation, the Lady of the Lake functions as a dominant mystical figure, diva persona, and seductive character.
- Rather than operating as direct societal satire, her portrayal acts as a lighthearted deconstruction of conventional theatrical damsels, utilizing wit and agency to subvert expected feminine narratives.
- Her character adds depth to the show through motivation and complexity beyond simple parody.

### Touring Production Personnel (Cast & Creative Team)
- Current touring company casts feature Steve McCoy portraying King Arthur, Emma Williams as the Lady of the Lake, and Richard Meek as Sir Galahad.[[session/dialog/feba9363_1.jsonl#L11-L12]]
- Direction for the touring branch is handled by BT McNicholl, succeeding original Broadway director Mike Nichols.
- Dance sequences are maintained under the choreographic oversight of Casey Nicholaw.
- Historical ensemble rosters highlight Hank Azaria, who originally originated the role of Sir Lancelot on Broadway, and Tim Curry, who portrayed King Arthur during the initial West End run.
