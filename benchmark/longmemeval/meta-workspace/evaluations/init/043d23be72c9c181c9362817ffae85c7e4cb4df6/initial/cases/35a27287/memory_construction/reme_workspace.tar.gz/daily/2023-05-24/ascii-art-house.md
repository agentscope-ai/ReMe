---
description: A request to generate an image of a house using only text characters
  and symbols (ASCII art). The assistant provided a geometric representation built
  from forward slashes (/), backslashes (\), underscores (_), and vertical pipes (|)
  to form a triangular roof over a rectangular base.
name: ascii-art-house
session_id: sharegpt_86llQ0z_0
source_conversation: '[[session/dialog/sharegpt_86llQ0z_0.jsonl]]'
---

## ASCII Art Template Request

- User inquired how to represent the visual shape of a building structure exclusively using available keyboard characters and symbols rather than traditional graphics tools. [[session/dialog/sharegpt_86llQ0z_0.jsonl#L1-L1]]
- Solution provided constructs a simple residential structure utilizing four distinct characters: forward slash (`/`) for ascending diagonal lines, backslash (`\`) for descending diagonal lines, underscore (`_`) for horizontal foundations, and vertical pipe (`|`) for wall boundaries. [[session/dialog/sharegpt_86llQ0z_0.jsonl#L2-L2]]

```text
      /\ 
     /  \
    /    \
   /______\
  |        |
  |        |
  |        |
  |________|
```
[[session/dialog/sharegpt_86llQ0z_0.jsonl#L2-L2]]
