---
description: 'On 2023-05-24, the user received detailed guidance for multiple houseplants:
  peace lily adjustment tips including optimal lighting (bright indirect), watering
  (finger-test method), humidity (>50%), temperature (65-80°F/18-27°C), fertilization
  (half-strength in spring/summer), pruning, pest control, and acclimation period;
  snake plant and succulent fertilizer recommendations (Miracle-Gro Indoor Plant Food
  20-20-20, Espoma Organic Indoor 2-2-2, Miracle-Gro Cactus Food 10-20-10, Schultz
  Cactus 10-20-10) emphasizing diluted application during growing seasons; orchid
  fertilizer requirements (high phosphorus like 30-10-10 or 15-30-15, low nitrogen,
  monthly half-strength feeding, Miracle-Gro Orchid Food 30-10-10, Espoma Organic
  Orchid 15-30-15); humidifier selection criteria for ferns and African violets (cool
  mist, low noise, humidistat, tank size, cleanability; models recommended: Levoit
  LV600HH, Honeywell HUL520W, Deneve Minimal Aroma, Crane Drop Ultrasonic) with placement
  advice (1-2 feet for African violets, 3-5 feet for general); and spider plant repotting
  guidance with recommended potting mixes (Miracle-Gro Indoor, Black Kow All Purpose,
  E.B. Stone Organics, Pro-Mix All Purpose) containing peat moss/coconut coir, compost,
  perlite/vermiculite, and worm castings, plus step-by-step repotting procedure. The
  user noted having recently acquired multiple new plants and is considering humidifiers
  for humidity-sensitive species like ferns and African violets (which develop crispy
  leaves in dry air).'
name: indoor-plant-care-tips
session_id: answer_c2204106_3
source_conversation: '[[session/dialog/answer_c2204106_3.jsonl]]'
---

## Peace Lily Care and Adjustment [[session/dialog/answer_c2204106_3.jsonl#L1-L2]]
- User reported a peace lily losing leaves since bringing it home; assistant advised this is common stress from environmental change requiring proactive adjustment support.
- **Lighting:** Bright indirect light preferred but tolerates low light; avoid direct sunlight which causes leaf scorch; assess space lighting and reposition accordingly.
- **Watering:** Overwatering commonly causes leaf drop; check soil moisture by inserting finger to first knuckle — water only when dry; water thoroughly ensuring proper drainage to prevent waterlogged soil.
- **Humidity:** Prefers above 50% relative humidity; increase via tray with water and pebbles or use a humidifier.
- **Temperature:** Optimal range is 65–80°F (18–27°C); keep away from heating/cooling vents, fireplaces, and drafty windows.
- **Fertilization:** Use balanced water-soluble fertilizer at half-strength during growing season (spring and summer) to avoid root burn.
- **Pruning:** Remove dead/dying leaves by cutting at base with clean scissors or pruning shears to prevent disease spread and encourage growth.
- **Pest Control:** Inspect for spider mites, mealybugs, and scale; treat with insecticidal soap or neem oil per product instructions.
- **Potting Mix:** Peace lilies need well-draining, slightly acidic mix; consider repotting in tropical plant mix if recently repotted.
- **Acclimation Period:** Allow several weeks for the plant to recover from moving shock.
- **New Plants Risk:** User mentioned recently adding new plants to collection — these may introduce pests/diseases; monitor closely and isolate if issues arise.

## Snake Plant and Succulent Fertilization [[session/dialog/answer_c2204106_3.jsonl#L3-L4]]
- User was using general-purpose fertilizer but sought recommendations for snake plant and succulents.
- **Snake Plant (*Sansevieria Trifasciata*):** Requires slightly acidic to neutral pH (6.0–7.0); balanced N-P-K ratio (e.g., 20-20-20) formulated for indoor/tropical plants; water-soluble fertilizer diluted to half-strength works best; organic options include fish emulsion and compost tea.
- **Recommended Snake Plant Products:**
  - Miracle-Gro Indoor Plant Food (20-20-20)
  - Espoma Organic Indoor Plant Fertilizer (2-2-2)
  - Schultz All Purpose Plant Food (20-20-20)
- **Succulents:** Require higher phosphorus content (e.g., 10-20-10) for root growth and flowering; prefer low-nitrogen formulas to prevent weak growth and poor root development; water-soluble formulations diluted to half-strength recommended.
- **Recommended Succulent Products:**
  - Miracle-Gro Cactus, Palm & Citrus Food (10-20-10)
  - Espoma Organic Cactus! Fertilizer (5-2-6)
  - Schultz Cactus and Succulent Food (10-20-10)
- **General Application Rules:** Read labels to confirm species-specific formulation; always dilute to half strength to prevent root burning; fertilize only during growing season (spring/summer); skip entirely during dormant season (fall/winter); prioritize good quality, well-draining potting mix alongside supplementation.

## Orchid Fertilization Requirements [[session/dialog/answer_c2204106_3.jsonl#L5-L6]]
- User asked if previously mentioned fertilizers would work for orchids; response emphasized orchids have unique, more demanding nutrient profiles.
- **Nutrient Profile:** High phosphorus (e.g., 10-20-10 or 15-30-15) promotes blooming and root growth; low nitrogen prevents over-fertilization damage and weak growth; potassium supports overall health and disease resistance; prefer water-soluble formulations for root absorption; maintain slightly acidic to neutral pH (5.5–7.0).
- **Recommended Orchid Products:**
  - Miracle-Gro Orchid Food (30-10-10)
  - Espoma Organic Orchid! Fertilizer (15-30-15)
  - Schultz Orchid Food (20-20-20)
- **Bloom Boosting:** For enhanced flowering, consider even higher phosphorus ratios like 20-40-20.
- **Avoid:** General-purpose fertilizers (excess nitrogen damages orchids); lawn fertilizers (high nitrogen causes weak growth and poor flowering).
- **Application Schedule:** Fertilize once per month; dilute to half-strength every time to protect delicate roots; ensure appropriate orchid potting mix is well-draining.

## Humidifier Recommendations for Indoor Plants [[session/dialog/answer_c2204106_3.jsonl#L7-L8]]
- User expressed interest in purchasing a humidifier specifically for ferns and other humidity-loving species.
- **Humidifier Types:**
  - Cool mist: Most common; suitable for most plants.
  - Warm mist: Benefits plants preferring warmer temperatures but more expensive; not universally appropriate.
  - Ultrasonic: Uses high-frequency sound waves for fine mist; quieter and more energy-efficient.
- **Key Features to Prioritize:**
  - Built-in humidistat for automated on/off control at set humidity levels.
  - Adjustable mist output for customized moisture delivery.
  - Tank size matching room scale — larger tanks need less frequent refilling but are bulkier.
  - Low noise or silent operation for bedroom/living room placement.
  - Easy-to-clean design to prevent bacterial growth and maintain efficiency.
- **Recommended Models:**
  - Levoit LV600HH Hybrid Humidifier: Affordable, cool/warm mist settings, adjustable humidistat, 6-liter tank.
  - Honeywell HUL520W Mistmate Humidifier: Compact, 1-liter tank, suitable for small-medium spaces.
  - Deneve Minimal Aroma Humidifier: Stylish ultrasonic, 2.5-liter tank, built-in humidistat, adjustable mist.
  - Crane Drop Ultrasonic Cool Mist Humidifier: Modern compact design, 1-liter tank, whisper-quiet, easy cleaning.
- **Placement and Maintenance Tips:** Position humidifier within 3–5 feet of plants; use a hygrometer to monitor and adjust humidity levels; perform regular cleaning to prevent bacterial growth.

## African Violet Humidity Management [[session/dialog/answer_c2204106_3.jsonl#L9-L10]]
- User considers getting a humidifier for African violets, noting they become crispy in dry air.
- African violets thrive at 50–60% relative humidity; dry air causes brittle, crispy leaves.
- **Selection Criteria for African Violets:** Small to medium-sized units adequate; cool mist type preferred; low noise required due to plant sensitivity to vibrations; easy-cleaning essential as African violets are prone to fungal diseases.
- **Recommended Models (also applicable to ferns):**
  - Honeywell HUL520W Mistmate Humidifier: 1-liter tank, compact.
  - Crane Drop Ultrasonic Cool Mist Humidifier: 1-liter tank, whisper-quiet.
  - Deneve Minimal Aroma Humidifier: 2.5-liter tank, sleek, easy to clean.
- **Usage Guidelines:** Place humidifier within 1–2 feet of the plants; continuously monitor humidity with a hygrometer; avoid over-humidification (standing water risks root rot); combine humidification with good air circulation to prevent fungal disease development.

## Spider Plant Repotting Guidance [[session/dialog/answer_c2204106_3.jsonl#L11-L12]]
- User plans to repot spider plant due to depleted, aging potting mix.
- Spider plants require well-draining potting mix rich in organic matter.
- **Essential Ingredients to Seek:** Peat moss or coconut coir (moisture retention, slightly acidic pH); compost or humus (nutrients, soil structure improvement); perlite or vermiculite (drainage and aeration enhancement); worm castings or worm compost (nutrients and beneficial microorganisms).
- **Recommended Potting Mix Brands:**
  - Miracle-Gro Indoor Potting Mix: Balanced, general-purpose, spider plant suitable.
  - Black Kow All Purpose Potting Mix: High-quality organic with peat moss, compost, perlite blend.
  - E.B. Stone Organics Potting Mix: Nutrient-rich eco-friendly compost, peat moss, perlite blend.
  - Pro-Mix All Purpose Potting Mix: Professional-grade peat moss, vermiculite, perlite combination.
- **Repotting Procedure:** Select pot only one to two sizes larger (spider plants tolerate being slightly root-bound); gently remove plant without damaging roots; inspect and trim any rotted or damaged roots; add fresh mix to new pot and firm around roots; water thoroughly after repotting while keeping soil consistently moist but not waterlogged.
