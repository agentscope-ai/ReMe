---
description: Discussion of the 2004 Supreme Court of New South Wales judgment in Prime
  Constructions Pty Ltd v Westbridge Investments Pty Ltd concerning a settlement agreement
  dispute for goods sold. Covers the timeline of a Jan–Feb 2004 settlement offer,
  acceptance, and subsequent execution of a defective deed signed by only one director.
  Explains how the court resolved the execution defect under the Corporations Act
  2001 and Conveyancing Act 1919 via estoppel and ratification, enforcing delivery
  on 12 February 2004. Details judicial commentary on section 127(4) scope from Young
  CJ in Eq, Einstein J, and Ann Lyons J across cases including Boz One Pty Ltd v McLellan,
  Guang Dong Zhi Gao Australia Pty Ltd v Fortuna Network Pty Ltd, and Sunbay Projects
  Pty Ltd v PR Wieland Holdings Pty Ltd, clarifying that statutory provisions preserve
  common law execution methods, constitutional alternatives, and estoppel-based validity
  without mandating rigid corporate signing formalities.
name: corporate-deed-execution-section-127-4
session_id: sharegpt_Onuprpa_15
source_conversation: '[[session/dialog/sharegpt_Onuprpa_15.jsonl]]'
---

## Legal Precedent: Prime Constructions Pty Ltd v Westbridge Investments Pty Ltd [[session/dialog/sharegpt_Onuprpa_15.jsonl#L1-L2]]
- Case heard in the Supreme Court of New South Wales in 2004 concerning a dispute over a settlement agreement for goods sold and delivered.
- Plaintiff filed a statement of liquidated claim for $11,754.60 in the Local Court, which was disputed by the defendant.
- On 21 January 2004, the plaintiff's solicitor made a settlement offer for the claimed amount, requiring each party to pay its own costs and enter a deed of release.
- The defendant's solicitor accepted the offer on 23 January 2004, and parties agreed upon the deed of release terms.
- The defendant subsequently proposed an additional term regarding a letter from the plaintiff to the proprietor about the quality of works, prompting further solicitor correspondence.
- The central issue determined by the court was whether a final settlement of the proceedings existed.
- The court concluded a final settlement existed because deed and settlement terms were agreed upon, leaving only the mechanics of exchanging deeds and the settlement cheque.
- A document expressed as a deed was executed on 9 February 2004 but was not properly executed according to the Corporations Act and the Conveyancing Act.
- The court held that via estoppel or ratification, the deed took effect from the delivery date of 12 February 2004, with consequences flowing per settlement terms.
- The court declared the defendant bound by the deed of release terms, ordered payment of $11,721.60 to the plaintiff, and ordered the defendant to pay the plaintiff's proceedings costs.

## Deed Execution Defects & Corporate Authority [[session/dialog/sharegpt_Onuprpa_15.jsonl#L3-L4]]
- The primary defect in the deed involved incomplete signing authorization by the plaintiff company.
- Under the Corporations Act 2001 and the Conveyancing Act 1919, a company binds itself by a deed if two directors sign, or a director and a company secretary sign; if only one director exists, that single director alone may sign.
- Only one director of the plaintiff company signed the deed in this instance, causing the document to fail compliance with statutory execution standards.
- The plaintiff argued the deed remained binding due to delivery to the defendant's solicitor and willingness to perform the agreement, alongside an argument that the defendant was estopped from denying deed execution status after the plaintiff's solicitor representation.
- The court ruled that regardless of non-compliance, the deed became effective from the 12 February 2004 delivery date through estoppel or ratification mechanisms.
- The court noted that strict application of execution standards could have created complications had the defendant adopted a contrary position.

## Statutory Scope: Section 127(4) Corporations Act 2001 [[session/dialog/sharegpt_Onuprpa_15.jsonl#L4-L5]]
- Section 127(4) of the Corporations Act 2001 establishes that the section does not restrict alternative methods for a company to execute documents, including deeds.
- Paragraph 206 of Boz One Pty Ltd v McLellan [2015] VSCA 68; 105 ACSR 325 examines judicial interpretations of section 127(4) coverage.
- Young CJ in Eq observed in Prime Constructions Pty Ltd v Westbridge Investments Pty Ltd that section 127(4) encompasses the common law execution method, constitution-prescribed execution methods, or situations where estoppel renders a deed binding on the company.
- Einstein J cited Young CJ in Eq's reasoning with approval in Guang Dong Zhi Gao Australia Pty Ltd v Fortuna Network Pty Ltd, agreeing regarding the ambiguity of section 127(4) coverage.
- Ann Lyons J addressed section 127(4) contextually in Sunbay Projects Pty Ltd v PR Wieland Holdings Pty Ltd, stating that no specific formality is mandated when a corporate entity signs a document.
