---
description: 'Gaming consultation session documenting user transition from Call of
  Duty (completed Nov 15) to FPS recommendations emphasizing fast-paced action, intensity,
  and deep narratives. Covers comprehensive game lists (Battlefield, Titanfall, Doom,
  etc.) with specific campaign length estimates. Details decision to adopt Deus Ex:
  Mankind Divided and its strategic pivot requirements. Documents mechanical breakdown
  of Cybernetic Augmentations (Combat, Stealth, Exploration, Social categories, Praxis
  currency, specific tools like Typhoon/Smart Vision) and post-campaign engagement
  content including New Game Plus, Breaching Mode, and Jensen''s Stories DLC.'
name: gaming-fps-recommendations-deus-ex-guide
session_id: d20be4f3_1
source_conversation: '[[session/dialog/d20be4f3_1.jsonl]]'
---

# Gaming Recommendations and Analysis

## User Context and Preferences
- User completed the Call of Duty campaign mode on November 15th [[session/dialog/d20be4f3_1.jsonl#L1-L1]].
- Primary criteria for future games involve fast-paced action, intense combat sequences, and strong single-player campaign narratives [[session/dialog/d20be4f3_1.jsonl#L3-L3]].
- User speculates completing the Call of Duty campaign rapidly may indicate playing too quickly, suggesting a preference for deeper engagement or longer experiences [[session/dialog/d20be4f3_1.jsonl#L5-L5]].

## Comprehensive FPS Recommendation Pool
Assistant provides categorized suggestions based on general interest in First-Person Shooters (FPS):
- **Battlefield Series**: Titles include Battlefield 1, Battlefield 4, and Battlefield V; noted for large-scale multiplayer battles and engaging single-player campaigns [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Titanfall Series**: Titanfall 2 recommended for mech combat focus and well-regarded single-player campaign [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Halo Series**: Sci-Fi themed shooters with strong multiplayer components; specifically Halo 5: Guardians and Halo Infinite [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **CS:GO (Counter-Strike: Global Offensive)**: Suggested for players seeking competitive tactical FPS gameplay [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Overwatch**: Described as a team-based shooter featuring heroes with distinct abilities rather than traditional FPS mechanics [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Wolfenstein Series**: Wolfenstein: The New Colossus and Wolfenstein: Youngblood offer fast-paced, action-oriented FPS experiences [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Far Cry Series**: Emphasis on open-world exploration and strong narratives; includes Far Cry 5 [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Rainbow Six Siege**: Tactical FPS focused on strategic team play and competitive firefights [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Doom (2016)**: Action-packed title with heavy focus on combat intensity and single-player campaign structure [[session/dialog/d20be4f3_1.jsonl#L2-L2]].
- **Metro Series**: Atmospheric, story-driven options including Metro 2033 and Metro: Last Light [[session/dialog/d20be4f3_1.jsonl#L2-L2]].

## Filtered Recommendations Based on Narrative Depth
User requests stronger storytelling and longer campaign durations aligned with fast-paced action preferences [[session/dialog/d20be4f3_1.jsonl#L3-L5]]. Assistant filters recommendations:
- **Deus Ex: Mankind Divided**: Estimated duration of 20-30 hours; highly story-driven with significant focus on player choice and exploration [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Dishonored 2**: Estimated duration of 15-20 hours; acclaimed for stealth mechanics, storytelling quality, and beautifully designed worlds [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Wolfenstein: The New Colossus**: Estimated duration of 10-12 hours; possesses strong storytelling and immersive atmosphere [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Far Cry 5**: Estimated duration of 20-30 hours; utilizes an open-ended story approach centered on exploration and neutralizing villain leaders [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Battlefield 1**: Estimated duration of 6-8 hours; campaign structured around cinematic "War Stories" combining action, stealth, and vehicles [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Titanfall 2**: Estimated duration of 6-8 hours; praised for tight level design and narrative integration [[session/dialog/d20be4f3_1.jsonl#L6-L6]].
- **Warframe**: Free-to-play cooperative sci-fi title focusing on action; delivers story through quests playable solo or co-op [[session/dialog/d20be4f3_1.jsonl#L4-L4]].
- **Overkill's The Walking Dead**: Cooperative FPS set in The Walking Dead universe featuring a strong single-player campaign [[session/dialog/d20be4f3_1.jsonl#L4-L4]].

## Selection: Deus Ex: Mankind Divided
- User elects to play Deus Ex: Mankind Divided motivated by high reputations regarding story and setting, accepting a shift away from pure fast-paced action mechanics [[session/dialog/d20be4f3_1.jsonl#L7-L9]].
- Assistant warns that Deus Ex: Mankind Divided operates differently from Call of Duty, prioritizing methodical stealth, hacking, social engineering, and strategic planning over rapid-fire combat [[session/dialog/d20be4f3_1.jsonl#L8-L8]].
- Success in Deus Ex relies on augmentations, ability utilization, and environmental interaction rather than solely direct engagement [[session/dialog/d20be4f3_1.jsonl#L8-L8]].

## Deus Ex: Mankind Divided Mechanics Breakdown
- **Cybernetic Augmentations**: Enhancements installed in the player body granting new abilities or improving existing ones; purchased/crafted using Praxis Points earned via missions and activities [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
- **Augmentation Categories**:
    - Combat: Increases damage output, accuracy, and stealth capabilities [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - Stealth: Enables undetected movement, system hacking, and distraction creation [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - Exploration: Facilitates accessing restricted zones via climbing, enhanced jumping, or identifying hidden paths [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - Social: Improves effectiveness in persuading or intimidating Non-Player Characters (NPCs) [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
- **Specific Augmentation Examples**:
    - Smart Vision: Highlights enemies, security grids, and hidden items [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - Icarus Landing: Prevents fall damage upon impact, allowing safe traversal of heights [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - Typhoon: Releases explosive energy bursts capable of eliminating multiple targets simultaneously [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
    - Social Enhancer: Upgrades interpersonal skills for dialogue interactions [[session/dialog/d20be4f3_1.jsonl#L10-L10]].
- **Usage Strategy**: Players must match augmentation types to situations (e.g., stealth for ambushes, combat for crowds, exploration for secrets) while managing limited equipment slots and scarce Praxis resources [[session/dialog/d20be4f3_1.jsonl#L10-L10]].

## Post-Campaign Content and Replayability
- **New Game Plus Mode**: Permits replaying the game retaining upgraded augmentations, introducing tougher enemy scaling and previously unencountered story elements [[session/dialog/d20be4f3_1.jsonl#L12-L12]].
- **Breaching Mode**: Distinct game mode challenging users to breach simulated corporate facilities for wave-based combat scoring and leaderboard ranking [[session/dialog/d20be4f3_1.jsonl#L12-L12]].
- **Jensen's Stories DLC**: Expands available missions, characters, and augmentations; intended for play following main story completion [[session/dialog/d20be4f3_1.jsonl#L12-L12]].
- **Exploration and Side Content**: Abundant side quests, optional objectives, hub exploration, and secret discovery mechanisms provide ongoing engagement during primary and subsequent playthroughs [[session/dialog/d20be4f3_1.jsonl#L12-L12]].
