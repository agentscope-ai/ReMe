---
description: Detailed regulatory directives governing customs tariff classification
  for heavy goods vehicles operating in the transport sector. Distinguishes between
  Heading 8705 (Special purpose motor vehicles) and Heading 8704 (Motor vehicles for
  transport of goods). Addresses scenarios involving motor breakdown lorries devoid
  of floors, identifying retained recovery mechanisms (cranes, winches, hoists) as
  critical classification factors. Evaluates multi-purpose logistics platforms capable
  of hauling both disabled and operational vehicles, establishing that dedicated recovery
  apparatus dictates Heading 8705 while general transport functionality implies Heading
  8704. Analyzes the structural characteristics of beaver-tail rear decking, confirming
  that such architectural features alone do not mandate special-purpose classification
  without corroborating recovery equipment. Mandates reliance on Combined Nomenclature
  (CN) and HSENS frameworks alongside professional trade advisory consultation for
  unresolved design ambiguities.
name: vehicle-custom-classification-guidance
session_id: sharegpt_8Qorb3g_0
source_conversation: '[[session/dialog/sharegpt_8Qorb3g_0.jsonl]]'
---

### Regulatory Directives for Special Purpose Recovery Vehicles (Heading 8705) `[[session/dialog/sharegpt_8Qorb3g_0.jsonl#L1-L2]]`
- A motor breakdown lorry lacking a cargo floor generally qualifies for classification under heading 8705 ("Special purpose motor vehicles, other than those principally designed for the transport of persons or goods"), provided the architecture maintains the core objective of recovering and transporting immobilized vehicles [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L2]].
- Absence of a floor configuration does not preclude classification under heading 8705 if the chassis retains specialized recovery apparatus, encompassing cranes, booms, winches, hoists, or lifting arms essential for vehicle extraction operations [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L2]].
- Removal of a floor necessitates immediate re-evaluation of the classification category if the modification entirely negates the vehicle's capacity to execute designated recovery functions or fundamentally transforms the operational design parameters [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L2]].
- Resolution of classification uncertainties mandates direct consultation with established Combined Nomenclature (CN) and Harmonized Commodity Description and Coding System (HSENS) regulatory frameworks, supplemented by engagement with certified trade compliance professionals [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L2]].

### Evaluation Protocols for Multi-Purpose Logistics Platforms (Headings 8704 vs 8705) `[[session/dialog/sharegpt_8Qorb3g_0.jsonl#L3-L4]]`
- Commercial lorries engineered to haul both disabled units and operational road vehicles constitute multi-purpose logistical designs. Applicable tariff categories depend strictly upon principal manufacturing intent, inherent engineering specifications, and installed hardware configurations [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L4]].
- Integration of dedicated recovery mechanisms—including tilting platforms, sliding decks, high-capacity winches, structural hoists, or articulated lifting arms—anchors classification firmly under heading 8705, reflecting a primary design orientation toward broken-down vehicle recovery [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L4]].
- Constructs built primarily for operational vehicle transportation, operating without active recovery machinery and functioning as standard car carriers or general flatbed distribution trucks, default to classification under heading 8704 ("Motor vehicles for the transport of goods") [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L4]].
- Ambiguity regarding principal design objectives or functional hierarchy necessitates rigorous reference to applicable CN/HSENS documentation and mandatory verification sessions with authorized customs and trade experts [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L4]].

### Structural Assessment of Beaver-Tail Chassis Configurations `[[session/dialog/sharegpt_8Qorb3g_0.jsonl#L5-L6]]`
- Beaver-tail flooring designates a specialized sloped rear deck architecture engineered specifically to streamline the loading and unloading procedures for vehicles onto cargo platforms [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L6]].
- Sole deployment of a beaver-tail chassis configuration fails to definitively classify a heavy goods vehicle as a motor breakdown unit, given identical structural traits remain standard across general car-hauler networks and broad-spectrum flatbed freight fleets [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L6]].
- Accurate identification of recovery-specific classification standards requires a holistic examination of total chassis utility, overarching manufacturing blueprints, and the presence of integrated mechanical aids (winches, hoists, lifting arms) directly supporting disabled vehicle extraction processes [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L6]].
- Persistent ambiguity surrounding chassis primary utility demands strict validation through official regulatory manuals (CN and HSENS) and consultation with qualified trade compliance advisors to guarantee precise tariff categorization [[session/dialog/sharegpt_8Qorb3g_0.jsonl#L6]].
