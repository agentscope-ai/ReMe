---
description: Comprehensive operational notes covering the cleaning, storage, and restoration
  protocols for a newly acquired 1920s-era Kodak Brownie camera and a vintage Leica
  lens, detailing chemical processing workflows for amateur film development in a
  residential garage darkroom, historical timeline data for both Kodak and Leica optical
  manufacturing branches throughout the early-to-mid 20th century, curated bibliography
  of foundational photography treatises and historical periodicals, and a log of recent
  collection acquisitions including a Capitol Hill purchase.
name: vintage-camera-collection-maintenance-history
session_id: f5cf8815_3
source_conversation: '[[session/dialog/f5cf8815_3.jsonl]]'
---

## Vintage Camera Acquisition & Current Inventory
- On 2023-05-28, purchased a vintage copy of Ansel Adams' technical photography book "The Camera" at a used bookstore located in Capitol Hill. [[session/dialog/f5cf8815_3.jsonl#L1-L1,L11-L11]]
- Recently acquired a 1920s-era Kodak Brownie camera at a neighborhood garage sale for $20. [[session/dialog/f5cf8815_3.jsonl#L1-L1]]
- Secured a vintage Leica camera lens through an online eBay auction. [[session/dialog/f5cf8815_3.jsonl#L5-L5]]

## Systematic Cleaning, Maintenance & Storage Protocols
- Handle all camera bodies and optical components exclusively with clean, dry hands or protective gloves to prevent sebum transfer and finish degradation. [[session/dialog/f5cf8815_3.jsonl#L2-L10]]
- Remove exterior particulate matter using only soft, dry brushes or dedicated camel hair brushes; strictly prohibit compressed air usage due to internal debris displacement risks. [[session/dialog/f5cf8815_3.jsonl#L2-L2]]
- Execute exterior washdowns utilizing lukewarm water combined with minimal dish soap, applying the solution via dampened lint-free microfiber cloths while rigorously protecting apertures, viewfinders, and seam gaps. [[session/dialog/f5cf8815_3.jsonl#L2-L2]]
- Optic surface treatment requires breathing directly onto glass to deposit condensation, followed by gentle circular wiping with clean microfiber textiles; apply proprietary lens cleaning fluids exclusively to the textile substrate. [[session/dialog/f5cf8815_3.jsonl#L2-L2]]
- Prohibit all abrasive cleaning agents, solvent-based tissue products, and coarse weaves to eliminate scratch hazards and anti-reflective coating stripping. [[session/dialog/f5cf8815_3.jsonl#L2-L2]]
- Mechanical gear longevity depends on precise application of specialized camera lubricants or silicone derivatives to exposed pivots and transmission shafts; excessive viscosity accumulation necessitates periodic extraction to deter particulate adhesion. [[session/dialog/f5cf8815_3.jsonl#L2-L2]]
- Environmental storage parameters mandate isolation from ultraviolet exposure, thermal spikes, and elevated relative humidity levels to inhibit metallic oxidation, organic adhesive failure, and fungal spore proliferation. [[session/dialog/f5cf8815_3.jsonl#L2-L10]]
- Coordinate ongoing restoration strategy with an active professional photography classmate who provides targeted mechanical diagnostic guidance. [[session/dialog/f5cf8815_3.jsonl#L9-L10]]

## Historical Context: Kodak Brownie Line (1920s Era)
- The original Brownie platform debuted in 1900 manufactured by the Eastman Kodak Company under founder George Eastman, utilizing 117 roll film media at a base retail price of $1 to achieve mass-market photographic democratization. [[session/dialog/f5cf8815_3.jsonl#L3-L4]]
- The 1920s manufacturing cycle established industry-standard form factors incorporating streamlined Art Deco chassis architecture, upgraded meniscus and Anastigmat compound lens assemblies, and enhanced electromechanical shutter timing mechanisms. [[session/dialog/f5cf8815_3.jsonl#L4-L4]]
- Definitive model iterations released during the decade include: the Brownie No. 2 (1920) establishing 120 roll film adoption, the Brownie No. 2A (1922) introducing refined optical housing geometry, the Brownie Hawkeye (1925) popularizing ultra-compact carry formats, the Brownie Six-20 (1926) targeting higher-resolution imagery via 620 media integration, and the Brownie Special (1929) implementing premium structural metallurgy. [[session/dialog/f5cf8815_3.jsonl#L4-L4]]

## Historical Context: Leica Brand & Optical Systems
- The Ernst Leitz corporate entity traces industrial origins to 1849 when German precision instrument designer Oskar Barnack initiated optical fabrication operations focusing on microscope engineering. [[session/dialog/f5cf8815_3.jsonl#L5-L6]]
- Portable cinematic photography transitioned to still imaging platforms through the 1925 Leica A launch at the Leipzig Spring Fair, successfully adapting 35mm motion picture cel stock into handheld rectangular enclosures. [[session/dialog/f5cf8815_3.jsonl#L6-L6]]
- Foundational optical engineering directives originated within the corporate research division overseen by Max Berek, pioneering the inaugural 50mm f/3.5 Anastigmat configuration before sequentially releasing advanced telephoto and wide-angle variants including the 50mm f/2 Summar (1933), 35mm f/2 Summicron (1958), and 90mm f/2 Summicron (1957). [[session/dialog/f5cf8815_3.jsonl#L6-L6]]
- Mid-century production peaks corresponding to the Leica M3 (1954) and Leica M6 (1968) solidified premium manufacturing tolerances relied upon extensively by documentary war photographers Robert Capa and Don McCullin, street documentation practitioners Henri Cartier-Bresson and Garry Winogrand, and fine art landscape specialists Ansel Adams, Dorothea Lange, and Josef Koudelka. [[session/dialog/f5cf8815_3.jsonl#L6-L6]]
- Authentication protocols require cross-referencing physical mounting thread specifications against legacy L39, M39, and M-mount architectural standards while evaluating adapter feasibility for contemporary digital sensor arrays. [[session/dialog/f5cf8815_3.jsonl#L6-L6]]

## Amateur Film Development Procedures & Chemicals
- Construct temporary processing facilities within isolated residential structures like garages, ensuring absolute light-tight environmental sealing, forced atmospheric exchange via exhaust ventilation, and continuous liquid temperature stabilization near 20°C/68°F. [[session/dialog/f5cf8815_3.jsonl#L7-L8]]
- Execute sequential emulsion processing workflows comprising primary reduction chemistry activation, secondary neutralization interruption phases utilizing dilute acetic acid solutions, and tertiary insolubilization fixation baths employing sodium thiosulfate compounds. [[session/dialog/f5cf8815_3.jsonl#L8-L8]]
- Select standardized developer formulations such as D-76 universal processing fluid or concentrated HC-110 flexible concentrates according to target ISO sensitivity ratings. [[session/dialog/f5cf8815_3.jsonl#L8-L8]]
- Maintain rigorous procedural discipline by cross-referencing manufacturer time-temperature correction tables, integrating analog thermometric monitoring equipment, operating synchronized digital chronometers for exact agitation intervals, and executing controlled mechanical inversion sequences to guarantee uniform silver grain deposition. [[session/dialog/f5cf8815_3.jsonl#L8-L8]]
- Supplement practical experimentation with external pedagogical materials sourced through dedicated digital repositories including Reddit r/filmphotography communities, Film Photography Forum networks, video tutorial databases hosted on YouTube, and authoritative print publications authored by Steve Anchell ("The Darkroom Handbook") and Andy Kreyche ("Film Development by Hand"). [[session/dialog/f5cf8815_3.jsonl#L8-L8]]

## Photography Literature & Periodical Recommendations
- Primary instructional framework centers on Ansel Adams' definitive technical trilogy: "The Camera" addressing exposure calculation matrices and optical transmission physics, "The Negative" detailing silver gelatin printing architecture, and "The Print" outlining density gradation management techniques. [[session/dialog/f5cf8815_3.jsonl#L12-L12]]
- Supplementary theoretical foundations incorporate Henri Cartier-Bresson's spatial composition philosophy documented in "The Decisive Moment" and John Szarkowski's visual perception frameworks catalogued in "The Photographer's Eye". [[session/dialog/f5cf8815_3.jsonl#L12-L12]]
- Archival research benefits from tracking historical editorial publications ranging from early twentieth-century technical journals like Camera Arts (1903–1917) and mid-century enthusiast guides like Popular Photography (established 1937), to aesthetic focus reviews including Aperture (inaugurated 1952) and Modern Photography (operated until 1989). [[session/dialog/f5cf8815_3.jsonl#L12-L12]]
- Retrieve restricted circulation editions utilizing aggregated digitization infrastructures provided by The Internet Archive institutional library and Google Books preview indexing engines. [[session/dialog/f5cf8815_3.jsonl#L12-L12]]
