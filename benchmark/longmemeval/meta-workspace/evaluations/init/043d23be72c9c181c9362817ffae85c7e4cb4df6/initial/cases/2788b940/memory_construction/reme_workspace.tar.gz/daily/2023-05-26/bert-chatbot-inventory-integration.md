---
description: Python chatbot script using Hugging Face Transformers (BERT), PyTorch,
  and MySQL. Features include loading a local BERT model for generic questions, caching
  known Q&A pairs in a 'memory' table, querying products by tags ('fever', 'cold',
  'headache') via SQL, and managing a shopping cart. The execution loop prioritizes
  memory cache hits, then tag searches, falling back to the BERT model.
name: bert-chatbot-inventory-integration
session_id: sharegpt_c22x2ZP_15
source_conversation: '[[session/dialog/sharegpt_c22x2ZP_15.jsonl]]'
---

## Hybrid Chatbot System Implementation

### Core Technologies & Dependencies
The system integrates Natural Language Processing with relational database management.

-   **AI/ML**: `transformers` (Hugging Face) for `BertTokenizer` and `BertForQuestionAnswering`; `torch` for tensor operations.
-   **Database**: `mysql.connector` connecting to a local `inventory` database on `localhost` using user `root` and password `password`.
-   **Model Artifacts**:
    -   Tokenizer Config: `'path/to/tokenizer/config.json'`
    -   Model Weights: `'path/to/model.bin'`

### Functional Modules

#### 1. BERT Answer Generation
Function: `get_bert_answer(question)`
Processes text through a custom-trained BERT model. It uses `tokenizer.convert_ids_to_tokens` and `tokenizer.convert_tokens_to_string` to extract the answer span based on the maximum `start_logits` and `end_logits` indices.

#### 2. Database Operations
The script manages three key tables/entities within the MySQL instance:
-   **Chat Memory**: Stored via `add_to_memory()`. Allows retrieving specific answers if the exact question string has been seen before (`SELECT ... WHERE question = %s`).
-   **Shopping Cart**: Managed via `add_to_cart(product, price)`. Totals are calculated using `get_cart_total()` which executes a SQL sum query.
-   **Product Inventory**: Queried via `list_products_by_tag(tag)`. Uses SQL `LIKE '%tag%'` matching to find products associated with specific health conditions (e.g., fever, cold, headache). Results are formatted in Rupees (₹).

### Execution Logic & Control Loop
The main conversation loop follows a specific precedence order:
1.  **Cache Lookup**: The system first checks the `memory` table for the user's input string. If found, it returns the stored response immediately.
2.  **Tag-Based Search**: If no memory match is found, the system scans for keywords within predefined lists: `['fever', 'cold', 'headache']`.
    -   If a keyword is detected, `list_products_by_tag()` executes.
    -   Output format: `"- ProductName (₹Price)"` per line.
    -   Graceful handling: Prints "Sorry, we don't have any products..." if the list is empty.
3.  **Generative Fallback**: If neither memory nor tags trigger a result, the code structure indicates the intention to invoke the BERT model to handle open-ended queries.

### Source Code Reference
```python
import mysql.connector
import torch
from transformers import BertTokenizer, BertForQuestionAnswering

# Load the custom-trained BERT model and tokenizer
tokenizer = BertTokenizer.from_pretrained('path/to/tokenizer/config.json')
model = BertForQuestionAnswering.from_pretrained('path/to/model.bin')

# Connect to the MySQL database
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="password",
    database="inventory"
)

# Define a function to get an answer from the BERT model
def get_bert_answer(question):
    # Encode the question using the tokenizer
    inputs = tokenizer(question, return_tensors='pt')

    # Pass the encoded question to the BERT model
    outputs = model(**inputs)

    # Get the answer from the model's output
    answer_start = torch.argmax(outputs.start_logits)
    answer_end = torch.argmax(outputs.end_logits) + 1
    answer = tokenizer.convert_tokens_to_string(tokenizer.convert_ids_to_tokens(inputs['input_ids'][0][answer_start:answer_end]))

    return answer.strip()

# Define a function to add a question-answer pair to the chatbot's memory
def add_to_memory(question, answer):
    cursor = db.cursor()
    sql = "INSERT INTO memory (question, answer) VALUES (%s, %s)"
    val = (question, answer)
    cursor.execute(sql, val)
    db.commit()

# Define a function to add a product to the user's cart
def add_to_cart(product, price):
    cursor = db.cursor()
    sql = "INSERT INTO cart (product, price) VALUES (%s, %s)"
    val = (product, price)
    cursor.execute(sql, val)
    db.commit()

# Define a function to calculate the total price of the user's cart
def get_cart_total():
    cursor = db.cursor()
    cursor.execute("SELECT SUM(price) FROM cart")
    result = cursor.fetchone()[0]
    return result if result else 0

# Define a function to list all products with a particular tag
def list_products_by_tag(tag):
    cursor = db.cursor()
    cursor.execute("SELECT name, price FROM products WHERE tags LIKE %s", ('%' + tag + '%',))
    result = cursor.fetchall()
    return result

# Start the conversation loop
while True:
    # Get the user's question
    question = input("You: ")

    # Check if the question is in the chatbot's memory
    cursor = db.cursor()
    cursor.execute("SELECT answer FROM memory WHERE question = %s", (question,))
    result = cursor.fetchone()

    # If the question is in the chatbot's memory, retrieve the answer
    if result is not None:
        print("Bot: " + result[0])

    # If the question is not in the chatbot's memory, use the BERT model to get an answer
    else:
        # Check if the question contains a tag for listing products
        tags = ['fever', 'cold', 'headache'] # replace with actual tags
        for tag in tags:
            if tag in question:
                products = list_products_by_tag(tag)
                if len(products) == 0:
                    print("Bot: Sorry, we don't have any products for that tag.")
                else:
                    print("Bot: Here are the products we have for that tag:")
                    for product in products:
                        print("- " + product[0] + " (₹" + str(product[1]) + ")")
                break
        
        # If the question does not contain a tag for listing products, use the BERT model to get an answer
```
[[session/dialog/sharegpt_c22x2ZP_15.jsonl#L1-L5]]
