---
description: A detailed troubleshooting log for configuring the right-click button
  behavior (specifically assigning or prioritizing the 'Zoom Window' function) in
  AutoCAD LT 2013. The entry captures repeated UI-related failures, specifically noting
  missing components such as the application menu, standard mouse buttons, 'New Command'
  button, and 'RButton' options within the CUI window. The documentation preserves
  seven distinct configuration paths explored during the session, utilizing interfaces
  like the CUI dialog, the 'Right-click Customization' section under User Preferences,
  and macro assignments like '\_.ZOOM' and '\_ZOOMW'. Fallback advice includes resetting
  the software defaults or checking for updates.
name: autocad-lt-2013-right-click-customization
session_id: sharegpt_72qIaGg_12
source_conversation: '[[session/dialog/sharegpt_72qIaGg_12.jsonl]]'
---

## Problem Context
- Software Version: AutoCAD LT 2013 [[session/dialog/sharegpt_72qIaGg_12.jsonl#L1-L1]].
- Objective: Assign the "Zoom Window" function to the right-click button or configure "Zoom Window" as the default option inside the right-click shortcut menu [[session/dialog/sharegpt_72qIaGg_12.jsonl#L1-L11,L15-L15]].
- Initial Issues: The end-user could not find the application menu inside the Options dialog box, causing initial confusion regarding prior instructions [[session/dialog/sharegpt_72qIaGg_12.jsonl#L1-L1]].

## UI Constraints & Missing Elements in AutoCAD LT 2013
- Mouse Section Gaps: The Mouse section does not feature a standard "Right Mouse Button" selection; available options remain limited to combinations such as "click shift plus click", "control plus click", and "control plus shift click" [[session/dialog/sharegpt_72qIaGg_12.jsonl#L3-L3]].
- Options Dialog Layout: Instead of a comprehensive Mouse section, the Options dialog displays a dedicated button explicitly named "right click customization" [[session/dialog/sharegpt_72qIaGg_12.jsonl#L5-L7]].
- CUI Dialog Limitations: Specific elements required for advanced customization are absent in this software version, including a "New Command" button and the expected "RButton" option inside the "Customizations In Main CUI" window [[session/dialog/sharegpt_72qIaGg_12.jsonl#L9-L9,L13-L13]].

## Troubleshooting Attempts & Configurations
### Attempt 1: Via CUI Mouse Buttons Section
- Navigate to the Customize User Interface (CUI) dialog box by typing "CUI" inside the command line [[session/dialog/sharegpt_72qIaGg_12.jsonl#L2-L2]].
- Expand the "Mouse Buttons" section to locate the "ZOOM" category [[session/dialog/sharegpt_72qIaGg_12.jsonl#L2-L2]].
- Drag the "Zoom Window" function onto the Right Button item and save adjustments via the Save button present in the CUI dialog box [[session/dialog/sharegpt_72qIaGg_12.jsonl#L2-L2]].

### Attempt 2: Via Options > User Preferences > Mouse Section
- Access the Options dialog via the Application menu or by typing "OPTIONS" inside the command line [[session/dialog/sharegpt_72qIaGg_12.jsonl#L4-L4]].
- Switch to the User Preferences tab and click the "Customize Button" button positioned inside the Mouse section [[session/dialog/sharegpt_72qIaGg_12.jsonl#L4-L4]].
- Select "Button 2" which corresponds to the right-click button, type `\_.ZOOM` outside quotation marks into the "Macro" field, then apply adjustments [[session/dialog/sharegpt_72qIaGg_12.jsonl#L4-L4]].

### Attempt 3: Via Options > User Preferences > Right-click Customization > Standard Path
- From the User Preferences tab, locate the "Right-click Customization" section and click the "Customize" button placed next to that section [[session/dialog/sharegpt_72qIaGg_12.jsonl#L6-L6]].
- Inside the generated Customize User Interface dialog box, expand the "Shortcuts" area and afterwards expand the "All Commands" area [[session/dialog/sharegpt_72qIaGg_12.jsonl#L6-L6]].
- Locate "Zoom Window", drag that element to the "Customizations in Main CUI" section, drop the element onto the "RButton" item before saving [[session/dialog/sharegpt_72qIaGg_12.jsonl#L6-L6]].

### Attempt 4: Via Custom Macro Creation
- Repeat navigation to the "Right-click Customization" section and click the "Customize" button [[session/dialog/sharegpt_72qIaGg_12.jsonl#L8-L8]].
- Use the unavailable "New Command" button, name the resulting command (for example "Zoom Window"), and assign the macro `\_ZOOMW` [[session/dialog/sharegpt_72qIaGg_12.jsonl#L8-L8]].
- Expand the "RButton Menus" section, select the "Default" subsection, and attempt to drag the newly created command there [[session/dialog/sharegpt_72qIaGg_12.jsonl#L8-L8]].

### Attempt 5: Using the "Add Command" Feature
- Inside the Customize User Interface dialog, switch focus to the "RButton Menu" placed under the "Customizations In Main CUI" section [[session/dialog/sharegpt_72qIaGg_12.jsonl#L10-L10]].
- Trigger the "Add Command" button, select "All Commands" from the Categories list, identify the "Zoom Window" command, and confirm with the "OK" button [[session/dialog/sharegpt_72qIaGg_12.jsonl#L10-L10]].

### Attempt 6: Customizing the Shortcut Menu Directly
- Responding to an inquiry about making "Zoom Window" the default right-click option, navigate again through Options, User Preferences, the "Right-click Customization" section, and finally the "Customize" button [[session/dialog/sharegpt_72qIaGg_12.jsonl#L12-L12]].
- Target the "RButton Menu" located inside the main CUI window, find "Zoom Window" inside the "All Commands" list, and relocate that item to the top position inside the "RButton Menu" section [[session/dialog/sharegpt_72qIaGg_12.jsonl#L12-L12]].

### Attempt 7: Using the "Shortcuts" Node
- After discovering the "RButton" option remains absent, select the "Shortcuts" node positioned under the "Customizations In Main CUI" section inside the Customize User Interface dialog box [[session/dialog/sharegpt_72qIaGg_12.jsonl#L14-L14]].
- Scroll to locate "Zoom Window" inside the "All Commands" list, perform a right-click action, and select the "Add to Shortcut Menu" option to finalize the addition [[session/dialog/sharegpt_72qIaGg_12.jsonl#L14-L14]].

## Fallback Recommendations
- If the customized right-click behavior remains incorrect after applying configurations, reset AutoCAD LT to its original default settings or investigate available software updates [[session/dialog/sharegpt_72qIaGg_12.jsonl#L2-L2,L4-L4,L6-L6,L8-L8,L10-L10,L12-L12,L14-L14]].
