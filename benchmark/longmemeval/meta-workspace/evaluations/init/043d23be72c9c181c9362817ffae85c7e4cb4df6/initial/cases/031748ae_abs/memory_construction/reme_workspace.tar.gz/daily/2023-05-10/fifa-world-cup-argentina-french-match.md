---
description: Records the state of the FIFA World Cup match between Argentina and France
  on 2023-05-10. Argentina led 2-0 with Di Maria scoring a second goal in the 35th
  minute via a counter-attack against defending champions France.
name: fifa-world-cup-argentina-french-match
session_id: sharegpt_KwbJJ66_13
source_conversation: '[[session/dialog/sharegpt_KwbJJ66_13.jsonl]]'
---

### Argentina vs. France Match [[session/dialog/sharegpt_KwbJJ66_13.jsonl#L1-L1]]
- **Match Status on 2023-05-10**: At 05:03:00 UTC, Argentina was leading France 2-0 in the ongoing FIFA World Cup match.
- **Di Maria Performance**: Di Maria was instrumental for Argentina and scored a "fantastic second goal" in the 35th minute of the game.
- **Tactical Description**: The second goal was the result of an "impressive counter-attack that tore France apart."
- **Opponent Context**: France is identified as the defending champions in this matchup.
