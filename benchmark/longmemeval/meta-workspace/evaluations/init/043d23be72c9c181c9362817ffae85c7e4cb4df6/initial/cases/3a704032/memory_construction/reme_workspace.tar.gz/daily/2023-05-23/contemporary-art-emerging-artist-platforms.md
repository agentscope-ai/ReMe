---
description: Summary of user interest in contemporary art and emerging artists, detailing
  past attendance at the Contemporary Art Space (October) and Modern Art Museum (viewing
  Sarah Johnson's climate change installations). Includes a comprehensive list of
  recommended online platforms for discovering new artwork—such as Artsy, Saatchi
  Art, Artspace, and Uprise Art—and the user's plan to explore these specific sites.
name: contemporary-art-emerging-artist-platforms
session_id: 0babf5b6_2
source_conversation: '[[session/dialog/0babf5b6_2.jsonl]]'
---

## Artistic Interests and Historical Context
The user is actively seeking recommendations for contemporary art exhibitions with a specific preference for emerging artists [[session/dialog/0babf5b6_2.jsonl#L1-L2]].
Key interests include thought-provoking themes such as social justice, environmentalism, and technology [[session/dialog/0babf5b6_2.jsonl#L2]].
A past visit to the **Contemporary Art Space** occurred in **October** featuring a renowned artist; the user spent more than two hours there absorbing the experience [[session/dialog/0babf5b6_2.jsonl#L1]].
The user previously attended the "**Contemporary Art Exhibition**" at the **Modern Art Museum**, where the user viewed amazing installations and paintings by emerging artist **Sarah Johnson** that focused on climate change [[session/dialog/0babf5b6_2.jsonl#L5]].

## Recommended Online Platforms
The assistant provided a detailed list of digital resources for discovering emerging artists and curated collections [[session/dialog/0babf5b6_2.jsonl#L4]].

### General Discovery and Community Platforms
*   **Artsy**: A leading platform featuring a vast collection of emerging and established artworks with dedicated sections and filtering tools [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Saatchi Art**: An online gallery focusing on emerging artists with curated collections and events [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Behance**: A creative portfolio platform allowing discovery by medium, style, or location [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Instagram**: Social media channel for discovery using hashtags like `#emergingartist`, `#artoftheday`, and `#contemporaryart` [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Juxtapoz**: An online magazine publishing artist interviews, profiles, and exhibition news [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Hyperallergic**: A blog covering art world news and in-depth emerging artist coverage [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **New American Paintings**: A platform highlighting emerging painters from the United States through a magazine and archive [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **ArtNet**: An art platform offering news, exhibitions, and emerging artist search capabilities [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **The Artist's Institute**: An online platform showcasing emerging talent through essays and interviews [[session/dialog/0babf5b6_2.jsonl#L4]].
*   **Platform**: A global resource curating emerging artworks and artist profiles [[session/dialog/0babf5b6_2.jsonl#L4]].

### Curated Contemporary Art Platforms
*   **Artspace**: Focuses specifically on contemporary art and emerging artists with curated selections [[session/dialog/0babf5b6_2.jsonl#L8]].
*   **1stdibs**: A marketplace partnering with galleries to display high-quality contemporary art and antiques [[session/dialog/0babf5b6_2.jsonl#L8]].
*   **Uprise Art**: Dedicated to emerging artists with direct purchasing options for artworks [[session/dialog/0babf5b6_2.jsonl#L8]].
*   **Minted**: Showcases unique and exclusive contemporary art and design from emerging creators [[session/dialog/0babf5b6_2.jsonl#L8]].
*   **Collecteurs**: Provides curated contemporary art selections tailored to collector interests [[session/dialog/0babf5b6_2.jsonl#L8]].

## User Next Steps
The user intends to explore **Artsy**, **Saatchi Art**, **Artspace**, and **Uprise Art** to find relevant emerging artists and artworks [[session/dialog/0babf5b6_2.jsonl#L9-L11]].
