---
description: Comprehensive extraction of a digital literacy curriculum module designed
  for 6th-grade elementary students, specifically detailing the 10th session focused
  on evaluating online information via the CRAAP Test. Document includes complete
  tabular scheduling (timings, activities, materials, outcomes), assessment protocols,
  pedagogical techniques for facilitating structured reflection and discussion, and
  vetted EdTech software recommendations for classroom interactivity.
name: digital-literacy-lesson-plan-6th-grade
session_id: sharegpt_RrdCPkt_0
source_conversation: '[[session/dialog/sharegpt_RrdCPkt_0.jsonl]]'
---

## Context and Pedagogical Requirements
- Instructor Role Designation: Media education instructor.
- Target Audience: 6th-grade elementary school students.
- Course Positioning: 10th session within a sequential digital literacy curriculum.
- Output Format Mandate: Tabular layout for schedule and activity breakdown.
- Language Configuration: English. [[session/dialog/sharegpt_RrdCPkt_0.jsonl#L1-L2,L3-L4]]

## Initial Framework Overview (General Scope)
- Initial System Output Title: Digital Literacy Lesson Plan for 6th Grade.
- Core Objective: Equip students with competencies to safely navigate digital environments, recognize online threats, adopt responsible behavioral standards, and leverage technology for academic enhancement.
- Resource Inventory: Computers/laptops with active internet connectivity; standard whiteboards with writing markers; physical distributions of the Digital Citizenship and Responsibility Checklist; web-based repositories including Common Sense Media's Digital Citizenship Curriculum; supplementary audiovisual assets covering "Internet Safety for Kids" and "What is Cyberbullying?".
- Structural Timeline: 10-minute conceptual introduction regarding technological benefits and hazards; 20-minute directive phase reviewing protection protocols, cyberbullying prevention, and digital etiquette; 30-minute collaborative practical exercise utilizing an online scavenger hunt to catalog trustworthy science or history domains; mandatory 10-minute pause; 20-minute mediated viewing segment culminating in a collaborative development of operational dos and don'ts; closing 10-minute synthesis emphasizing daily responsibility application.
- Evaluation Mechanisms: Continuous observation of collaborative engagement, rubric-based grading of student deliverables, and summative comprehension checks executed through oral examinations or written quizzes. [[session/dialog/sharegpt_RrdCPkt_0.jsonl#L2]]

## Session 10 Execution Plan: Evaluating Online Information
- Revised Title: Evaluating Online Information.
- Primary Learning Goal: Master critical analysis techniques to determine source credibility and factual reliability across digital platforms.
- Required Equipment: Internet-enabled computing devices; whiteboards; printed CRAAP Test documentation; curated digital archives containing journalistic reports and scholarly publications.
- Scheduled Module Breakdown:
  - Opening Directive (10 minutes): Establish foundational definitions regarding source verification and articulate the necessity of cross-referencing digital claims.
  - Conceptual Instruction (20 minutes): Decode the CRAAP Test analytical framework (Currency, Relevance, Authority, Accuracy, Purpose); demonstrate procedural application using live examples; student-pair exercises analyzing model texts with documented worksheet entries.
  - Field Application (30 minutes): Independent investigation of assigned themes, dual-source acquisition, systematic rating via the CRAAP worksheet, followed by public defense of selected materials before the cohort.
  - Intermission (10 minutes): Unstructured rest period.
  - Collaborative Synthesis (20 minutes): Collective drafting of verification heuristics onto whiteboard surfaces, prioritizing credential auditing and multi-platform cross-searching, alongside tactical implementation discussions.
  - Closing Summary (10 minutes): Reiterate analytical priority and mandate continuous CRAAP deployment during independent academic inquiry.
- Performance Metrics: Documentation accuracy auditing, competency demonstration through formalized testing or peer dialogue, and real-time engagement tracking throughout applied tasks. [[session/dialog/sharegpt_RrdCPkt_0.jsonl#L4]]

## Facilitation Strategies for Reflection and Discussion Phases
- Core Pedagogical Stance: Employ attentive listening paired with strategic inquiry sequences to maximize cognitive investment and knowledge retention.
- Operational Tactics: Deploy interrogative formats demanding expansive explanations rather than binary responses; implement linguistic mirroring to validate learner contributions and eliminate comprehension ambiguities; activate reciprocal listening disciplines by mandating peer summarization and subsequent probing questions; integrate schematic diagrams and mind-mapping templates to externalize internal reasoning structures. [[session/dialog/sharegpt_RrdCPkt_0.jsonl#L5-L6]]

## Validated EdTech Platforms for Classroom Interaction
- Padlet: Networked digital bulletin board system optimized for asynchronous and synchronous ideation sharing.
- Nearpod: Integrated educational delivery suite embedding dynamic polling interfaces and free-text submission channels to stimulate direct engagement.
- Flipgrid: Asynchronous video messaging ecosystem allowing learners to record and upload multimedia reactions to curriculum prompts.
- Google Jamboard: Real-time synchronized canvas environment enabling simultaneous graphical annotation and collective brainstorming sessions. [[session/dialog/sharegpt_RrdCPkt_0.jsonl#L6]]
