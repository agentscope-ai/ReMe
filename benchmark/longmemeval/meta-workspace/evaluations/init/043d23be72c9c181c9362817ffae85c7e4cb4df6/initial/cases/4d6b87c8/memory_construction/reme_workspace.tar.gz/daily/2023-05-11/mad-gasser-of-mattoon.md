---
description: Detailed archival record of the 1944 Mad Gasser of Mattoon incidents,
  including verbatim witness testimony, theoretical chemical constituents from WWII
  war plants, hypotheses regarding gas dissemination, systemic deficiencies in the
  police investigation, profiles of cleared suspects, cross-referenced historical
  mass hysteria phenomena, and biographical summaries of prominent individuals associated
  with Mattoon, Illinois.
name: mad-gasser-of-mattoon
session_id: sharegpt_kFcVnSx_15
source_conversation: '[[session/dialog/sharegpt_kFcVnSx_15.jsonl]]'
---

# Mad Gasser of Mattoon Case Archives

## Witness Testimony and Official Statements [[session/dialog/sharegpt_kFcVnSx_15.jsonl#L1-L1]]
*   Willamina "Blackie" Haisley, a Mattoon resident reporting symptoms in 1944, stated: "It was the weirdest thing I ever heard of. It seemed like something out of a storybook."
*   Harold A. Mangold, a gas company inspector investigating the incidents, stated: "It was definitely gas, but not natural gas. It was something much stronger."
*   W.H. Harrison, editor of the Mattoon Daily Journal Gazette, stated: "The Mad Gasser was probably the greatest individual menace to the health and life of the community in its history."

## Theoretical Chemical Constituents [[session/dialog/sharegpt_kFcVnSx_15.jsonl#L3-L3]]
*   Analysis of gases emanating from World War II-era war plants identified several candidates, though none were definitively confirmed in the Mattoon cases.
*   Chlorine gas: A chemical weapon deployed during World War I that continued to be utilized by Japan during World War II.
*   Mustard gas: A blistering agent causing severe burns and blisters, employed by both Allied and Axis powers.
*   Phosgene gas: A toxic agent used during World War I and in smaller quantities throughout World War II.
*   Hydrogen cyanide: A substance utilized in the Holocaust gas chambers, as well as in pesticides and fumigation.
*   Ammonia: A refrigerant widely used in the production of explosives during the war.

## Dissemination Mechanisms [[session/dialog/sharegpt_kFcVnSx_15.jsonl#L9-L9]]
*   Investigators theorized the perpetrator utilized spray guns, shooting devices, or released gas through ventilation systems and wall penetrations.
*   Eyewitnesses described observing a "flute-like" object being used to project the gas toward residences.
*   Police hypotheses suggested the substance behaved either as a heavy vapor similar to carbon disulfide pooling in low areas, or as a tear gas variant causing respiratory distress.

## Investigative Failures [[session/dialog/sharegpt_kFcVnSx_15.jsonl#L11-L11]]
*   The investigation suffered from a total absence of physical evidence, rendering suspect identification impossible.
*   Witness accounts of the gasser contradicted one another regarding stature (tall and thin versus short and stocky) and facial coverings.
*   Public panic resulted in numerous hoaxes and false alarms, hindering police ability to discern legitimate events.
*   Operational fragmentation occurred between the Mattoon Police Department, the Illinois State Police, and the Federal Bureau of Investigation due to poor inter-agency coordination.

## Subject Profiles Under Scrutiny [[session/dialog/sharegpt_kFcVnSx_15.jsonl#L13-L13]]
*   Farley Llewellyn, a former war plant employee terminated for chemical theft, appeared as a suspect due to vehicle sightings but possessed valid alibis clearing his involvement.
*   Theodore Durrant, a traveling salesman present in the region, faced suspicion due to car sightings but was exonerated via alibi verification.
*   An unverified theory implicated a mentally ill man spotted wearing a gas mask and carrying a flashlight; authorities could not prove this connection.
*   Investigators suspected pranksters or copycats responsible for fabricated attacks exploiting public fear.

## Historical Mass Hysteria Parallels [[session/dialog/sharegpt_kFcVnSx_15.jsonl#L5-L5]]
*   Salem witch trials (1692, Salem, Massachusetts): Judicial proceedings resulting in 20 executions among over 200 accusations, driven by complex social, economic, and religious factors.
*   Dancing mania (14th/15th Century, Europe): Outbreaks of uncontrollable spontaneous dancing linked to cultural fervor and psychological hysteria.
*   Satanic ritual abuse panic (1980s/1990s, United States): Widespread allegations based on dubious evidence leading to wrongful convictions.
*   Tanganyika laughter epidemic (1962, Tanzania): Contagious laughter spreading through a boarding school and surrounding area, attributed to stress and collective hysteria.
*   Pokémon panic (1997, Japan): Baseless rumors linking the video game to children's health issues leading to widespread bans.

## Prominent Mattoon Demographics [[session/dialog/sharegpt_kFcVnSx_15.jsonl#L7-L7]]
*   Burl Ives (born Jasper County, 1909; died 1995): Folk singer, actor, and author recognized for American folk music contributions and distinctive vocal style.
*   John Malkovich (born Christopher, Illinois; childhood in Benton): Actor and director acclaimed for roles in "Dangerous Liaisons," "Being John Malkovich," and "Bird Box."
*   William L. Enloe (born Mattoon, 1917; died 1997): World War II Medal of Honor recipient awarded for actions during the Battle of Okinawa.
*   Robert Ridgway (born Mount Carmel, 1850; raised Mattoon; died 1929): One of the most respected ornithologists in history.
*   Michael Finke (born Mattoon, 1952): Retired professional basketball player for the Phoenix Suns, Milwaukee Bucks, and San Antonio Spurs active in the 1970s and 1980s.
