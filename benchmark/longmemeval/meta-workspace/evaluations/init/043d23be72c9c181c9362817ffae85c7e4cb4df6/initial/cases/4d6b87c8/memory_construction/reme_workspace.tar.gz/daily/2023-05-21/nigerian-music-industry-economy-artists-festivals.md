---
description: Overview of the economic landscape of Nigeria's music industry, highlighting
  opportunities such as a large market size (over 200 million population), digital
  streaming growth via platforms like Spotify and Apple Music, and investment trends.
  Notes key challenges including piracy, poor infrastructure, limited financial support,
  copyright infringement, and cultural resistance to new concepts. Highlights specific
  rising artists (Omah Lay, Tems, Bella Shmurda, Joeboy, Oxlade, Fireboy DML, CKay)
  along with their notable releases (EPs and singles). Lists recommended annual music
  festivals in Lagos such as Felabration (celebrating Fela Kuti), Gidi Culture Festival,
  Ake Arts and Book Festival, and Lagos Jazz Festival.
name: nigerian-music-industry-economy-artists-festivals
session_id: ultrachat_411499
source_conversation: '[[session/dialog/ultrachat_411499.jsonl]]'
---

### Economic Landscape of the Nigerian Music Industry

**Market Potential**: With a population exceeding 200 million, Nigeria possesses a massive music market capable of generating significant revenue [[session/dialog/ultrachat_411499.jsonl#L1-L2]].

**Digital Growth**: Digital streaming platforms such as Spotify and Apple Music have expanded Nigerian artists' reach to a global audience, diversifying revenue streams [[session/dialog/ultrachat_411499.jsonl#L1-L2]].

**Investment Trends**: Growing demand has attracted local and foreign investment, leading to the establishment of new recording studios, record labels, and music festivals [[session/dialog/ultrachat_411499.jsonl#L1-L2]].

**Industry Challenges**:
*   **Piracy**: Illegal downloading and distribution persist, costing the industry billions of Naira in lost revenue [[session/dialog/ultrachat_411499.jsonl#L1-L2]].
*   **Infrastructure**: Scarcity of proper infrastructure, including recording studios and sound systems, hampers quality production [[session/dialog/ultrachat_411499.jsonl#L1-L2]].
*   **Financial Barriers**: Lack of government or institutional financial support makes it difficult for emerging artists to fund production and promotion [[session/dialog/ultrachat_411499.jsonl#L1-L2]].
*   **Copyright Issues**: Protection of intellectual property remains a significant hurdle affecting artist revenue [[session/dialog/ultrachat_411499.jsonl#L1-L2]].
*   **Cultural Constraints**: Traditional values and history often resist challenging the status quo, creating difficulties for artists introducing new concepts [[session/dialog/ultrachat_411499.jsonl#L1-L2]].

### Prominent Emerging Artists

The following artists have significantly impacted the Nigerian music scene recently:

*   **Omah Lay**: Singer-songwriter who achieved fame in 2020 with his debut EP "Get Layd"; known for blending Afrobeat and R&B [[session/dialog/ultrachat_411499.jsonl#L3-L4]].
*   **Tems**: Singer-songwriter recognized for her hit song "Mr Rebel" and a unique musical style [[session/dialog/ultrachat_411499.jsonl#L3-L4]].
*   **Bella Shmurda**: Singer, rapper, and songwriter famous for the hit single "Vision 2020"; has collaborated with Olamide and Davido [[session/dialog/ultrachat_411499.jsonl#L3-L4]].
*   **Joeboy**: Singer-songwriter who rose to prominence with the single "Baby" and released hits like "Beginning" and "Don't call me back" [[session/dialog/ultrachat_411499.jsonl#L3-L4]].

### Additional Upcoming Artists

Recommendations for exploring the diverse Nigerian music scene include:

*   **Oxlade**: Singer-songwriter noted for hits "Away" and "O2" [[session/dialog/ultrachat_411499.jsonl#L7-L8]].
*   **Fireboy DML**: Recognized since his hit single "Jealous", with subsequent releases "Scatter" and "Vibration" [[session/dialog/ultrachat_411499.jsonl#L7-L8]].
*   **CKay**: Singer, producer, and songwriter whose 2019 debut EP "CKay the First" received critical acclaim; has collaborated with established Nigerian artists [[session/dialog/ultrachat_411499.jsonl#L7-L8]].

### Recommended Music Festivals in Lagos

Events recommended to experience local and international talent in Nigeria:

*   **Felabration**: Annual festival celebrating Fela Kuti's life, music, and legacy; attracts thousands of attendees globally [[session/dialog/ultrachat_411499.jsonl#L5-L6]].
*   **Gidi Culture Festival**: Annual event featuring a mix of local and international artists to showcase Nigerian culture [[session/dialog/ultrachat_411499.jsonl#L5-L6]].
*   **Ake Arts and Book Festival**: Annual multidisciplinary event combining music, art, and literature [[session/dialog/ultrachat_411499.jsonl#L5-L6]].
*   **Lagos Jazz Festival**: Annual celebration of jazz music drawing both local and international jazz artists [[session/dialog/ultrachat_411499.jsonl#L5-L6]].
