---
description: Captures user's recollection of visiting 'The Art Cube' on February 15,
  2023, to see James Parker and the 'Disrupting Reality' exhibition curated by Rachel
  Lee. Includes detailed recommendations for immersive contemporary artists (e.g.,
  Anicka Yi, Chiharu Shiota), a comprehensive list of digital art resources (Artsy,
  Hyperallergic, Artnet, Colossal), key social media accounts (@artsy, @hansulrichobriss,
  @jerrysaltz, @marinaabromovic), and strategic methods for discovering local gallery
  exhibitions.
name: art-inspiration-and-resources
session_id: answer_990c8992_abs_2
source_conversation: '[[session/dialog/answer_990c8992_abs_2.jsonl]]'
---

## Exhibition Visit Context [[session/dialog/answer_990c8992_abs_2.jsonl#L1-L3,L10-L12]]
- User recounts a visit to **The Art Cube** on **February 15, 2023**, attending the opening night of an exhibition titled "**Disrupting Reality**," characterized by unique installation pieces.
- User identifies **James Parker** as an artist whose work they admired during this visit.
- During the event, User met curator **Rachel Lee** and purchased a limited edition print from one of the featured artists.
- Assistant notes potential inaccuracies regarding the existence of The Art Cube, James Parker, and Rachel Lee in current databases, suggesting the possibility of hallucination or obscurity; however, records here reflect User's stated experiences and interests.

## Contemporary Artist Recommendations [[session/dialog/answer_990c8992_abs_2.jsonl#L4-L4]]
Assistant recommends prominent contemporary practitioners known for interactive, technology-integrated, and thought-provoking installations:
- **Anicka Yi**: Korean-American artist creating interactive works exploring intersections of nature, technology, and human experience.
- **Carsten Höller**: German artist producing installations challenging perception and blurring boundaries between art, architecture, and science.
- **Chiharu Shiota**: Japanese artist specializing in large-scale immersive environments focused on body, memory, and spatial relationships.
- **Random International**: Collective utilizing light, sound, and movement to examine boundaries between technology, nature, and human experience.
- **Rafael Lozano-Hemmer**: Mexican-Canadian artist employing biometric sensors and surveillance tech to explore politics and the human body within architectural spaces.

## Digital Art Resources and Publications [[session/dialog/answer_990c8992_abs_2.jsonl#L6-L6]]
Listed platforms and publications for tracking contemporary art news, market trends, and emerging creators:
- **Websites**: **Artsy** (artsy.net, comprehensive database and news); **Hyperallergic** (hyperallergic.com, independent arts journal focusing on art/politics intersection); **Artnet** (artnet.com, market trends, auction data, and galleries); **The Culture Trip** (theculturetrip.com, emerging artist spotlights and cultural travel); **Contemporary Art Daily** (contemporaryartdaily.com, daily exhibition updates and reviews).
- **Blogs**: **Colossal** (thisiscolossal.com, visual art and design showcase); **The Jealous Curator** (thejealouscurator.com, painting, sculpture, and installation focus); **My Modern Met** (mymodernmet.com, inspiring stories and emerging talent); **Art F City** (artfcity.com, New York City art criticism and industry news); **We Make Money Not Art** (we-make-money-not-art.com, analysis of art/design technology intersections).
- **Digital Magazines**: **Frieze**, **Artforum**, **Art in America**.

## Social Media Accounts to Follow [[session/dialog/answer_990c8992_abs_2.jsonl#L6-L6]]
Specific institutional profiles and critical voices identified on Instagram and Twitter:
- **Instagram**: Institutional/gallery feeds such as @artsy, @hyperallergic, @artnet, and @museummodernart.
- **Twitter**: Prominent critics, curators, and artists including @HansUlrlichObrist, @JerrySaltz, and @MarinaAbromovic.

## Local Art Scene Discovery Strategies [[session/dialog/answer_990c8992_abs_2.jsonl#L8-L8]]
Methodological approaches recommended for locating physical exhibitions and local opportunities due to lack of location-specific AI access:
- Utilize geolocation search queries (e.g., "art exhibitions near me").
- Monitor official websites and social channels of municipal museums, independent galleries, and arts organizations.
- Search online aggregation calendars including **Eventbrite**, **Meetup**, and **Facebook Events**.
- Investigate academic institutions (local art schools/universities) for student shows, faculty exhibitions, and visiting artist showcases.
- Review regional newspapers and hyperlocal cultural blogs.
