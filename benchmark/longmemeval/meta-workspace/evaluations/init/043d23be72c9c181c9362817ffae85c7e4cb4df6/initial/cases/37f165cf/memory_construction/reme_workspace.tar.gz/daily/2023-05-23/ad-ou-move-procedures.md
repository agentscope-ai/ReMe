---
description: Procedures for moving Organizational Units (OUs) within Windows Active
  Directory, detailing the usage of the PowerShell Move-ADObject cmdlet and the Apache
  Directory Studio graphical interface.
name: ad-ou-move-procedures
session_id: sharegpt_wohQ2LX_0
source_conversation: '[[session/dialog/sharegpt_wohQ2LX_0.jsonl]]'
---

# Moving Organizational Units (OUs) in Windows Active Directory

## PowerShell Implementation
*   **Core Tool**: The `Move-ADObject` cmdlet is used to move Active Directory objects, such as Organizational Units (OUs), between locations [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
*   **Connection Procedure**: Open PowerShell and establish a connection to the domain by running `Connect-ADDomain -Server <AD_server_name>` [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
*   **Retrieval Command**: Use the `Get-ADObject` cmdlet with the `-Filter` parameter to identify targets; for example, `$sourceOUs = Get-ADObject -Filter 'Name -like "Sales*"' -SearchBase '<DN_of_parent_OU>'` retrieves OUs starting with "Sales" [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].
*   **Execution Command**: Move the targeted entries with the command `Move-ADObject -Identity $sourceOUs -TargetPath '<DN_of_destination_OU>'` [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L2-L2]].

## Apache Directory Studio Implementation
*   **Tool Overview**: Apache Directory Studio serves as a free, open-source LDAP browser and directory client for managing and navigating Active Directory structures [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
*   **GUI Navigation Steps**:
    1.  Connect to the Active Directory server via the application interface [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
    2.  In the "LDAP Browser" view, locate the Organizational Unit containing the target entries [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
    3.  Right-click the relevant entry and select "Move" from the context menu to trigger the "Move Entry" dialog box [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
    4.  Within the dialog, click "Browse" to select the destination Organizational Unit, then finalize the transfer by clicking "Finish" [[session/dialog/sharegpt_wohQ2LX_0.jsonl#L4-L4]].
