---
description: 'Drafts for HR performance notes regarding three supervised full-time
  employees: Natalie (consistently meeting goals, positive client feedback, team player),
  Jordan (showing performance improvement, strong time/resource management, proactive
  communicator), and Josh (consistent high-quality performer, strong work ethic, positive
  attitude).'
name: hr-notes-drafts-natalie-jordan-josh
session_id: sharegpt_PEr0L5a_0
source_conversation: '[[session/dialog/sharegpt_PEr0L5a_0.jsonl]]'
---

# HR Performance Notes Drafts for Supervised Employees

On 2023-05-22, the supervisor required drafted HR status records and performance notes for three supervised full-time employees: Natalie, Jordan, and Josh. [[session/dialog/sharegpt_PEr0L5a_0.jsonl#L1-L2]]

## Natalie
- **Status**: Currently employed as a full-time employee.
- **Notes**: Natalie has been consistently meeting her performance goals and has been a valuable member of the team. She recently completed a successful project and received positive feedback from the client. She is a team player and always willing to help out when needed.

## Jordan
- **Status**: Currently employed as a full-time employee.
- **Notes**: Jordan has been showing improvement in his work performance and has been taking on more responsibilities. He recently completed a challenging project and did a good job managing his time and resources. He is proactive and communicates effectively with the team.

## Josh
- **Status**: Currently employed as a full-time employee.
- **Notes**: Josh has been a consistent performer and has been delivering high-quality work. He has a strong work ethic and is always willing to go the extra mile to get the job done. He is a valuable asset to the team and has a positive attitude.
