---
description: Documentation of effective prompting strategies for Midjourney's artificial
  intelligence program. Includes guidelines on structuring visual descriptions using
  comma-separated keyword arrays rather than narrative sentences, and incorporating
  cinematic camera movements and 4K resolution requirements. Contains verified prompt
  templates for fantasy, nature, and sci-fi themes. Also records an operational session
  limitation encountered regarding hourly request rates.
name: midjourney-prompt-strategies
session_id: sharegpt_XCIKBKE_0
source_conversation: '[[session/dialog/sharegpt_XCIKBKE_0.jsonl]]'
---

## Midjourney AI Prompt Guidelines

### Core Formatting Rules
* Provide detailed and imaginative descriptions designed to help the AI understand wide ranges of language and interpret abstract concepts [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L1-L1]].
* Convert narrative-style stories into comma-separated descriptive lists to optimize result clarity [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L3-L4,L9-L10]].
* Include specific cinematography instructions such as camera positioning, panning, tilting, and focal lengths [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L7-L8]].
* Integrate technical quality tags to enforce high fidelity, specifically utilizing "4K resolution" to highlight intricate details [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L7-L8]].

## Visual Scene Templates

### Fantasy / Dragon Theme
* String: "Dragon, mystical forest, scales glistening, sunlight filtering through trees, wings beating fiercely, fiery breath, brave warriors, weapons ready, village, powerful jaws" [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L4-L4]].

### Science Fiction / Battle Scene
* String: "Futuristic battle, droids and humans, explosions, ships, aerial view, 4K resolution, intricate details, smoke and fire, pan and tilt, full scale, destruction, close-up, droid and human, intense fight, determination, intensity" [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L10-L10]].
* Directional Notes: The camera should be positioned high above the battle providing an aerial view, capturing chaos below, emphasizing smoke and fire while revealing the destruction scale via panning and tilting shots [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L8-L8]].

### Nature / Mystical Forest Theme
* String: "Mystical forest, foggy morning, misty veil, golden light, autumn leaves, old tree, creaky branches, twisted roots, moss-covered, wildlife, birds chirping, camera positioned low, 4K resolution, slow-motion, close-up, movement of leaves, texture of the bark, dew droplets" [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L12-L12]].

### Deep Sea / Underwater City Theme
* String: "An underwater city, glowing lights, futuristic technology, submarines, sea creatures, schools of fish, divers, deep sea exploration, ancient ruins" [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L6-L6]].

## Operational Events

* An attempt to recreate a prompt for a "present Japanese woman" failed because the system enforced a rate limit, returning the message: "Too many requests in 1 hour. Try again later" [[session/dialog/sharegpt_XCIKBKE_0.jsonl#L13-L14]].
