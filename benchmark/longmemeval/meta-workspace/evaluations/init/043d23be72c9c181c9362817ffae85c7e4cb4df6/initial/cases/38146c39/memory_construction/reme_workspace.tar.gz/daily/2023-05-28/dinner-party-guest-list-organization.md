---
description: Comprehensive planning guidelines and organizational frameworks established
  for a dinner party intended for the weekend of 2023-05-28. Details cover strategic
  methodologies for constructing a balanced guest list that highlights core friends
  (explicitly identifying Rachel, Emily, and Olivia) alongside social acquaintances
  to foster deeper community ties. The session formally adopts Evernote as the primary
  digital infrastructure, prescribing a rigorous hierarchical notebook architecture
  supported by an extensive multi-dimensional tagging taxonomy for managing both interpersonal
  relationships and complex logistical event requirements.
name: dinner-party-guest-list-organization
session_id: eae40261
source_conversation: '[[session/dialog/eae40261.jsonl]]'
---

# Dinner Party Guest List and Contact Organization

### Planning Context and Goals
- Objective is to host a dinner party during the weekend following 2023-05-28. [[session/dialog/eae40261.jsonl#L1-L1]]
- Intentional focus placed on actively nurturing existing friendships over time. [[session/dialog/eae40261.jsonl#L1-L1]]
- Initial draft for the close friends category features specific individuals: Rachel, Emily, and Olivia. [[session/dialog/eae40261.jsonl#L3-L3]]

### Guest Selection Strategy
- Primary consideration dictates prioritizing close friends located geographically nearby to improve confirmed attendance rates. [[session/dialog/eae40261.jsonl#L9-L10]]
- Secondary objective recommends assembling a mixed demographic encompassing diverse personalities and interests to generate natural conversation dynamics. [[session/dialog/eae40261.jsonl#L9-L10]]
- Tailoring the attendee pool depends heavily on the specific purpose defining the gathering, distinguishing between celebratory occasions and standard casual meetups. [[session/dialog/eae40261.jsonl#L9-L10]]
- Final constraint requires maintaining a manageable headcount suited to physical capacity and personal comfort boundaries. [[session/dialog/eae40261.jsonl#L9-L10,L11-L11]]
- Resolved methodology commits to centering the invitation round on close friends while selectively adding social friends requiring catch-up sessions. [[session/dialog/eae40261.jsonl#L11-L11]]

### Digital Organization via Evernote
#### Note Architecture
- Decision made to deploy Evernote as the primary software environment for contact tracking and event administration. [[session/dialog/eae40261.jsonl#L5-L5]]
- Structural framework begins with a master "Contacts" notebook branching into segmented sub-notebooks labeled "Close Friends", "Social Friends", and "Acquaintances". [[session/dialog/eae40261.jsonl#L6-L6]]
- Parallel isolation strategy creates independent notebooks named after specific occasions (e.g., "Dinner Party") designed exclusively for scheduling, grocery shopping lists, and deadline reminders. [[session/dialog/eae40261.jsonl#L6-L6]]
- Cross-referencing capability allows connecting discrete contact records directly inside the respective event notebooks. [[session/dialog/eae40261.jsonl#L6-L6]]
- Recommended functionalities include setting automated reminders for upcoming anniversaries and important dates, constructing step-by-step preparation checklists, and attaching photo or audio files to notes for contextual reference. [[session/dialog/eae40261.jsonl#L6-L6]]

#### Tagging Taxonomy
- Contact metadata utilizes multi-axis filtering criteria: Relationship tier (Close Friend, Social Friend, Colleague, Family, Mutual Friends), Geography (Local, Out-of-Town, International), Lifestyle Interests (Hobbies, Sports Teams, Music Genres, Movie Buffs), Personal Milestones (Birthday dates, Anniversary dates, Children), and Active Communication Channels (Phone lines, Email addresses, Social Media accounts). [[session/dialog/eae40261.jsonl#L8-L8]]
- Event metadata relies on operational tracking labels: Occasion classification (Dinner Party, Birthday Party), Attendee Status (Invited, Confirmed, Declined, Pending), Chronological markers (Upcoming, Past, This Week), Execution steps (Shopping List, Preparation, Follow-up), and Infrastructure requirements (Venue location, Catering services, Decorations supplies). [[session/dialog/eae40261.jsonl#L8-L8]]
