---
description: 'Record of movie recommendations provided by an assistant to a user seeking
  high-scale, non-Marvel sci-fi and action films similar to ''Avengers: Endgame''.
  Covers specific genres including giant monster movies (Kaiju), space operas, time-loop
  thrillers, dystopian narratives, and disaster films. Includes viewing history indicating
  the user re-watched ''Avengers: Endgame'' on 2023-05-20 and recently watched ''Doctor
  Strange'', while specifically asking for non-MCU titles like ''Pacific Rim'', ''Edge
  of Tomorrow'', and others.'
name: movie-recs-scale-action
session_id: answer_3be95d43_1
source_conversation: '[[session/dialog/answer_3be95d43_1.jsonl]]'
---

## User Preferences & Viewing History
- Seeking movie recommendations with scale, epic scope, grandeur, and a blend of sci-fi and action elements, specifically referencing **Avengers: Endgame** as the baseline [[L1,L3]].
- Explicitly requested **non-Marvel** recommendations because the user recently watched and enjoys Marvel movies, including **Doctor Strange** [[L3]].
- Re-watched **Avengers: Endgame** on **2023-05-20** [[L5]].
- Already seen and enjoyed **Pacific Rim: Uprising** (2018) and believes **Edge of Tomorrow** (2014) has a similar sense of urgency [[L7,L9]].

## High-Scale Sci-Fi & Action Movie Recommendations
[[session/dialog/answer_3be95d43_1.jsonl#L1-L12]]
### Giant Monsters & Kaiju Battles
- **Pacific Rim** (2013): A film directed by **Guillermo del Toro** featuring massive monsters (Kaijus) battling against giant robots (Jaegers) to save humanity [[L4-L8]].
- **Godzilla: King of the Monsters** (2019): An epic monster battle featuring iconic creatures such as **Godzilla**, **Mothra**, and **King Ghidorah**, defined by destruction and grandeur [[L6-L8]].
- **The Meg** (2018): Features a massive prehistoric shark known as the **Megalodon** terrorizing a beach resort [[L8]].

### Space Operas & Expansive Universes
- **Guardians of the Galaxy Vol. 2** (2017): An MCU film providing a mix of humor, action, and adventure focused on the mysteries of **Peter Quill**'s past [[L2]].
- **Valerian and the City of a Thousand Planets** (2017): Based on a French comic book series; features visually stunning space battles, alien creatures, and richly detailed universe building [[L6-L8]].
- **Star Wars: The Last Jedi** (2017): Provides epic scope, dramatic stakes, and action within the **Star Wars** franchise [[L4]].

### Time Manipulation & Urgent Action
- **Edge of Tomorrow** (2014): Starring **Tom Cruise**; features a time-looping narrative where soldiers fight repetitive, intense battles against an alien threat [[L4-L6,L8-L10]].
- **Looper** (2012): Starring **Joseph Gordon-Levitt** and **Bruce Willis**; focuses on altering timelines and the consequences thereof, blending action with urgency [[L10]].
- **The Tomorrow War** (2020): Starring **Chris Pratt**; follows soldiers sent to the future to combat an alien invasion involving time travel [[L10]].
- **Source Code** (2011): Starring **Jake Gyllenhaal**; a sci-fi thriller using a time-loop mechanic where a soldier relives a day to prevent a terrorist attack [[L10]].

### Dystopian, Cyberpunk & Post-Apocalyptic Settings
- **Oblivion** (2013): Starring **Tom Cruise**; set in a post-apocalyptic world where a repairman uncovers hidden truths [[L4,L8,L10]].
- **I Am Legend** (2007): Starring **Will Smith**; a desperate survival battle in desolate landscapes against a deadly contagion [[L4]].
- **Elysium** (2013): Starring **Matt Damon** and **Jodie Foster**; explores a dystopian future separated between a wealthy utopia and struggling Earth [[L10]].
- **Alita: Battle Angel** (2019): Adapts a manga into a sci-fi action story about a cyborg heroine fighting powerful forces in a post-apocalyptic setting [[L6-L8]].
- **Ghost in the Shell** (2017): Blends cyberpunk and action, following a cyborg policewoman hunting terrorists in futuristic society [[L10]].
- **Blade Runner 2049** (2017): A cerebral sequel delivering stunning visuals, complex action sequences, and sprawling narrative expansion [[L6]].
- **Hotel Artemis** (2018): Starring **Jodie Foster**; tracks a nurse running a secret hospital for criminals in a dystopian era [[L10]].

### Global Disasters, Conspiracies & Epic Action
- **Independence Day** (1996) & **Independence Day: Resurgence** (2016): Classic and expanded global alien invasion narratives emphasizing heroism and destruction [[L4-L6]].
- **The Matrix Reloaded** (2003) & **The Matrix Revolutions** (2003): Directed by **The Wachowskis**; concludes the trilogy with innovative "bullet time" action sequences [[L4-L6,L8,L12]].
- **War of the Worlds** (2005): Directed by **Steven Spielberg**; adapts the H.G. Wells novel detailing a sudden, worldwide alien incursion [[L4]].
- **Geostorm** (2017): Directed by **Dean Devlin**; centers on a network of climate-control satellites that malfunction, causing catastrophic global disasters [[L4-L8]].
- **The Fifth Element** (1997): Directed by **Luc Besson**; a fast-paced, vibrant adventure set in a visually striking futuristic world [[L4]].
- **The Cloverfield Paradox** (2018): A Netflix original where a deep-space crew uncovers a conspiracy threatening the universe [[L6-L8]].

### Large-Scale Action, Espionage & AI Themes
- **Skyscraper** (2018): Starring **Dwayne Johnson**; a former FBI agent attempts to rescue his family from a burning skyscraper [[L8]].
- **Atomic Blonde** (2017): Starring **Charlize Theron**; features high-stakes espionage and brutal close-quarters combat set in Cold War-era Berlin [[L10]].
- **Chappie** (2015): Directed by **Neill Blomkamp**; examines the emergence of consciousness in a police robot questioning its purpose [[L10]].
- **RoboCop** (2014): Remake focusing on a police officer brought back to life as a heavily armored cyborg enforcer [[L10]].
- **Captain America: The Winter Soldier** (2014): Combines action and espionage as **Steve Rogers** uncovers a sinister plot within **S.H.I.E.L.D.** [[L2]].

## Other Notable Sci-Fi & Superhero Mentions
- **The Justice League** (2017): DC superhero ensemble bringing together **Batman**, **Wonder Woman**, and **Superman** against a common threat [[L2]].
- **X-Men: Days of Future Past** (2014): Blends action and time-travel as mutants prevent a dystopian timeline [[L2]].
- **Logan** (2017): A darker take on the X-Men universe exploring emotional depth with **Wolverine** and **Professor X** [[L2]].
- **The Incredibles** (2004) & **Incredibles 2** (2018): Pixar films capturing superhero family dynamics [[L2]].
- **Spider-Man: Into the Spider-Verse** (2018): Animated film featuring visual innovation as characters from multiple dimensions team up [[L2]].
- **Big Hero 6** (2014): Follows a robotics prodigy working alongside a robot named **Baymax** to save San Fransokyo [[L2]].
