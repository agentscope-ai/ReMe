---
description: Comprehensive guide on locating reputable jewelers for appraising and
  insuring antique brooches, engagement rings, and custom pieces; outlines cost structures,
  multi-item discount policies, specific insurer requirements (Jewelers Mutual, State
  Farm), detailed appraisal workflows, required documentation for custom items like
  engraved gold cuffs, and lists specialized appraisal organizations and industry
  experts.
name: jewelry-appraisal-insurance-guide
session_id: 57594b25
source_conversation: '[[session/dialog/57594b25.jsonl]]'
---

## Finding Reputable Jewelers & Appraisers [[session/dialog/57594b25.jsonl#L1-L2]]
- Obtain referrals from friends, family, or colleagues possessing similar jewelry pieces to gather personal experiences.
- Target jewelers affiliated with professional organizations enforcing strict ethical codes: National Association of Jewelry Appraisers (NAJA), American Gem Trade Association (AGTA), American Gem Society (AGS), Jewelers Board of Trade (JBT), National Jeweler's Association (NJA).
- Review ratings and testimonials on Yelp, Google Reviews, Facebook Reviews, Trustpilot, and Better Business Bureau (BBB).
- Verify professional credentials including certifications (GIA, AGS, NAJA), tenure in the industry, and formal education in jewelry appraisal/valuation.
- Confirm available insurance options such as carrier partnerships or in-house quote capabilities.
- Narrow search to 2–3 candidate jewelers; request details on appraisal methodology, documentation deliverables, insurance offerings, and specific expertise with antique jewelry and engagement rings.
- Established entities suitable for appraisal and insurance: The RealReal (luxury consignment firm employing expert appraisers and gemologists), Worthy (digital appraisal/sales platform providing insurance options), Jewelers Mutual (specialty insurer offering appraisal services), Gemological Institute of America (GIA) (nonprofit delivering appraisal services via a network of certified gemologists).

## Cost Estimates for Appraisal & Insurance [[session/dialog/57594b25.jsonl#L3-L4]]
- Pricing fluctuates based on piece complexity, appraisal format, professional qualifications, geographic location, and insurance parameters.
- Verbal appraisal: $25–$100 (informal verbal assessment).
- Written appraisal: $50–$500 (structured report containing description, valuation, and images).
- Detailed appraisal report: $100–$2,000 (fully documented report featuring comprehensive descriptions, valuations, photography, and supporting paperwork).
- Annual insurance premiums generally range between 1.5% and 3% of the registered value (e.g., $15–$30 yearly for a $1,000 item).
- Policy deductibles typically span $0–$1,000 contingent upon carrier and plan tier.
- Anticipated ancillary expenses: Reappraisal charges (often mandated every 3–5 years by insurers), report revision fees, logistics/shipping costs, policy administration/cancellation fees, and referral/commission payouts to intermediaries.
- Carrier-specific annual premium baselines: Jewelers Mutual (1.5%–2.5%), State Farm (1.5%–3%), Liberty Mutual (1.5%–3%), Chubb (1.5%–3%), Worth Avenue Group (1.5%–2.5%).

## Multi-Item Discounts & Policy Structures [[session/dialog/57594b25.jsonl#L5-L6]]
- Jewelers Mutual: Offers a "Collection Policy" bundling multiple assets under one contract; discount scales with item quantity and aggregate value.
- State Farm: Provides a "Valuable Articles Policy" spanning multiple categories; multi-item discount yields 5%–15% premium reduction.
- Liberty Mutual: Provides a "Valuable Possessions Policy" spanning multiple categories; multi-item discount yields 5%–10% premium reduction.
- Chubb: Provides a "Valuable Articles Policy" spanning multiple categories; multi-item discount yields 5%–15% premium reduction.
- Worth Avenue Group: Provides a "Jewelry Collection Policy" spanning multiple assets; multi-item discount yields 5%–10% premium reduction.
- Supplemental discount opportunities to investigate: Bundle incentives (combining watches/jewelry), longevity rewards, vault/safe-storage credits, and trade association membership perks (e.g., American Gem Society affiliation).

## Insurance Provider Requirements & Restrictions [[session/dialog/57594b25.jsonl#L7-L8]]
### Jewelers Mutual
- Antique inventory: Mandates supplementary verification such as independent appraisals or historical provenance to establish authenticity and current market worth.
- Custom commissions: Requires granular descriptive breakdowns, independent valuations, and high-resolution imagery.
- Valuation thresholds: Enforces a $100 minimum per unit; accommodates valuations exceeding $100,000.
- Standard exclusions: Unmounted loose gems/stones, artifacts with intrinsic flaws or pre-existing damage, poorly maintained pieces, inventory with contested ownership histories.
- Credential mandates: Independent certified appraisals or gemologist assessments required for elevated-value or singular works.
### State Farm
- Antique inventory: Frequently requires independent certified appraisals or gemologist assessments.
- Custom commissions: Requires granular descriptive breakdowns, independent valuations, and high-resolution imagery.
- Valuation thresholds: Enforces a $500 minimum per unit; accommodates valuations exceeding $100,000.
- Standard exclusions: Artifacts with intrinsic flaws/pre-existing damage, poorly maintained pieces, inventory with contested ownership histories, undocumented/unlisted policy assets.
- Credential mandates: Independent certified appraisals or gemologist assessments required for elevated-value or singular works.
- Core documentation suite: Formal appraisal reports, multi-angle photographic records, historical/provenance archives, maintenance/restoration logs, manufacturer/designer authenticity certificates.

## Appraisal Workflow & Documentation Standards for Custom Jewelry [[session/dialog/57594b25.jsonl#L9-L10]]
- Execution sequence: Initial consultative alignment on coverage strategy → On-site physical examination documenting composition/craftsmanship/condition → Market comparability research weighing creator fame, scarcity, demand → Compilation of evidentiary materials → Final actuarial valuation.
- Evidentiary package for complex custom works (illustrative case: heavily engraved gold cuff): Architectural design schematics specifying alloy grade, engraving methodology, and unique structural elements; original purchase orders/commission invoices recording maker identity, creation date, and transaction price; authorized certificates of authenticity issued by designing artisans/firms; third-party professional appraisal memoranda; macro/micro photography isolating surface details and metallurgical traits; assayed material certifications verifying purity and mass; archival provenance chronicles tracking exhibition history, bibliographic citations, or distinguished prior custodians.
- Preservation protocols: Centralize physical and digital repositories housing receipts, valuation summaries, and certification dossiers; engage specialists exclusively versed in bespoke manufacturing methodologies; supply exhaustive technical metadata to optimize valuation precision; maintain encrypted cloud mirroring of all photographic and documentary assets against theft or degradation scenarios.

## Specialized Appraiser Organizations & Industry Experts [[session/dialog/57594b25.jsonl#L11-L12]]
### Professional Bodies & Credential Frameworks
- The Appraisal Institute of America (AIA): Administers the Jewelry and Personal Property (JPP) credential.
- National Association of Jewelry Appraisers (NAJA): Awards the Certified Jewelry Appraiser (CJA) designation.
- American Gem Society (AGS): Grants the Certified Gemologist Appraiser (CGA) certification.
- The Gemological Institute of America (GIA): Nonprofit institution delivering standardized gemological appraisal services.
- The American Society of Appraisers (ASA): Bestows the Personal Property (PP) specialization track.
- The National Jewelry Appraisal Institute (NJA): Confers the Certified Jewelry Appraiser (CJA) professional mark.
- Digital Directories: The Appraisal Foundation (regulatory guidance and directory listings), Jewelry Appraisal Institute (consumer-facing matchmaking portal).
### Recognized Practitioners
- Cindy Edelstein: Leading authority conducting valuations for vintage estates and bespoke commissions.
- Geoffrey Munn: Academic jewelry historian executing forensic appraisals for period and custom creations.
- Elise B. Misiorowski: Specialist tracing provenance and assessing transatlantic (European/American) heritage collections.
