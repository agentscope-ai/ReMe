---
description: Detailed character sheets for Lily Underfoot (Halfling Arcane Trickster
  Rogue) and Jasper Duskwhisper (Half-Elf College of Lore Bard), including specific
  ability scores, skill selections, equipment, spell lists, and backstory. Includes
  a documented rule correction regarding Arcane Trickster cantrip counts per the Player's
  Handbook. Captures established backstory for the four-adventurer party (Soloman,
  Finn, Jasper, Mia), detailing their formation via a Wild West caravan guarding contract,
  encountered hazards, and their current status of several months of active adventuring.
name: dnd-character-sheets-and-party-backstory
session_id: sharegpt_cMHMPNy_29
source_conversation: '[[session/dialog/sharegpt_cMHMPNy_29.jsonl]]'
---

## Character Sheet: Lily Underfoot

**Rule Note:** Initial draft listed 2 cantrips; corrected to 3 cantrips per the *Player's Handbook* requirement for the Arcane Trickster archetype. Added *Prestidigitation*.
- **Name:** Lily Underfoot
- **Race:** Halfling
- **Class:** Rogue (Arcane Trickster)
- **Background:** Criminal
- **Alignment:** Chaotic Neutral
- **Ability Scores:** Strength: 8, Dexterity: 16, Constitution: 12, Intelligence: 16, Wisdom: 10, Charisma: 12
- **Skills:** Acrobatics (Dex), Deception (Cha), Sleight of Hand (Dex), Stealth (Dex), Investigation (Int), Arcana (Int)
- **Equipment:** Shortsword, Hand crossbow with 20 bolts, Thieves' tools, Leather armor, Burglar's pack, 15 gold pieces
- **Spells Known:** Cantrips: Mage Hand, Minor Illusion, Prestidigitation | 1st Level Spells: Disguise Self, Sleep
- **Backstory:** Born into a family of thieves and rogues, learned the art of thievery from a young age. As a Halfling, small size and nimbleness made her an ideal pickpocket and burglar. Always fascinated by magic, spent hours studying arcane lore in secret. Natural curiosity and talent led her to pursue the Arcane Trickster path, blending rogue skills with magical abilities. Expert at using illusions and enchantments to distract and confuse targets. Not motivated purely by greed; seeks new challenges and enjoys the thrill of difficult heists. Fiercely independent, resents being told what to do. Trusts few people, constantly scanning for potential threats or double-crosses. [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L1-L3]]

## Character Sheet: Jasper Duskwhisper

**Rule Note:** Initially generated as a Level 3 Half-Elf Bard (College of Valor); rewritten to College of Lore per user request.
- **Name:** Jasper Duskwhisper
- **Race:** Half-Elf
- **Class:** Bard (College of Lore)
- **Level:** 3
- **Background:** Sage
- **Alignment:** Neutral Good
- **Ability Scores:** Strength: 10, Dexterity: 16, Constitution: 12, Intelligence: 14, Wisdom: 12, Charisma: 16
- **Skills:** Acrobatics (Dex), Deception (Cha), Investigation (Int), Performance (Cha), Persuasion (Cha), Stealth (Dex)
- **Equipment:** Shortsword, Shortbow with 20 arrows, Lute, Leather armor, Scholar's pack, 10 gold pieces
- **Spells Known:** Cantrips: Dancing Lights, Mage Hand, Vicious Mockery | 1st Level Spells: Charm Person, Cure Wounds, Dissonant Whispers, Faerie Fire, Healing Word, Thunderwave
- **Backstory:** Born to a family of wandering bards and performers. Showed remarkable musical aptitude from a young age; parents encouraged a career as a bard. Proved talented in music and performance, known for soaring vocals and intricate lute playing. Content to simply entertain crowds; also a voracious reader and scholar with deep interest in history, mythology, and arcane lore. Spent countless hours studying ancient texts and practicing spellcasting. Joined the College of Lore, a prestigious institution focused on scholarship and learning. Delved deeper into mysteries of magic and music. Highly valuable to adventuring parties, utilizing magic to charm enemies and heal allies through music. [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L5-L7]]

## Party Formation & Dynamics

- **Identified Members:** Soloman, Finn, Jasper, Mia
- **Origin Story:** Met when all four were hired by a wealthy merchant to guard a caravan traveling through the Wild West. The merchant hired individuals based on their unique skills, intending to create a formidable team.
- **Journey Hazards:** Encountered numerous dangers including bandits, outlaws, and natural hazards such as sandstorms and wild animals.
- **Outcome:** Overcame challenges collectively through combined efforts; successfully escorted the caravan to its destination.
- **Current Status:** Continued working together after the initial job concluded, recognizing high teamwork effectiveness. Have been adventuring together for several months, accepting various jobs and quests requiring their distinct skill sets.
- **Relationship:** Developed a strong bond despite differing backgrounds and personalities; trust each other implicitly. [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L8-L9]]
