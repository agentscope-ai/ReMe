---
description: Lists of common objects associated with Easter (including descriptive
  context), Mother's Day (item names only), and the fast-food brand Jollibee (specific
  menu items and merchandise).
name: holiday-and-brand-iconography
session_id: sharegpt_d6Xeauh_0
source_conversation: '[[session/dialog/sharegpt_d6Xeauh_0.jsonl]]'
---

## Easter Objects [[session/dialog/sharegpt_d6Xeauh_0.jsonl#L1-L2]]
- Easter eggs (usually made of chocolate or decorated hard-boiled eggs)
- Easter baskets (usually filled with candy, small toys, or other treats)
- Easter bunny (a symbol of Easter in many countries, often depicted as delivering eggs and candy)
- Easter chicks (baby chickens often used as a symbol of new life during Easter)
- Cross (a symbol of the Christian faith and the resurrection of Jesus)
- Hot cross buns (a sweet spiced bread traditionally eaten on Good Friday)
- Easter lilies (a type of flower commonly used in Easter decorations)
- Peeps (marshmallow candies shaped like chicks, bunnies, or other Easter-themed shapes)
- Easter grass (shredded paper or plastic used to line Easter baskets)
- Jelly beans (small candy in a variety of flavors and colors, often associated with Easter treats)

## Mother's Day Objects [[session/dialog/sharegpt_d6Xeauh_0.jsonl#L3-L4]]
- Cards
- Flowers (especially roses)
- Jewelry
- Perfume
- Chocolates or candy
- Breakfast in bed
- Photo frames or albums
- Clothing or accessories
- Spa or beauty treatments
- Home decor or kitchenware gifts

## Jollibee Objects [[session/dialog/sharegpt_d6Xeauh_0.jsonl#L5-L6]]
- Jollibee mascot costume
- Chickenjoy (Jollibee's famous fried chicken)
- Yumburger (Jollibee's signature burger)
- Jolly Spaghetti
- Peach Mango Pie
- Jollibee toys (given with kids' meals)
- Jollibee party hats
- Jollibee tumblers and cups
- Jollibee balloons
- Jollibee food containers and packaging
