---
description: 'A comprehensive recipe for Paneer Bhurji using store-bought paneer.
  Details include step-by-step cooking instructions and two sets of ingredient measurements:
  a base ratio for approximately one cup of crumbled paneer, and a revised quantitative
  list specifically scaled for 400g of paneer. Covers spice quantities (cumin, coriander,
  turmeric, red chili powder, garam masala, cumin powder) and the preparation sequence
  (sautéing aromatics, cooking tomatoes, spicing crumbled paneer, and serving suggestions
  like roti or rice).'
name: paneer-bhurji-recipe
session_id: sharegpt_IZ5NgqD_0
source_conversation: '[[session/dialog/sharegpt_IZ5NgqD_0.jsonl]]'
---

## Paneer Bhurji Recipe

### Base Recipe Parameters (Approx. 1 Cup Paneer)
These are the standard measurements for a single-serving portion or base preparation:
- **Paneer**: 1 cup, crumbled
- **Aromatics**: 
    - 1 medium onion, finely chopped
    - 1 medium tomato, finely chopped
    - 1 green chili, finely chopped
    - 1 teaspoon ginger paste
    - 1 teaspoon garlic paste
- **Spices & Seasoning**:
    - 1/2 teaspoon cumin seeds
    - 1/2 teaspoon coriander seeds
    - 1/4 teaspoon turmeric
    - 1/2 teaspoon red chili powder
    - 1/2 teaspoon garam masala
    - 1/4 teaspoon cumin powder
    - Salt, to taste
- **Cooking Oil**: 2 tablespoons
- **Garnish**: Chopped cilantro [[session/dialog/sharegpt_IZ5NgqD_0.jsonl#L2]]

### Adjusted Quantities for 400g Paneer
The following list represents the revised proportions required when increasing the main ingredient to 400g of paneer. These quantities supersede the base parameters above:
- **Paneer**: 400g, crumbled
- **Aromatics**:
    - 2 medium onions, finely chopped
    - 2 medium tomatoes, finely chopped
    - 2 green chilies, finely chopped
    - 2 teaspoons ginger paste
    - 2 teaspoons garlic paste
- **Spices & Seasoning**:
    - 1 teaspoon cumin seeds
    - 1 teaspoon coriander seeds
    - 1/2 teaspoon turmeric
    - 1 teaspoon red chili powder
    - 1 teaspoon garam masala
    - 1/2 teaspoon cumin powder
    - Salt, to taste
- **Cooking Oil**: 4 tablespoons
- **Garnish**: Chopped cilantro [[session/dialog/sharegpt_IZ5NgqD_0.jsonl#L4]]

### Cooking Procedure
The following method applies consistently across both quantity variations:
1. **Heating**: Heat the specified amount of oil in a pan over medium heat.
2. **Tempering**: Add the whole cumin seeds and coriander seeds; allow them to sizzle for a few seconds.
3. **Sautéing Aromatics**: Add the chopped onions, green chilies (adjust quantity per scaling), and ginger paste. Sauté the mixture until the onions turn translucent.
4. **Cooking Tomatoes**: Add the chopped tomatoes and continue cooking until they become soft and mushy.
5. **Combining Paneer**: Add the crumbled paneer to the pan and mix well with the vegetable base.
6. **Spicing**: Add the ground spices—turmeric, red chili powder, garam masala, and cumin powder—along with salt. Mix thoroughly to ensure even coating.
7. **Final Cooking**: Continue cooking the mixture for 2–3 minutes, ensuring the paneer absorbs the spices and is well-coated.
8. **Serving**: Remove from heat, garnish with chopped cilantro, and serve hot alongside roti or rice. [[session/dialog/sharegpt_IZ5NgqD_0.jsonl#L2,L4]]
