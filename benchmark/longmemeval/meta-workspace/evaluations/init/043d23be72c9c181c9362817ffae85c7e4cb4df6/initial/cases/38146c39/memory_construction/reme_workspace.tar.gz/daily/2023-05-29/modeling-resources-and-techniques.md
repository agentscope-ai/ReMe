---
description: Technical advice and resource compilation for 1/48 scale 1940s–1980s
  military modeling. Covers constructing realistic WWII Pacific island dioramas for
  B-29 aircraft and fabricating detailed 1/48 scale USS Iowa naval models, including
  specific weathering techniques (drybrushing, washes, rust effects) and scratch-building
  practices. Includes an extensive directory of online communities, literature, and
  manufacturers such as Trumpeter, Tamiya, Vallejo, and AK Interactive.
name: modeling-resources-and-techniques
session_id: a86b30e4
source_conversation: '[[session/dialog/a86b30e4.jsonl]]'
---

## User Hobbies and Active Projects [[session/dialog/a86b30e4.jsonl#L1-L3,L5-L9]]
* User re-engaged with physical model building as a creative hobby over the period leading up to 2023-05-29.
* Primary focus areas include aircraft modeling and large-scale vessel construction.
* Currently designing a physical diorama base intended to depict a World War II-era Pacific island airfield suitable for placing a B-29 bomber model.
* Preparing to assemble a 1/48 scale replica of the USS Iowa heavy cruiser/battleship, intending to augment standard kit components with hand-sculpted and fabricated additions.
* Building basic functional mechanical parts from raw materials (including metal barrels and antenna structures) to achieve higher fidelity than factory-supplied alternatives.

## Diorama Fabrication: Pacific Island Runway Scene [[session/dialog/a86b30e4.jsonl#L2-L2]]
* Establish a foundational substrate using sloped foam or wooden boards, textured with mixed sand, pebbles, and static fibers to replicate natural tropical ground cover.
* Mold flat runway strips using styrene or resin sheets, applying artificial scratches and discolorations to simulate heavy vehicular and aerodynamic wear.
* Populate the surrounding landscape with synthetic palm trees, constructed wire-framed ferns, bushes, and scattered vine elements to create dense foliage depth.
* Construct auxiliary structures such as hangars, control towers, and maintenance sheds utilizing prefabricated kits or scratch-built architectural frameworks.
* Place scale-appropriate ground support equipment including jeeps, trucks, fuel tankers, oil drums, toolboxes, and wheel chocks to establish active operational atmosphere.
* Paint standardized runway identifiers, taxiway demarcations, and warning signage to maintain historical accuracy matching Guam, Saipan, or Tinian facilities.
* Embed miniature personnel figures representing pilots and ground maintenance crews to provide scale reference and narrative context.
* Install miniature LED illumination systems or apply luminous glow paint to generate authentic daylight or nighttime flight operations ambiance.

## Naval Scale Construction: 1/48 USS Iowa [[session/dialog/a86b30e4.jsonl#L6,L8,L12]]
* Source highly detailed injection-molded kits produced by manufacturers Trumpeter or Tamiya. Strip away visible plastic flash lines and mold artifacts before assembly.
* Seal bare surfaces with high-quality aerosol primers followed by uniformly applied light gray or beige enamel undercoats designed to match painted steel hull configurations.
* Apply specialized acrylic and enamel finishing layers—specifically Vallejo Model Air products and AK Interactive Naval Colors—to execute historically accurate wartime camouflage and marking patterns.
* Execute multi-stage weathering processes: utilize drybrushing methods with lighter grays to highlight surface ridges; apply concentrated liquid washes to recessed seams for grime accumulation; manually paint microscopic impact chips and abrasion marks onto painted panels.
* Treat exposed exterior decks by stamping artificial wood-grain textures over base planks, then layering localized stains, rust bleeding, and corrosion agents to replicate severe marine exposure.
* Attach structural superstructures sequentially, prioritizing the integration of bridge towers, funnel assemblies, and communication masts to secure vertical proportions early in the process.
* Install massive primary weaponry—specifically 16-inch artillery turrets—alongside secondary portholes, rivets, and anchor chains directly onto the main hull segments.
* Add final delicate accessories last: weave rigid copper wires and lightweight aluminum tubing to represent navigation antennas, crane booms, cable winches, pulley systems, and mooring lines.
* Encase the fully finished scale replica inside custom transparent display cabinets featuring targeted internal lighting schemes to accentuate deep shadowing and material contrasts.

## Recommended Literature and Digital Communities [[session/dialog/a86b30e4.jsonl#L4,L6,L8]]
* Join dedicated technical forums including Hyperscale, Scalemates, Model Mayhem, ModelWarships.com, and The Ship Model Forum to exchange blueprints, troubleshooting techniques, and finish critiques.
* Follow instructional video channels hosted by established industry experts Mig Jimenez, Scale Model Builder, Model Shipwrights, The Modeling Community, and The Model Shipyard.
* Read authoritative periodicals such as FineScale Modeler magazine, Scale Model Handbook series, and The Weathering Magazine for periodic technique breakdowns and industry news.
* Consult comprehensive instructional texts like *The Ship Model Builder's Handbook*, *Naval Modeling: A Guide to Building and Detailing Model Warships*, Mig Jimenez's *The Scratch-Building Guide*, and the freely distributed digital handbook *The Modeler's Guide to Scratch-Building*.
* Monitor visual galleries on Instagram feeds and participate in community-driven Facebook networks specifically titled Scale Model Builders and Model Building Community.
* Study archival articles published on the websites Modeling Madness, Scale Model News, and The Plastic Surgeon.

## Material Specifications and Manufacturing Brands [[session/dialog/a86b30e4.jsonl#L6-L8]]
* **Kit Manufacturers:** Trumpeter, Tamiya.
* **Finish Coatings:** Vallejo Model Air, AK Interactive Naval Wash, AK Interactive Naval Colors.
* **Weathering Agents:** Vallejo Wood Grain stamping compound, Vallejo Rust chemical treatments, AK Interactive Rust and Corrosion pastes.
* **Fabrication Substrates:** Acrylic styrene sheets, casting resins, brass/metal rods, copper wiring, thin-wall aluminum tubing.
