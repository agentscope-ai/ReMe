---
description: A curated list of eight mandatory markets in Marrakech, Morocco, detailing
  their primary merchandise, geographic context, and visitor tips (e.g., arriving
  early at Souk El Khemis). The note also catalogs six staple street foods to sample
  at Jemaa el-Fnaa, including tagine, harira, tanjia, mint tea, grilled meats, and
  pastries. The conversation concludes with the traveler deciding to initiate their
  market circuit at Jemaa el-Fnaa before branching out to Souk Semmarine and Rahba
  Kedima.
name: marrakech-markets-and-street-food
session_id: ultrachat_358391
source_conversation: '[[session/dialog/ultrachat_358391.jsonl]]'
---

## Markets in Marrakech [[session/dialog/ultrachat_358391.jsonl#L1-L2]]
- **Jemaa el-Fnaa**: The iconic square in the heart of the Old City functions as a vibrant, bustling marketplace selling Moroccan handicrafts, spices, and traditional street food.
- **Souk Semmarine**: Located in the heart of Marrakech's Medina, the market provides clothes, shoes, handbags, and Moroccan souvenirs.
- **Souk El Khemis**: Recognized for antique and vintage items including carpets, textiles, and jewelry; visitors should arrive early in the morning to secure the best deals.
- **Babouche Souk**: Dedicated to traditional Moroccan slippers called babouche, the vendor stalls offer a wide range of styles and colors handcrafted by local artisans.
- **Rahba Kedima**: Known as the "Spice Square," the marketplace sells various Moroccan spices, herbs, and essential oils.
- **Souk Smarine Leather Market**: Situated near Jemaa el-Fnaa, the market features rows of leather goods such as bags, belts, shoes, and jackets available at reasonable prices.
- **Marché Atiq**: The venue is widely popular for authentic Moroccan pottery, ceramics, and kitchenware.
- **Ensemble Artisanal**: The government-run complex showcases high-quality artisanal crafts and souvenirs created by artisans from across Morocco.

## Recommended Street Foods [[session/dialog/ultrachat_358391.jsonl#L5-L6]]
- **Tagine**: A traditional Moroccan dish consisting of slow-cooked meat or vegetables with spices, typically served with bread.
- **Harira**: A spicy and hearty soup prepared with lentils, chickpeas, and lamb.
- **Tanjia**: A meat dish cooked inside a clay pot, traditionally prepared by men for special occasions.
- **Moroccan Tea**: Mint tea is heavily consumed in Marrakech and is served in small glasses alongside sugar cubes.
- **Grilled Meats**: Food vendors provide grilled items throughout the market, including kebabs, merguez sausages, and lamb chops.
- **Moroccan Pastries**: The sweet treat options encompass baklava, almond cookies, and honey-soaked pastries.

## Travel Plan & Decisions [[session/dialog/ultrachat_358391.jsonl#L3-L4]]
- The assistant advised beginning the market tour at **Jemaa el-Fnaa**, citing its reputation as the most famous market and the heart of Marrakech's old city to immerse visitors in the vibrant atmosphere before proceeding to **Souk Semmarine** or **Rahba Kedima**.
- The user accepted this recommendation and planned to begin their exploration at **Jemaa el-Fnaa** to experience the local street food.
