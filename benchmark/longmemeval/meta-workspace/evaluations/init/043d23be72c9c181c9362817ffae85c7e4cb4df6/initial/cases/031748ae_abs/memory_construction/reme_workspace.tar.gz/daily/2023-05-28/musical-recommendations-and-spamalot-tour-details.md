---
description: On 2023-05-28, the user began listening to The Book of Mormon soundtrack
  and requested comedic musical recommendations, leading to suggestions including
  Avenue Q, The Producers, and Spamalot. The user confirmed prior enjoyment of Avenue
  Q and The Producers. Extensive details regarding the Spamalot touring production
  were gathered, covering international and domestic schedules (London, Manchester,
  Dublin, US 2023–2024), ticketing via ATG Tickets and Ticketmaster, and highly detailed
  set and costume designs by Tim Hatley (noted by the user as visually comparable
  in grandeur to The Great and Bridgerton). The music composed by Eric Idle and John
  Du Prez was analyzed comparatively to The Book of Mormon, alongside character analysis
  of the Lady of the Lake. Current touring personnel were identified as Steve McCoy
  (King Arthur), Emma Williams (Lady of the Lake), Richard Meek (Sir Galahad), under
  director BT McNicholl and choreographer Casey Nicholaw.
name: musical-recommendations-and-spamalot-tour-details
session_id: feba9363_1
source_conversation: '[[session/dialog/feba9363_1.jsonl]]'
---

### User Preferences & Musical Recommendations
- On 2023-05-28, the user began listening to the soundtrack of *The Book of Mormon* and requested other musicals featuring similar humor and irreverent styles.[[session/dialog/feba9363_1.jsonl#L1-L3]]
- Recommended titles included *South Park: Bigger, Longer & Uncut*, *Avenue Q*, *The Producers*, *Spamalot*, *Urinetown*, *Something Rotten!*, *The Full Monty*, *Young Frankenstein*, *The Addams Family*, and *Bat Out of Hell*.
- The user confirmed having previously attended performances of *Avenue Q* and *The Producers*, describing both productions as hilarious.
- Trey Parker and Matt Stone are noted as the creators behind both *South Park* and *The Book of Mormon*.[[session/dialog/feba9363_1.jsonl#L2]]

### Spamalot Tour Schedule & Ticket Information
- The UK and Ireland Tour 2023 includes scheduled stops in London, Manchester, Birmingham, and Dublin.[[session/dialog/feba9363_1.jsonl#L4]]
- An anticipated United States Tour for the 2023–2024 season was discussed, though specific city and date announcements had not yet been finalized at the time of the conversation.
- Past or planned international productions have taken place in Australia, Canada, and Germany.
- Official ticketing channels recommended include ATG Tickets, Ticketmaster, and Telecharge.
- Following official updates via Facebook, Twitter, and Instagram, alongside local theater newsletters, is advised for tracking new dates.

### Production Design (Set & Costumes)
- The user expresses strong appreciation for large-scale visual aesthetics, citing the production design of *The Great* and *Bridgerton* as examples of preferred visual grandeur.[[session/dialog/feba9363_1.jsonl#L5-L6]]
- Both the set and costume designs for the stage production of *Spamalot* were executed by designer Tim Hatley.
- Core set elements consist of King Arthur's Castle (including a functional drawbridge), a dense forest environment, The French Castle, and the Knights' Campground.
- The physical staging intentionally employs exaggerated scale, projection mapping, theatrical lighting, and special effects to emphasize comedic absurdity.
- Costume wardrobes feature heavily stylized knight armor, dramatic wigs, rustic peasant outfits, and intricate French court garments incorporating lace, ruffles, and feathers.
- While *The Great* and *Bridgerton* prioritize historical opulence, *Spamalot* utilizes intentional absurdity, oversized props, and period-inspired anachronism to enhance comedy.

### Music & Composition
- The user maintains a regular habit of listening to musical theatre soundtracks and was recently comparing *The Book of Mormon* to *Spamalot*.[[session/dialog/feba9363_1.jsonl#L7-L8]]
- The *Spamalot* musical score was written collaboratively by Eric Idle (a founding member of Monty Python) and John Du Prez.
- Prominent featured tracks include "The Song That Goes Like This", the iconic "Always Look on the Bright Side of Life", "Find Your Grail", and "The Diva's Lament".
- Musically, *Spamalot* relies more heavily on traditional theatrical storytelling structures and medieval-inspired tunes compared to the contemporary, pop-infused, and heavily satirical soundtrack of *The Book of Mormon*.

### Character Focus: The Lady of the Lake
- The user noted that *The Book of Mormon* frequently frames its female leads through heavy-handed satirical lenses and asked if the Lady of the Lake operates similarly.[[session/dialog/feba9363_1.jsonl#L9-L10]]
- Within the stage adaptation, the Lady of the Lake serves as a dominant, mystical guide for King Arthur who functions as a diva and seductress.
- Rather than acting as direct societal satire, her portrayal serves as an affectionate deconstruction of conventional theatrical "damsels," utilizing wit and agency to subvert expected feminine narratives while maintaining complete character depth.

### Touring Production Cast & Creative Team
- Current touring company casts feature Steve McCoy portraying King Arthur, Emma Williams as the Lady of the Lake, and Richard Meek as Sir Galahad.[[session/dialog/feba9363_1.jsonl#L11-L12]]
- Direction for the touring branch is handled by BT McNicholl, succeeding original Broadway director Mike Nichols.
- Dance sequences are maintained under the ongoing choreographic oversight of original choreographer Casey Nicholaw.
- Historical notable ensemble rosters highlight Hank Azaria (who originated the role of Sir Lancelot on Broadway) and Tim Curry (who portrayed King Arthur during the initial West End run).
