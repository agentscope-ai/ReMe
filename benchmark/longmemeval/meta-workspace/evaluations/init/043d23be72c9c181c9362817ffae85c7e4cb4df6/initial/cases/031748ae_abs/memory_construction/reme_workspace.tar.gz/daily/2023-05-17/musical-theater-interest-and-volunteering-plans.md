---
description: User notes developing interest in musical theater triggered by the 2019
  Cats film on Amazon Prime, active listening of In the Heights, and pending volunteer
  application as a local theater usher. Entry catalogs extensive genre-based musical
  recommendations including classics like West Side Story and modern hits like Hamilton.
  Additionally, details specific acquisition tactics for Hadestown Broadway tickets
  (Digital Lottery versus Rush pricing and temporal availability strategies) and outlines
  plans to coordinate behind-the-scenes support for the summer 2023 local production
  of Kinky Boots, specifically targeting the July 15, 2023 performance date.
name: musical-theater-interest-and-volunteering-plans
session_id: 4445fe6c
source_conversation: '[[session/dialog/4445fe6c.jsonl]]'
---

## User Context & Triggers [[session/dialog/4445fe6c.jsonl#L3-L5,L9-L9]]
- Interest in musical theater originated following the viewing of the 2019 film adaptation of *Cats* hosted on Amazon Prime [[session/dialog/4445fe6c.jsonl#L5-L5]].
- As of 2023-05-17, the user continuously listens to the original cast recording of *In the Heights* [[session/dialog/4445fe6c.jsonl#L3-L3]].
- As of 2023-05-17, the user submitted an application to volunteer as an usher at a local theater and awaits a response [[session/dialog/4445fe6c.jsonl#L9-L9]].

## Comprehensive Musical Theater Catalog [[session/dialog/4445fe6c.jsonl#L2-L2]]
### Classic Musicals
- ***West Side Story*** (1957): A timeless *Romeo and Juliet*-inspired narrative featuring iconic music by Leonard Bernstein and Stephen Sondheim.
- ***The Sound of Music*** (1959): Centers on a young nun becoming a governess for a large family; songs by Rodgers and Hammerstein.
- ***Chicago*** (1975): A sassy, jazz-infused story of murder, fame, and corruption in 1920s Chicago; music by John Kander and Fred Ebb.
### Modern Musicals
- ***Hamilton*** (2015): A groundbreaking hip-hop historical epic focusing on American history and featuring a diverse cast; created by Lin-Manuel Miranda.
- ***Dear Evan Hansen*** (2015): A thought-provoking story exploring social media, loneliness, and human connection; music by Benj Pasek and Justin Paul.
- ***The Book of Mormon*** (2011): An irreverent comedy following two young Mormon missionaries in Uganda; created by Trey Parker, Matt Stone, and Robert Lopez.
### Jukebox Musicals
- ***Mamma Mia!*** (1999): A fun musical utilizing the hits of ABBA set upon a Greek island.
- ***Jersey Boys*** (2005): Documents the true story of the rock group The Four Seasons.
- ***On Your Feet!*** (2015): Chronicles the lives of Emilio and Gloria Estefan with infectious Latin rhythms.
### Dark and Edgy Musicals
- ***Sweeney Todd: The Demon Barber of Fleet Street*** (1979): A dark, Gothic thriller involving a vengeful barber; music by Stephen Sondheim.
- ***Les Misérables*** (1980): An emotional adaptation of Victor Hugo's novel set in 19th-century France.
- ***Spring Awakening*** (2006): A provocative rock-infused narrative concerning teenage rebellion in 19th-century Germany.
### Additional Recommendations
- ***Hadestown*** (2019): A folk-opera retelling of the Orpheus and Eurydice myth with music by Anaïs Mitchell.
- ***The Band's Visit*** (2017): Follows an Egyptian police band's visit to Israel; music by David Yazbek.
- ***In the Heights*** (2008): A tribute to Washington Heights blending hip-hop, salsa, and Latin music; composed by Lin-Manuel Miranda.

## Broadway Ticket Acquisition Strategy: Hadestown [[session/dialog/4445fe6c.jsonl#L4-L6]]
### Official Channels & Pricing
- Authorized purchasing platforms include Telecharge (telecharge.com), Ticketmaster (ticketmarket.com), and the official website (hadestown.com/tickets) [[session/dialog/4445fe6c.jsonl#L4-L4]].
- Auxiliary apps include TodayTix and Lucky Seat for last-minute opportunities [[session/dialog/4445fe6c.jsonl#L4-L4]].
- Secondary markets exist via StubHub and Vivid Seats [[session/dialog/4445fe6c.jsonl#L4-L4]].
- **Digital Lottery**: Provides online entry for a chance to win tickets priced at $30 each; results notify winners 24 hours prior to the performance [[session/dialog/4445fe6c.jsonl#L4-L4]].
- **Rush Tickets**: A limited number of $30 tickets are available physically at the box office starting at 10:00 AM on performance days [[session/dialog/4445fe6c.jsonl#L4-L4]].
- **Physical Location**: The Walter Kerr Theatre box office is situated at 219 W 48th St in New York City [[session/dialog/4445fe6c.jsonl#L4-L4]].
### Temporal Availability Optimization
- Maintaining a flexible range of dates improves success rates by capturing unexpected cancellations or price drops [[session/dialog/4445fe6c.jsonl#L6-L6]].
- Prioritizing weekday shows (Tuesday through Thursday) typically yields better stock levels and lower prices compared to weekend performances [[session/dialog/4445fe6c.jsonl#L6-L6]].
- Targeting matinee performances increases the probability of finding available inventory over evening shows [[session/dialog/4445fe6c.jsonl#L6-L6]].
- Visiting during low-tourism windows, such as the winter months spanning December to February, may improve overall availability [[session/dialog/4445fe6c.jsonl#L6-L6]].

## Local Theater Volunteer Operations Plan [[session/dialog/4445fe6c.jsonl#L7-L12]]
### Usher Position Details
- Core duties encompass greeting patrons, scanning tickets, and guiding individuals to their assigned seats [[session/dialog/4445fe6c.jsonl#L8-L8]].
- Perks provide free viewing access either from designated usher seats or by observing from the wings [[session/dialog/4445fe6c.jsonl#L8-L8]].
- Access extends to behind-the-scenes areas including dressing rooms, backstage technical zones, and crew interaction [[session/dialog/4445fe6c.jsonl#L8-L8]].
- Requires arriving roughly one to two hours prior to showtimes and maintaining professional conduct across varying shifts, including evenings and weekends [[session/dialog/4445fe6c.jsonl#L8-L8]].
### Expanded Production Opportunities
- Alternative operational departments accessible through further training include set construction/scenic painting, costume wardrobe operations, lighting/sound systems, and stage management [[session/dialog/4445fe6c.jsonl#L10-L10]].
- Proactive engagement requires direct communication with volunteer coordinators, flexibility toward unfamiliar tasks, and attendance at department-specific orientations [[session/dialog/4445fe6c.jsonl#L10-L10]].
### Summer 2023 Project Engagement
- The user initiated contact procedures with a local theater organization intending to assist behind-the-scenes with the summer 2023 staging of *Kinky Boots* [[session/dialog/4445fe6c.jsonl#L11-L11]].
- Specific attendance confirmed for the July 15, 2023 performance of *Kinky Boots* [[session/dialog/4445fe6c.jsonl#L11-L11]].
- Strategic outreach involves notifying the production team directly regarding specific availability blocks for load-in, technical rehearsals, and strike operations [[session/dialog/4445fe6c.jsonl#L12-L12]].
