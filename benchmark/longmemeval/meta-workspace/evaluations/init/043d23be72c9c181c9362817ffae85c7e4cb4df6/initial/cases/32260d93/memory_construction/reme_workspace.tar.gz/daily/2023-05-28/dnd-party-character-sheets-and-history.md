---
description: Detailed character profiles for D&D party members Lily Underfoot (Halfling
  Rogue Arcane Trickster) and Jasper Duskwhisper (Half-Elf Bard College of Lore),
  including corrected ability scores, skill selections, equipment loadouts, spell
  lists, and full backstories. Also documents the group composition (Soloman, Finn,
  Jasper, Mia), their recruitment by a wealthy merchant to guard a Wild West caravan,
  combat encounters, and established multi-month tenure as a trusted adventuring party.
name: dnd-party-character-sheets-and-history
session_id: sharegpt_cMHMPNy_29
source_conversation: '[[session/dialog/sharegpt_cMHMPNy_29.jsonl]]'
---

## D&D Party Characters

### Lily Underfoot
- **Race:** Halfling
- **Class:** Rogue (Arcane Trickster archetype)
- **Background:** Criminal
- **Alignment:** Chaotic Neutral
- **Ability Scores:** Strength 8, Dexterity 16, Constitution 12, Intelligence 16, Wisdom 10, Charisma 12
- **Skills:** Acrobatics (Dexterity), Deception (Charisma), Sleight of Hand (Dexterity), Stealth (Dexterity), Investigation (Intelligence), Arcana (Intelligence)
- **Equipment:** Shortsword, hand crossbow with 20 bolts, thieves' tools, leather armor, burglar's pack, 15 gold pieces
- **Spells Known:** Cantrips (Mage Hand, Minor Illusion, Prestidigitation), 1st-level spells (Disguise Self, Sleep) [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L1-L3]]
- **Backstory:** Born into a family of thieves and rogues; learned thievery from a young age. As a small and nimble Halfling, she excelled as a pickpocket and burglar. Fascinated by magic, she secretly studied arcane lore. She pursued the Arcane Trickster path, blending rogue skills with magical abilities. She uses illusions and enchantments to distract and confuse targets and is recognized as one of the most notorious and successful burglars in the city. Despite her success, she is not motivated purely by greed; she seeks new challenges, opportunities to learn, and enjoys the thrill of difficult heists. She is fiercely independent, resists being told what to do, trusts few people, and constantly watches for threats or double-crosses [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L1-L3]].

### Jasper Duskwhisper
- **Initial Statistics (Level 3 Bard, College of Valor):** Armor Class 14 (wearing studded leather armor), Hit Points 23 (derived from d8 hit dice per level plus Constitution modifier of +2), proficiency in light armor, Dexterity modifier +3. Melee weapon: Rapier (+5 to hit, 1d8+3 piercing damage). Ranged weapon: Shortbow (+5 to hit, 1d6+3 piercing damage, range 80/320) [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L5]]
- **Revised Statistics (Level 3 Bard, College of Lore):** Background Sage, Alignment Neutral Good.
- **Ability Scores:** Strength 10, Dexterity 16, Constitution 12, Intelligence 14, Wisdom 12, Charisma 16
- **Skills:** Acrobatics (Dexterity), Deception (Charisma), Investigation (Intelligence), Performance (Charisma), Persuasion (Charisma), Stealth (Dexterity)
- **Equipment:** Shortsword, shortbow with 20 arrows, lute, leather armor, scholar's pack, 10 gold pieces
- **Spells Known:** Cantrips (Dancing Lights, Mage Hand, Vicious Mockery), 1st-level spells (Charm Person, Cure Wounds, Dissonant Whispers, Faerie Fire, Healing Word, Thunderwave) [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L7]]
- **Backstory:** Born to a family of wandering bards and performers; displayed remarkable musical aptitude early on, encouraged by parents. Known for soaring vocals and intricate lute playing. A voracious reader and scholar with deep interests in history, mythology, and arcane lore. Spent countless hours studying ancient texts and practicing spellcasting. Joined the prestigious College of Lore, focusing on scholarship and learning. Delved deeper into magic and music mysteries. Possesses extensive knowledge and versatile spellcasting abilities, making him a valuable asset to any adventuring party for charming enemies or healing allies [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L7]].

## Party History & Group Composition
- **Party Members:** Soloman, Finn, Jasper Duskwhisper, and Mia [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L8]]
- **Origin Story:** The four characters met after being hired simultaneously by a wealthy merchant to guard a caravan traveling through the Wild West [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L9]]. The merchant had heard of their individual skills and believed they would form a formidable team [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L9]]
- **Early Experiences:** During the journey, they encountered numerous dangers including bandits, outlaws, natural hazards like sandstorms, and wild animals [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L9]]. Through collective effort, they overcame these challenges and successfully escorted the caravan to its destination [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L9]]
- **Current Status:** After the journey, the adventurers decided to continue working together due to their high effectiveness as a team, complementing each other's strengths and covering weaknesses [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L9]]. They have been together for several months, accepting various jobs and quests that require their unique skills [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L9]]. Despite different backgrounds and personalities, they have formed a strong bond and trust each other implicitly [[session/dialog/sharegpt_cMHMPNy_29.jsonl#L9]].
