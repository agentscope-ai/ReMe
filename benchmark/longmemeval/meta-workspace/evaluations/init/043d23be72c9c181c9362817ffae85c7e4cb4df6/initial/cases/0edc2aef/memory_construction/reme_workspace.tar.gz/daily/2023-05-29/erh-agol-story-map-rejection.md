---
description: Drafted an email rejecting an ArcGIS Online (AGOL) Story Map submission
  due to violation of the 2020 ERH policy prohibiting live/dynamic AGOL pages from
  being made public in the ER environment. The email communicates the specific policy
  violation, acknowledges the creator's effort, justifies the denial based on system
  security and data stability requirements, and extends an invitation for follow-up
  discussion.
name: erh-agol-story-map-rejection
session_id: sharegpt_6ZpPBwe_0
source_conversation: '[[session/dialog/sharegpt_6ZpPBwe_0.jsonl]]'
---

## ArcGIS Online Story Map Submission Rejection

- An ArcGIS Online (AGOL) Story Map was submitted but will not be approved due to violation of ERH policy established in 2020, which states "there will be no 'live/dynamic' AGOL pages made public in ER" [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L1-L1]]
- A rejection email was drafted with the subject line: "ArcGIS Online Story Map Submission - Rejection" [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
- The email explicitly informs the recipient that the submission will not be approved due to the 2020 ERH policy against live/dynamic AGOL pages being made public in ER [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
- The email acknowledges significant effort put into creating the Story Map and includes an apology for any inconvenience caused by the non-approval decision [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
- The justification for rejecting the submission cites the need to ensure security and stability of systems and data as the reason policies are enforced [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
- The closing offers to answer questions or concerns and expresses willingness to discuss the matter further with the recipient [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
