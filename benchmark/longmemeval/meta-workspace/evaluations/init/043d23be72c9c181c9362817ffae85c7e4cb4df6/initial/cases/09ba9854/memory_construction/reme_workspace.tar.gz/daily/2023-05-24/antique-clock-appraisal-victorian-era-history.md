---
description: Detailed guide on appraising antique clocks based on an owner's grandmother's
  heirloom recently repaired in late April 2023; step-by-step instructions for identifying
  mechanical movements with a focus on the fusee movement's mechanics and history;
  comprehensive overview of the Victorian era clockmaking industry (1837–1901) covering
  technological advancements, major manufacturing centers (London, Birmingham, Swiss
  Jura region), notable makers (John Harrison, Dent, Patek Philippe), guild regulations,
  7–10 year apprenticeship requirements, and the historical practice, placement, and
  decline of the clockmaker's mark.
name: antique-clock-appraisal-victorian-era-history
session_id: df963ea2_1
source_conversation: '[[session/dialog/df963ea2_1.jsonl]]'
---

## Antique Clock Appraisal Methodology
- An owner possesses a grandmother's antique clock family heirloom that underwent professional repair around late April 2023 (approximately one month prior to May 24, 2023) and has kept accurate time since restoration.
- Determining historical significance and market value requires a systematic eight-step appraisal procedure:
  1. Compile Documentation: Collect provenance records detailing ownership lineage, receipts, certificates of past repairs or sales, manufacturer labels, engraved signatures, markings, archival photographs, and supplementary paperwork.
  2. Visual Inspection: Catalog physical attributes including classification (grandfather, mantle, wall, table), construction materials (wood, metal, glass), decorative elements (carvings, inlays, engravings), cosmetic condition (patina, scratches, finish wear), visible damage, signs of prior restoration, and unique design traits.
  3. Maker Identification: Research the original creator or manufacturing house to determine reputation, operational timeline, notable models, approximate production date, and historical era.
  4. Movement Classification: Distinguish mechanical systems (powered by weights, springs, or balance wheels), quartz systems (battery-operated), or specialty mechanisms (cuckoo, automaton, musical). Document distinctive features such as strike trains.
  5. Condition Assessment: Evaluate structural integrity, part originality versus replacement components, functional accuracy, striking performance, and overall aesthetic preservation.
  6. Market Comparison: Analyze auction records and dealer inventories for comparable models to establish current demand, pricing trends, rarity status, and uniqueness.
  7. Expert Consultation: Seek insights from collectors, horologists, dealers specializing in antique timepieces, and enthusiasts.
  8. Formal Valuation: Commission written appraisals from qualified professionals affiliated with recognized bodies such as the National Association of Watch and Clock Collectors (NAWCC), American Clock and Watch Museum (ACWM), or International Society of Appraisers (ISA).
[[session/dialog/df963ea2_1.jsonl#L1-L2]]

## Mechanical Clock Movement Identification
- Mechanical calibers operate using interconnected gears, levers, and springs driven solely by hand-wound or weight-driven mainsprings, entirely eliminating reliance on electrical batteries.
- Diagnostic hallmarks identifying mechanical movement include interlocking transmission gears transferring energy, a coiled mainspring providing primary torque, a regulating balance wheel or oscillating counterweight pacing time progression, and an escape mechanism releasing gear rotation at precise intervals.
- Inspection protocol requires careful removal of the rear casing plate to expose the internal caliber while strictly avoiding direct finger contact with metallic components to prevent corrosive skin-oil transfer, followed by verification of the gear architecture and professional consultation when ambiguity arises.
- Standardized classification branches for mechanical movements encompass the anchor escapement (historically earliest and most widely deployed configuration), lever escapement utilizing levers to release gear trains, tourbillon arrangements featuring rotating cages to counteract gravitational torque (typically found in high-end instruments), and fusee mechanisms.
[[session/dialog/df963ea2_1.jsonl#L3-L4]]

## Fusee Movement Mechanics and History
- Historical footprint: Originated during the 15th-century Renaissance, achieved peak adoption across England and France throughout the 17th and 18th centuries, and remained dominant until being superseded by newer technologies in the mid-19th century. Introduced superior power consistency over predecessor designs, directly improving timekeeping reliability.
- Engineering operation: Relies on a tapered cone pulley known as the fusee, machined with a mathematically calculated spiral groove. A specialized mainspring wraps around this fusee. As the mainspring naturally uncoils and loses tension, the increasing radius engagement along the spiral profile automatically compensates, delivering uniformly steady rotational force to the gear train rather than the fluctuating torque characteristic of standard direct-drive spring movements.
- Performance advantages: Maintains constant tension delivery for exceptional precision and stability, distributes mechanical stress evenly across bearings to minimize component degradation, and supports high-tolerance calibration required for elite chronometers.
- Structural divergences: Utilizes indirect pulley-based torque transfer rather than direct spur gearing; mandates specialized mainspring routing circumferentially around the fusee cone; incorporates a distinctly shaped gear train optimized for synchronization with the fusee geometry.
- Operational constraints: High machining complexity raises manufacturing costs and complicates maintenance procedures; typically yields shorter operational duration between manual windings compared to later designs; remains vulnerable to ambient temperature drift and cumulative mechanical fatigue inherent to pre-modern mechanics.
[[session/dialog/df963ea2_1.jsonl#L5-L6]]

## Victorian Era Clockmaking Industry (1837–1901)
- Industrial environment: Experienced unprecedented expansion fueled by commercial globalization, railway scheduling necessities, maritime navigation demands, urban population growth, and broad economic prosperity during the 1837–1901 timeframe.
- Manufacturing innovations: Implemented automated machine tools enabling efficient mass fabrication; introduced standardized interchangeable component systems drastically improving quality control; applied precision engineering tolerances yielding highly reliable calibers; integrated resilient alloys including hardened steel and nickel plating to extend component longevity.
- Primary production districts:
  - London: Retained premier status housing renowned workshop establishments.
  - Birmingham (English Midlands): Evolved into a massive output hub spearheaded by organizations like the Birmingham Clock and Watch Company.
  - Switzerland (Jura Mountain zone): Developed into a global watchmaking epicenter during this period, serving as the foundational base for Patek Philippe (founded 1839) and Vacheron Constantin.
- Signature product categories: Longcase (grandfather) furniture pieces becoming domestic staples; ornamental mantel shelves; portable carriage chronometers featuring heavy engraving for travel; monumental civic turret clocks installed atop public towers.
- Leading practitioners and corporate houses:
  - John Harrison: English pioneer celebrated for inventing the marine chronometer critical for transoceanic longitude calculation.
  - Dent: Elite London manufacturing firm responsible for high-caliber instruments including the regulator at the Royal Observatory Greenwich.
  - Patek Philippe: Established 1839, rapidly ascended to become a leading luxury timepiece manufacturer still active today.
[[session/dialog/df963ea2_1.jsonl#L7-L8]]

## Clockmakers' Guilds, Apprenticeships, and Authentication Marks
- Professional governance: Trade associations enforced rigorous quality benchmarks, ethical standards, and craft promotion throughout the Victorian period. Dominant organizations included the Worshipful Company of Clockmakers (chartered in London in 1631) and the British Horological Institute (incorporated in 1858 to elevate horological science and artisanal practice).
- Craft responsibilities: Artisans engineered complex internal assemblies comprising escapements, gear reductions, and balance regulators; executed precision diagnostics and restorative repairs; continuously refined mechanical architectures and material substitutions.
- Educational pipeline: Mastery required extended seven-to-ten-year indentures under registered masters. Trainees acquired metallurgical forging skills, cabinet woodworking techniques, applied physics principles, arithmetic calculations, and practical troubleshooting methodologies through hands-on experience.
- Authentication tradition: Makers permanently impressed personalized signatures, monograms, heraldic devices, or proprietary logos onto movement plates, dial faces, or exterior casings. Authentication marks originated in the 16th century and were formally mandated by guild regulations by the 17th century. The authentication marks certified artisanal authorship, guaranteed material and craftsmanship standards against counterfeits, and frequently implied durability warranties. The custom declined sharply following early 20th-century factory standardization replacing bespoke manufacturing, though contemporary independent makers retain signatures as symbols of artisanal heritage.
- Female participation: Women actively contributed to the trade alongside male artisans, frequently operating within dynastic workshop structures or completing formal apprenticeships. Historically documented participants include Mary Seacole (Jamaican-Scottish designer acknowledged for innovative configurations and granted admission to the Worshipful Company of Clockmakers) and Elizabeth Thompson (English craftswoman whose work was exhibited at the Great Exhibition of 1851).
[[session/dialog/df963ea2_1.jsonl#L9-L12]]
