---
description: A comprehensive compilation of recommendations for an aspiring stand-up
  comedian, including ten Netflix specials highlighted for strong storytelling techniques,
  a detailed step-by-step guide for building a home recording studio to produce YouTube
  comedy videos, curated lists of books, podcasts, and websites for mastering comedy
  writing, and essential resources for developing a comedian's personal brand and
  digital presence. Also records the user's confirmation to attend a local comedy
  writing workshop on Friday to improve craft, gather feedback, and network.
name: standup-comedy-craft-and-career-resources
session_id: answer_0250ae1c
source_conversation: '[[session/dialog/answer_0250ae1c.jsonl]]'
---

## Netflix Stand-up Specials for Storytelling Study
John Mulaney's 'Kid Gorgeous' serves as the primary reference benchmark for evaluating strong stand-up storytelling ability. [[session/dialog/answer_0250ae1c.jsonl#L1-L2]]
- **Hasan Minhaj: Homecoming King (2017)** - Masterclass in weaving personal anecdotes, cultural commentary, and clever observations together.
- **Ali Wong: Hard Knock Wife (2018)** - Raw and refined exploration of motherhood, marriage, and personal life experiences.
- **Mike Birbiglia: My Girlfriend's Boyfriend (2013)** - Delivers engaging narratives that balance humor with poignant moments.
- **Taylor Tomlinson: Quarter-Life Crisis (2020)** - Effectively structures sets around relatable themes and personal stories, heavily focusing on character development.
- **Maria Bamford: Lady Dynamite (2016)** - Features a unique voice blending surreal storytelling with poignant reflections on life.
- **Bo Burnham: Make Happy (2016)** - Experimental special tackling complex topics including relationships, mental health, and growing up.
- **Demetri Martin: Live (At the Time) (2018)** - Utilizes deadpan delivery and clever observational humor to still successfully tell a story.
- **Wanda Sykes: Not Normal (2019)** - Expertly weaves personal stories, sharp observations, and biting social commentary.
- **Hannah Gadsby: Nanette (2018)** - Powerful non-traditional stand-up that uses personal experiences to tackle deep topics like trauma and identity.
- **Brian Regan: Nunchucks and Flamethrowers (2017)** - Combines physical comedy with highly engaging, clear storytelling.

## Home Recording Studio Setup for Comedy Videos
Detailed technical and environmental requirements for recording stand-up performances to upload to YouTube. [[session/dialog/answer_0250ae1c.jsonl#L3-L4]]
- **Lighting**: Utilize soft, indirect natural light from a nearby window; invest in a basic lighting kit containing a key light, fill light, and backlight; softbox lights are ideal for providing even illumination that minimizes harsh shadows.
- **Audio**: Use a decent USB microphone such as the Blue Yeti or Rode NT-USB; position the microphone 6-8 inches from the mouth slightly off-center; employ a pop filter or a DIY hoop with a mesh screen to mitigate background noise.
- **Camera**: Select a smartphone, DSLR, or mirrorless camera featuring excellent low-light performance and image stabilization; secure the camera on a tripod for stability; frame the performer using either a medium shot (waist-up) or a close-up (head and shoulders).
- **Background**: Maintain a plain, neutral-colored backdrop like a white or gray wall; optionally introduce a subtle colored background or props that complement the specific comedy style.
- **Recording Software**: Free alternatives include OBS Studio (for PC) and QuickTime (for Mac); professional-grade options include Adobe Premiere Pro, Final Cut Pro, and DaVinci Resolve.
- **Recording Protocol**: Thoroughly rehearse the material beforehand; attempt to capture the entire set in a single continuous take to preserve natural pacing and simplify editing; record files directly to an external hard drive to secure ample storage space; continuously monitor audio levels using headphones during the session.
- **Post-Production Workflow**: Restrict editing edits to preserve the authenticity of the live performance; incorporate auto-generated or manual captions to boost accessibility and viewer engagement; optimize all video metadata—including relevant keywords, tags, and descriptions—to align with the YouTube recommendation algorithm.

## Comedy Writing and Storytelling Resources
Curated educational materials specifically aimed at elevating joke structure, narrative construction, and overall comedic craft. [[session/dialog/answer_0250ae1c.jsonl#L5-L6]]
- **Newsletters & Websites**: The Comedy Writing Secrets Newsletter authored by Mark Shatz; The Comedy Bureau website offering industry news and critique; The Comedy Industry Insider website covering the business mechanics of comedy.
- **Courses & Manuals**: Comedy Writing 101 free foundational course provided by Second City; The Upright Citizens Brigade (UCB) Comedy Improvisation Manual detailing core improv and writing principles.
- **Online Communities**: r/ComedyWriting subreddit for peer exchange; r/Comedy general subreddit for broader career discussion.
- **Textbooks**:
  - *Comedy Writing Secrets* by Mark Shatz (covers structural fundamentals, character development, and narrative arcs).
  - *The Comedy Bible* by Judy Carter (provides actionable step-by-step writing exercises and illustrative examples).
  - *And Here's the Kicker: Conversations with 21 Humor Writers on Their Craft* edited by Mike Sacks (compiles direct interviews regarding creative workflows).
  - *The Hidden Tools of Comedy* by Steve Kaplan (analyzes underlying dramatic frameworks applicable to humor).
  - *Story* by Robert McKee (establishes universal rules of narrative structure and psychological character growth).
  - *Zen and the Art of Stand-Up Comedy* by Jay Sankey (focuses on the psychological readiness required for stage delivery).
  - *I'm Dying Up Here: Heartbreak and High Times in Stand-Up Comedy's Golden Era* by William Knoedelseder (documents historical trends and the realities of professional performing careers).
- **Audio Resources**: The Comedy Nerds Podcast; The Writing Comedy Podcast; The You Made It Weird with Pete Holmes podcast.

## Personal Brand and Online Presence Resources
Strategic guides and literature dedicated to establishing a distinctive digital footprint and cultivating audience loyalty. [[session/dialog/answer_0250ae1c.jsonl#L7-L8]]
- **Digital Guides**: Comedian's Guide to Building a Website authored by Chris Mancini; The Comedian's Guide to Social Media authored by Steve Hofstetter.
- **Industry Programs**: Comedy Central's Creators Program providing institutional exposure; The Comedy Network offering centralized training modules.
- **Academic & Self-Help Texts**:
  - *Building a Brand as a Comedian* by Steve Hofstetter.
  - *Comedy Goes Digital* by Chris Mancini (focuses on content distribution and monetization pipelines).
  - *The Comedian's Way* by Barry Friedman (outlines strategies for discovering an original artistic voice).
  - *Crush It!* by Gary Vaynerchuk (broad digital marketing methodology adaptable to individual artists).
  - *Influencer: Building Your Personal Brand in the Age of Social Media* by Brittany Hennessy.
- **Educational Platforms**: Comedy Writing and Performance Course taught by Mark Shatz; The Stand-Up Comedy Academy delivering structured mentorship tracks.
- **Broadcast Content**: The Comedian's Guide to Marketing podcast; The Business of Comedy podcast; The Comedy Industry Insider Podcast.

## Upcoming Comedy Writing Workshop
Attendance confirmed for an upcoming comedy writing workshop hosted at a local independent writing center on Friday. [[session/dialog/answer_0250ae1c.jsonl#L9-L12]]
- **Primary Objectives**: Absorb instruction from seasoned industry professionals, submit current draft material for direct analytical feedback, and cultivate professional connections with fellow emerging writers.
- **Operational Strategy**: Prepare finalized writing drafts for active sharing during group exercises; maintain a highly receptive mindset toward unconventional formats and structural risks; document instructor critiques meticulously in real-time notebooks; commit to maintaining active correspondence with new peers following the event to facilitate ongoing collaborative projects.
