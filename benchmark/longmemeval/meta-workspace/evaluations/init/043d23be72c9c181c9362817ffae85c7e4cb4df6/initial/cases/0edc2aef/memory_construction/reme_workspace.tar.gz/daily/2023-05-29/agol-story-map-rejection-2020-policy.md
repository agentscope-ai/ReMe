---
description: Drafted an email rejecting an ArcGIS Online (AGOL) Story Map submission
  due to violation of the 2020 ERH policy prohibiting live/dynamic AGOL pages from
  being made public in the ER environment. The email communicates the specific policy
  violation, acknowledges the creator's effort, justifies the denial based on system
  security and data stability requirements, and extends an invitation for follow-up
  discussion.
name: agol-story-map-rejection-2020-policy
session_id: sharegpt_6ZpPBwe_0
source_conversation: '[[session/dialog/sharegpt_6ZpPBwe_0.jsonl]]'
---

## ArcGIS Online Story Map Submission Rejection [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L1-L2]]

* An ArcGIS Online (AGOL) Story Map submitted for review was denied approval because it violates the ERH policy established in 2020, which strictly prohibits making "live/dynamic" AGOL pages public within the ER environment.
* A rejection email was drafted using the specific subject line: "ArcGIS Online Story Map Submission - Rejection".
* The email explicitly states that the rejection is mandated by the 2020 ERH policy prohibiting live or dynamic AGOL pages from being made public in ER.
* The draft acknowledges significant effort invested in creating the Story Map and includes an apology for any inconvenience caused by the non-approval decision.
* The justification centers on maintaining overall system security and data stability as the reason for enforcing the existing policy.
* The closing invites questions or concerns and extends an offer to discuss the decision further with the recipient.
