---
description: 'Development of WordPress functionality for a custom post type called
  "Policy". Includes iterative creation of a dynamic shortcode `[custom_post_list]`
  that lists policies filtered by taxonomy (specifically the "Topic" taxonomy with
  slugs like "academic-affairs" and "student-life"). The final shortcode displays
  first 5 policies per topic under H2 headings as hyperlinked lists. Also includes
  creation of a PHP single template file (Template Name: Policy Single) displaying
  ACF fields including Title, Published Date, Unit taxonomy, Topic taxonomy, Body
  content, Additional Resources (collapsible), and History (collapsible).'
name: wordpress-policy-cpt-shortcode-and-template
session_id: sharegpt_8jxRz9U_0
source_conversation: '[[session/dialog/sharegpt_8jxRz9U_0.jsonl]]'
---

## WordPress Policy CPT Shortcode Development [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L1-L4,L7-L8]]

### Initial Shortcode Request
- User requested a WordPress function that creates a shortcode to display a list of custom posts with configurable parameters [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L1]]. Function signature utilizes `shortcode_atts` for parameter configuration [[L2]].
- Configurable attributes established for the shortcode:
  - `number_of_posts`: Integer controlling maximum entries displayed (Default: `5`) [[L2]].
  - `category`: String representing a standard WordPress category slug [[L2]].
  - `taxonomy`: String representing a custom taxonomy slug [[L2]].
- Implementation constructs a `WP_Query` object using the configured arguments [[L2]]. Category filtering populates the `category_name` argument within `$args` [[L2]]. Taxonomy filtering constructs a nested `tax_query` array containing `taxonomy`, `field => 'slug'`, and `terms` parameters matching the input value [[L2]].
- Output formatting utilizes a wrapped unordered list (`<ul>`) structure. Loop traverses results, generating `<li>` items containing anchor elements linking to `get_the_permalink()` alongside `get_the_title()` text content [[L2]]. Query resets via `wp_reset_postdata()` following traversal completion [[L2]]. Fallback string returns when `$query->have_posts()` evaluates false: `"No custom posts found."` [[L2]]. Shortcode registration executes via `add_shortcode( 'custom_post_list', 'custom_post_list_shortcode' )` [[L2]]. Usage syntax examples provided: `[custom_post_list number_of_posts="5" category="category-slug" taxonomy="taxonomy-slug"]` [[L2]].

### Modification to Target "Policy" Post Type
- Code modifications restricted internal `$args` retrieval exclusively to the custom post type named `'policy'` [[L3]]. Corresponding empty-state error message updated to `"No policy post found."` [[L4]]. All query logic remains unchanged [[L4]]. Usage example confirmed utilizing identical syntax targeting policies [[L4]].

### Transition to Custom Taxonomy Filtering (Topic)
- Requirement shift eliminated standard category filtering mechanisms, replacing them entirely with custom taxonomy filtering for the `"topic"` taxonomy [[L5]]. Attribute `category` removed; replaced by attribute named `topic` [[L6]].
- Configuration assigns specific mapping inside `tax_query`: `taxonomy` set to `'topic'`, `field` set to `'slug'`, `terms` assigned directly to the evaluated `topic` attribute value [[L6]]. Error handling text revised to `"No policies found for the given topic."` [[L6]]. 
- Explicit architectural prerequisite noted: the taxonomy `'topic'` must be registered against the custom post type `'policy'` prior to shortcode execution [[L6]]. Valid usage examples explicitly listed include `topic="academic-affairs"` and `topic="student-life"` [[L6]].

### Multi-Term Display Generation
- Updated requirement demands generation of combined listing presenting the initial five policies associated with every available term belonging to the `'topic'` taxonomy [[L7]].
- Structural transition involved altering function signature to accept no arguments: `custom_post_list_shortcode()` [[L8]]. Execution initiates by calling `get_terms( array( 'taxonomy' => 'topic', 'hide_empty' => false ) )` to retrieve complete term list [[L8]]. Iterative loop processes each term sequentially [[L8]]. Term names output encapsulated within `<h2>` tags preceding their respective result groups [[L8]]. Internal nested `WP_Query` generates paginated subset queries executing `posts_per_page = 5` and applying localized `tax_query` matching current iteration `$term->slug` [[L8]]. If post data exists, outputs linked item lists; otherwise displays placeholder message `"No policies found for this topic."` [[L8]]. Deployment guidance reiterated ensuring `'topic'` maps properly to `'policy'` CPT structure [[L8]]. 

## WordPress Single Template Architecture for Policy CPT [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L9-L10]]

### File Requirements
- User specified requirements for a dedicated PHP template rendering individual entries corresponding to the "Policy" custom post type [[L9]]. Interface must integrate Associated Advanced Custom Fields (ACF) data mappings seamlessly [[L9]]. 

### Skeleton Structure
- Generated implementation declares `Template Name: Policy Single` header metadata block [[L10]]. Execution flows through standard WordPress boilerplate sequence invoking `get_header()`, loading primary content wrappers (`div#primary.content-area div#main.site-main`), appending `get_sidebar()`, and concluding with `get_footer()` [[L10]]. Loop initialization follows native methodology: `while ( have_posts() ) : the_post();` [[L10]]. Semantic article container applies dynamic classes via `post_class()` and constructs ID strings utilizing `the_ID()` [[L10]].

### Field Rendering Configuration
- **Entry Header**: Displays page title via `the_title()` inside `h1.entry-title` element [[L10]]. Publication date renders utilizing ACF accessor method echoing string prefix concatenated with `get_field('published_date')` value [[L10]].
- **Taxonomy Data Injection**: Executes `get_the_terms(get_the_ID(), 'unit')` and `get_the_terms(get_the_ID(), 'topic')` respectively [[L10]]. Conditional checks verify non-empty arrays before proceeding [[L10]]. Iteration outputs term names separated by whitespace within descriptive paragraph labels [[L10]].
- **Main Content**: Editor text content inserts unmodified via `the_content()` [[L10]]. 
- **Additional Resources**: Retrieved dynamically employing `get_field('additional_resources')` [[L10]]. Conditional evaluation bypasses display blocks when variables evaluate empty/null [[L10]]. Renders heading hierarchy level 3 labeled "Additional Resources" enclosing raw field value inside designated collapsible wrapper div [[L10]].
- **History Module**: Fetches `get_field('history')` identically structured as additional resources block above [[L10]]. Applies conditional gating producing matching heading + collapsible container architecture [[L10]].
- **Administrative Footer Zone**: Backend editing shortcut links activate through `edit_post_link()` wrapping span markup [[L10]]. Loop terminates conventionally [[L10]].

### Specified Field Layout Summary
- Title mapped to standard H1 presentation [[L9-L10]].
- Published Date extracted via ACF interface [[L9-L10]].
- Unit taxonomy integrated into presentation layout [[L9-L10]].
- Topic taxonomy integrated into presentation layout [[L9-L10]].
- Body content routed through standard editor injection [[L9-L10]].
- Additional Resources configured requiring collapsible row mechanism [[L9-L10]].
- History section configured requiring collapsible row mechanism [[L9-L10]].
