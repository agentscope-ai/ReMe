---
description: Notes and answers derived from a multiple-choice quiz covering categorization
  models (prototype vs. exemplar), cognitive biases and decision-making heuristics
  (triangle inequality constraints on similarity, anchoring effect, attraction effect),
  abstract perceptual learning, synaptic plasticity, Moravec's paradox, and the classical
  mind-body problem contrasting materialism and dualism.
name: cognitive-science-mcq-review
session_id: sharegpt_TcUL15d_19
source_conversation: '[[session/dialog/sharegpt_TcUL15d_19.jsonl]]'
---

## Categorization Models [[session/dialog/sharegpt_TcUL15d_19.jsonl#L1-L1,L6-L15]]
- **Prototype models**: Demonstrate that category prototypes can be learned by processing every instance in the category.
- **Exemplar models**: Hold that instances are more important than prototypes. Category membership is determined by the similarity of a new instance to previously encountered examples (exemplars) stored in memory—including their unique features and context of occurrence—rather than relying on a single abstract prototype or an abstract representation of the category.

## Cognitive Biases and Decision Effects [[session/dialog/sharegpt_TcUL15d_19.jsonl#L2-L3,L4-L11,L16-L17]]
- **Similarity and the triangle inequality**: The triangle inequality demonstrates that models of similarity judgments require constraints, such as attentional weighting as specified in Tversky’s contrast model.
- **Anchoring effects**: Occur when an individual relies too heavily on the first piece of information encountered (the "anchor") when making subsequent judgments or decisions. An illustrative case involves Andrew telling Christina that the meaning of life is 42, which subsequently biased Christina's estimate of her ideal number of children to 38.
- **Attraction effect**: Demonstrates that two choices with equal overall utility can be shifted by introducing a third "attractor" choice. The presence of an attractor choice placed near one of the options causes the nearby choice to be preferred, even if the attractor itself is strictly inferior on all dimensions compared to its neighbor.

## Perception and Learning [[session/dialog/sharegpt_TcUL15d_19.jsonl#L20-L25]]
- **Abstract perceptual learning**: Refers to the development of representations of abstract entities, including descriptions of shape. This process involves forming abstract representations of complex stimuli (e.g., shapes and patterns) that cannot be reduced to simple features, and conceptually overlaps with other learning processes like statistical or conceptual learning.

## Neuroscience and Philosophy of Mind [[session/dialog/sharegpt_TcUL15d_19.jsonl#L18-L19,L26-L31]]
- **Synaptic plasticity**: Defines a form of learning that involves structural changes to neuron connections.
- **Moravec's paradox**: Posits that high-level reasoning requires very little computation, while low-level sensorimotor skills require enormous computational substructure. Consequently, perceptual systems (including vision and locomotion) and complex bodily functions ("smart" features like organs and muscles) represent the most difficult components to simulate computationally, whereas human-difficult tasks like logical reasoning remain computer-easy.
- **Classical mind-body problem**: Explores distinctions between philosophical stances on consciousness and physiology. The discussion contrasts 'materialism' (characterized as positing that brain processes and mental processes are two interacting physical substances) against 'dualism' (defined as the view that brain processes and mental behaviors lack causal relationships or are only very loosely causally related).
