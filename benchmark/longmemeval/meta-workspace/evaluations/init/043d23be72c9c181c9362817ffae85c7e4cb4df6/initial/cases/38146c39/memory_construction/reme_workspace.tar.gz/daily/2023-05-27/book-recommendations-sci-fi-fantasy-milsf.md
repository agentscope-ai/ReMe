---
description: User requested book recommendations across science fiction, fantasy,
  and military science fiction, citing previously enjoyed titles including Ender's
  Game, Red Rising, and Harry Potter. Assistant provided initially categorized recommendations,
  then narrowed results to cross-genre titles spanning all three genres, and finally
  filtered further to cross-genre works featuring magic systems. Detailed series descriptions
  and author attributions are preserved.
name: book-recommendations-sci-fi-fantasy-milsf
session_id: sharegpt_ww4hwxX_0
source_conversation: '[[session/dialog/sharegpt_ww4hwxX_0.jsonl]]'
---

### User Previously Enjoyed Books [[session/dialog/sharegpt_ww4hwxX_0.jsonl#L1-L1]]
- *Ender's Game*
- *Starship's Mage*
- *Harry Potter*
- *Gregor the Overlander*
- *Percy Jackson*
- *Red Rising*

### Initial Genre-Categorized Recommendations [[session/dialog/sharegpt_ww4hwxX_0.jsonl#L1-L2]]
#### Science Fiction
- *Dune* by Frank Herbert
- *Foundation* by Isaac Asimov
- *The Hitchhiker's Guide to the Galaxy* by Douglas Adams
- *The Hunger Games* by Suzanne Collins
- *Ready Player One* by Ernest Cline

#### Fantasy
- *The Lord of the Rings* by J.R.R. Tolkien
- *The Wheel of Time* by Robert Jordan
- *The Lies of Locke Lamora* by Scott Lynch
- *The First Law* trilogy by Joe Abercrombie
- *The Kingkiller Chronicle* by Patrick Rothfuss

#### Military Science Fiction
- *The War of the Worlds* by H.G. Wells
- *Starship Troopers* by Robert A. Heinlein
- *The Forever War* by Joe Haldeman
- *The Empire Trilogy* by Janny Wurts
- *The Vorkosigan Saga* by Lois McMaster Bujold

### Cross-Genre Recommendations (Science Fiction, Fantasy, Military Fiction) [[session/dialog/sharegpt_ww4hwxX_0.jsonl#L3-L4]]
- *The Lies of Locke Lamora* by Scott Lynch — combines fantasy and crime fiction, featuring con artists in a fantasy setting.
- *The Kingkiller Chronicle* by Patrick Rothfuss — combines fantasy and epic fantasy, following a musician and assassin.
- *The Lightbringer* series by Brent Weeks — combines fantasy and epic fantasy, following a man who can create light.
- *The First Law* trilogy by Joe Abercrombie — combines fantasy and epic fantasy, featuring a gritty, realistic, and brutal world with military fiction elements.
- *The Vorkosigan Saga* by Lois McMaster Bujold — combines science fiction and military fiction, following a disabled war veteran.
- *The Empire Trilogy* by Janny Wurts — combines fantasy and epic fantasy, featuring a war between two powerful nations and a prophecy.

### Cross-Genre Recommendations Including Magic [[session/dialog/sharegpt_ww4hwxX_0.jsonl#L5-L6]]
- *The Dresden Files* series by Jim Butcher — combines urban fantasy, mystery, and noir fiction, featuring a wizard detective.
- *The Mistborn* series by Brandon Sanderson — combines epic fantasy, science fiction, and high fantasy, featuring a world with diverse magical abilities and a rebellion against a powerful ruler.
- *The Shadow Campaigns* series by Django Wexler — combines fantasy, military fiction, and political intrigue, featuring a world with diverse magical abilities and war between nations.
- *The Powder Mage* series by Brian McClellan — combines fantasy, military fiction, and political intrigue, featuring a world with diverse magical abilities and war between nations.
- *The Black Company* series by Glen Cook — combines fantasy and military fiction, featuring mercenaries hired by a powerful sorcerer.
