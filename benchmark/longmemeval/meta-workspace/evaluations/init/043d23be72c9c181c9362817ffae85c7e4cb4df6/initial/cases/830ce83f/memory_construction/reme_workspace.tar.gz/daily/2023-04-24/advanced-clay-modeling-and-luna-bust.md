---
description: 'Comprehensive workflow documentation for an artist practicing clay modeling
  several hours weekly at home. Covers recommended educational platforms (Craftsy,
  Skillshare, Udemy, YouTube) and specific master instructors (Dan Gheno, Michael
  James Smith, Rafael Grassetti, Bruno Lucchesi, Maureen Carlson) for advanced figure
  and realistic facial sculpting. Details the complete production pipeline for a current
  sculpting project: creating a lifelike clay bust of the user''s cat, Luna. Includes
  step-by-step methodologies for anatomical proportion scaling, preserving nuanced
  feline expressions, executing structural eye formation, applying biological textures
  via stippling and drybrushing, selecting appropriate material matrices (earthenware,
  terra cotta, polymer versus standard white clay), and executing complex chromatic
  layering to match specific iris pigmentation.'
name: advanced-clay-modeling-and-luna-bust
session_id: 062e9120_1
source_conversation: '[[session/dialog/062e9120_1.jsonl]]'
---

# Advanced Clay Modeling Practice & General Resources [[session/dialog/062e9120_1.jsonl#L1-L2]]
- Current routine involves dedicating a few hours each week to hands-on clay modeling practice at home.
- High-value online education ecosystems identified for advanced technique acquisition:
  - Commercial course aggregators: Craftsy, Skillshare, Udemy, The Virtual Instructor.
  - Free instructional repositories: YouTube channels branded as The Clay Whisperer, Polymer Clay Tutorials, and Sculpture Tutorials Live.
- Foundational skill pathways recommended for curriculum progression: anatomy/figure sculpting, intricate texture/pattern fabrication, macro/micro animal sculpting, miniature scaling, and mixed-media integration.

# Anatomy & Facial Feature Sculpting Curricula [[session/dialog/062e9120_1.jsonl#L3-L4]]
- Specialized learning objective centers on dissecting and reconstructing realistic human facial architecture, prioritizing proportional accuracy and expressiveness.
- Structured academic programs and published reference texts:
  - "Sculpting the Human Face" (Dan Gheno): Comprises a 5-hour video course hosted on Craftsy and a supplementary print volume detailing cranial proportion standards and carving mechanics.
  - "Realistic Face Sculpting" (Michael James Smith): A 2-hour Skillshare module emphasizing polymer clay manipulation for rendering eyes, nasal cartilage, labial structures, and dermal topography.
  - "Facial Anatomy and Sculpting" (Rafael Grassetti): A comprehensive 10-hour New Masters Academy lecture series mapping underlying skeletal landmarks, muscular insertion points, and superficial tissue layers.
  - "The Art of Sculpting: A Guide to Sculpting the Human Form" (Bruno Lucchesi): Foundational textbook covering holistic figure construction including appendicular extremities and craniofacial units.
  - "Sculpting Facial Expressions" (Maureen Carlson): Digital monograph isolating affective biomechanics for clay translation.
- Operational best practices: cross-reference anatomical atlases for osseous and myofascial baselines; enforce rigid weekly repetition cycles; compile curated reference databases capturing varied head orientations, ambient lighting conditions, and emotional valences; calibrate feature inter-distance metrics before applying tertiary surface details; treat clay medium variability as an experimental variable rather than a fixed constraint.

# Project Workflow: Luna the Cat Bust [[session/dialog/062e9120_1.jsonl#L5-L6]]
- Active commission/self-initiated undertaking: fabrication of a three-dimensional clay replica of the user's domestic feline, designated Luna, with emphasis on photorealistic trait replication and behavioral characterization.
- Proportional calibration protocol: implement tactile measurement gauges to establish canonical head-to-face ratios; transcribe observations into dimensional notes; deploy wireframe gridding algorithms on photographic source material to guarantee uniform vertical/horizontal scaling across the armature; designate ocular placement as the primary geometric anchor point.
- Expressive morphology preservation: document spontaneous affective states through sequential photography; deconstruct kinetic modifications occurring within the perioral cavity and nasal aperture during emotional triggers; restrict displacement vectors to sub-millimeter increments to prevent cartoonish distortion; adopt modular assembly tactics, isolating individual anatomical zones during active manipulation phases; implement iterative cooling-off periods between work intervals to reset binocular adaptation and expose latent symmetry deviations.
- Supplementary archival requirements: catalog peer-reviewed pet portraiture videos; acquire veterinary anatomical atlases specializing in felid cranial osteology.

# Technical Execution: Realistic Eye Sculpting [[session/dialog/062e9120_1.jsonl#L7-L12]]
- Persistent bottleneck localized to ocular rendering fidelity, requiring specialized micro-sculpting interventions.
- Foundational geometry construction sequence: introduce high-resolution styluses (industrial toothpicks, carbide modeling picks) to establish baseline boundaries; forge the scleral hemisphere utilizing spherical forming balls; extrude the corneal annulus via controlled planar compression radiating from the central axis; incise the apical focal point (pupil) using conical abrasives; overlay peripheral micro-topography (palpebral fissures, ciliary margins, lacrimal caruncles).
- Biometric data extraction mandates: record precise chord lengths, radial curvatures, and angular inclinations relative to the orbital rim; characterize specular reflectance profiles correlated with affective triggers to inform subsequent lighting manipulations.
- Surface maturation engineering: replace default smooth/white polymer blanks with organically porous substrates (unfired earthenware, oxidized terra cotta) that accept aggressive texturing without slumping; implement mechanical stippling routines using linear abrasives to simulate keratinous striations; transfer randomized micro-reliefs via botanical or fibrous impression stamps; execute additive lamination sequences alternating matte and grainy strata for subsurface scattering simulation; apply friction-based dry brushing with suspended pigment particulates to replicate desiccated conjunctival networks.
- Chromatic reproduction methodology: synthesize stratified color matrices by cold-blending varying saturation levels before kiln curing or bake-hardening; distribute localized shadow gradients via narrow-edged planishing tools to emulate vascular pooling; integrate nitrate or alkyd glaze mediums over finished surfaces to artificially boost refractive index and simulate aqueous film presence; maintain physical Pantone-equivalence charts mapping commercial clay ingot codes to accelerate iterative matching trials; archive domain-specific video walkthroughs documenting solvent-based pigment migration and gradient diffusion controls.
