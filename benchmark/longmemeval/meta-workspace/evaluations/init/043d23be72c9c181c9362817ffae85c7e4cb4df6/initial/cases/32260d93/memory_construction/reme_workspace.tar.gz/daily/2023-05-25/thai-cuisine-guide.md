---
description: A comprehensive reference for Thai cooking detailing essential pantry
  staples (coconut milk, lemongrass, galangal, fish sauce, tamarind, etc.), popular
  entrees and desserts (Tom Yum Soup, Pad Thai, Green Curry, Massaman Curry, Papaya
  Salad, Pad Kra Pao, Tom Kha Gai, Mango Sticky Rice) with their specific constituent
  ingredients, practical strategies for locating local restaurants through Yelp and
  Google Maps, and curated book recommendations from authors Andy Ricker, David Thompson,
  Leela Punyaratabandhu, Katie Chin, and Danette St. Onge for mastering traditional
  and modern Thai recipes.
name: thai-cuisine-guide
session_id: ultrachat_486807
source_conversation: '[[session/dialog/ultrachat_486807.jsonl]]'
---

## Thai Cuisine Ingredients [[session/dialog/ultrachat_486807.jsonl#L1-L2]]

Typical ingredients used in Thai cuisine encompass the following items:
- Coconut milk
- Lemongrass
- Galangal (a root similar to ginger)
- Kaffir lime leaves
- Thai basil
- Chili peppers
- Fish sauce
- Tamarind paste
- Palm sugar
- Rice noodles
- Shrimp paste
- Green curry paste
- Coriander/cilantro
- Soy sauce
- Oyster sauce
- Garlic
- Shallots
- Turmeric
- Peanut oil/peanuts
- Lime juice

## Popular Thai Dishes [[session/dialog/ultrachat_486807.jsonl#L3-L4]]

Various well-known Thai dishes utilize the aforementioned flavorings, often incorporating proteins alongside vegetables and herbs:
- Tom Yum Soup: A spicy and sour soup featuring lemongrass, galangal, kaffir lime leaves, chili peppers, and shrimp.
- Pad Thai: A stir-fried noodle dish composed of rice noodles, eggs, tofu, shrimp or chicken, bean sprouts, and peanuts.
- Green Curry: A curry preparation utilizing coconut milk, green curry paste, lemongrass, kaffir lime leaves, and Thai basil, typically accompanying chicken or shrimp.
- Massaman Curry: A curry combination containing coconut milk, Massaman curry paste, tamarind paste, and potatoes, generally served with beef.
- Papaya Salad: A refreshing salad assembled from shredded green papaya, tomatoes, chili peppers, garlic, palm sugar, and lime juice.
- Pad Kra Pao: A stir-fried mixture consisting of ground pork, chili peppers, garlic, and Thai basil.
- Tom Kha Gai: A coconut milk-based soup prepared with lemongrass, galangal, kaffir lime leaves, chicken, and mushrooms.
- Mango Sticky Rice: A popular dessert component made with sticky rice, fresh mango, and coconut milk.

## Restaurant Discovery Advice [[session/dialog/ultrachat_486807.jsonl#L5-L6]]

Locating authentic Thai dining options relies on external resources rather than internal knowledge bases:
- Online searches for "Thai restaurants in your area" provide immediate results.
- Review aggregation websites such as Yelp and Google Maps offer customer ratings and menu listings.
- Personal networks consisting of friends and family yield reliable culinary suggestions.
- Examining digital menus helps verify available dishes before visiting physical locations.

## Recommended Thai Cookbooks [[session/dialog/ultrachat_486807.jsonl#L7-L8]]

Individuals wishing to prepare Thai meals domestically can consult several authoritative publications:
- "Pok Pok: Food and Stories from the Streets, Homes, and Roadside Restaurants of Thailand" authored by Andy Ricker and JJ Goode provides foundational recipes spanning appetizers, curries, soups, and stir-fries.
- "Thai Food" written by David Thompson offers a comprehensive collection exceeding 500 recipes alongside detailed examinations of ingredients, techniques, and regional traditions.
- "Simple Thai Food: Classic Recipes from the Thai Home Kitchen" by Leela Punyaratabandhu emphasizes traditional preparations designed for regular household cooks utilizing accessible ingredients.
- "Everyday Thai Cooking" authored by Katie Chin presents more than 100 recipes combining classical styles with contemporary variations, supported by sequential instructional steps.
- "The Better than Takeout Thai Cookbook" by Danette St. Onge focuses on replicating commercially popular items such as Pad Thai, Drunken Noodles, and Green Curry within domestic kitchens.
