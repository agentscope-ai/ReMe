---
description: Comparison of Taxpayer Identification Numbers (TIN), Social Security
  Numbers (SSN), and Employer Identification Numbers (EIN). Overview of state sales
  tax obligations and economic nexus thresholds for a Delaware C-Corporation with
  nationwide operations, covering general nexus principles, triggering activities,
  and specific sales tax rules, exemptions, and use tax regulations for New York and
  California.
name: tax-id-vs-ssn-and-state-sales-tax-nexus
session_id: sharegpt_NYTjlfE_0
source_conversation: '[[session/dialog/sharegpt_NYTjlfE_0.jsonl]]'
---

## Differences Between TIN, SSN, and EIN [[session/dialog/sharegpt_NYTjlfE_0.jsonl#L1-L4]]
- A Taxpayer Identification Number (TIN) is a unique identifier assigned by the Internal Revenue Service (IRS) to businesses and individuals for tax reporting purposes. Common types include Employer Identification Numbers (EIN) for businesses and Individual Taxpayer Identification Numbers (ITIN) for non-resident aliens ineligible for an SSN.
- A Social Security Number (SSN) is a nine-digit number issued by the US government to US citizens, permanent residents, and temporary residents authorized to work. Its primary purpose is tracking earnings and determining eligibility for Social Security benefits, though it serves as identification for banking, credit, and driver's licenses.
- An Employer Identification Number (EIN), also known as a Federal Tax Identification Number (FEIN), is a specific type of TIN assigned by the IRS to businesses. Businesses must obtain an EIN if they employ workers, operate as a partnership or corporation, or file employment, excise, alcohol, tobacco, or firearms taxes. An EIN enables a business to open bank accounts, apply for credit, and obtain necessary licenses. The format of an EIN is XX-XXXXXXX, representing a geographic location.

## State Tax Obligations for a Delaware C-Corporation [[session/dialog/sharegpt_NYTjlfE_0.jsonl#L5-L8]]
- The owner operates a Delaware C-Corporation serving customers located throughout the United States [[session/dialog/sharegpt_NYTjlfE_0.jsonl#L5]].
- While a Delaware C-Corp pays income tax on business activities conducted within Delaware, companies engaging in nationwide commerce may face additional state tax liabilities depending on economic presence.
- Determining whether a business possesses sufficient "nexus" or economic presence in another state requires evaluating individual state laws based on sales volume, property ownership, or payroll distribution. Many states enforce economic nexus laws that mandate out-of-state businesses register and pay taxes once sales or transaction thresholds are surpassed. 

## Examples of Activities Triggering State Tax Obligations in the US [[session/dialog/sharegpt_NYTjlfE_0.jsonl#L9-L10]]
- Maintaining a physical presence such as a retail store or office within a state.
- Conducting internet sales to state residents when state limits are breached.
- Selling digital products, including software, video games, music, and e-books, which are subject to taxation in certain jurisdictions.
- Providing taxable services, such as accounting or legal services, in states that impose levies on service-based transactions.
- Participating in special events like craft fairs or festivals where vendors collect sales tax on event-specific sales.

## New York State Sales Tax Rules [[session/dialog/sharegpt_NYTjlfE_0.jsonl#L11-L12]]
- Economic Nexus Threshold: Out-of-state businesses lacking physical presence in New York must collect sales tax if gross sales within the state surpass $300,000 in a civil year, or if there are more than 100 separate transactions delivered into New York during that same period.
- Physical Presence: Entities owning physical locations like offices or stores in New York are required to collect and remit sales tax for all sales originating within the state, irrespective of sales volume thresholds.
- Sales Tax Exemptions in New York encompass food purchased for home consumption, prescribed medications, and clothing and footwear priced below $110.

## California State Sales Tax Rules [[session/dialog/sharegpt_NYTjlfE_0.jsonl#L13-L14]]
- Economic Nexus Threshold: Out-of-state businesses without physical operations in California must collect sales tax if gross sales within the state exceed $500,000 in a civil year, or if there are more than 100 separate transactions delivered into California during the year.
- Physical Presence: Companies with physical locations in California must collect and remit sales tax for all in-state transactions regardless of threshold criteria.
- Sales Tax Exemptions in California include food for home consumption, prescribed medications, and clothing and footwear valued at less than $100.
- Use Tax: California enforces a use tax that applies to goods purchased outside of the state but subsequently utilized or consumed within its borders.
