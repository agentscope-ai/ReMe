---
description: A Python script integrating a custom-trained BERT model (using Hugging
  Face transformers) with a MySQL inventory database to function as a chatbot. Features
  include retrieving answers via BERT, checking a local memory cache for Q&A pairs,
  searching products by tags ('fever', 'cold', 'headache'), and managing a shopping
  cart with price calculations.
name: bert-chatbot-inventory-code
session_id: sharegpt_c22x2ZP_15
source_conversation: '[[session/dialog/sharegpt_c22x2ZP_15.jsonl]]'
---

## Chatbot Integration Script

### Core Components
The system combines a Retrieval-Augmented Generation approach (checking local storage) with a Generative Neural Network approach (BERT) for answering questions, backed by MySQL for persistent data.

#### Python Libraries Used
- `mysql.connector`: Handles the database connection.
- `torch`: PyTorch library used for tensor manipulation.
- `transformers`: Specifically `BertTokenizer` for tokenization and `BertForQuestionAnswering` for the model.

#### Environment & Configuration
- **DB Configuration**:
  - Host: `localhost`
  - User: `root`
  - Password: `password`
  - Database Name: `inventory`
- **Model Configuration**:
  - Tokenizer path: `path/to/tokenizer/config.json`
  - Model path: `path/to/model.bin`

### Functional Definitions
- **`get_bert_answer(question)`**: Encodes a question using the tokenizer and processes it through the loaded `BertForQuestionAnswering` model. It retrieves the indices for the maximum `start_logits` and `end_logits`, then converts the corresponding token IDs back into a human-readable string.
- **`add_to_memory(question, answer)`**: Inserts new question-answer pairs into the MySQL `memory` table.
- **`add_to_cart(product, price)`**: Adds product name and cost to the `cart` table.
- **`get_cart_total()`**: Executes a SQL `SELECT SUM(price)` query on the `cart` table to calculate the total checkout value. Returns `0` if the result is empty.
- **`list_products_by_tag(tag)`**: Performs a SQL `SELECT` on the `products` table filtering by `tags LIKE '%tag%'`, returning a list of product names and their costs.

### Full Source Code
```python
import mysql.connector
import torch
from transformers import BertTokenizer, BertForQuestionAnswering

# Load the custom-trained BERT model and tokenizer
tokenizer = BertTokenizer.from_pretrained('path/to/tokenizer/config.json')
model = BertForQuestionAnswering.from_pretrained('path/to/model.bin')

# Connect to the MySQL database
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="password",
    database="inventory"
)

# Define a function to get an answer from the BERT model
def get_bert_answer(question):
    # Encode the question using the tokenizer
    inputs = tokenizer(question, return_tensors='pt')

    # Pass the encoded question to the BERT model
    outputs = model(**inputs)

    # Get the answer from the model's output
    answer_start = torch.argmax(outputs.start_logits)
    answer_end = torch.argmax(outputs.end_logits) + 1
    answer = tokenizer.convert_tokens_to_string(tokenizer.convert_ids_to_tokens(inputs['input_ids'][0][answer_start:answer_end]))

    return answer.strip()

# Define a function to add a question-answer pair to the chatbot's memory
def add_to_memory(question, answer):
    cursor = db.cursor()
    sql = "INSERT INTO memory (question, answer) VALUES (%s, %s)"
    val = (question, answer)
    cursor.execute(sql, val)
    db.commit()

# Define a function to add a product to the user's cart
def add_to_cart(product, price):
    cursor = db.cursor()
    sql = "INSERT INTO cart (product, price) VALUES (%s, %s)"
    val = (product, price)
    cursor.execute(sql, val)
    db.commit()

# Define a function to calculate the total price of the user's cart
def get_cart_total():
    cursor = db.cursor()
    cursor.execute("SELECT SUM(price) FROM cart")
    result = cursor.fetchone()[0]
    return result if result else 0

# Define a function to list all products with a particular tag
def list_products_by_tag(tag):
    cursor = db.cursor()
    cursor.execute("SELECT name, price FROM products WHERE tags LIKE %s", ('%' + tag + '%',))
    result = cursor.fetchall()
    return result

# Start the conversation loop
while True:
    # Get the user's question
    question = input("You: ")

    # Check if the question is in the chatbot's memory
    cursor = db.cursor()
    cursor.execute("SELECT answer FROM memory WHERE question = %s", (question,))
    result = cursor.fetchone()

    # If the question is in the chatbot's memory, retrieve the answer
    if result is not None:
        print("Bot: " + result[0])

    # If the question is not in the chatbot's memory, use the BERT model to get an answer
    else:
        # Check if the question contains a tag for listing products
        tags = ['fever', 'cold', 'headache'] # replace with actual tags
        for tag in tags:
            if tag in question:
                products = list_products_by_tag(tag)
                if len(products) == 0:
                    print("Bot: Sorry, we don't have any products for that tag.")
                else:
                    print("Bot: Here are the products we have for that tag:")
                    for product in products:
                        print("- " + product[0] + " (₹" + str(product[1]) + ")")
                break
        
        # If the question does not contain a tag for listing products, use the BERT model to get an answer
```
[[session/dialog/sharegpt_c22x2ZP_15.jsonl#L1-L5]]
