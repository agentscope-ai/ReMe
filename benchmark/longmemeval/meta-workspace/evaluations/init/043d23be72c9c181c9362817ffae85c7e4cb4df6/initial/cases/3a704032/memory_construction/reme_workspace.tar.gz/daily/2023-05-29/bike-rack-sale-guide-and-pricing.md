---
description: Comprehensive guide for photographing and listing a used bike rack on
  platforms like Craigslist and Facebook Marketplace, including valuation tools and
  research methods. Includes personal context regarding a $50 parking meter violation
  expense requiring financial recovery.
name: bike-rack-sale-guide-and-pricing
session_id: d729b790_2
source_conversation: '[[session/dialog/d729b790_2.jsonl]]'
---

## Photography and Listing Essentials
- Clean the bike rack thoroughly to remove accumulated dirt, dust, and debris before photographing to improve visual appeal [[session/dialog/d729b790_2.jsonl#L1-L4]].
- Utilize natural daylight positioned near windows or outdoors while avoiding flash photography which produces harsh shadows; supplement indoor shots with well-lit environments or a lightbox [[session/dialog/d729b790_2.jsonl#L1-L4]].
- Capture the bike rack from multiple comprehensive angles including front, back, sides, top, bottom, close-ups of hooks/straps/adaptation mechanisms, and lifestyle shots demonstrating attachment or trunk storage [[session/dialog/d729b790_2.jsonl#L1-L4]].
- Include a scale reference object like a bike helmet or ruler alongside the rack, utilize plain backgrounds such as white sheets or walls, highlight unique features like locking mechanisms, and employ photo editing software to crop and brighten images for optimal multi-device display [[session/dialog/d729b790_2.jsonl#L1-L4]].
- Construct listings with clear titles, exhaustive descriptions documenting condition/features/flaws, explicit asking prices with stated negotiation flexibility, and direct contact information [[session/dialog/d729b790_2.jsonl#L1-L4]].

## Pricing Research and Estimation Tools
- Analyze completed and sold listings across eBay, Craigslist, Facebook Marketplace, and Letgo, applying filters for geographic location and item condition to establish fair market value [[session/dialog/d729b790_2.jsonl#L3-L4]].
- Cross-reference prices in Amazon's Used & New marketplace, utilize pricing tracking utilities like Price Checker and CamelCamelCamel, and scan physical barcodes via the Decluttr application to receive instant valuations for comparable bike carriers and accessories [[session/dialog/d729b790_2.jsonl#L3-L4]].
- Consult the Kelley Blue Book pricing guide specifically for bicycles and components, seek physical inspection estimates from local bicycle retail shops, browse community insights on Reddit threads (r/bicycletouring, r/biking), and execute targeted web queries for historical sales data [[session/dialog/d729b790_2.jsonl#L3-L4]].
- Set final competitive pricing by accurately weighing the bike rack's chronological age, baseline production cost, and present physical condition [[session/dialog/d729b790_2.jsonl#L3-L4]].

## Financial Context
- The user documented recovering capital expenses stemming from a $50 parking meter violation ticket issued the preceding month [[session/dialog/d729b790_2.jsonl#L1-L2]].
