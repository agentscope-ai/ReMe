---
description: 'Drafted an email rejecting an ArcGIS Online (AGOL) Story Map submission
  due to violation of the 2020 ERH policy prohibiting live/dynamic AGOL pages from
  being made public in the ER environment. The drafted rejection email uses the subject
  line ''ArcGIS Online Story Map Submission - Rejection'' and includes: explicit notification
  of non-approval citing the 2020 policy restriction, acknowledgment of substantial
  effort invested in creating the Story Map with an apology for inconvenience, justification
  based on maintaining system security and data stability requirements, and an invitation
  for follow-up discussion.'
name: agol-story-map-rejection
session_id: sharegpt_6ZpPBwe_0
source_conversation: '[[session/dialog/sharegpt_6ZpPBwe_0.jsonl]]'
---

## Rejection Rationale

* An ArcGIS Online (AGOL) Story Map submitted for review received a denial of approval due to a violation of the ERH policy established in 2020, which mandates that there will be no "live/dynamic" AGOL pages made public in the ER environment. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L1-L1]]

## Drafted Email Architecture

* The message utilizes the precise subject line: "ArcGIS Online Story Map Submission - Rejection". [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
* The opening paragraph formally notifies the recipient that the submission will not receive approval due to the referenced 2020 policy restriction. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
* The second paragraph acknowledges significant effort invested by the creator in developing the Story Map and includes an apology for any inconvenience caused by the non-approval determination. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
* The third paragraph provides justification for policy enforcement, citing the necessity of preserving overall system security and data integrity as the rationale for maintaining these restrictions. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
* The closing paragraph invites the recipient to contact the sender with questions or concerns and expresses willingness to discuss the rejection decision further. [[session/dialog/sharegpt_6ZpPBwe_0.jsonl#L2-L2]]
