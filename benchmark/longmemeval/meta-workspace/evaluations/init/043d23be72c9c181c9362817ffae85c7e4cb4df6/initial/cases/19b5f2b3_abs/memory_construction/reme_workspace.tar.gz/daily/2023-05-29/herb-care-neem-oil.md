---
description: Actionable advice on maintaining healthy herb plants including watering,
  lighting, temperature, fertilization, and pruning routines. Detailed breakdown of
  neem oil as an organic pesticide, covering its extraction, biological mechanisms,
  safety benefits, precise dilution ratios, application timing, and sourcing criteria.
name: herb-care-neem-oil
session_id: 9f8fa5e4_2
source_conversation: '[[session/dialog/9f8fa5e4_2.jsonl]]'
---

## Herb Care Fundamentals [[session/dialog/9f8fa5e4_2.jsonl#L2-L6]]
* **Watering**: Check soil daily and water only when the top inch feels dry. Water strictly at the base level to encourage root development and avoid wetting leaves, which prevents fungal diseases.
* **Lighting**: Provide at least 4–6 hours of direct sunlight daily. For indoor cultivation, position near sunny windows or install grow lights. Filter intense afternoon sun with sheer curtains to prevent scorching sensitive varieties like basil and mint.
* **Temperature**: Maintain daytime ranges of 65°F–75°F (18°C–24°C) and nighttime ranges of 55°F–65°F (13°C–18°C). Keep plants away from heating vents, radiators, or drafty windows.
* **Fertilization**: Apply a balanced, water-soluble fertilizer (20-20-20) weekly diluted to half-strength to prevent root burn. Maintain slightly acidic to neutral soil pH between 6.0 and 7.0.
* **Pruning & Grooming**: Regularly pinch off flower buds to direct energy toward leaf production. Remove dead or damaged foliage immediately to stop pest and disease transmission. Repot overgrown containers and divide clumping species like mint. Consistent harvesting stimulates continuous leaf production and delays flowering.

## Organic Pest Control & Neem Oil [[session/dialog/9f8fa5e4_2.jsonl#L2-L2,L4-L10]]
* **General Monitoring & Isolation**: Inspect plants routinely for aphids, whiteflies, spider mites, and mealybugs. Quarantine heavily infested specimens immediately. Alternate neem oil with insecticidal soap or horticultural oil to maintain efficacy.
* **Neem Oil Mechanism & Benefits**: Extracted from the seeds of the Indian neem tree (*Azadirachta indica*), neem oil acts as a multi-target biological pesticide. It disrupts insect life cycles by blocking molting (insect growth regulator), repelling insects through bitter taste and odor (feeding deterrent), and circulating systemically through plant tissues upon absorption. It offers broad-spectrum protection against insects, mites, and fungi with low toxicity to humans, pets, and beneficial pollinators like bees. Pests rarely develop resistance due to its complex mode of action.
* **Application Protocol**: Dilute 2–4 teaspoons of neem oil per quart of water. Spray comprehensively across all foliage, stems, and soil surfaces. Schedule applications for early morning or late evening to prevent phototoxicity (leaf burn). Repeat every 7–10 days for sustained control. Always perform a small-area test spray beforehand to check for phytotoxicity.
* **Sourcing & Management**: Use cold-pressed, organic products featuring high azadirachtin concentrations. View neem oil as a preventative ecosystem tool rather than a quick fix; combine usage with optimal environmental conditions and regular weed removal.
