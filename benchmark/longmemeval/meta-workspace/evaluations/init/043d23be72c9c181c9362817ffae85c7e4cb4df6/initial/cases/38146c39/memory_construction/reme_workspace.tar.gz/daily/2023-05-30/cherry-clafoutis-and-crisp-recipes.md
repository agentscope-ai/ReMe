---
description: 'Detailed recipes for Cherry Clafoutis and Cherry Crisp, listing exact
  ingredients, measurements, step-by-step baking instructions, and servings. Provides
  comprehensive guidance on modifications: substituting granulated sugar with brown
  sugar, replacing all-purpose flour with almond flour, and adding a sliced almond
  topping. Outlines specific preparation protocols for using frozen cherries in place
  of fresh fruit.'
name: cherry-clafoutis-and-crisp-recipes
session_id: 87aaee77
source_conversation: '[[session/dialog/87aaee77.jsonl]]'
---

## Cherry Clafoutis and Cherry Crisp Recipes

### Cherry Clafoutis Recipe
**Serving Size:** 6-8 people
**Description:** A classic French dessert resembling a cobbler but possessing a lighter, fluffier texture.
**Ingredients:**
- 2 cups fresh or frozen cherries, pitted
- 1 1/2 cups granulated sugar
- 1/2 cup all-purpose flour
- 1/2 teaspoon baking powder
- 1/2 teaspoon salt
- 1/2 cup whole milk
- 2 large eggs
- 2 tablespoons unsalted butter, melted
- 1 teaspoon vanilla extract
**Instructions:**
1. Preheat oven to 375°F (190°C).
2. In a large bowl, whisk together the sugar, flour, and baking powder.
3. In a separate bowl, whisk together the milk, eggs, and melted butter.
4. Combine wet and dry ingredients, whisking until smooth.
5. Pour batter into a 9x13-inch baking dish and arrange cherries on top.
6. Bake for 35-40 minutes until puffed and golden brown.
7. Dust with powdered sugar and serve warm.
[[session/dialog/87aaee77.jsonl#L2]]

### Cherry Crisp Recipe
**Serving Size:** 6-8 people
**Description:** A classic American dessert ideal for warm weather.
**Ingredients:**
- 2 cups fresh or frozen cherries, pitted
- 1/2 cup granulated sugar
- 2 tablespoons cornstarch
- 1/4 cup all-purpose flour
- 1/2 teaspoon cinnamon
- 1/4 teaspoon nutmeg
- 1/4 teaspoon salt
- 1/2 cup rolled oats
- 1/2 cup brown sugar
- 1/2 cup cold unsalted butter, cut into small pieces
**Instructions:**
1. Preheat oven to 375°F (190°C).
2. Mix cherries, granulated sugar, cornstarch, and flour in a large bowl.
3. Transfer mixture to a 9x9-inch baking dish.
4. In a separate bowl, mix rolled oats, brown sugar, cinnamon, nutmeg, and salt.
5. Work cold butter into the oat mixture using fingers or a pastry blender until crumbly.
6. Spread the crumb topping evenly over the cherry mixture.
7. Bake for 40-45 minutes until the topping is golden brown and the fruit is bubbly.
8. Serve warm with vanilla ice cream or whipped cream.
[[session/dialog/87aaee77.jsonl#L2]]

## Recipe Modifications and Substitutions

### Granulated Sugar to Brown Sugar
**Context:** User requested substituting granulated sugar with brown sugar in the Cherry Clafoutis recipe.
**Flavor Impact:** Brown sugar imparts a richer, deeper flavor profile featuring caramel and molasses notes, creating a more complex and nuanced taste compared to granulated sugar.
**Texture Impact:** Brown sugar contains higher moisture levels, resulting in a denser, moister, and more cake-like consistency. The clafoutis will exhibit heavier browning and reduced puffiness during baking.
**Application Tips:** 
- Use light brown sugar rather than dark brown sugar to prevent overpowering the cherry flavor.
- Reduce the volume from 1 1/2 cups to 1 1/4 cups, as brown sugar is sweeter.
- Monitor baking closely and cover the top with foil during the final 10-15 minutes to prevent over-browning.
[[session/dialog/87aaee77.jsonl#L3-L4]]

### All-Purpose Flour to Almond Flour
**Context:** User requested substituting all-purpose flour with almond flour in the Cherry Clafoutis recipe.
**Flavor Impact:** Introduces a distinct, pronounced nutty flavor that complements the cherries, particularly when utilizing high-quality blanched almond flour.
**Texture Impact:** Produces a significantly denser, moist, and tender crumb resembling a pound cake. The final product will be more delicate and possess a slightly crumbly consistency.
**Application Tips:**
- Ensure the use of high-quality, finely ground, blanched almond flour; sift to eliminate lumps.
- Apply a 1:1 substitution ratio, but anticipate increased liquid absorption; supplement with additional milk or eggs to achieve proper batter consistency.
- Decrease baking powder to 1/4 teaspoon, as almond flour is highly sensitive to leavening agents.
- Avoid overmixing the batter to prevent a dense, tough result. This substitution provides a gluten-free, low-carb dessert alternative.
[[session/dialog/87aaee77.jsonl#L5-L6]]

### Sliced Almonds as Topping
**Context:** User intended adding sliced almonds atop the cherries prior to baking for enhanced texture and visual presentation.
**Flavor & Texture Benefits:** Provides a contrasting crunchy texture and complementary nutty depth.
**Application Tips:**
- Select thinly sliced almonds (slivers) to ensure even toasting and prevent bitterness.
- Distribute evenly across the entire surface, utilizing approximately 1/4 to 1/2 cup based on preference.
- Consider sprinkling a pinch of brown sugar over the almonds to promote caramelization and create a crunchy crust.
- Maintain close observation during baking; the almonds toast rapidly and burn easily. Implement the standard foil-covering technique during the final 10-15 minutes if necessary.
[[session/dialog/87aaee77.jsonl#L7-L8]]

### Fresh Cherries to Frozen Cherries
**Context:** User planned to utilize previously frozen cherries stored in their freezer instead of fresh cherries.
**Viable Alternative Status:** Frozen cherries are acceptable and advantageous, often being flash-frozen at peak ripeness to maintain flavor and structural integrity.
**Preparation Requirements:**
- Thaw cherries either by leaving them at room temperature for several hours or according to microwave package instructions.
- Thoroughly pat the thawed cherries dry using paper towels to extract excess moisture, thereby preventing a soggy clafoutis base.
- Gently fold the cherries into the sugar and flour mixture to avoid crushing the fragile fruit.
**Baking Adjustments:** Anticipate increased juice release and softer fruit retention post-baking. If the thawed cherries are exceptionally watery, reduce the overall sugar quantity to balance the sweetness.
[[session/dialog/87aaee77.jsonl#L9-L10]]

## Final Execution Plan
On 2023-05-30, the user determined to prepare the Cherry Clafoutis recipe incorporating all proposed substitutions: utilizing brown sugar in place of granulated sugar, replacing all-purpose flour with almond flour, applying a sliced almond topping, and employing thawed frozen cherries. The user expressed intent to report back regarding the culinary results upon completion.
[[session/dialog/87aaee77.jsonl#L11-L12]]
