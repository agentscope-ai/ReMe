---
description: WordPress development session (2023-05-28) creating a dynamic shortcode
  and single-post template for the 'policy' custom post type. The shortcode [custom_post_list]
  was iteratively developed to support configurable number_of_posts, category, taxonomy,
  and topic parameters, ultimately displaying the first 5 policies per topic under
  H2 headings as hyperlinked lists. Requires the 'topic' taxonomy (registered to 'policy'
  CPT) with slug values like 'academic-affairs' and 'student-life'. The single template
  file declares 'Policy Single' as its Template Name, renders entry title in H1, published
  date via ACF get_field('published_date'), Unit and Topic taxonomy terms via get_the_terms(),
  main body content via the_content(), and collapsible Additional Resources and History
  sections via ACF fields get_field('additional_resources') and get_field('history').
  All code uses standard WordPress functions including WP_Query, shortcode_atts, add_shortcode,
  wp_reset_postdata, get_terms, the_title, get_the_permalink, post_class, and edit_post_link.
name: wordpress-policy-cpt-development
session_id: sharegpt_8jxRz9U_0
source_conversation: '[[session/dialog/sharegpt_8jxRz9U_0.jsonl]]'
---

## WordPress Custom Post Type Development for 'policy' [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L1-L10]]

### Project Context
- Working on WordPress implementation for a custom post type named `policy` [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L3-L4,L7-L8]]
- Uses custom taxonomy `Topic` (machine name: `topic`) registered for the `policy` CPT [[L5-L8]]
- Example topic slugs used: `academic-affairs` and `student-life` [[L6]]
- Requires integration with Advanced Custom Fields (ACF) [[L9-L10]]
- Date: 2023-05-28 [[L1|user @ 2023-05-28T13:53:00]]

### Dynamic Shortcode Implementation [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L1-L8]]

#### Function Signature and Registration
- Function name: `custom_post_list_shortcode` [[L2-L8]]
- Registered via: `add_shortcode('custom_post_list', 'custom_post_list_shortcode')` [[L2,L4,L6,L8]]
- Parameterless variant used for multi-term display: `function custom_post_list_shortcode()` [[L8]]

#### Attributes and Defaults [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L2]]
Configuration handled through `shortcode_atts`:
- `number_of_posts`: integer defaulting to 5
- `category`: empty string default (removed later)
- `taxonomy`: empty string default (renamed to `topic`)
- `topic`: empty string default (replaces `taxonomy` attribute)

#### Query Construction [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L2-L8]]
Base `$args` array initialization:
```php
$args = array(
    'post_type' => 'policy',
    'posts_per_page' => $atts['number_of_posts'],
);
```
Conditional filters applied when attributes contain values:
- Category filter: `$args['category_name'] = $atts['category'];` (early versions only) [[L4]]
- Taxonomy filter using `tax_query`:
```php
$args['tax_query'] = array(
    array(
        'taxonomy' => 'topic',
        'field'    => 'slug',
        'terms'    => $atts['topic'],
    ),
);
```
[[L6-L8]]

Query execution uses `new WP_Query($args)` [[L4-L8]].

#### Output Rendering Pipeline [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L4-L6]]
1. Checks `$query->have_posts()` boolean state [[L4-L6]]
2. If posts exist:
   - Opens `<ul>` container [[L4-L6]]
   - Loops through posts calling `$query->the_post()` [[L4-L6]]
   - Generates `<li><a href="' . get_the_permalink() . '">' . get_the_title() . '</a></li>` [[L4-L6]]
   - Calls `wp_reset_postdata()` after loop [[L4-L6]]
   - Closes `</ul>` [[L4-L6]]
3. If no posts return fallback message:
   - Version 1: `"No custom posts found."` [[L2]]
   - Version 2: `"No policy post found."` [[L4]]
   - Version 3: `"No policies found for the given topic."` [[L6]]
   - Multi-term version: `"No policies found for this topic."` [[L8]]

#### Iterative Development Summary
| Step | Change | Lines |
|------|--------|-------|
| 1 | Generic custom post listing shortcode with `number_of_posts`, `category`, `taxonomy` params | L1-L2 |
| 2 | Changed `post_type` to `'policy'` | L3-L4 |
| 3 | Replaced `category` param with `topic` param; hardcoded taxonomy name `'topic'` | L5-L6 |
| 4 | Added multi-term logic: fetch all terms via `get_terms()`, display 5 policies per term under `<h2>` headings | L7-L8 |

#### Usage Examples [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L2-L8]]
- Basic: `[custom_post_list]` [[L6,L8]]
- With topic filter: `[custom_post_list number_of_posts="5" topic="academic-affairs"]` [[L6]]
- With topic filter: `[custom_post_list number_of_posts="5" topic="student-life"]` [[L6]]

#### Prerequisite
- Taxonomy `topic` must be registered for post type `policy` before using the shortcode [[L6,L8]]

### Single Post Template for Policy CPT [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L9-L10]]

#### Template Declaration
- File header comment: `/* Template Name: Policy Single */` [[L10]]

#### Structural Layout [[L10]]
Standard WordPress template hierarchy flow:
1. `get_header()` call [[L10]]
2. Content wrapper: `<div id="primary" class="content-area">` containing `<main id="main" class="site-main" role="main">` [[L10]]
3. Article element: `<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>` [[L10]]
4. Sidebar: `get_sidebar()` [[L10]]
5. Footer: `get_footer()` [[L10]]

Loop structure:
```php
<?php while ( have_posts() ) : the_post(); ?>
    <!-- article content -->
<?php endwhile; ?>
```
[[L10]]

#### Entry Header Section [[L10]]
- Title: `<h1 class="entry-title"><?php the_title(); ?></h1>`
- Meta info: `<div class="entry-meta">` containing `<?php echo 'Published on: ' . get_field('published_date'); ?>`

#### Taxonomy Display Sections [[L10]]
Both taxonomies retrieved via `get_the_terms(get_the_ID(), '{name}')` with emptiness checks:

- **Unit Taxonomy**:
```php
$unit_terms = get_the_terms(get_the_ID(), 'unit');
if (!empty($unit_terms)) {
    echo '<p>Unit: ';
    foreach ($unit_terms as $term) {
        echo $term->name . ' ';
    }
    echo '</p>';
}
```

- **Topic Taxonomy**:
```php
$topic_terms = get_the_terms(get_the_ID(), 'topic');
if (!empty($topic_terms)) {
    echo '<p>Topic: ';
    foreach ($topic_terms as $term) {
        echo $term->name . ' ';
    }
    echo '</p>';
}
```

#### Main Content Area [[L10]]
- Standard editor content: `<?php the_content(); ?>`

#### ACF Custom Field Sections [[L10]]
Both follow identical conditional rendering pattern:

- **Additional Resources**:
```php
$additional_resources = get_field('additional_resources');
if (!empty($additional_resources)) {
    echo '<h3>Additional Resources</h3>';
    echo '<div class="collapsible-content">' . $additional_resources . '</div>';
}
```

- **History**:
```php
$history = get_field('history');
if (!empty($history)) {
    echo '<h3>History</h3>';
    echo '<div class="collapsible-content">' . $history . '</div>';
}
```

#### Entry Footer [[L10]]
```php
<footer class="entry-footer">
    <?php edit_post_link('Edit', '<span class="edit-link">', '</span>'); ?>
</footer>
```

### Specified Field and Component Reference [[session/dialog/sharegpt_8jxRz9U_0.jsonl#L9]]

| Field / Component | Type | Implementation |
|-------------------|------|----------------|
| Title | Post title | `the_title()` in `<h1>` |
| Published Date | ACF field | `get_field('published_date')` |
| Unit | Custom taxonomy | `get_the_terms(id, 'unit')` |
| Topic | Custom taxonomy | `get_the_terms(id, 'topic')` |
| Body content | Editor content | `the_content()` |
| Additional Resources | Collapsible row (ACF) | `get_field('additional_resources')` in `<div class="collapsible-content">` |
| History | Collapsible row (ACF) | `get_field('history')` in `<div class="collapsible-content">` |

### Key Functions Used
- `shortcode_atts()` — parameter defaults handling
- `add_shortcode()` — shortcode registration
- `WP_Query` — post retrieval with pagination and filtering
- `get_terms()` — taxonomy term collection retrieval
- `get_field()` — ACF field data access
- `get_the_terms()` — term association retrieval by post ID
- `the_title()` — post title output
- `get_the_permalink()` — post URL generation
- `get_the_ID()` — current post ID
- `post_class()` — CSS class generation for articles
- `wp_reset_postdata()` — query state cleanup
- `get_header()`, `get_footer()`, `get_sidebar()` — template inclusion
- `edit_post_link()` — backend edit link generation
