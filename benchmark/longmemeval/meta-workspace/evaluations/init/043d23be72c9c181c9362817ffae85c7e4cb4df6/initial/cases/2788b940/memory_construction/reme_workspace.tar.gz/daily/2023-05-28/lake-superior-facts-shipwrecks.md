---
description: Detailed notes on the geographical characteristics, ecological features,
  and maritime history of Lake Superior, including statistical data on volume, surface
  area, and depth, alongside documentation of major shipwrecks (SS Edmund Fitzgerald,
  SS Cyprus), contemporary diving practices, and legal protections governing underwater
  artifact recovery.
name: lake-superior-facts-shipwrecks
session_id: ultrachat_567558
source_conversation: '[[session/dialog/ultrachat_567558.jsonl]]'
---

## Geography & Ecology
- Largest lake by volume in North America [[session/dialog/ultrachat_567558.jsonl#L1-L2]].
- World's largest freshwater lake by surface area, covering approximately 82,000 square kilometers (31,700 square miles) [[session/dialog/ultrachat_567558.jsonl#L4-L4]].
- Deepest of the Great Lakes, reaching a maximum depth of 406 meters (1,333 feet) [[session/dialog/ultrachat_567558.jsonl#L4-L4]].
- Contains roughly 10% of the world's total freshwater supply [[session/dialog/ultrachat_567558.jsonl#L4-L4]].
- Supports unique native flora and fauna, specifically the lake trout, coaster brook trout, and the endangered Piping Plover bird [[session/dialog/ultrachat_567558.jsonl#L4-L4]].

## History & Shipwrecks
- Approximately 350 vessels have sunk in its waters since the mid-1800s, driven by unpredictable weather conditions and a rocky coastline [[session/dialog/ultrachat_567558.jsonl#L4-L6]].
- SS Edmund Fitzgerald: Disappeared and sank on November 10, 1975 during a severe storm, resulting in the loss of all 29 crew members. The event was permanently recorded in the folk song "The Wreck of the Edmund Fitzgerald" by musician Gordon Lightfoot [[session/dialog/ultrachat_567558.jsonl#L6-L6]].
- SS Cyprus: Sank in 1907 after being trapped in a storm while transporting a copper cargo. Historical estimates indicate that up to 20 million pounds of copper still lie on the lake bed [[session/dialog/ultrachat_567558.jsonl#L6-L6]].

## Exploration & Conservation
- Submerged vessel exploration remains an active pursuit; extensive depths necessitate specialized diver training and equipment, though select shallower wrecks accommodate divers across all proficiency tiers [[session/dialog/ultrachat_567558.jsonl#L8-L8]].
- Commercial operators run structured boat tours directly over identified wreck sites, frequently hiring researchers and professional historians to deliver educational commentary regarding vessel histories [[session/dialog/ultrachat_567558.jsonl#L8-L8]].
- All documented shipwrecks carry legal protection status; extracting artifacts or materially disturbing burial sites constitutes an illegal act intended to preserve the dignity of deceased mariners [[session/dialog/ultrachat_567558.jsonl#L8-L8]].
