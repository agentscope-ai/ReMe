---
description: Records a comprehensive discussion on creative writing improvement, including
  twelve actionable tips for character development, extensive poetry recommendations
  (classics, modern poets, notable collections, and online resources), strategies
  for experimenting with different literary forms, detailed essay writing and outlining
  methodologies tailored to exploring personal growth, and writing tool/environmental
  habits highlighting a preference for fountain pens alongside software suggestions.
name: writing-craft-and-tools
session_id: d5b3cf54_2
source_conversation: '[[session/dialog/d5b3cf54_2.jsonl]]'
---

# Writing Habits & Current Projects

- Established a consistent writing routine: 30 minutes every morning, Monday through Friday, which fosters creative flow.
- Currently working on a short story and experimenting with poetry.
- Plans to begin a new essay exploring the connection between writing and personal growth, specifically how writing clarifies thoughts and feelings.
- Prefers to brainstorm ideas and create an outline before drafting to ensure a clear structure.
[[session/dialog/d5b3cf54_2.jsonl#L1-L2,L9-L10]]

# Character Development Tips

- Develop a rich backstory including childhood, family, education, significant events, and relationships to understand motivations and fears.
- Create multi-dimensional characters by adding contradictions, flaws, and strengths.
- Express a wide range of emotions, including vulnerability and sadness, to increase relatability.
- Craft unique dialogue and voice for each character that reflects their personality and background.
- Establish relatable motivations such as desires for love, acceptance, revenge, or self-improvement.
- Make characters active agents who drive the plot forward through decisions and consequences rather than remaining passive.
- Illustrate character growth or regression throughout the narrative arc.
- Avoid overused tropes and stereotypes; aim for nuanced, unexpected traits.
- Maintain consistency in personality, traits, and behaviors.
- Dole out character details gradually, using timing and subtext to maintain curiosity.
- Observe real people and fictional characters in books, movies, and TV shows to study what makes them memorable.
[[session/dialog/d5b3cf54_2.jsonl#L2]]

# Poetry Recommendations & Resources

- **Classic Poets**: Emily Dickinson (unique style, themes of love/death/nature); William Wordsworth (Romantic movement, nature, human experience); John Keats (sensuality, beauty, "Ode to a Nightingale"); Walt Whitman (free verse, "Leaves of Grass"); Edgar Allan Poe (darkness, mystery, mortality).
- **Modern & Contemporary Poets**: Mary Oliver (Pulitzer Prize winner, accessibility, nature imagery); Billy Collins (former US Poet Laureate, humorous, everyday life); Danez Smith (powerful lyrical poetry on identity, race, social justice); Warsan Shire (British-Somali, themes of displacement and refugees); Tracy K. Smith (Pulitzer Prize winner and US Poet Laureate, lyricism, family, identity).
- **Notable Collections**: "The Complete Poems of Emily Dickinson"; "The Collected Poems of Langston Hughes" (jazz-inspired, African American experience); "The New Colossus" by Emma Lazarus (engraved on the Statue of Liberty); "The Waste Land" by T.S. Eliot (modernist masterpiece); "Citizen: An American Lyric" by Claudia Rankine (racism, identity, citizenship).
- **Online Resources**: The Poetry Foundation (vast library, biographies, essays); Poetry Magazine (new poetry, reviews); Button Poetry (performance and spoken word).
[[session/dialog/d5b3cf54_2.jsonl#L4]]

# Experimenting with Writing Forms

- Exploring different genres improves versatility, mastery of craft (e.g., dialogue for scripts, argumentation for essays), creativity, audience reach, and confidence.
- Benefits of specific forms: Essays enhance critical thinking, research, and persuasive voice. Scripts teach concise language, scene structure, and visual storytelling. Journalism develops interviewing and clear communication. Non-fiction covers memoir, biography, and technical writing.
- Recommended steps: select an interesting form, allocate dedicated time (even 10-15 minutes daily), start with short exercises, join a writer community or find a mentor, and practice patience.
[[session/dialog/d5b3cf54_2.jsonl#L5-L6]]

# Essay Writing & Outlining Strategies

- Outline creation requires a strong thesis statement, identification of main topics, logical ordering, hierarchical structuring with subtopics and supporting details, and regular revision. Use keywords and phrases for consistency. Keep the outline concise as a flexible guide. Sample structure includes Introduction (hook, background, thesis), Main Topics with subtopics, and Conclusion.
- Drafting techniques include starting with a clear thesis (e.g., framing writing as a transformative tool for clarity), incorporating personal anecdotes and examples, exploring emotional benefits and the writing process itself, using vivid language, organizing logically, and editing thoroughly.
- Potential essay structures: Narrative (focus on a specific life experience), Analytical (break down ways writing provides clarity), Reflective (introspective tone exploring influence on growth).
[[session/dialog/d5b3cf54_2.jsonl#L8-L10]]

# Writing Tools & Environmental Preferences

- The user recently started experimenting with fountain pens and enjoys the tactile satisfaction of the pen gliding across paper.
- Effective writing tools and habits include favorite physical pens/pencils, dedicated notebooks/journals, writing software and apps (specifically Scrivener, Grammarly, and Hemingway Editor), background music or ambient noise, established daily routines, scheduled break reminders for stretching, and accountability partners or writing groups.
[[session/dialog/d5b3cf54_2.jsonl#L11-L12]]
