---
description: Comprehensive record of the user's film viewing preferences (focus on
  dramas, documentaries, and semi-autobiographical narratives), evaluation criteria
  prioritizing storytelling and character development over technical elements, detailed
  analysis of the feature film Minari (2020) including cast, director Lee Isaac Chung,
  production methods, and accolades, and documentation of the user's first-time experience
  judging a university film festival on 2023-02-15 where a tie for first place in
  fiction was awarded to a semi-autobiographical short film about a first-generation
  immigrant.
name: film-interests-and-festival-judging
session_id: c7c10e58_1
source_conversation: '[[session/dialog/c7c10e58_1.jsonl]]'
---

### Film Preferences and Evaluation Criteria
- The user prioritizes storytelling and character development as the primary drivers of cinematic quality, valuing emotional resonance with character journeys over technical elements like cinematography, sound design, and direction. [[session/dialog/c7c10e58_1.jsonl#L11-L12]]
- The user currently enjoys dramas and documentaries, preferring feature films while remaining open to short films and documentary formats. The user seeks out recent releases and typically dedicates weekend hours to watching new content. [[session/dialog/c7c10e58_1.jsonl#L3-L4]]
- The user places high value on semi-autobiographical narratives due to the authenticity and genuine personal connection inherent in director-led autobiographical storytelling. [[session/dialog/c7c10e58_1.jsonl#L7-L8]]

### University Film Festival Judging Experience
- The user served as a guest judge at an unnamed university film festival on 2023-02-15 showcasing student-produced short films and documentaries. This engagement marked the user's inaugural experience evaluating professional-tier screenings. [[session/dialog/c7c10e58_1.jsonl#L1-L2]]
- The user awarded a tie for first place within the fiction category after determining which submissions delivered the strongest emotional impact. The user provided direct feedback to participating student filmmakers throughout the evaluation process. [[session/dialog/c7c10e58_1.jsonl#L7-L9]]
- One of the jointly awarded first-place fiction entries was a semi-autobiographical short film exploring the director's firsthand childhood experiences as a first-generation immigrant. The user recognized the submission specifically for unfiltered honesty, vulnerability, and effective thematic execution surrounding identity and cultural heritage. [[session/dialog/c7c10e58_1.jsonl#L7-L9]]
- The user characterized the entire judging framework as a deeply rewarding opportunity to validate emerging student talent and support early-career creative pursuits. [[session/dialog/c7c10e58_1.jsonl#L9-L10]]

### Feature Film Discussion — Minari (2020)
- The user accepted recommendation to view Lee Isaac Chung's semi-autobiographical feature film Minari aligned with existing interest in family-centric identity narratives. [[session/dialog/c7c10e58_1.jsonl#L5-L6]]
- The film centers on the Yi family departing California to establish an agricultural homestead in rural Arkansas during the 1980s, focusing on seven-year-old David Yi's cultural assimilation challenges and developing relationship with maternal grandmother Soonja Yi relocated from Korea. Core ensemble performance features Steven Yeun, Yeri Han, Noel Cho, Alan Kim, and Yuh-jung Youn. [[session/dialog/c7c10e58_1.jsonl#L6-L7]]
- The production employs 35mm film stock combined with unhurried observational camera work and deliberate pacing to emphasize character interaction over plot mechanics. The screenplay incorporates measured comedic beats alongside nuanced family conflict dynamics. [[session/dialog/c7c10e58_1.jsonl#L6-L7]]
- The production received Grand Jury Prize and Audience Award victories at the 2020 Sundance Film Festival prior to acquiring Academy Award nominations across Best Picture, Best Director, Best Actor, and Best Supporting Actress categories. [[session/dialog/c7c10e58_1.jsonl#L6-L7]]
- Additional genre-matched recommendations evaluated during the conversation include Nomadland (2020), The Father (2020), My Octopus Teacher (2020), The Truffle Hunters (2020), Time (2020), The Present (2020), Two Distant Strangers (2020), Small Axe (2020), and The Underground Railroad (2020). The user accesses these titles through Amazon Prime and Netflix streaming distribution networks. [[session/dialog/c7c10e58_1.jsonl#L4-L5]]
