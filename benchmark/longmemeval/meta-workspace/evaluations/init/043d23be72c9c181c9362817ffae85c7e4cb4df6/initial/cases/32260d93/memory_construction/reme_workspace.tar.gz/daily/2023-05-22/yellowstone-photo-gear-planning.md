---
description: Gear planning for an upcoming photography trip to Yellowstone National
  Park following a workshop attendance in downtown on 2023-05-22. Finalized equipment
  list includes a Nikon D500 camera body, 70-200mm telephoto lens, Nikon MC-36a Multi-Function
  Remote Cord, EN-EL15a spare batteries, Anker PowerCore charger, and a compact polarizing
  filter. Also prepared accessories including tripod, bear spray, rain cover, and
  layered clothing.
name: yellowstone-photo-gear-planning
session_id: 09b815e7_2
source_conversation: '[[session/dialog/09b815e7_2.jsonl]]'
---

## Trip Context & Workshop [[session/dialog/09b815e7_2.jsonl#L1-L2]]
- Organizing a photography expedition to **Yellowstone National Park**, requiring gear suited for varying weather conditions, wildlife, and landscape photography.
- On **2023-05-22**, attended a photography workshop in **downtown**. Used this session to test new equipment, specifically evaluating a remote shutter release, which influenced final purchasing decisions.

## Camera Body & Lens Selection [[session/dialog/09b815e7_2.jsonl#L2-L3,L9-L10]]
- **Camera Body**: **Nikon D500** selected for its superior low-light performance suitable for early morning or late evening shooting sessions.
- **Lens Strategy**: Prioritized carrying a **70-200mm telephoto lens** for capturing distant wildlife such as bears, bison, and elk. Considered versatile zoom options (24-105mm) and wide-angle lenses (10-22mm) for landscapes during initial planning.

## Remote Shutter Release Acquisition [[session/dialog/09b815e7_2.jsonl#L3-L8]]
- **Decision**: Purchased the **Nikon MC-36a Multi-Function Remote Cord**. 
- **Justification**: The official Nikon device guarantees compatibility with the D500's 10-pin terminal. It offers immediate shutter triggering for fleeting moments and eliminates camera shake compared to physical button pressing.
- **Rejected Alternatives**: Evaluated and declined the Vello RS-N1II ($15-$20), CamRanger CR-N1 ($20-$25), and Phottix C6 ($20-$25). Budget third-party brands like Neewer or JJC (~$10-$15) were also noted but not chosen.
- **Backup Method**: The camera's self-timer remains an available alternative if the remote is lost, though it introduces delays less ideal for active wildlife subjects.

## Power & Battery Management [[session/dialog/09b815e7_2.jsonl#L7-L8]]
- **Spare Batteries**: Procuring genuine **Nikon EN-EL15a** batteries is essential due to power drain risks from cold temperatures and long field hours.
- **Portable Charging**: Packing an **Anker PowerCore** external battery charger to top up devices remotely where wall outlets are unavailable.

## Filtration & Accessories [[session/dialog/09b815e7_2.jsonl#L2,L9-L12]]
- **Polarizing Filter**: Confirmed inclusion of a **compact polarizing filter**. 
    - Purpose: Reduces glare from reflective surfaces (water, snow), enhances color saturation, and deepens sky contrast.
    - Trade-off: Accepted the added weight and bulk because of the significant optical benefits for the park's lighting conditions.
- **Essential Kit**: Carrying a sturdy tripod for slow exposures (geysers/mist), camera rain cover, lens cleaning kit, bear spray for safety, waterproof jacket, warm layers, and hiking boots.
