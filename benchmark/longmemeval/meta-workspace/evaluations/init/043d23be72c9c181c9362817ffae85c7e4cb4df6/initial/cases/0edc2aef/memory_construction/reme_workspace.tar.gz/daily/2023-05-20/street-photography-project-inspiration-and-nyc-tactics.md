---
description: Actionable strategy for launching a street photography project triggered
  by a concurrent visit to the Photography Museum with cousin Alex during April 2023.
  Catalogs authoritative resource networks including five primary photography blogs,
  ten targeted Instagram accounts across six distinct visual genres, and three community
  feedback platforms. Maps multi-vector discovery pipelines for regional and international
  street photography education, detailing search algorithms, directory aggregators,
  professional guild affiliations (PPA, NPPA), and established pedagogical programs
  (Eric Kim's Workshop, Magnum Photography Workshops, Leica Akademie). Delineates
  curatorial navigation protocols and historical/modernist collection taxonomy for
  the Modern Museum of Art (MoMA) Contemporary Art Exhibition scheduled for late May
  2023. Compiles ten methodological directives for dense metropolitan fieldwork, enforcing
  stealth deployment mechanics, low-angle compositional framing, ambient light manipulation,
  structural dialectic spotting, and rigorous interpersonal consent compliance.
name: street-photography-project-inspiration-and-nyc-tactics
session_id: 3c3a9042_3
source_conversation: '[[session/dialog/3c3a9042_3.jsonl]]'
---

## Photography Inspiration & Resources [[session/dialog/3c3a9042_3.jsonl#L2-L2]]
- Recommended photography blogs include The Phoblographer (news and gear reviews), 500px (community-driven showcase), PetaPixel (industry trends and tutorials), Digital Photography School (comprehensive technical guides), and LensCulture (curated artist interviews and projects).
- Targeted Instagram handles span multiple disciplines: @natgeo (archival National Geographic expeditions), @jimmy_chin (outdoor adventure and alpine climbing), @martinschoeller (experimental portrait and documentary testing), @laurieinteriors (minimalist still life and architectural interiors), and @alikazemi (social and environmental documentary portraiture).
- Community ecosystems facilitating critique and networking comprise 500px, Flickr, and Reddit's dedicated photography subforum.
- Genre specialists suggested for stylistic immersion encompass street photography masters @garywinogrand, @henricartierbresson, and @martinmunkacsi; portrait professionals @annieleibovitz, @markseliger, and @platon; landscape creators @max Lowe, @tedhuetter, and @eliasaikaly; and still life artists @andrewzuckerman and @bethgalton.

## Locating Street Photography Education [[session/dialog/3c3a9042_3.jsonl#L3-L4]]
- Localized class identification relies on geographic keyword queries on general search engines, scanning event aggregators like Meetup.com, Eventbrite.com, and Facebook Events, and auditing local photography clubs, academic institutions, and professional guilds such as the Professional Photographers of America (PPA) and National Press Photographers Association (NPPA).
- Digital networking tactics involve participating in niche Facebook Groups, querying local industry professionals via direct Instagram messaging, and analyzing long-form discourse on technical boards like Fred Miranda or Photography-on-the-Net.
- International certification and intensive programs feature The Street Photography Workshop directed by Eric Kim, pedagogical seminars administered by Magnum Photos, and equipment-focused instruction hosted by Leica Akademie.

## Museum Itineraries & Collections [[session/dialog/3c3a9042_3.jsonl#L1-L1,L5-L8]]
- Exposure to archival and contemporary works at the Photography Museum alongside cousin Alex during April 2023 catalyzed the transition toward active artistic production in street photography.
- Scheduled attendance at the Modern Museum of Art (MoMA) targets the Contemporary Art Exhibition opening late May 2023.
- Institutional discovery mechanisms require querying MoMA's primary digital portal, applying algorithmic filters for temporal windows and thematic categories, tracking newsletter publications, and monitoring verified social media distribution channels.
- Programming trajectories prioritize documentary realism exploring societal friction and metropolitan geography, retrospective surveys cataloguing luminaries including Henri Cartier-Bresson, Garry Winogrand, and Lee Friedlander, and multimedia installations collapsing boundaries between analog capture and spatial design.
- Collection taxonomies diverge from mono-genre repositories by contextualizing captured frames within overarching modernist and postmodernist frameworks, emphasizing cross-disciplinary dialogue encompassing conceptualism, performance theater, and sculptural relief. Chronological representation spans mechanical invention era artifacts (Eadweard Muybridge, Julia Margaret Cameron, Edward Steichen), geometric reductionist experiments (Man Ray, László Moholy-Nagy, Berenice Abbott), and avant-garde contemporary deployments.

## New York City Shooting Methodology [[session/dialog/3c3a9042_3.jsonl#L9-L10]]
- Tactical reconnaissance dictates mapping high-footfall corridors near cultural landmarks, identifying elevated vantage points overlooking plaza intersections, calculating solar azimuths to engineer dramatic shadow projection and specular reflection utilization, and hunting compositional dialectics between aging infrastructure and nascent organic growth.
- Mechanical parameters prioritize concealment via pocket-sized optics or smartphone form factors, manipulating ergonomic stances to deploy waist-level hip-shooting dynamics for unselfconscious documentation, extracting narrative depth through macro-observation of transient street vendor activity or typographic signage, and stripping chromatic noise via monochromatic conversion algorithms to heighten tonal hierarchy.
- Social contract adherence necessitates maintaining defensive interpersonal boundaries, delivering immediate verbal contrition upon accidental intrusion detection, and permanently expunging conflicting visual records immediately upon custodial revocation requests.
