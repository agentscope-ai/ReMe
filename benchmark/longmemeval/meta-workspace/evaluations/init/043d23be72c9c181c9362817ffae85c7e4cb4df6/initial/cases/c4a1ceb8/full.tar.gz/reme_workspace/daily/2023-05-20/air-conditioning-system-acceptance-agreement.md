---
description: Drafting and revision of an Air Conditioning System Acceptance Agreement
  between customer Shannon Bennett, supplier AirSmart Pty Ltd., and installer Vuka
  Air for premises at 10 Border St, Byron Bay NSW 2481. The final agreement (dated
  16 February 2023) outlines terms for system acceptance, manufacturer warranty, full
  payment, liability limitation, owner maintenance obligations, governing law (State
  of New South Wales), and execution via counterparts. A proposed termination clause
  was specifically removed from the document.
name: air-conditioning-system-acceptance-agreement
session_id: sharegpt_YdITaOl_21
source_conversation: '[[session/dialog/sharegpt_YdITaOl_21.jsonl]]'
---

## Parties and Premises
- Customer: Shannon Bennett [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]
- Supplier: AirSmart Pty Ltd. [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]
- Installer: Vuka Air [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]
- Installation Location: 10 Border St, Byron Bay NSW 2481 [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]

## Document Structure: Air Conditioning System Acceptance Agreement
- Agreement effective date established as 16 February 2023 [[session/dialog/sharegpt_YdITaOl_21.jsonl#L4-L7]]
- System Inspection and Acceptance: Shannon Bennett acknowledges inspecting the air conditioning system and confirms it is fully installed and functioning correctly [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]
- Warranty Terms: The system is covered by a manufacturer's warranty, with AirSmart obligated to honor it only to the extent permitted by the manufacturer [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]
- Payment Status: Shannon Bennett has completed full payment for the system installation according to AirSmart's invoice [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]
- Liability Limitation: AirSmart and Vuka Air hold no liability for damages or losses incurred by Shannon Bennett regarding system use, excluding standard manufacturer warranty provisions [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]
- Maintenance Obligations: Ongoing maintenance responsibilities fall entirely to Shannon Bennett, specifically encompassing regular cleaning and filter replacement [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]
- Governing Law: Contractual interpretation and governance follow the laws of the State of New South Wales [[session/dialog/sharegpt_YdITaOl_21.jsonl#L6-L7]]
- Execution Method: Agreement allows for execution in multiple counterparts, with each counterpart considered an original legal instrument [[session/dialog/sharegpt_YdITaOl_21.jsonl#L1-L7]]
- Deleted Provisions: A previously included termination clause stipulating that the agreement would expire alongside the manufacturer's warranty was explicitly removed at the user's request [[session/dialog/sharegpt_YdITaOl_21.jsonl#L2-L3]]
