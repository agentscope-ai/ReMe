---
description: A comprehensive extraction of professional photography advice focused
  on urban environments, covering technical protocols for cameras (ISO, aperture,
  RAW shooting, tripod usage), distinct strategies for capturing cityscapes during
  different lighting conditions (nighttime blue hour and long exposures versus daytime
  harsh sunlight and diffusion), methodologies for researching and documenting historical
  urban transformation through archival resources, and ethical guidelines for photographing
  street art and graffiti including legal permissions and context preservation.
name: cityscape-and-street-art-photography-guide
session_id: cb2f5565_3
source_conversation: '[[session/dialog/cb2f5565_3.jsonl]]'
---

## User Context and Exhibition Visit [[session/dialog/cb2f5565_3.jsonl#L1-L1,L5-L5,L11-L11]]
- On 2023-02-15, the user attended a photography exhibition at the **Local History Museum**, spending approximately two and a half hours viewing displays and taking notes.
- The exhibit featured works depicting the city's architectural and cultural transformation over the past century.
- Viewing the exhibition served as direct inspiration for the user to improve personal photography skills, specifically targeting urban cityscapes, historical documentation, and street art photography.

## Fundamental Cityscape Techniques and Composition [[session/dialog/cb2f5565_3.jsonl#L2-L2]]
- Master camera controls by utilizing manual mode, aperture priority, and shutter priority to dictate depth of field and exposure.
- Prioritize the **golden hour** (dawn or dusk) to capture soft, warm ambient illumination; avoid harsh midday sun to prevent unflattering shadows.
- Construct images using leading lines, symmetry, framing devices, and the rule of thirds.
- Focus on visually distinct elements such as intricate architecture, repeating patterns, and surface textures.
- Explore unconventional angles, including looking upward at structures or shooting from elevated vantage points like skyscrapers and rooftops.
- Incorporate reflective surfaces (glass windows, puddles, mirrors) to add layered visual interest.
- Capture artificial city lights (neon signs, streetlights) to provide color depth.
- Record files exclusively in **RAW format** to maximize flexibility during post-processing.
- Utilize **bracketing** (taking multiple shots at different exposures) to facilitate merging in HDR software later.
- Stabilize equipment using a sturdy **tripod**.
- Conduct basic post-production editing using Adobe Lightroom or Photoshop to adjust contrast and color balance.
- Analyze and study the portfolios of other photographers found in exhibitions or online platforms.
- Include human activity, vehicles, or panning motion to inject energy into static scenes.
- Scout locations beforehand to identify iconic landmarks and bridges.

## Nighttime Cityscape Protocols [[session/dialog/cb2f5565_3.jsonl#L4-L4]]
- Deploy specialized gear such as sturdy tripods and wide-angle lenses (10-24mm focal length) to capture vast urban spaces.
- Lower the **ISO** setting to 100-400 to minimize digital noise and artifacts.
- Implement slow shutter speeds ranging between 10 and 30 seconds to create dynamic motion blur.
- Adjust white balance to match lighting conditions, using tungsten or fluorescent presets for artificial lighting, and daylight or shade for outdoor.
- Engage the "bulb" mode on the camera to execute exposures longer than 30 seconds.
- Schedule shoots during the **blue hour** (shortly after sunset) for optimal soft lighting.
- Manage digital noise using reduction software or techniques like dark frame subtraction.
- Scout unique vantage points prior to arrival, such as rooftops, bridges, or alleys.
- Minimize camera shake using remote shutter releases or self-timers.
- Prepare logistical backups, including extra batteries and memory cards, due to the power-intensive nature of night shoots.
- Seek out areas with minimal light pollution to capture cleaner skies and stars.
- Experiment with long exposures to capture light trails from traffic or star trails.

## Handling Daylight and Harsh Sun [[session/dialog/cb2f5565_3.jsonl#L6-L6]]
- Leverage overcast skies as natural diffusers that soften light and reduce harsh contrast.
- Attach a **polarizing filter** to reduce glare, enhance colors, and darken the sky.
- Position the photographer within shaded areas to mitigate the direct impact of intense sunlight.
- Identify interesting shadow formations created by buildings to add texture.
- Use reflectors or diffusers to bounce or scatter direct sunlight onto darker subjects.
- Monitor cloud cover as an element to add depth and interest to the composition.
- Utilize a **graduated neutral density filter** to balance exposure differences between bright skylines and darker ground foregrounds.
- Capture intimate details such as architectural ornamentation or street life alongside grand vistas.
- Prefer weekdays over weekends to avoid crowded streets and chaotic movement.
- Respect private property and remain aware of surroundings while shooting.

## Urban Transformation Research and Documentation [[session/dialog/cb2f5565_3.jsonl#L8-L8]]
- Conduct archival research using physical resources at the **Local History Museum** or digital databases like the Library of Congress's Chronicling America.
- Employ digital tools like Google Earth and Google Street View to map spatial changes over time.
- Consult local experts including historians, architects, and urban planners for insights on significant locations.
- Target areas exhibiting contrasts between historic architecture and modern redevelopment.
- Focus documentation efforts on infrastructure evolution, such as new transportation hubs or redeveloped waterfronts.
- Interview long-time residents to gather oral histories and contextual narratives about neighborhood shifts.
- Monitor social media, local forums, and Facebook groups to discover undocumented or trending locations.
- Photograph subjects from multiple angles, ensuring the inclusion of street signage and broader environmental context.
- Consider documenting the creative process of street artists when permitted.

## Street Art and Graffiti Photography Guidelines [[session/dialog/cb2f5565_3.jsonl#L10-L10,L12-L12]]
- Locate artwork via social media platforms (Instagram, Facebook, Flickr), local tour groups, and festivals.
- Exclusively capture authorized and legal street art to respect intellectual property and ownership rights.
- Adhere to ethical guidelines that prioritize artist anonymity and the preservation of the artwork's integrity.
- Shoot during the golden hour to maximize color vibrancy and reduce harsh reflections.
- Use wide-angle lenses (10-24mm) to capture the full piece within its surrounding architectural context.
- Experiment with varied perspectives and angles rather than shooting purely flat-on.
- Emphasize close-up details of paint textures, layering, and spray patterns.
- Apply black and white conversion techniques to highlight shapes and textures without color distraction.
- Document the immediate environment and neighborhood characteristics to establish context.
- Respect private property boundaries and be mindful of changing weather conditions during outdoor shoots.
