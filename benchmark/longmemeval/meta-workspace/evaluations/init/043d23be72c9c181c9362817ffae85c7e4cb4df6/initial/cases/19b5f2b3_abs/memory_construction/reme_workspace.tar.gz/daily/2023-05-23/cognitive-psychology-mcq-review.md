---
description: Comprehensive review of cognitive psychology multiple-choice questions
  answered during the session on 2023-05-23. Topics include categorization models
  (prototype vs exemplar), cognitive heuristics (anchoring, attraction effects, triangle
  inequality constraints), abstract perceptual learning, synaptic plasticity, Moravec’s
  paradox regarding computer simulation of perception, and the classical mind-body
  problem contrasting materialism and dualism definitions.
name: cognitive-psychology-mcq-review
session_id: sharegpt_TcUL15d_19
source_conversation: '[[session/dialog/sharegpt_TcUL15d_19.jsonl]]'
---

## Categorization Models [[session/dialog/sharegpt_TcUL15d_19.jsonl#L1-L1,L6-L15]]
- **Prototype models**: Demonstrate that category prototypes can be acquired by processing every individual instance within the category. Consequently, the correct option identifies that prototypes are learned through the accumulation of instances [[session/dialog/sharegpt_TcUL15d_19.jsonl#L1]].
- **Exemplar models**: Assert that category membership is determined by the similarity of a new instance to previously encountered examples (exemplars) rather than relying on an abstract prototype or representation. Under these models, specific instances are deemed more critical than prototypes, as exemplars are stored with their unique features and contexts [[session/dialog/sharegpt_TcUL15d_19.jsonl#L6-L7,L12-L15]].

## Decision-Making Heuristics and Biases [[session/dialog/sharegpt_TcUL15d_19.jsonl#L2-L3,L4-L11,L16-L17]]
- **Similarity and the Triangle Inequality**: The triangle inequality demonstrates that mathematical models of similarity judgments necessitate constraints. An example of such a constraint is attentional weighting, specifically as formulated in Tversky's contrast model [[session/dialog/sharegpt_TcUL15d_19.jsonl#L2-L3]].
- **Anchoring Effects**: Defined as the tendency to rely excessively on the initial piece of information (the anchor) when making subsequent judgments. In a case presented on 2023-05-23, Andrew told Christina that the meaning of life is 42; subsequently influenced by this anchor, Christina reported that her ideal number of children would be 38, illustrating how unrelated numerical anchors bias decision-making [[session/dialog/sharegpt_TcUL15d_19.jsonl#L4-L11]].
- **Attraction Effect**: Demonstrates how the introduction of a third "attractor" choice affects preference between two original choices with equal utility. In the reviewed scenario, the presence of an attractor choice that is inferior on all dimensions compared to its neighbor causes the neighbor to be selected [[session/dialog/sharegpt_TcUL15d_19.jsonl#L16-L17]].

## Neuroscience and Perceptual Learning [[session/dialog/sharegpt_TcUL15d_19.jsonl#L18-L27]]
- **Moravec’s Paradox**: Highlights a discrepancy in computational simulation difficulty. While tasks difficult for humans (like logical reasoning) are relatively easy for computers, tasks easy for humans (such as visual recognition and walking) are extremely difficult. Therefore, the most challenging parts of the mind to simulate computationally are perceptual systems (vision, locomotion) and physiological features (organs, muscles) [[session/dialog/sharegpt_TcUL15d_19.jsonl#L18-L19]].
- **Abstract Perceptual Learning**: Refers to the acquisition of abstract representations of perceptual stimuli, such as the descriptive properties of shapes. It encompasses the development of non-reducible representations that overlap with statistical learning concepts [[session/dialog/sharegpt_TcUL15d_19.jsonl#L20-L25]].
- **Synaptic Plasticity**: Terminology used to describe the mechanism of learning that results in structural modifications to the connections between neurons [[session/dialog/sharegpt_TcUL15d_19.jsonl#L26-L27]].

## Philosophy of Mind [[session/dialog/sharegpt_TcUL15d_19.jsonl#L28-L31]]
- **Classical Mind-Body Problem**: Analyzes distinctions regarding the causal relationship between brain processes and mental behaviors. In the reviewed assessment:
  - **Materialism**: Characterized as the stance that brain processes and mental processes function as two interacting physical substances [[session/dialog/sharegpt_TcUL15d_19.jsonl#L28-L29]].
  - **Dualism**: Defined as the perspective asserting that brain processes and mental behaviors are either not causally related or only very loosely causally related [[session/dialog/sharegpt_TcUL15d_19.jsonl#L29-L31]].
