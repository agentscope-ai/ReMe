---
description: 'Five on-the-go healthy snack recipes for fitness goals: Protein Energy
  Balls, Trail Mix, Apple Cinnamon Energy Bites, Greek Yogurt Parfait, and Banana
  Oat Bites. Includes storage tips (up to 5 days in airtight containers) and variation
  advice (adding protein powder, spices). Aligns with Sunday meal prep habit and Saturday
  morning Hip Hop Abs workout schedule.'
name: healthy-workout-snacks
session_id: answer_8f6b938d_2
source_conversation: '[[session/dialog/answer_8f6b938d_2.jsonl]]'
---

## Healthy On-The-Go Workout Snacks [[session/dialog/answer_8f6b938d_2.jsonl#L5-L8]]

### Recipes for Curbing Junk Food Cravings
Supporting fitness goals by replacing junk food with whole, unprocessed ingredients. 
- **Protein Energy Balls**
  - *Ingredients*: 2 cups rolled oats, 1 cup dried fruit (cranberries, raisins, or cherries), 1/2 cup nut butter (peanut butter or almond butter), 1/4 cup honey, 1 scoop vanilla protein powder, pinch of salt.
  - *Method*: Mix all ingredients in a bowl until a dough forms. Roll into small balls and refrigerate for 30 minutes.
  
- **Trail Mix**
  - *Ingredients*: 1 cup mixed nuts (almonds, cashews, and pecans), 1 cup dried fruit (cranberries, raisins, or cherries), 1/2 cup dark chocolate chips, 1/4 cup puffed rice cereal, pinch of sea salt.
  - *Method*: Mix all ingredients in a bowl and store in an airtight container.

- **Apple Cinnamon Energy Bites**
  - *Ingredients*: 2 cups rolled oats, 1 cup dried apple, 1/4 cup almond butter, 1/4 cup honey, 1/2 teaspoon cinnamon, pinch of salt.
  - *Method*: Mix all ingredients in a bowl until a dough forms. Roll into small balls and refrigerate for 30 minutes.

- **Greek Yogurt Parfait**
  - *Ingredients*: 1 cup Greek yogurt, 1/2 cup mixed berries (blueberries, strawberries, or raspberries), 1/4 cup granola, 1 tablespoon honey.
  - *Method*: Layer all ingredients in a container and refrigerate until ready to eat.

- **Banana Oat Bites**
  - *Ingredients*: 2 ripe bananas, 1/2 cup rolled oats, 1 tablespoon almond butter, 1 tablespoon honey, pinch of salt.
  - *Method*: Mash bananas in a bowl and mix with oats, almond butter, and honey until a dough forms. Roll into small balls and refrigerate for 30 minutes.

### Preparation Tips
- Use different types of nuts, seeds, or dried fruits to change up the flavor and texture.
- Add a scoop of protein powder to energy balls or bites for an extra boost.
- Experiment with different spices, such as cinnamon or nutmeg, to add flavor.
- Make a batch of snacks on the weekend and store them in airtight containers for up to 5 days.
- Practice portion control to support fitness goals.

### Fitness Context
- Sunday is established as the day for meal prepping and Sunday yoga classes.
- Saturdays are used for Hip Hop Abs class at 10:00 AM, which serves as a morning pump-up routine.
