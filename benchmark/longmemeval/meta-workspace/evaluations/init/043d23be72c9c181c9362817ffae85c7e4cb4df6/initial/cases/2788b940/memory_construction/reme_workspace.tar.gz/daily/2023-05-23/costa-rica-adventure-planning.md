---
description: 'Extraction of Costa Rica adventure travel recommendations including
  specific company suggestions for surfing, hiking, and combined trips. Includes work-exchange
  program options, user profile (completed Wahkeena Falls hike in Columbia River Gorge
  on 2023-05-23, enjoys Tonkatsu at Tonki restaurant in Tokyo), physical conditioning
  requirements for combination trips, comprehensive details on EcoAdventure International''s
  Surf and Turf program covering eco-lodges/boutique hotels (Lapa Rios Ecolodge, Hotel
  Punta Islita), meal plans featuring gallo pinto/empanadas/ceviche, airport transfers
  from SJO/LIR, full dietary accommodation policy, ISA/FCS certified instructors,
  and small group safety protocols. Next action: Book Surf and Turf trip with EcoAdventure
  International.'
name: costa-rica-adventure-planning
session_id: ff6e824b_1
source_conversation: '[[session/dialog/ff6e824b_1.jsonl]]'
---

# Costa Rica Adventure Travel Planning Guide

## Recommended Companies for Adventure Trips

### Surfing Providers
[[session/dialog/ff6e824b_1.jsonl#L1-L2]]
- **Costa Rica Surf Camp**: Offers surf lessons, guided surf tours, and surf camps in Tamarindo, Nosara, and other coastal towns.
- **Witch's Rock Surf Camp**: Based in Tamarindo; offers surf lessons, surf camps, and yoga retreats.
- **Pura Vida Adventures**: Offers surf and yoga retreats in Nosara, plus surf lessons and guided surf tours.

### Hiking Providers
- **Costa Rica Trek**: Offers guided hiking and trekking tours in various national parks including Corcovado and Los Quetzales.
- **Osa Aventuras**: Based in Puerto Jiménez; offers guided hiking and kayaking tours in Corcovado National Park and Osa Peninsula.
- **Tortuguero Expeditions**: Offers guided hiking and boat tours in Tortuguero National Park, accessible only by boat or plane.

### Combination Surf/Hiking Providers
- **EcoAdventure International**: Offers "Surf and Turf" trip combining surfing with hiking and exploring in Nicoya Peninsula.
- **Costa Rica Rios**: Offers "Surf and Hike" trip combining surfing with hiking and rafting in Central Pacific region.

## Work-Exchange Programs in Costa Runtime
[[session/dialog/ff6e824b_1.jsonl#L2]]
These programs offer room and board in exchange for volunteer work:
- **WWOOF Costa Runtime**: Network of organic farms and communities offering room and board for volunteer work.
- **HelpX Costa Runtime**: Platform connecting travelers with hosts for accommodation and meals in exchange for help with farming, childcare, or hospitality tasks.
- **Workaway Costa Runtime**: Similar to HelpX, offers a range of volunteer opportunities in exchange for accommodation and meals.
- **Surf and Work**: Program combining surfing with volunteer work such as teaching English or helping at a surf school.

## User Profile and Background

### Recent Activity
[[session/dialog/ff6e824b_1.jsonl#L1,L7]]
- On 2023-05-23, completed a day trip to Columbia River Gorge hiking to top of Wahkeena Falls, demonstrating readiness for challenging outdoor activities.

### Culinary Preferences
- Holds strong appreciation for culinary experiences including great food experiences on previous trips. Specifically mentions having excellent Tonkatsu at Tonki restaurant in Tokyo. Looking forward to trying Costa Rican cuisine (has not tried it yet). Heard great things about gallo pinto and empanadas.

### Current Intentions
- Plans to book trip with EcoAdventure International. Very excited about combination of surfing, hiking, and cultural experiences they offer. Ready to take next step and book trip.

## Physical Requirements for Combination Trips

### General Expectations
[[session/dialog/ff6e824b_1.jsonl#L4]]
To participate in combination surf and hike trip in Costa Rica:
- Must be in good physical condition comfortable with moderate exercise
- Need ability to paddle and swim in ocean
- Need ability to hike for several hours a day carrying daypack with water, snacks, essentials
- Good level of cardiovascular fitness, strength, flexibility required
- Medical conditions require doctor consultation before booking
- Must inform tour operator of any special needs or requirements

### Difficulty Levels - Surfing Component
- Most surf schools/camps cater to all levels from beginners to experienced
- Beginners start with lessons in calm waters learning basics: paddling, popping up, balancing
- Progression involves moving to more challenging waves, learning to read ocean, positioning, technique improvement
- Advanced options may include bigger waves, tricks, different breaks

### Difficulty Levels - Hiking Component
- Range from easy day hikes to more challenging multi-day treks
- Some involve well-maintained trails; others require rugged hiking with steep inclines, river crossings, dense jungle navigation
- Expect hiking several hours per day
- Some reaches high elevations requiring preparation for changing weather including rain and heat

### Questions to Ask Tour Operators
- What is difficulty level of surfing and hiking components?
- What is average daily hiking distance and elevation gain?
- What kind of physical conditioning is required for trip?
- Are there age or weight restrictions?
- What kind of support and guidance will be provided during trip?
- Are there opportunities for rest days or relaxation time?

## EcoAdventure International - Surf and Turf Trip Details

### Accommodations
[[session/dialog/ff6e824b_1.jsonl#L6-L8]]
**Types Used:**
- Mix of eco-lodges, boutique hotels, surf camps throughout trip
- Shared rooms or cabins with private bathrooms
- Amenities vary: pools, yoga decks, ocean views

**Location Strategy:**
- Strategically located near surfing and hiking spots minimizing travel time
- Variety includes beachfront properties, jungle settings, charming coastal towns

**Specific Property Examples:**
- **Lapa Rios Ecolodge**: Near Corcovado National Park; luxury rooms, pool, stunning surrounding rainforest views
- **Hotel Punta Islita**: Boutique hotel on Nicoya Peninsula; luxurious rooms, spa, private beach

**Eco-Lodge Philosophy:**
- Committed to sustainability, conservation, community engagement
- Often located within/near protected areas like national parks or wildlife refuges
- Use renewable energy sources, reduce waste, implement sustainable practices
- Minimize environmental impact, support local communities

**Boutique Hotels Characteristics:**
- Selected for unique character, comfort, location
- More luxurious feel with air conditioning, hot tubs, gourmet restaurants
- Located in coastal towns near surfing spots or scenic areas with easy trail access
- May offer spa treatments, yoga classes, surf lessons

### Meals and Dining
[[session/dialog/ff6e824b_1.jsonl#L6]]
**Cuisine Style:**
- Fusion of traditional Costa Rican cuisine with modern twists
- Fresh locally sourced ingredients whenever possible

**Daily Meal Structure:**
- Breakfast: gallo pinto (traditional Costa Rican dish), fruits, granola
- Lunches: sandwiches, salads, soups
- Dinners: three-course meals with seafood paella, grilled meats, vegetarian options
- Snacks and refreshments provided throughout day
- Opportunities to try local specialties like ceviche, empanadas

**Dietary Accommodations:**
[[session/dialog/ff6e824b_1.jsonl#L10]]
Company accommodates special requests ensuring everyone has great dining experience:
- **Vegetarian/Vegan Options**: Available for breakfast, lunch, dinner; coordinated with accommodations/local suppliers; communication with chefs/kitchen staff guaranteed
- **Gluten-Free Options**: Gluten-free bread, pasta, baked goods provided; work with local bakeries/suppliers to source gluten-free ingredients safely
- **Other Restrictions**: Dairy-free, nut-free, soy-free can be accommodated
- **Communication Protocol**: Must inform about dietary restrictions when booking; questions asked during booking process; direct contact encouraged for concerns

### Airport Transfers and Travel Arrangements
[[session/dialog/ff6e824b_1.jsonl#L6]]
- Airport transfers included from San José (SJO) or Liberia (LIR) airports to trip starting point
- Assistance arranging additional travel: domestic flights, shuttle services to/from other Costa Rica destinations
- International flights booked separately; company provides guidance on best arrival/departure dates
- Transportation between activities provided during trip

### Equipment and Logistics
- All necessary equipment for surfing, hiking, and activities provided (no personal gear needed)
- Experienced trip leaders and guides ensure safety and comfort throughout trip
- Company handles all logistics so guests focus on enjoying trip

### Surf Instructors and Guides Qualifications
[[session/dialog/ff6e824b_1.jsonl#L12]]
**Certifications and Training:**
- Certified by International Surfing Association (ISA) or Costa Rican Surf Federation (FCS)
- High standards of safety, instruction, environmental awareness maintained
- Many are lifeguards, first aid responders, or have certifications in water safety/rescue techniques

**Experience and Expertise:**
- Extensive experience teaching surf lessons to beginners and intermediate surfers
- Worked with guests of all ages and skill levels (children to seniors)
- Skilled at adapting instruction to individual needs and abilities
- Knowledgeable about local surf breaks, tides, ocean conditions

**Safety Protocols:**
- Safety prioritized above all else
- Trained to identify and manage risks
- Strict safety protocol for all surfing activities
- High-quality surf equipment used including soft-top surfboards and leashes to minimize injury risk

**Small Group Approach:**
- Small group sizes ensure personalized attention and instruction
- Allows immersive intimate experience
- Opportunities to ask questions, learn from locals, connect with fellow travelers

**Cultural Education Provided:**
- Guides knowledgeable beyond just surfing about local culture, history, environment
- Share insights about Costa Rica rich cultural heritage
- Topics include indigenous communities, colonial history, modern-day society

## Summary of Trip Value Proposition

EcoAdventure International reputation: Reputable company providing safe, fun, educational experiences. Excellent service and attention to detail. Company committed to inclusive enjoyable experience for all guests regardless of dietary needs.

Best peak destination challenge mentioned: Cerro Chirripó - highest peak in Costa Rica country.
