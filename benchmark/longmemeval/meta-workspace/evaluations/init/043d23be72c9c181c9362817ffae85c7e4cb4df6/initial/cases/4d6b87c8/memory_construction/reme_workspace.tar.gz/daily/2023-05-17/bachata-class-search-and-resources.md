---
description: Detailed extraction of a conversation regarding finding bachata dance
  classes, inquiring with salsa instructor Maria for recommendations, tracking three-month
  dance progress, preparing for a June 2023 studio showcase, and listing specific
  YouTube channels and online platforms for bachata tutorials.
name: bachata-class-search-and-resources
session_id: cffde796
source_conversation: '[[session/dialog/cffde796.jsonl]]'
---

## Searching for Bachata Classes & Instructor Recommendations [[session/dialog/cffde796.jsonl#L1-L5]]

- The participant initially searched for a quality dance studio in the city offering bachata classes
- The participant had already identified a preferred studio; that venue currently hosts the participant's salsa classes and additionally provides bachata class offerings
- The participant plans to inquire with salsa instructor Maria regarding her knowledge of competent bachata instructors or personal recommendations
- The inquiry with Maria will specifically occur during a private lesson scheduled for the week of 2023-05-17
- Asking Maria for recommendations provides multiple advantages: Maria understands the participant's learning style, ensures teaching-style compatibility, and possesses insider knowledge regarding instruction quality

## Dance Training Progress & Class Formats [[session/dialog/cffde796.jsonl#L7-L9]]

- The participant has attended dance classes at a local studio for approximately three months as of 2023-05-17
- Over the preceding several weeks leading up to 2023-05-17, the participant observed significant improvements in footwork execution and rhythmic precision
- The participant asked whether dance instructors commonly offer private lessons or group classes specialized in specific genres like salsa or bachata
- Private lessons deliver one-on-one instruction, customized scheduling aligned with individual goals, and accelerated skill development through targeted corrections
- Group classes facilitate social interaction, community building, high-energy motivation, and generally present a more budget-friendly alternative to private instruction

## Studio Showcase Preparation [[session/dialog/cffde796.jsonl#L11-L12]]

- The participant plans to request assistance from Maria to develop a choreographed routine intended for the studio's annual dance showcase, scheduled for June 2023
- Collaborating on a choreographed routine grants performance experience before an audience, supplies personalized technical feedback, allows creation of routines tailored to specific strengths, and fosters stronger bonds within the studio community
- Before submitting the request, the participant needs to evaluate available rehearsal time, honestly assess current skill readiness, and verify Maria's schedule availability

## Online Bachata Learning Resources [[session/dialog/cffde796.jsonl#L5-L7]]

- The participant requested recommendations for online platforms and YouTube channels suitable for bachata tutorials and general dance inspiration
- The assistant supplied the following curated list of online resources:
  - YouTube Channels: Bachata Addiction (focuses on technique, leading, and following); Korke Escalera (featuring instructor Korke Escalera offering tutorials, dance videos, and choreographies); Bachata Fusion (mixing bachata, salsa, and fusion styles); Tropical Gem (focusing on musicality and expression); Daniel and Desiree (specializing in technique and style across bachata, salsa, and cha cha cha)
  - Online Platforms & Schools: MasterClass (offering online courses taught by renowned instructors including Korke Escalera); Codarts (an online platform for classes, workshops, and courses); Bachata Dance Academy (a website for online classes and tutorials focusing on technique and leading/following mechanics); DanceWithMe (an online studio emphasizing technique and style)
  - Inspiration Sources: Bachata World Championship (professional dancer performances); Amsterdam Bachata Festival; Bachata Festival held in the Dominican Republic
- The participant stated consuming a substantial volume of dance videos online, specifically mentioning Juan's videos, which actively motivate increasing personal practice frequency
- A guideline states digital tutorials supplement but do not replace physical classes with qualified human instructors, because partner dancing requires live feedback and connection practice
