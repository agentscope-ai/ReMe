---
description: Records six historical fiction book recommendations (including author
  names and thematic summaries) similar to The Nightingale, culminating in the user's
  decision to read All the Light We Cannot See. Documents sleep-onset difficulties
  beginning 3 weeks prior to this session, alongside specific behavioral interventions
  implemented to improve rest—including shifting bed preparation to 10:00–10:30 PM,
  eliminating 4:00–5:00 PM afternoon caffeine intake, and adopting a mandatory 20–30
  minute nightly reading habit using fiction to facilitate relaxation and improve
  morning alertness.
name: book-recommendations-and-sleep-routine
session_id: 8e6bac11
source_conversation: '[[session/dialog/8e6bac11.jsonl]]'
---

## Book Recommendations
[[session/dialog/8e6bac11.jsonl#L1-L3]]
- Six historical fiction novels recommended as alternatives to The Nightingale by Kristin Hannah:
  - All the Light We Cannot See by Anthony Doerr: A Pulitzer Prize-winning novel set during WWII tracking a blind French girl and a German boy.
  - The Alice Network by Kate Quinn: Explores a socialite and a spy during WWI, emphasizing female friendship and wartime survival.
  - The Women in the Castle by Jessica Shattuck: Follows three women processing WWII trauma and attempting to rebuild their lives in the war's aftermath.
  - Those Who Save Us by Jenna Blum: Examines a mother-daughter dynamic throughout WWII and its repercussions.
  - The Lost Girls of Paris by Pam Jenoff: Set in 1946, centers on a widow uncovering photographs documenting female resistance fighters.
  - The Guernsey Literary and Potato Peel Pie Society by Mary Ann Shaffer: An epistolary work depicting islander life on Guernsey following WWII occupation.
- The user decided to read All the Light We Cannot See by Anthony Doerr next, noting positive prior hearsay about the title.

## Bedtime Routine & Sleep Adjustments
[[session/dialog/8e6bac11.jsonl#L5-L10]]
- Difficulty falling asleep began approximately 3 weeks prior to 2023-02-15.
- Schedule modification: shifting evening preparation time to begin between 10:00 PM and 10:30 PM.
- Dietary change: completely discontinued afternoon caffeine (previously consumed coffee or tea between 4:00 PM and 5:00 PM).
- Behavioral addition: established a nightly pre-sleep reading block lasting 20 to 30 minutes.
- Genre preference for sleep aid: mixes fiction and non-fiction, but finds fiction more effective for mental de-stressing due to narrative immersion.
- Documented results: earlier wind-down time, caffeine elimination, and the nightly reading habit have successfully improved sleep onset latency and resulted in waking up with greater morning alertness.
